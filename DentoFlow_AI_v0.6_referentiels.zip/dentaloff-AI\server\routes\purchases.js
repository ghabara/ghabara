const express = require('express');
const { pool } = require('../db');
const { auth, adminOnly } = require('../middleware/auth');
const {
  decimalOrNull,
  recordInventoryMovement,
  refreshAiAlerts,
  withTransaction,
} = require('../services/inventoryService');

const router = express.Router();
const asyncHandler = fn => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

router.get('/', auth, adminOnly, asyncHandler(async (_req, res) => {
  const [rows] = await pool.query(`
    SELECT ip.*, p.name AS product_name, p.tracking_unit
    FROM inventory_purchases ip
    JOIN inventory_products p ON p.id = ip.product_id
    ORDER BY ip.purchase_date DESC, ip.id DESC
    LIMIT 300
  `);
  res.json(rows);
}));

router.post('/', auth, adminOnly, asyncHandler(async (req, res) => {
  const productId = Number(req.body.product_id);
  const quantity = decimalOrNull(req.body.quantity_purchased);
  const totalPrice = decimalOrNull(req.body.total_price_tnd);
  const packagePrice = decimalOrNull(req.body.package_price_tnd);
  const supplier = String(req.body.supplier || '').trim();
  if (!productId || !supplier || quantity === null || quantity <= 0 || totalPrice === null || totalPrice < 0) {
    return res.status(400).json({ error: 'Fournisseur, produit, quantite et prix total sont requis.' });
  }
  if (packagePrice !== null && packagePrice < 0) {
    return res.status(400).json({ error: 'Prix du conditionnement invalide.' });
  }

  const result = await withTransaction(pool, async (conn) => {
    const [[product]] = await conn.query('SELECT * FROM inventory_products WHERE id = ? FOR UPDATE', [productId]);
    if (!product) throw new Error('Produit introuvable.');
    const stockBefore = decimalOrNull(product.current_stock) ?? 0;
    const stockAfter = stockBefore + quantity;
    const updatePackagePrice = !!req.body.updated_package_price || !!req.body.update_package_price;

    const [purchase] = await conn.query(
      `INSERT INTO inventory_purchases
         (purchase_date, supplier, product_id, quantity_purchased, unit, total_price_tnd,
          package_price_tnd, invoice_number, lot_number, expiration_date, comment,
          updated_package_price, stock_after)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        req.body.purchase_date || new Date().toISOString().slice(0, 10),
        supplier,
        productId,
        quantity,
        product.tracking_unit,
        totalPrice,
        packagePrice,
        String(req.body.invoice_number || '').trim() || null,
        String(req.body.lot_number || '').trim() || null,
        req.body.expiration_date || null,
        String(req.body.comment || '').trim() || null,
        updatePackagePrice ? 1 : 0,
        stockAfter,
      ]
    );

    const fields = ['current_stock = ?', 'supplier_alias = ?'];
    const params = [stockAfter, supplier];
    if (updatePackagePrice && packagePrice !== null) {
      fields.push('package_price_tnd = ?');
      params.push(packagePrice);
    }
    if (req.body.lot_number) {
      fields.push('lot_number = ?');
      params.push(String(req.body.lot_number).trim());
    }
    if (req.body.expiration_date) {
      fields.push('expiration_date = ?');
      params.push(req.body.expiration_date);
    }
    params.push(productId);
    await conn.query(`UPDATE inventory_products SET ${fields.join(', ')} WHERE id = ?`, params);

    await recordInventoryMovement(conn, {
      product_id: productId,
      product_name_snapshot: product.name,
      quantity,
      unit: product.tracking_unit,
      direction: 'IN',
      origin: 'PURCHASE',
      origin_id: purchase.insertId,
      stock_before: stockBefore,
      stock_after: stockAfter,
      created_by: req.user?.username || req.user?.role || null,
    });

    if (req.body.lot_number || req.body.expiration_date) {
      await conn.query(
        `INSERT INTO inventory_lots
           (product_id, lot_number, quantity_current, quantity_initial, expiration_date,
            purchase_id, storage_location, comment)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          productId,
          String(req.body.lot_number || `ACHAT-${purchase.insertId}`).trim(),
          quantity,
          quantity,
          req.body.expiration_date || null,
          purchase.insertId,
          String(req.body.storage_location || '').trim() || product.storage_location || null,
          String(req.body.comment || '').trim() || 'Lot cree depuis achat',
        ]
      );
    }

    return {
      purchase_id: purchase.insertId,
      product_id: productId,
      product_name: product.name,
      stock_before: stockBefore,
      stock_after: stockAfter,
      unit: product.tracking_unit,
    };
  });

  await refreshAiAlerts(pool);
  res.status(201).json(result);
}));

router.use((err, _req, res, _next) => {
  res.status(400).json({ error: err.message || 'Erreur achats.' });
});

module.exports = router;
