import { useMemo, useState } from 'react';
import DentalLegend from './DentalLegend.jsx';
import DentalTooth from './DentalTooth.jsx';
import DentalToothEditor from './DentalToothEditor.jsx';
import { getToothMeta, permanentRows, temporaryRows, toothStatuses } from './dentalChartConfig';
import './dentalChart.css';

const statusMap = Object.fromEntries(toothStatuses.map(([key, label, color]) => [key, { label, color }]));

export default function DentalChart() {
  const [mode, setMode] = useState('permanent');
  const rows = mode === 'permanent' ? permanentRows : temporaryRows;
  const [selected, setSelected] = useState(rows[0][0]);
  const [draft, setDraft] = useState({});

  const selectedTooth = useMemo(() => {
    const meta = getToothMeta(selected);
    return { status: 'healthy', surfaces: [], notes: '', ...meta, ...(draft[selected] || {}) };
  }, [draft, selected]);

  const updateSelected = (next) => setDraft(current => ({ ...current, [selected]: next }));

  return (
    <div className="dental-chart-shell">
      <div className="dental-chart-toolbar">
        <div>
          <span className="admin-eyebrow">Odontogramme SVG</span>
          <h3>Selection clinique en brouillon</h3>
        </div>
        <div className="segmented-control" role="group" aria-label="Dentition">
          <button type="button" className={mode === 'permanent' ? 'active' : ''} onClick={() => { setMode('permanent'); setSelected(18); }}>Permanente</button>
          <button type="button" className={mode === 'temporary' ? 'active' : ''} onClick={() => { setMode('temporary'); setSelected(55); }}>Temporaire</button>
        </div>
      </div>
      <div className="dental-chart-grid">
        <div className="dental-arches">
          {rows.map((row, index) => (
            <div className="dental-row" key={`${mode}-${index}`}>
              {row.map(number => {
                const status = draft[number]?.status || 'healthy';
                return (
                  <DentalTooth
                    key={number}
                    number={number}
                    active={selected === number}
                    color={statusMap[status]?.color || statusMap.healthy.color}
                    statusLabel={statusMap[status]?.label || 'Saine'}
                    onSelect={setSelected}
                  />
                );
              })}
            </div>
          ))}
          <DentalLegend />
        </div>
        <DentalToothEditor tooth={selectedTooth} selectedNumber={selected} onChange={updateSelected} />
      </div>
    </div>
  );
}
