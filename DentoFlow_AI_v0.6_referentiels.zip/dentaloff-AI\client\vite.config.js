import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      // Tout ce qui commence par /api ou /uploads est redirigé vers Express
      '/api': 'http://localhost:4000',
    },
  },
});
