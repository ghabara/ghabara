export default function BrandLogo({ compact = false, className = '' }) {
  const classes = ['brand-logo', compact ? 'brand-logo--compact' : '', className].filter(Boolean).join(' ');

  return (
    <div className={classes} aria-label="DentoFlow AI">
      <img
        src="/branding/dentoflow-ai-logo.png"
        alt="DentoFlow AI"
        className="brand-logo__image"
      />
    </div>
  );
}
