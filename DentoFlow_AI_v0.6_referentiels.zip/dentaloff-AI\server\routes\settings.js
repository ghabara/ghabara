const express = require('express');
const { pool } = require('../db');
const { auth, adminOnly } = require('../middleware/auth');
const router = express.Router();

// ── SERVICES ────────────────────────────────────────────────
router.get('/services', async (req, res) => {
  const [rows] = await pool.query('SELECT * FROM services ORDER BY id');
  res.json(rows);
});
router.post('/services', auth, adminOnly, async (req, res) => {
  const { ico, name, prix, descr } = req.body;
  if (!name) return res.status(400).json({ error: 'Nom requis.' });
  await pool.query('INSERT INTO services (ico, name, prix, descr) VALUES (?,?,?,?)',
    [ico || '🦷', name, prix || '', descr || '']);
  const [rows] = await pool.query('SELECT * FROM services ORDER BY id');
  res.status(201).json(rows);
});
router.put('/services/:id', auth, adminOnly, async (req, res) => {
  const { ico, name, prix, descr } = req.body;
  const [[old]] = await pool.query('SELECT name FROM services WHERE id = ?', [req.params.id]);
  await pool.query('UPDATE services SET ico=?, name=?, prix=?, descr=? WHERE id=?',
    [ico, name, prix, descr, req.params.id]);
  // Le lien service↔consommables se fait par le NOM : on propage le renommage
  if (old && old.name && old.name !== name) {
    try { await pool.query('UPDATE service_consommables SET service = ? WHERE service = ?', [name, old.name]); }
    catch (e) { /* table stock absente : sans effet */ }
  }
  const [rows] = await pool.query('SELECT * FROM services ORDER BY id');
  res.json(rows);
});
router.delete('/services/:id', auth, adminOnly, async (req, res) => {
  await pool.query('DELETE FROM services WHERE id = ?', [req.params.id]);
  const [rows] = await pool.query('SELECT * FROM services ORDER BY id');
  res.json(rows);
});

// ── HORAIRES ────────────────────────────────────────────────
router.get('/horaires', async (req, res) => {
  const [rows] = await pool.query('SELECT * FROM horaires ORDER BY id');
  res.json(rows);
});
router.put('/horaires', auth, adminOnly, async (req, res) => {
  const { horaires } = req.body; // tableau
  for (const h of horaires) {
    await pool.query('UPDATE horaires SET ouverture=?, fermeture=?, ferme=? WHERE id=?',
      [h.ouverture, h.fermeture, h.ferme ? 1 : 0, h.id]);
  }
  const [rows] = await pool.query('SELECT * FROM horaires ORDER BY id');
  res.json(rows);
});

// ── INFOS CABINET ───────────────────────────────────────────
router.get('/info', async (req, res) => {
  const [[row]] = await pool.query('SELECT * FROM cabinet_info WHERE id = 1');
  res.json(row || {});
});
router.put('/info', auth, adminOnly, async (req, res) => {
  const { name, doctor, tel, email, addr } = req.body;
  await pool.query(
    `INSERT INTO cabinet_info (id, name, doctor, tel, email, addr) VALUES (1,?,?,?,?,?)
     ON DUPLICATE KEY UPDATE name=?, doctor=?, tel=?, email=?, addr=?`,
    [name, doctor, tel, email, addr, name, doctor, tel, email, addr]
  );
  const [[row]] = await pool.query('SELECT * FROM cabinet_info WHERE id = 1');
  res.json(row);
});

// ── NOTES PATIENTS ──────────────────────────────────────────
router.get('/notes', auth, adminOnly, async (req, res) => {
  const [rows] = await pool.query('SELECT * FROM notes ORDER BY created_at DESC');
  res.json(rows);
});
router.get('/notes/me', auth, async (req, res) => {
  const [rows] = await pool.query('SELECT * FROM notes WHERE id_patient = ? ORDER BY created_at DESC', [req.user.id_patient]);
  res.json(rows);
});
router.post('/notes', auth, adminOnly, async (req, res) => {
  const { id_patient, date, texte } = req.body;
  if (!id_patient || !texte) return res.status(400).json({ error: 'Patient et note requis.' });
  await pool.query('INSERT INTO notes (id_patient, date, texte) VALUES (?,?,?)',
    [id_patient, date || new Date().toISOString().slice(0, 10), texte]);
  const [rows] = await pool.query('SELECT * FROM notes ORDER BY created_at DESC');
  res.status(201).json(rows);
});

module.exports = router;
