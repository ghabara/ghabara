const { logAudit } = require('./auditService');

const TARGET_COUNTRY = 'Tunisie';
const TARGET_CURRENCY = 'TND';
const SOURCE_NAME = 'Backfill controle prix indicatif PDF';
const SOURCE_FILE = 'Prix moyens des produits dentaires dans le monde.pdf; Rapport consommation produits dentaires France.pdf';

const supplementalPriceCandidates = [
  ['Acide orthophosphorique gel bleu', 'Restauratrice', 'seringue / gel', 15, 25, 45, 'Gel de mordancage, observabilite fournisseur faible.'],
  ['Adhesif / bonding', 'Restauratrice', 'flacon 5 ml', 75, 120, 210, 'Equivalent adhesif universel / bonding.'],
  ['Aiguille dentaire', 'Anesthesie', 'boite 100', 16, 28, 65, 'Equivalent aiguilles dentaires courtes/longues.'],
  ['Ciment de scellement', 'Collage', 'kit / capsule', 55, 90, 180, 'Equivalent ciment verre ionomere / scellement.'],
  ['Papier absorbant endo', 'Endodontie', 'boite', 8, 18, 40, 'Consommable endodontie a prix indicatif public.'],
  ['Gutta percha', 'Endodontie', 'boite', 14, 28, 65, 'Equivalent pointes gutta-percha.'],
  ['Granulotec', 'Endodontie', 'boite / seringue', 35, 75, 160, 'Equivalent intrant endodontique specialise.'],
  ['Alginate empreinte 450 g', 'Empreinte', 'sachet 450 g', 18, 34, 75, 'Equivalent alginate empreinte.'],
  ['Silicone empreinte cartouche 50 ml', 'Empreinte', 'cartouche 50 ml', 55, 100, 220, 'Equivalent silicone VPS.'],
  ['Composite seringue 3 g reference France', 'Restauratrice', 'seringue 3-4 g', 45, 75, 140, 'Equivalent composite restauration.'],
  ['Composite compule 0.2 g', 'Restauratrice', 'compule', 5, 12, 28, 'Equivalent composite en compule unitaire.'],
  ['Ciment resine capsule 16 g', 'Collage', 'capsule / seringue', 70, 130, 270, 'Equivalent ciment resine.'],
  ['Adhesif dentaire flacon 5 ml', 'Restauratrice', 'flacon 5 ml', 75, 120, 210, 'Equivalent adhesif universel.'],
  ['Embout aspiration jetable', 'Usage unique', 'sachet / carton', 18, 38, 85, 'Consommable aspiration usage unique.'],
  ['Masque chirurgical', 'Usage unique', 'boite 50', 8, 14, 32, 'Equivalent masques chirurgicaux.'],
  ['Sachet sterilisation autoclavable 5x20', 'Sterilisation', 'lot 1000', 55, 95, 180, 'Sachets sterilisation autoclavables.'],
  ['Solution desinfectante instrumentation 5 L', 'Sterilisation', 'bidon 5 L', 45, 95, 190, 'Desinfectant instrumentation.'],
  ['Coton salivaire / rouleau coton', 'Usage unique', 'sachet / rouleaux', 12, 28, 65, 'Equivalent coton salivaire / rouleaux.'],
];

function normalizeName(value) {
  return String(value || '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, ' ')
    .trim();
}

function tokenScore(product, reference) {
  const productName = normalizeName(product.name);
  const refName = normalizeName(reference.candidate_name || reference.canonical_name);
  if (!productName || !refName) return 0;
  if (productName === refName) return 100;
  if (productName.includes(refName) || refName.includes(productName)) return 80;

  const productTokens = new Set(productName.split(' ').filter(token => token.length > 2));
  const refTokens = new Set(refName.split(' ').filter(token => token.length > 2));
  let common = 0;
  for (const token of productTokens) if (refTokens.has(token)) common += 1;
  const denominator = Math.max(productTokens.size, refTokens.size, 1);
  let score = (common / denominator) * 70;

  const productCategory = normalizeName(`${product.category || ''} ${product.sub_category || ''}`);
  const refCategory = normalizeName(`${reference.category || ''} ${reference.subcategory || ''}`);
  if (productCategory && refCategory && (productCategory.includes(refCategory) || refCategory.includes(productCategory))) score += 10;
  return score;
}

function priceToTnd(reference) {
  if (reference.currency === TARGET_CURRENCY) {
    return {
      min: reference.price_min,
      avg: reference.price_avg,
      max: reference.price_max,
    };
  }
  if (reference.price_usd) {
    const usdToTnd = 3.05;
    const avg = Number(reference.price_usd) * usdToTnd;
    const ratioMin = reference.price_avg ? Number(reference.price_min || reference.price_avg) / Number(reference.price_avg) : 0.7;
    const ratioMax = reference.price_avg ? Number(reference.price_max || reference.price_avg) / Number(reference.price_avg) : 1.4;
    return {
      min: Number((avg * ratioMin).toFixed(3)),
      avg: Number(avg.toFixed(3)),
      max: Number((avg * ratioMax).toFixed(3)),
    };
  }
  return { min: null, avg: null, max: null };
}

async function ensureSupplementalReferenceRows(db) {
  for (const [name, category, unit, min, avg, max, note] of supplementalPriceCandidates) {
    await db.query(
      `INSERT INTO international_price_references
         (entity_type, candidate_name, category, country, currency, price_min, price_avg, price_max, price_usd,
          unit, source_name, source_file, source_page, observed_at, effective_date, confidence_score, validation_status)
       VALUES ('cabinet_consumable', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'backfill', NOW(), CURDATE(), 0.62, 'candidate')
       ON DUPLICATE KEY UPDATE
         price_min = IF(validation_status = 'validated', price_min, VALUES(price_min)),
         price_avg = IF(validation_status = 'validated', price_avg, VALUES(price_avg)),
         price_max = IF(validation_status = 'validated', price_max, VALUES(price_max)),
         price_usd = IF(validation_status = 'validated', price_usd, VALUES(price_usd)),
         source_name = VALUES(source_name),
         source_file = VALUES(source_file),
         confidence_score = GREATEST(confidence_score, VALUES(confidence_score))`,
      [name, category, TARGET_COUNTRY, TARGET_CURRENCY, min, avg, max, Number((avg / 3.05).toFixed(3)), unit, SOURCE_NAME, SOURCE_FILE]
    );
    await db.query(
      `INSERT INTO reference_product_candidates
         (source_table, source_id, candidate_name, category, context_type, proposal_json, status, created_by)
       SELECT 'international_price_references', id, candidate_name, category, 'CABINET',
              JSON_OBJECT('name', candidate_name, 'category', category, 'reference_price', price_avg, 'currency', currency, 'note', ?),
              'candidate', 'system-backfill'
       FROM international_price_references
       WHERE candidate_name = ? AND country = ? AND currency = ? AND source_name = ?
       ON DUPLICATE KEY UPDATE proposal_json = VALUES(proposal_json)`,
      [note, name, TARGET_COUNTRY, TARGET_CURRENCY, SOURCE_NAME]
    );
  }
}

async function getMissingRealPriceProducts(db) {
  const [rows] = await db.query(
    `SELECT *
     FROM inventory_products
     WHERE is_active = 1
       AND (package_price_tnd IS NULL OR package_price_tnd <= 0 OR package_quantity IS NULL OR package_quantity <= 0)
     ORDER BY id`
  );
  return rows;
}

async function fetchReferenceRows(db) {
  const [internationalRows] = await db.query(
    `SELECT *
     FROM international_price_references
     WHERE validation_status IN ('candidate','validated')
       AND price_avg IS NOT NULL
     ORDER BY
       CASE country WHEN 'Tunisie' THEN 0 WHEN 'France' THEN 1 ELSE 2 END,
       CASE currency WHEN 'TND' THEN 0 WHEN 'EUR' THEN 1 WHEN 'USD' THEN 2 ELSE 3 END,
       confidence_score DESC`
  );
  const [labRows] = await db.query(
    `SELECT id, canonical_name AS candidate_name, category, subcategory, price_min, ((price_min + price_max) / 2) AS price_avg,
            price_max, price_currency AS currency, NULL AS price_usd, source_name, source_file
     FROM lab_consumable_reference
     WHERE validation_status IN ('candidate','validated')
       AND price_min IS NOT NULL
       AND price_max IS NOT NULL`
  );
  return [
    ...internationalRows.map(row => ({ ...row, source_table: 'international_price_references' })),
    ...labRows.map(row => ({ ...row, source_table: 'lab_consumable_reference' })),
  ];
}

function findBestReference(product, references) {
  let best = null;
  for (const reference of references) {
    const score = tokenScore(product, reference);
    if (score < 45) continue;
    const countryBonus = reference.country === TARGET_COUNTRY ? 8 : 0;
    const sourceBonus = reference.source_name === SOURCE_NAME ? 20 : 0;
    const total = score + countryBonus + sourceBonus + Number(reference.confidence_score || 0);
    if (!best || total > best.total) best = { reference, total, score };
  }
  return best;
}

async function backfillReferencePrices(db, req) {
  await ensureSupplementalReferenceRows(db);
  const products = await getMissingRealPriceProducts(db);
  const references = await fetchReferenceRows(db);
  const summary = {
    found: products.length,
    updated: 0,
    remaining_without_reference: 0,
    skipped_real_price: 0,
    candidates: [],
    remaining: [],
  };

  for (const product of products) {
    if (Number(product.package_price_tnd || 0) > 0 && Number(product.is_real_price || 0) === 1) {
      summary.skipped_real_price += 1;
      continue;
    }
    const best = findBestReference(product, references);
    if (!best) {
      summary.remaining_without_reference += 1;
      summary.remaining.push({ id: product.id, name: product.name });
      continue;
    }
    const ref = best.reference;
    const tnd = priceToTnd(ref);
    await db.query(
      `UPDATE inventory_products
       SET reference_price_min = ?,
           reference_price_avg = ?,
           reference_price_max = ?,
           reference_price_tnd_min = ?,
           reference_price_tnd_avg = ?,
           reference_price_tnd_max = ?,
           reference_currency = ?,
           price_source = ?,
           price_source_table = ?,
           price_source_id = ?,
           price_validation_status = 'candidate',
           is_real_price = IF(package_price_tnd IS NOT NULL AND package_price_tnd > 0, 1, is_real_price),
           reference_price_note = ?
       WHERE id = ?
         AND (package_price_tnd IS NULL OR package_price_tnd <= 0)
         AND price_validation_status <> 'validated'`,
      [
        ref.price_min,
        ref.price_avg,
        ref.price_max,
        tnd.min,
        tnd.avg,
        tnd.max,
        ref.currency,
        ref.source_name || SOURCE_NAME,
        ref.source_table,
        ref.id,
        `Prix indicatif candidat, non valide fournisseur. Score rapprochement ${best.score.toFixed(1)}.`,
        product.id,
      ]
    );
    summary.updated += 1;
    summary.candidates.push({
      id: product.id,
      name: product.name,
      reference: ref.candidate_name,
      source: ref.source_name || SOURCE_NAME,
      price_avg: ref.price_avg,
      currency: ref.currency,
      price_tnd_avg: tnd.avg,
    });
  }

  await logAudit(db, req, {
    action: 'INVENTORY_REFERENCE_PRICE_BACKFILL',
    entity_type: 'inventory_products',
    details: {
      found: summary.found,
      updated: summary.updated,
      remaining_without_reference: summary.remaining_without_reference,
    },
  });
  return summary;
}

async function validateReferencePrice(db, productId, req) {
  const [[product]] = await db.query('SELECT * FROM inventory_products WHERE id = ? AND is_active = 1', [productId]);
  if (!product) return null;
  if (Number(product.package_price_tnd || 0) > 0 && Number(product.is_real_price || 0) === 1) {
    throw new Error('Un prix reel est deja renseigne. Validation refusee pour eviter un ecrasement.');
  }
  if (!product.reference_price_tnd_avg || Number(product.reference_price_tnd_avg) <= 0) {
    throw new Error('Aucun prix indicatif TND disponible pour ce produit.');
  }
  await db.query(
    `UPDATE inventory_products
     SET package_price_tnd = ?,
         price_validation_status = 'validated',
         is_real_price = 1,
         price_validated_by = ?,
         price_validated_at = NOW(),
         source_type = CASE
           WHEN source_type LIKE '%Prix indicatif valide%' THEN source_type
           ELSE CONCAT(source_type, ' + Prix indicatif valide')
         END
     WHERE id = ?
       AND (package_price_tnd IS NULL OR package_price_tnd <= 0)`,
    [product.reference_price_tnd_avg, req?.user?.username || req?.user?.role || 'admin', productId]
  );
  await logAudit(db, req, {
    action: 'INVENTORY_REFERENCE_PRICE_VALIDATE',
    entity_type: 'inventory_product',
    entity_id: productId,
    details: {
      product: product.name,
      package_price_tnd: product.reference_price_tnd_avg,
      source: product.price_source,
    },
  });
  const [[updated]] = await db.query('SELECT * FROM inventory_products WHERE id = ?', [productId]);
  return updated;
}

module.exports = {
  backfillReferencePrices,
  getMissingRealPriceProducts,
  validateReferencePrice,
};
