﻿# RAPPORT_HARMONISATION_CODEX.md

Phrase cle appliquee :

```text
Ne refais pas une integration brute. Fais une harmonisation intelligente avec l'ancien code : audite d'abord, etends l'existant, evite les doublons, cree des conflits a valider, garde la compatibilite, teste chaque etape et ne casse jamais le MVP fonctionnel.
```

## 1. Resume de l'audit initial

Le projet audite est bien `DentoFlow AI`, avec l'architecture existante conservee :

- `client/` : React / Vite.
- `server/` : Express.js.
- `database/` : MySQL / MariaDB.

La base n'a pas ete consideree comme vide. Les modules existants patients, rendez-vous, dossiers, documents, Stock AI, recettes par acte, actes realises, achats, mouvements, alertes, laboratoire, roles, audit logs, plans de traitement et pilotage local ont ete conserves.

Etat final releve sur la base locale `dentaloff_ai` :

- 31 alias de reference.
- 3 mappings en attente de revue.
- 6 conflits en attente de validation humaine.
- 22 produits Stock AI actifs.
- 2 produits doublons desactives mais conserves.
- 19 recettes actives.
- 0 patient modifie, 0 RDV modifie, 1 acte realise conserve, 1 mouvement de stock conserve.

## 2. Tables existantes detectees

Tables detectees dans la base locale :

```text
act_recipes, admins, ai_alerts, audit_logs, brand_aliases, cabinet_info,
clinical_acts, commercial_equivalences, consumption_logs, documents,
documents_index, dossiers, horaires, inventory_lots, inventory_movements,
inventory_products, inventory_purchases, lab_case_events, lab_cases,
lab_consumption_logs, lab_recipes, lab_steps, mouvements, notes, ordonnances,
patients, performed_acts, produits, recipe_versions, reference_aliases,
reference_conflicts, reference_consumption_standards, reference_import_logs,
reference_mapping_review, reference_market_indicators, reference_sources,
rendez_vous, reservations, service_consommables, services, supplier_aliases,
treatment_plan_items, treatment_plans
```

## 3. Routes existantes detectees

Routes montees dans `server/index.js` :

```text
/api
/api/patients
/api/dossiers
/api/rdv
/api/inventory
/api/clinical-acts
/api/recipes
/api/performed-acts
/api/purchases
/api/shopping-list
/api/ai
/api/lab
/api/treatment-plans
/api/security
/api/pilotage
/api/reference-harmonization
```

Fichiers de routes detectes :

```text
ai.js, auth.js, clinicalActs.js, dossiers.js, inventory.js, lab.js,
patients.js, performedActs.js, pilotage.js, purchases.js, rdv.js,
recipes.js, referenceHarmonization.js, security.js, settings.js,
shoppingList.js, stock.js, treatmentPlans.js
```

## 4. Composants React existants detectes

Fichiers React et frontend detectes :

```text
client/src/App.jsx
client/src/main.jsx
client/src/api.js
client/src/ErrorBoundary.jsx
client/src/pages/Admin.jsx
client/src/pages/Home.jsx
client/src/pages/Login.jsx
client/src/pages/Profil.jsx
client/src/pages/Rdv.jsx
client/src/pages/Register.jsx
client/src/pages/StockAi.jsx
client/src/styles/theme.css
client/src/styles/public.css
```

Aucun dossier `client/src/components` separe n'est present dans cette version ; les panneaux admin sont integres principalement dans `Admin.jsx`.

## 5. Ancien code conserve

Le code utile existant a ete conserve :

- Routes historiques `stock.js`, `inventory.js`, `recipes.js`, `performedActs.js`, `purchases.js`, `shoppingList.js`.
- Tables historiques `produits`, `mouvements`, `services`, `service_consommables`.
- Tables Stock AI principales `inventory_products`, `act_recipes`, `clinical_acts`, `inventory_movements`, `inventory_lots`, `inventory_purchases`.
- Donnees sensibles et historiques : patients, rendez-vous, actes realises, mouvements de stock, recettes actives.
- Scripts et migrations deja presents : `dentaloff_ai.sql`, `stock_ai_migration.sql`, `pilotage_intelligent_migration.sql`, `rapport_france_consumption_seed.sql`.

## 6. Ancien code masque ou remplace

Aucune suppression brutale de route ou table n'a ete faite.

Les anciens libelles interdits fournis dans l'injonction maitre ne sont pas visibles dans le code audite hors dependances et builds.

Le module Stock AI reste le module principal pour la chaine :

```text
Produit -> recette par acte -> acte realise -> consommation -> cout matiere -> mouvement -> lots/peremption -> alertes -> liste d'achat -> pilotage IA local
```

Les doublons techniques de produits detectes ont ete desactives seulement apres transfert compatible des recettes. Ils n'ont pas ete supprimes physiquement.

## 7. Nouvelles tables creees

La couche d'harmonisation utilise ou cree les tables suivantes :

- `reference_sources`
- `reference_aliases`
- `reference_conflicts`
- `reference_import_logs`
- `reference_mapping_review`
- `brand_aliases`
- `supplier_aliases`
- `commercial_equivalences`
- `recipe_versions`

Les migrations utilisent `CREATE TABLE IF NOT EXISTS` et des ajouts de colonnes idempotents.

## 8. Tables enrichies

Tables enrichies ou completees :

- `act_recipes` : source, version, validation, bornes min/max, perte, obligation.
- `reference_consumption_standards` : tracabilite source et rattachement aux references.
- `inventory_products` : harmonisation par alias, detection de doublons, conservation active/inactive.
- `clinical_acts` : alias d'actes et rattachement aux standards de consommation.
- `audit_logs` : decisions humaines sur conflits et mappings.

## 9. Routes ajoutees

Route ajoutee pour l'harmonisation :

```text
/api/reference-harmonization
```

Endpoints disponibles :

```text
GET /api/reference-harmonization
POST /api/reference-harmonization/run
PATCH /api/reference-harmonization/conflicts/:id
PATCH /api/reference-harmonization/mappings/:id
```

Les actions de validation restent protegees par authentification et role docteur/admin.

## 10. Fichiers modifies

Fichiers ajoutes ou modifies pour cette harmonisation :

- `database/reference_harmonization_migration.sql`
- `server/services/referenceHarmonizationService.js`
- `server/scripts/harmonizeReferenceCatalogs.js`
- `server/routes/referenceHarmonization.js`
- `server/index.js`
- `server/package.json`
- `client/src/pages/Admin.jsx`
- `README.md`
- `RAPPORT_CODEX_PILOTAGE_INTELLIGENT.md`
- `RAPPORT_HARMONISATION_REFERENTIELS.md`
- `RAPPORT_HARMONISATION_CODEX.md`

## 11. Doublons detectes

Doublons probables signales dans `reference_mapping_review` :

- `Composite seringue 3 g reference France` -> `Resine / composite A2`, score 0.8800.
- `Ciment resine capsule 16 g` -> `Ciment de scellement`, score 0.8600.
- `Adhesif dentaire flacon 5 ml` -> `Adhesif / bonding`, score 0.7200.

Deux doublons compatibles ont ete desactives apres transfert de recettes, sans suppression physique :

- `Composite seringue 3 g reference France`.
- `Ciment resine capsule 16 g`.

## 12. Conflits crees a validation humaine

Conflits en attente :

- `act_recipe #1 / quantity_per_act` : 0.4000 -> 0.3000.
- `consumable #3 / tracking_unit` : g -> ml, severite critique.
- `consumable #3 / min_stock` : 0.3000 -> 2.0000.
- `consumable #10 / min_stock` : 0.5000 -> 2.0000.
- `consumable #1 / min_stock` : 1.0000 -> 1.5000.
- `consumable #1 / package_quantity` : 4.0000 -> 3.0000.

Ces conflits ne sont pas appliques automatiquement. Ils restent en attente de validation humaine dans l'admin, onglet `Harmonisation`.

## 13. Tests executes

Tests et verifications executes :

- Relance de `database/reference_harmonization_migration.sql` deux fois.
- Relance de `npm run harmonize` deux fois.
- Verification des compteurs patients, RDV, actes realises et mouvements avant/apres.
- Recherche des anciens noms interdits dans le code hors `node_modules`, `dist`, donnees MariaDB et logs.
- `cd server && npm ci`.
- `cd server && npm run check`.
- `cd server && npm audit --audit-level=moderate`.
- `cd client && npm ci`.
- `cd client && npm run build`.
- `cd client && npm audit --audit-level=moderate`.
- Sonde HTTP locale sur `http://127.0.0.1:5174/admin`.

## 14. Resultat des tests

Resultats :

- Migration SQL relancee deux fois : OK.
- Harmonisation relancee deux fois : OK.
- Doublons metier non recrées : OK.
- Conflits maintenus en validation humaine : OK.
- Patients conserves : OK.
- Rendez-vous conserves : OK.
- Actes realises conserves : OK.
- Mouvements de stock conserves : OK.
- Recherche anciens noms interdits : 0 occurrence visible dans le code audite.
- Serveur `npm ci` : OK, 0 vulnerabilite.
- Serveur `npm run check` : OK, 26 fichiers JavaScript verifies.
- Serveur `npm audit --audit-level=moderate` : OK, 0 vulnerabilite.
- Client `npm ci` : OK apres arret temporaire du serveur Vite qui verrouillait le binaire Rolldown.
- Client `npm run build` : OK.
- Client `npm audit --audit-level=moderate` : OK, 0 vulnerabilite.
- Interface locale `/admin` : HTTP 200.

## 15. Limites restantes

Limites a garder :

- Les 6 conflits restants doivent etre valides par un humain avant application.
- Les prix reels fournisseur ne doivent pas etre remplaces par des valeurs de reference.
- Les regles de remboursement par pays ne doivent pas etre inferees sans source officielle.
- Les actes modernes hors nomenclature doivent rester separes des actes CNAM/CCAM tant qu'une preuve n'existe pas.
- Le module odontogramme / cas clinique assiste n'est pas encore implemente dans cette passe.

## 16. Prochaine etape recommandee

Prochaine etape recommandee :

1. Valider ou rejeter les 6 conflits depuis l'onglet admin `Harmonisation`.
2. Completer les prix reels du cabinet a partir des factures.
3. Ajouter la migration complementaire `clinical_assistant_migration.sql` seulement apres validation de l'harmonisation stock/referentiels.
4. Construire le module `Cas clinique assiste` comme extension controlee : suggestion clinique + suggestion stock + cout previsionnel, puis validation humaine obligatoire.

## Conclusion

La base DentoFlow AI a ete harmonisee sans conflit destructeur.
Le code existant utile a ete conserve.
Les nouvelles fonctionnalites ont ete ajoutees comme extensions controlees.
Les doublons probables sont signales ou fusionnes apres validation.
Les conflits restent en attente de validation humaine.
Aucune donnee patient, acte realise, mouvement de stock, recette validee ou regle de remboursement n'a ete supprimee ou ecrasee.
