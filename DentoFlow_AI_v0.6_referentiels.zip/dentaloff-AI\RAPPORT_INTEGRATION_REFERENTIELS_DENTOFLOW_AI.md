# Rapport integration referentiels DentoFlow AI

Date : 2026-07-05

## 1. Objet

Integration d'un module `Referentiels` dans DentoFlow AI pour enrichir la plateforme de pilotage intelligent du cabinet dentaire : consommables de laboratoire, prix produits internationaux, prix actes dentaires par pays et prix actes laboratoire.

## 2. Positionnement conserve

Le nom visible reste `DentoFlow AI`. Le nom technique de base conserve est `dentaloff_ai`. L'architecture conservee est React/Vite pour le client, Express.js pour l'API et MySQL/MariaDB pour la base.

## 3. Sources exploitees

- `Inventaire mondial des consommables de laboratoire dentaire.pdf`
- `Prix moyens des produits dentaires dans le monde.pdf`
- `Prix moyens et conventionnels des actes dentaires dans le monde.pdf`
- `Benchmark mondial des prix des actes de laboratoire dentaire.pdf`
- Donnees deja presentes dans DentoFlow AI : stock, actes, recettes, harmonisation, conflits et audit.

Les valeurs importees restent indicatives et candidates. Elles ne remplacent pas des prix cabinet valides.

## 4. Fichiers crees ou modifies

- `database/reference_catalogs_migration.sql`
- `server/services/referenceImportService.js`
- `server/routes/references.js`
- `server/index.js`
- `client/src/pages/ReferencesPanel.jsx`
- `client/src/pages/Admin.jsx`
- `README.md`
- `RAPPORT_INTEGRATION_REFERENTIELS_DENTOFLOW_AI.md`

## 5. Tables creees

- `countries_reference`
- `lab_consumable_reference`
- `international_price_references`
- `international_price_history`
- `international_price_conflicts`
- `exchange_rate_references`
- `dental_act_global_catalog`
- `dental_act_local_aliases`
- `dental_act_price_references`
- `dental_act_price_conflicts`
- `dental_act_price_import_logs`
- `lab_act_price_references`
- `reference_product_candidates`

Les tables existantes `inventory_products`, `inventory_lots`, `inventory_movements`, `clinical_acts`, `reference_aliases`, `reference_conflicts` et `audit_logs` sont reutilisees sans ecrasement.

## 6. API ajoutee

Nouveau prefixe : `/api/references`.

- `GET /dashboard`
- `POST /import`
- `GET /lab-consumables`
- `POST /lab-consumables/import`
- `POST /lab-consumables/:id/validate`
- `POST /lab-consumables/:id/reject`
- `POST /lab-consumables/:id/create-product-candidate`
- `GET /international-prices`
- `POST /international-prices/:id/validate`
- `POST /international-prices/:id/reject`
- `POST /international-prices/:id/create-product-candidate`
- `GET /dental-act-prices`
- `POST /dental-act-prices/:id/validate`
- `POST /dental-act-prices/:id/reject`
- `GET /lab-act-prices`
- `POST /lab-act-prices/:id/validate`
- `POST /lab-act-prices/:id/reject`
- `GET /conflicts`
- `POST /conflicts/:id/resolve`
- `GET /import-logs`
- `POST /aliases`

## 7. Interface React ajoutee

Nouvel onglet admin : `Referentiels`.

Onglets internes :

- Consommables laboratoire
- Prix produits internationaux
- Prix actes dentaires
- Prix actes laboratoire
- Conflits
- Journaux import

Actions visibles : import controle, filtrage, validation, rejet, creation d'un candidat produit sans creation de stock reel.

## 8. Donnees effectivement en base

Comptage apres import enrichi :

- Pays : 15
- Consommables laboratoire : 30
- Prix produits internationaux : 809
- Actes dentaires globaux : 28
- Prix actes dentaires : 435
- Prix actes laboratoire : 210
- Journaux d'import : 16

L'import enrichi a tente 812 references prix produits et 223 references prix laboratoire. Les contraintes uniques ont absorbe les doublons sans creer de lignes redondantes.

## 9. Donnees ignorees ou fusionnees

- 3 prix produits etaient des doublons logiques selon la cle `(type, nom, pays, devise, unite)`.
- 13 prix actes laboratoire recoupaient deja la matrice pays/actes selon la cle `(acte, pays, devise, type, source)`.
- Aucun lot, mouvement de stock, prix cabinet reel ou recette validee n'a ete remplace.

## 10. Conflits et validation humaine

Tous les nouveaux referentiels sont en statut `candidate`.

Etat observe :

- `lab_consumable_reference` : 30 candidats
- `international_price_references` : 809 candidats
- `dental_act_price_references` : 435 candidats
- `lab_act_price_references` : 210 candidats
- `reference_conflicts` existants : 6 en attente, 5 deja merges
- Nouveaux conflits prix detectes : 0

Les validations et rejets passent par l'API authentifiee et sont audites dans `audit_logs`.

## 11. Protection des donnees reelles

Le service d'import applique les principes suivants :

- pas de creation automatique de stock reel ;
- pas de creation automatique de lot ;
- pas de mouvement automatique ;
- pas d'ecrasement des prix ou champs deja valides ;
- creation possible uniquement d'un candidat produit dans `reference_product_candidates`.

Verification SQL apres import :

- `inventory_lots` : 0
- `inventory_movements` : 1, inchange par l'import referentiels
- `inventory_products` : 24

## 12. Tests realises

- Migration SQL appliquee deux fois sans erreur.
- `node --check server/services/referenceImportService.js`
- `node --check server/routes/references.js`
- `npm run check` serveur : 28 fichiers JavaScript verifies.
- `npm run build` client : build Vite OK.
- `npm audit --audit-level=moderate` serveur : 0 vulnerabilite.
- `npm audit --audit-level=moderate` client : 0 vulnerabilite.
- API login admin OK.
- API `/api/references/dashboard` OK.
- API listes avec filtres OK : consommables, prix produits France, prix actes France, prix labo France.
- Navigateur integre : `/admin` OK, onglet `Referentiels` visible, six onglets internes charges sans erreur.

## 13. Limites et prochaines etapes

- Les prix restent indicatifs et doivent etre confirmes par pays, fournisseur, date et devise avant usage operationnel.
- Les conversions de devise servent de base de comparaison, pas de facturation.
- La prochaine etape utile est d'ajouter une vue de conversion d'un candidat produit vers `inventory_products` avec validation explicite du praticien.
- Ajouter ensuite un assistant de mapping entre les actes locaux du cabinet, les actes globaux et les nomenclatures pays.
- Ajouter une pagination serveur visible dans l'UI pour parcourir au-dela des 200 premieres lignes affichees par onglet.
