const express = require('express');
const { pool } = require('../db');
const { auth, adminOnly, docteurOnly } = require('../middleware/auth');
const { decimalOrNull } = require('../services/inventoryService');
const { logAudit } = require('../services/auditService');

const router = express.Router();
const asyncHandler = fn => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
const STATUSES = new Set(['draft', 'sent', 'in_progress', 'received', 'try_in', 'validated', 'delivered', 'cancelled']);

function cleanCasePayload(body) {
  return {
    patient_id: String(body.patient_id || '').trim() || null,
    performed_act_id: body.performed_act_id ? Number(body.performed_act_id) : null,
    case_code: String(body.case_code || `LAB-${Date.now().toString().slice(-8)}`).trim(),
    prosthesis_type: String(body.prosthesis_type || '').trim(),
    external_lab_name: String(body.external_lab_name || '').trim() || null,
    status: STATUSES.has(body.status) ? body.status : 'draft',
    shade: String(body.shade || '').trim() || null,
    material: String(body.material || '').trim() || null,
    tooth_numbers: String(body.tooth_numbers || '').trim() || null,
    sent_date: body.sent_date || null,
    due_date: body.due_date || null,
    received_date: body.received_date || null,
    lab_cost_tnd: decimalOrNull(body.lab_cost_tnd),
    notes: String(body.notes || '').trim() || null,
  };
}

router.get('/overview', auth, adminOnly, asyncHandler(async (_req, res) => {
  const [[casesCount]] = await pool.query('SELECT COUNT(*) AS n FROM lab_cases');
  const [[lateCount]] = await pool.query("SELECT COUNT(*) AS n FROM lab_cases WHERE due_date IS NOT NULL AND due_date < CURDATE() AND status NOT IN ('delivered','cancelled')");
  const [[stepsCount]] = await pool.query('SELECT COUNT(*) AS n FROM lab_steps');
  const [[recipesCount]] = await pool.query('SELECT COUNT(*) AS n FROM lab_recipes');
  res.json({
    module: 'Laboratoire de prothese dentaire',
    status: 'workflow-ready',
    counts: {
      cases: casesCount.n,
      late_cases: lateCount.n,
      steps: stepsCount.n,
      recipes: recipesCount.n,
    },
    workflow: ['draft', 'sent', 'in_progress', 'received', 'try_in', 'validated', 'delivered'],
    next_steps: [
      'Relier le cas labo au patient et a l acte realise',
      'Suivre cout labo + cout matiere cabinet',
      'Alerter les retards avant la date de retour',
    ],
  });
}));

router.get('/cases', auth, adminOnly, asyncHandler(async (_req, res) => {
  const [rows] = await pool.query(
    `SELECT lc.*, CONCAT(p.prenom, ' ', p.nom) AS patient_name,
            pa.actual_total_cost_tnd AS material_cost_tnd
     FROM lab_cases lc
     LEFT JOIN patients p ON p.id_patient = lc.patient_id
     LEFT JOIN performed_acts pa ON pa.id = lc.performed_act_id
     ORDER BY lc.created_at DESC, lc.id DESC
     LIMIT 200`
  );
  res.json(rows);
}));

router.get('/cases/:id/events', auth, adminOnly, asyncHandler(async (req, res) => {
  const [rows] = await pool.query('SELECT * FROM lab_case_events WHERE lab_case_id = ? ORDER BY event_date DESC, id DESC', [req.params.id]);
  res.json(rows);
}));

router.post('/cases', auth, docteurOnly, asyncHandler(async (req, res) => {
  const data = cleanCasePayload(req.body);
  if (!data.prosthesis_type) return res.status(400).json({ error: 'Type de travail labo requis.' });
  const [result] = await pool.query(
    `INSERT INTO lab_cases
       (patient_id, performed_act_id, case_code, prosthesis_type, external_lab_name, status,
        shade, material, tooth_numbers, sent_date, due_date, received_date, lab_cost_tnd, notes)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      data.patient_id,
      data.performed_act_id,
      data.case_code,
      data.prosthesis_type,
      data.external_lab_name,
      data.status,
      data.shade,
      data.material,
      data.tooth_numbers,
      data.sent_date,
      data.due_date,
      data.received_date,
      data.lab_cost_tnd,
      data.notes,
    ]
  );
  await pool.query(
    'INSERT INTO lab_case_events (lab_case_id, previous_status, new_status, actor, notes) VALUES (?, NULL, ?, ?, ?)',
    [result.insertId, data.status, req.user?.username || req.user?.role || null, 'Creation demande labo']
  );
  await logAudit(pool, req, { action: 'LAB_CASE_CREATE', entity_type: 'lab_case', entity_id: result.insertId, patient_id: data.patient_id, details: { prosthesis_type: data.prosthesis_type } });
  const [[row]] = await pool.query('SELECT * FROM lab_cases WHERE id = ?', [result.insertId]);
  res.status(201).json(row);
}));

router.put('/cases/:id/status', auth, docteurOnly, asyncHandler(async (req, res) => {
  const status = String(req.body.status || '');
  if (!STATUSES.has(status)) return res.status(400).json({ error: 'Statut labo invalide.' });
  const [[before]] = await pool.query('SELECT * FROM lab_cases WHERE id = ?', [req.params.id]);
  if (!before) return res.status(404).json({ error: 'Cas labo introuvable.' });
  await pool.query('UPDATE lab_cases SET status = ?, received_date = COALESCE(?, received_date) WHERE id = ?', [status, req.body.received_date || null, req.params.id]);
  await pool.query(
    'INSERT INTO lab_case_events (lab_case_id, previous_status, new_status, actor, notes) VALUES (?, ?, ?, ?, ?)',
    [req.params.id, before.status, status, req.user?.username || req.user?.role || null, String(req.body.notes || '').trim() || null]
  );
  await logAudit(pool, req, { action: 'LAB_CASE_STATUS_UPDATE', entity_type: 'lab_case', entity_id: req.params.id, patient_id: before.patient_id, details: { previous: before.status, next: status } });
  res.json({ ok: true });
}));

router.use((err, _req, res, _next) => {
  res.status(400).json({ error: err.message || 'Erreur laboratoire.' });
});

module.exports = router;
