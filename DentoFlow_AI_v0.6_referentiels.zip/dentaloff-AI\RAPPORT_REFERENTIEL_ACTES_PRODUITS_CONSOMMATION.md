# Rapport Codex - Referentiel actes, produits et consommations

Date : 2026-07-05

## Objectif

Transformer DentoFlow AI en plateforme de pilotage intelligent du cabinet dentaire :

```text
Acte dentaire -> produits utilises -> consommation moyenne -> cout matiere -> stock -> alerte -> achat
```

La mise a jour respecte les regles demandees :

- ne jamais considerer la base comme vide ;
- ne pas creer de doublons ;
- ne pas remplacer les actes, produits, recettes ou prix deja valides ;
- ne pas modifier ni deduire le stock reel automatiquement ;
- garder les ajouts comme references candidates jusqu'a validation humaine.

## Fichiers ajoutes ou modifies

- `database/act_product_catalog_migration.sql`
- `database/act_product_catalog_seed.sql`
- `server/services/actProductCatalogService.js`
- `server/routes/actProductCatalog.js`
- `server/index.js`
- `client/src/pages/ActProductCatalogPanel.jsx`
- `client/src/pages/Admin.jsx`
- `README.md`

## Base de donnees

Tables creees ou completees :

- `dental_act_catalog`
- `dental_product_catalog`
- `act_product_recipes`
- `act_product_catalog_import_logs`

Champs importants dans `act_product_recipes` :

- `consumption_min`
- `consumption_typical`
- `consumption_max`
- `unit`
- `required`
- `confidence_level`
- `unit_cost_tnd`
- `unit_cost_source`
- `unit_cost_status`
- `estimated_cost_tnd_min`
- `estimated_cost_tnd_typical`
- `estimated_cost_tnd_max`
- `cost_validation_status`
- `validated_by_user`
- `validation_status`

## Donnees integrees

Import API execute avec succes :

- 72 actes dentaires candidats
- 107 produits candidats
- 107 lignes de consommation par acte
- 21 produits de reference lies a des produits stock existants
- 37 lignes avec cout matiere estime
- 24 couts bases sur prix indicatif candidat
- 13 couts bases sur prix reel stock
- 4 conflits de cout dus a des unites incompatibles
- 0 conflit bloquant de recette

Toutes les recettes restent `pending` et `validated_by_user = 0` tant qu'un praticien ne valide pas.

## Exemples controles

- Composite 2 faces / composite seringue : 0,3-0,5 g, typique 0,4 g, cout typique 4,500 TND depuis le prix reel stock `Resine / composite A2`.
- Empreinte alginate : 20-30 g, typique 25 g, cout typique 1,889 TND depuis un prix indicatif candidat.
- Couronne ceramique / silicone VPS : 15-30 ml, typique 20 ml, cout typique 40,000 TND depuis un prix indicatif candidat.
- Extraction simple / carpule anesthesie : 1-2 carpules, cout typique 1,500 TND depuis le prix reel stock.
- Acide orthophosphorique : conflit de cout signale car la recette est en ml alors que le stock existant est suivi en g. Aucun cout force.

## Interface admin

Deux nouvelles entrees sont disponibles dans l'administration :

- `Referentiel actes`
- `Referentiel produits`

Le panneau contient aussi :

- `Consommations par acte`
- `Journaux`
- bouton `Importer / mettre a jour`
- bouton `Creer produit reel depuis reference`
- actions `Valider` et `Rejeter`

Le bouton `Creer produit reel depuis reference` ne cree pas de ligne dans `inventory_products`. Il cree seulement un candidat dans `reference_product_candidates`.

## Routes API

- `GET /api/act-product-catalog/dashboard`
- `POST /api/act-product-catalog/import`
- `GET /api/act-product-catalog/acts`
- `POST /api/act-product-catalog/acts/:id/validate`
- `POST /api/act-product-catalog/acts/:id/reject`
- `GET /api/act-product-catalog/products`
- `POST /api/act-product-catalog/products/:id/validate`
- `POST /api/act-product-catalog/products/:id/reject`
- `POST /api/act-product-catalog/products/:id/create-real-product`
- `GET /api/act-product-catalog/recipes`
- `POST /api/act-product-catalog/recipes/:id/validate`
- `POST /api/act-product-catalog/recipes/:id/reject`
- `GET /api/act-product-catalog/logs`

## Tests realises

- `npm run check` serveur : OK, 31 fichiers JavaScript verifies.
- `npm run build` client : OK.
- `npm audit --audit-level=moderate` serveur : 0 vulnerabilite.
- `npm audit --audit-level=moderate` client : 0 vulnerabilite.
- API login admin : OK.
- API dashboard actes-produits : OK.
- API listes actes/produits/recettes : OK.
- API creation candidat produit reel : OK, sans modification de `inventory_products` (24 avant, 24 apres).
- Test navigateur integre avant correction : menus et compteurs visibles, onglets actes/produits/consommations accessibles.
- Correction appliquee apres test navigateur : les couts inconnus ne sont plus affiches comme `0.000 TND`.

## Limites connues

- Les couts restent incomplets pour les produits qui n'ont ni conditionnement exploitable ni prix reel/indicatif relie.
- Les conflits d'unite sont volontairement bloques au lieu d'etre convertis automatiquement.
- Les prix indicatifs doivent rester candidats jusqu'a validation cabinet/labo.
