USE dentaloff_ai;

CREATE TABLE IF NOT EXISTS dental_chart_records (
  id INT AUTO_INCREMENT PRIMARY KEY,
  patient_id VARCHAR(40) NULL,
  tooth_number INT NOT NULL,
  dentition_type ENUM('permanent','temporary') NOT NULL DEFAULT 'permanent',
  arcade VARCHAR(40) NULL,
  quadrant VARCHAR(10) NULL,
  surface VARCHAR(40) NULL,
  status VARCHAR(60) NOT NULL DEFAULT 'healthy',
  notes TEXT NULL,
  linked_treatment_plan_item INT NULL,
  linked_performed_act INT NULL,
  validated TINYINT(1) NOT NULL DEFAULT 0,
  created_by INT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY idx_dental_chart_patient (patient_id),
  KEY idx_dental_chart_tooth (tooth_number)
);

CREATE TABLE IF NOT EXISTS clinical_case_suggestions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  patient_id VARCHAR(40) NULL,
  rdv_id INT NULL,
  tooth_number INT NULL,
  clinical_case VARCHAR(120) NOT NULL,
  black_class VARCHAR(40) NULL,
  sista_class VARCHAR(40) NULL,
  suggested_act_id INT NULL,
  suggested_stock_json TEXT NULL,
  estimated_cost_tnd DECIMAL(12,3) NULL,
  status ENUM('draft','suggested','validated','rejected','applied') NOT NULL DEFAULT 'draft',
  created_by INT NULL,
  validated_by INT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY idx_clinical_suggestions_patient (patient_id),
  KEY idx_clinical_suggestions_status (status)
);
