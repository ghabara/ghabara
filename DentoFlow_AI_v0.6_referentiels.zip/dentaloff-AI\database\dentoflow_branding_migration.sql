USE dentaloff_ai;

CREATE TABLE IF NOT EXISTS app_branding_settings (
  id INT PRIMARY KEY,
  app_name VARCHAR(120) NOT NULL DEFAULT 'DentoFlow AI',
  slogan_en VARCHAR(180) NOT NULL DEFAULT 'Dental Practice & Lab Intelligence',
  slogan_fr VARCHAR(220) NOT NULL DEFAULT 'Gestion intelligente du cabinet dentaire et du laboratoire',
  logo_path VARCHAR(255) NOT NULL DEFAULT '/branding/dentoflow-ai-logo.png',
  icon_path VARCHAR(255) NOT NULL DEFAULT '/branding/dentoflow-ai-icon.png',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

INSERT INTO app_branding_settings (id, app_name, slogan_en, slogan_fr, logo_path, icon_path)
VALUES (
  1,
  'DentoFlow AI',
  'Dental Practice & Lab Intelligence',
  'Gestion intelligente du cabinet dentaire et du laboratoire',
  '/branding/dentoflow-ai-logo.png',
  '/branding/dentoflow-ai-icon.png'
)
ON DUPLICATE KEY UPDATE
  app_name = VALUES(app_name),
  slogan_en = VALUES(slogan_en),
  slogan_fr = VALUES(slogan_fr),
  logo_path = VALUES(logo_path),
  icon_path = VALUES(icon_path);

UPDATE cabinet_info
SET
  name = 'DentoFlow AI',
  email = CASE
    WHEN email IS NULL OR email = '' OR email LIKE '%denta%' THEN 'w.ghabara@hotmail.fr'
    ELSE email
  END
WHERE id = 1;
