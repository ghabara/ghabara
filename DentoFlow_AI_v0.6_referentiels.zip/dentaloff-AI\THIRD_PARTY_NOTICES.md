# Third-party notices

This project was upgraded with architectural inspiration from the provided open-source reference pack.

No GPL or AGPL source code has been copied into this deliverable.

Permissive inspiration areas:

- Inventory concepts inspired by permissive stock-management patterns: product catalog, stock movements, low-stock alerts, purchase history.
- AI workflow concepts inspired by permissive local assistant patterns: draft-first extraction, human validation, no automatic stock mutation.
- Dashboard patterns inspired by common operational software layouts: KPI cards, alert queues, recent movements.

If third-party source code is added later, keep its license text in this file and verify compatibility before merging.
