import { useEffect, useState } from 'react';
import { adminApi } from '../api';

const tabs = [
  ['lab', 'Consommables laboratoire'],
  ['prices', 'Prix produits internationaux'],
  ['dentalActs', 'Prix actes dentaires'],
  ['labActs', 'Prix actes laboratoire'],
  ['conflicts', 'Conflits'],
  ['logs', 'Journaux import'],
];

const endpoints = {
  lab: '/references/lab-consumables',
  prices: '/references/international-prices',
  dentalActs: '/references/dental-act-prices',
  labActs: '/references/lab-act-prices',
  conflicts: '/references/conflicts',
  logs: '/references/import-logs',
};

export default function ReferencesPanel() {
  const [tab, setTab] = useState('lab');
  const [rows, setRows] = useState([]);
  const [dashboard, setDashboard] = useState(null);
  const [filters, setFilters] = useState({ q: '', country: '', category: '', status: '' });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [message, setMessage] = useState('');

  const load = async (nextTab = tab) => {
    setBusy(true);
    setError('');
    try {
      const params = ['conflicts', 'logs'].includes(nextTab)
        ? {}
        : cleanParams({ ...filters, limit: 200 });
      const [dashboardResponse, rowsResponse] = await Promise.all([
        adminApi.get('/references/dashboard'),
        adminApi.get(endpoints[nextTab], { params }),
      ]);
      setDashboard(dashboardResponse.data);
      setRows(Array.isArray(rowsResponse.data) ? rowsResponse.data : []);
    } catch (e) {
      setError(e.response?.data?.error || 'Referentiels indisponibles.');
    } finally {
      setBusy(false);
    }
  };

  useEffect(() => { load(tab); }, [tab]);

  const runImport = async () => {
    setBusy(true);
    setError('');
    setMessage('');
    try {
      const { data } = await adminApi.post('/references/import');
      setMessage(`Import termine : ${data.updated || 0} references candidates, ${data.conflicts || 0} conflits detectes.`);
      await load(tab);
    } catch (e) {
      setError(e.response?.data?.error || 'Import impossible.');
    } finally {
      setBusy(false);
    }
  };

  const doAction = async (path, label, body) => {
    setError('');
    setMessage('');
    try {
      await adminApi.post(path, body || {});
      setMessage(label);
      await load(tab);
    } catch (e) {
      setError(e.response?.data?.error || 'Action impossible.');
    }
  };

  const updateFilter = (key, value) => setFilters(current => ({ ...current, [key]: value }));

  return (
    <>
      <PanelTitle sub="Bibliotheques de reference, prix indicatifs et nomenclatures en candidats validables.">
        Referentiels
      </PanelTitle>
      {error && <div className="alert error">{error}</div>}
      {message && <div className="alert success">{message}</div>}

      <div className="card" style={{ marginBottom: 16 }}>
        <div className="dashboard-line">
          <div>
            <strong>Import controle, sans ecrasement du reel</strong>
            <p className="muted" style={{ margin: '4px 0 0' }}>
              Les catalogues importes restent candidats. Stocks reels, lots, mouvements, prix cabinet et actes valides ne sont pas remplaces automatiquement.
            </p>
          </div>
          <button className="btn btn-primary" disabled={busy} onClick={runImport}>
            {busy ? 'Traitement...' : 'Importer / mettre a jour'}
          </button>
        </div>
        <div className="dashboard-grid" style={{ marginTop: 16 }}>
          <MiniKpi label="Consommables labo" value={dashboard?.lab?.total} hint={`${count(dashboard?.lab?.candidates)} candidats`} />
          <MiniKpi label="Prix produits" value={dashboard?.prices?.total} hint={`${count(dashboard?.prices?.candidates)} candidats`} />
          <MiniKpi label="Prix actes" value={dashboard?.acts?.total} hint={`${count(dashboard?.acts?.candidates)} candidats`} />
          <MiniKpi label="Prix labo" value={dashboard?.labActs?.total} hint={`${count(dashboard?.labActs?.candidates)} candidats`} />
          <MiniKpi label="Conflits ouverts" value={dashboard?.conflicts?.pending} hint="validation requise" />
        </div>
      </div>

      <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 14 }}>
        {tabs.map(([key, label]) => (
          <button key={key} className={tab === key ? 'btn btn-primary' : 'btn btn-secondary'} onClick={() => setTab(key)}>
            {label}
          </button>
        ))}
      </div>

      {!['conflicts', 'logs'].includes(tab) && (
        <div className="card" style={{ marginBottom: 14 }}>
          <div className="form-grid">
            <div className="fg">
              <label>Recherche</label>
              <input value={filters.q} onChange={e => updateFilter('q', e.target.value)} placeholder="Nom, categorie, acte..." />
            </div>
            <div className="fg">
              <label>Pays</label>
              <input value={filters.country} onChange={e => updateFilter('country', e.target.value)} placeholder="France, Tunisie, Canada..." />
            </div>
            <div className="fg">
              <label>Categorie</label>
              <input value={filters.category} onChange={e => updateFilter('category', e.target.value)} placeholder="Famille ou categorie" />
            </div>
            <div className="fg">
              <label>Statut</label>
              <select value={filters.status} onChange={e => updateFilter('status', e.target.value)}>
                <option value="">Tous</option>
                <option value="candidate">Candidat</option>
                <option value="validated">Valide</option>
                <option value="rejected">Rejete</option>
                <option value="conflict">Conflit</option>
              </select>
            </div>
          </div>
          <button className="btn btn-secondary" disabled={busy} onClick={() => load(tab)} style={{ marginTop: 10 }}>
            Filtrer
          </button>
        </div>
      )}

      {tab === 'lab' && <LabConsumablesTable rows={rows} onAction={doAction} />}
      {tab === 'prices' && <InternationalPricesTable rows={rows} onAction={doAction} />}
      {tab === 'dentalActs' && <DentalActPricesTable rows={rows} onAction={doAction} />}
      {tab === 'labActs' && <LabActPricesTable rows={rows} onAction={doAction} />}
      {tab === 'conflicts' && <ReferenceConflictsTable rows={rows} onAction={doAction} />}
      {tab === 'logs' && <ReferenceLogsTable rows={rows} />}
    </>
  );
}

function PanelTitle({ children, sub }) {
  return (
    <div style={{ marginBottom: 22 }}>
      <h2 className="section-title">{children}</h2>
      {sub && <p className="muted">{sub}</p>}
    </div>
  );
}

function MiniKpi({ label, value, hint }) {
  return (
    <div className="kpi-card">
      <span className="kpi-value">{count(value)}</span>
      <span className="kpi-label">{label}</span>
      <span className="kpi-hint">{hint}</span>
    </div>
  );
}

function LabConsumablesTable({ rows, onAction }) {
  return (
    <ReferenceTable empty="Aucun consommable laboratoire candidat.">
      <thead><tr><th>Consommable</th><th>Categorie</th><th>Unites</th><th>Prix indicatif</th><th>Statut</th><th>Actions</th></tr></thead>
      <tbody>
        {rows.map(row => (
          <tr key={row.id}>
            <td><strong>{row.canonical_name}</strong><br /><small className="muted">{row.typical_use || '-'}</small></td>
            <td>{row.category}<br /><small className="muted">{row.subcategory || '-'}</small></td>
            <td>{row.purchase_unit || '-'}<br /><small className="muted">{row.storage_unit || '-'}</small></td>
            <td>{range(row.price_min, row.price_max, row.price_currency)}</td>
            <td>{statusLabel(row.validation_status)}</td>
            <td style={{ minWidth: 300 }}>
              <ActionButtons
                onValidate={() => onAction(`/references/lab-consumables/${row.id}/validate`, 'Reference validee.')}
                onReject={() => onAction(`/references/lab-consumables/${row.id}/reject`, 'Reference rejetee.')}
                onCandidate={() => onAction(`/references/lab-consumables/${row.id}/create-product-candidate`, 'Candidat produit prepare, sans creation de stock reel.')}
              />
            </td>
          </tr>
        ))}
        {!rows.length && <EmptyRow columns={6} text="Aucun consommable laboratoire candidat." />}
      </tbody>
    </ReferenceTable>
  );
}

function InternationalPricesTable({ rows, onAction }) {
  return (
    <ReferenceTable empty="Aucun prix produit candidat.">
      <thead><tr><th>Produit</th><th>Pays</th><th>Prix local</th><th>USD</th><th>Source</th><th>Statut</th><th>Actions</th></tr></thead>
      <tbody>
        {rows.map(row => (
          <tr key={row.id}>
            <td><strong>{row.candidate_name}</strong><br /><small className="muted">{row.entity_type} / {row.category || '-'}</small></td>
            <td>{row.country}<br /><small className="muted">{row.currency}</small></td>
            <td>{range(row.price_min, row.price_max, row.currency)}<br /><small className="muted">moy. {money(row.price_avg, row.currency)}</small></td>
            <td>{money(row.price_usd, 'USD')}</td>
            <td className="muted">{row.source_name || '-'}</td>
            <td>{statusLabel(row.validation_status)}</td>
            <td style={{ minWidth: 300 }}>
              <ActionButtons
                onValidate={() => onAction(`/references/international-prices/${row.id}/validate`, 'Prix valide.')}
                onReject={() => onAction(`/references/international-prices/${row.id}/reject`, 'Prix rejete.')}
                onCandidate={() => onAction(`/references/international-prices/${row.id}/create-product-candidate`, 'Candidat produit prepare, sans creation de stock reel.')}
              />
            </td>
          </tr>
        ))}
        {!rows.length && <EmptyRow columns={7} text="Aucun prix produit candidat." />}
      </tbody>
    </ReferenceTable>
  );
}

function DentalActPricesTable({ rows, onAction }) {
  return (
    <ReferenceTable empty="Aucun tarif acte candidat.">
      <thead><tr><th>Acte</th><th>Pays</th><th>Type</th><th>Prix</th><th>Remboursement</th><th>Statut</th><th>Actions</th></tr></thead>
      <tbody>
        {rows.map(row => (
          <tr key={row.id}>
            <td><strong>{row.act_name}</strong><br /><small className="muted">{row.family || row.act_key}</small></td>
            <td>{row.country}<br /><small className="muted">{row.currency}</small></td>
            <td>{row.price_type}</td>
            <td>{range(row.price_min, row.price_max, row.currency)}<br /><small className="muted">moy. {money(row.price_avg, row.currency)}</small></td>
            <td>{percent(row.reimbursement_rate)}</td>
            <td>{statusLabel(row.validation_status)}</td>
            <td style={{ minWidth: 220 }}>
              <button className="btn btn-green" onClick={() => onAction(`/references/dental-act-prices/${row.id}/validate`, 'Tarif acte valide.')}>Valider</button>{' '}
              <button className="btn btn-secondary" onClick={() => onAction(`/references/dental-act-prices/${row.id}/reject`, 'Tarif acte rejete.')}>Rejeter</button>
            </td>
          </tr>
        ))}
        {!rows.length && <EmptyRow columns={7} text="Aucun tarif acte candidat." />}
      </tbody>
    </ReferenceTable>
  );
}

function LabActPricesTable({ rows, onAction }) {
  return (
    <ReferenceTable empty="Aucun tarif laboratoire candidat.">
      <thead><tr><th>Acte labo</th><th>Pays</th><th>Type</th><th>Prix local</th><th>USD</th><th>Statut</th><th>Actions</th></tr></thead>
      <tbody>
        {rows.map(row => (
          <tr key={row.id}>
            <td><strong>{row.act_name}</strong><br /><small className="muted">{row.act_key}</small></td>
            <td>{row.country}<br /><small className="muted">{row.currency}</small></td>
            <td>{row.price_type}</td>
            <td>{range(row.price_min, row.price_max, row.currency)}<br /><small className="muted">moy. {money(row.price_avg, row.currency)}</small></td>
            <td>{money(row.price_usd, 'USD')}</td>
            <td>{statusLabel(row.validation_status)}</td>
            <td style={{ minWidth: 220 }}>
              <button className="btn btn-green" onClick={() => onAction(`/references/lab-act-prices/${row.id}/validate`, 'Tarif laboratoire valide.')}>Valider</button>{' '}
              <button className="btn btn-secondary" onClick={() => onAction(`/references/lab-act-prices/${row.id}/reject`, 'Tarif laboratoire rejete.')}>Rejeter</button>
            </td>
          </tr>
        ))}
        {!rows.length && <EmptyRow columns={7} text="Aucun tarif laboratoire candidat." />}
      </tbody>
    </ReferenceTable>
  );
}

function ReferenceConflictsTable({ rows, onAction }) {
  return (
    <ReferenceTable empty="Aucun conflit ouvert.">
      <thead><tr><th>Source</th><th>Champ</th><th>Valeur actuelle</th><th>Candidat</th><th>Criticite</th><th>Statut</th><th>Actions</th></tr></thead>
      <tbody>
        {rows.map(row => (
          <tr key={`${row.source_table}-${row.id}`}>
            <td><strong>{row.source_table}</strong><br /><small className="muted">{row.entity_type || '-'}</small></td>
            <td>{row.field_name || '-'}</td>
            <td>{row.current_value || '-'}</td>
            <td>{row.candidate_value || '-'}</td>
            <td>{row.severity || '-'}</td>
            <td>{row.status}</td>
            <td style={{ minWidth: 220 }}>
              <button className="btn btn-green" onClick={() => onAction(`/references/conflicts/${row.id}/resolve`, 'Conflit accepte.', { source_table: row.source_table, status: 'accepted' })}>Accepter</button>{' '}
              <button className="btn btn-secondary" onClick={() => onAction(`/references/conflicts/${row.id}/resolve`, 'Conflit rejete.', { source_table: row.source_table, status: 'rejected' })}>Rejeter</button>
            </td>
          </tr>
        ))}
        {!rows.length && <EmptyRow columns={7} text="Aucun conflit ouvert." />}
      </tbody>
    </ReferenceTable>
  );
}

function ReferenceLogsTable({ rows }) {
  return (
    <ReferenceTable empty="Aucun journal d'import.">
      <thead><tr><th>Date</th><th>Run</th><th>Operation</th><th>Type</th><th>Table</th><th>Details</th></tr></thead>
      <tbody>
        {rows.map(row => (
          <tr key={row.id}>
            <td className="muted">{formatDateTime(row.created_at)}</td>
            <td>{row.import_run_id || '-'}</td>
            <td>{row.operation}</td>
            <td>{row.entity_type}</td>
            <td>{row.target_table || '-'}</td>
            <td className="muted">{shortJson(row.details_json)}</td>
          </tr>
        ))}
        {!rows.length && <EmptyRow columns={6} text="Aucun journal d'import." />}
      </tbody>
    </ReferenceTable>
  );
}

function ReferenceTable({ children }) {
  return (
    <div className="table-wrap">
      <table>{children}</table>
    </div>
  );
}

function ActionButtons({ onValidate, onReject, onCandidate }) {
  return (
    <>
      <button className="btn btn-green" onClick={onValidate}>Valider</button>{' '}
      <button className="btn btn-secondary" onClick={onReject}>Rejeter</button>{' '}
      <button className="btn btn-secondary" onClick={onCandidate}>Candidat produit</button>
    </>
  );
}

function EmptyRow({ columns, text }) {
  return <tr><td colSpan={columns} className="center muted" style={{ padding: 24 }}>{text}</td></tr>;
}

function cleanParams(params) {
  return Object.fromEntries(Object.entries(params).filter(([, value]) => value !== '' && value !== null && value !== undefined));
}

function count(value) {
  const n = Number(value || 0);
  return Number.isFinite(n) ? n : 0;
}

function money(value, currency) {
  if (value === null || value === undefined || value === '') return '-';
  const n = Number(value);
  return Number.isFinite(n) ? `${n.toFixed(2)} ${currency || ''}`.trim() : '-';
}

function range(min, max, currency) {
  if (min === null && max === null) return '-';
  if (min === undefined && max === undefined) return '-';
  if (String(min ?? '') === String(max ?? '')) return money(min, currency);
  return `${money(min, currency)} - ${money(max, currency)}`;
}

function percent(value) {
  if (value === null || value === undefined) return '-';
  const n = Number(value);
  return Number.isFinite(n) ? `${n.toFixed(0)}%` : '-';
}

function statusLabel(status) {
  const labels = { candidate: 'Candidat', validated: 'Valide', rejected: 'Rejete', conflict: 'Conflit' };
  return labels[status] || status || '-';
}

function formatDateTime(value) {
  if (!value) return '-';
  try { return new Date(value).toLocaleString('fr-FR'); }
  catch { return value; }
}

function shortJson(value) {
  if (!value) return '-';
  try {
    const parsed = typeof value === 'string' ? JSON.parse(value) : value;
    return Object.entries(parsed).slice(0, 4).map(([k, v]) => `${k}: ${v}`).join(', ');
  } catch {
    return String(value).slice(0, 140);
  }
}
