﻿const express = require('express');
const { pool } = require('../db');
const { auth, adminOnly, docteurOnly } = require('../middleware/auth');
const {
  calculateRecipeLineCost,
  decimalOrNull,
  expirationStatus,
  fetchRecipeRows,
  recordInventoryMovement,
  refreshAiAlerts,
  summarizeRecipeRows,
  unitsMatch,
  withTransaction,
} = require('../services/inventoryService');

const router = express.Router();
const asyncHandler = fn => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

function quantityFromPayload(actualQuantities, recipeId, fallback) {
  if (!actualQuantities) return fallback;
  if (Array.isArray(actualQuantities)) {
    const found = actualQuantities.find(item => Number(item.recipe_id) === Number(recipeId));
    return found ? found.quantity : fallback;
  }
  if (Object.prototype.hasOwnProperty.call(actualQuantities, recipeId)) {
    return actualQuantities[recipeId];
  }
  return fallback;
}

router.get('/', auth, adminOnly, asyncHandler(async (_req, res) => {
  const [rows] = await pool.query(`
    SELECT pa.*,
           a.name AS act_name,
           a.clinical_variant,
           COUNT(cl.id) AS line_count
    FROM performed_acts pa
    JOIN clinical_acts a ON a.id = pa.act_id
    LEFT JOIN consumption_logs cl ON cl.performed_act_id = pa.id
    GROUP BY pa.id
    ORDER BY pa.performed_date DESC, pa.id DESC
    LIMIT 300
  `);
  res.json(rows);
}));

router.get('/:id/lines', auth, adminOnly, asyncHandler(async (req, res) => {
  const [rows] = await pool.query(`
    SELECT cl.*, p.name AS product_name, p.tracking_unit
    FROM consumption_logs cl
    JOIN inventory_products p ON p.id = cl.product_id
    WHERE cl.performed_act_id = ?
    ORDER BY cl.id
  `, [req.params.id]);
  res.json(rows);
}));

router.post('/', auth, docteurOnly, asyncHandler(async (req, res) => {
  const actId = Number(req.body.act_id);
  if (!actId) return res.status(400).json({ error: 'Acte requis.' });

  const result = await withTransaction(pool, async (conn) => {
    const [[act]] = await conn.query('SELECT * FROM clinical_acts WHERE id = ? AND is_active = 1', [actId]);
    if (!act) throw new Error('Acte introuvable ou inactif.');

    const rows = await fetchRecipeRows(conn, actId, { forUpdate: true });
    if (rows.length === 0) throw new Error('Aucune recette definie pour cet acte.');

    const estimatedSummary = summarizeRecipeRows(rows);
    const lines = [];
    const blockers = [];
    const warnings = [];
    let actualTotal = 0;
    let actualUnknownCount = 0;
    let hasPositiveQuantity = false;

    for (const row of rows) {
      const fallback = decimalOrNull(row.quantity_per_act) ?? 0;
      const qty = decimalOrNull(quantityFromPayload(req.body.actual_quantities, row.id, fallback)) ?? 0;
      if (qty < 0) {
        blockers.push(`${row.product_name}: quantite negative refusee`);
        continue;
      }
      if (qty === 0) {
        lines.push({ row, qty, line_cost: null, stock_before: decimalOrNull(row.current_stock), stock_after: decimalOrNull(row.current_stock), skipped: true });
        continue;
      }

      hasPositiveQuantity = true;
      const stockBefore = decimalOrNull(row.current_stock);
      if (!unitsMatch(row.unit, row.tracking_unit)) {
        blockers.push(`${row.product_name}: unite recette (${row.unit}) differente du produit (${row.tracking_unit})`);
      }
      if (stockBefore === null) {
        blockers.push(`${row.product_name}: stock non renseigne`);
      } else if (stockBefore < qty) {
        blockers.push(`${row.product_name}: stock insuffisant (${stockBefore}, demande ${qty})`);
      }
      const expiry = expirationStatus(row.expiration_date);
      if (expiry === 'EXPIRED') blockers.push(`${row.product_name}: lot perime`);
      if (expiry === 'SOON') warnings.push(`${row.product_name}: peremption proche`);

      const lineCost = calculateRecipeLineCost(row, qty, row.unit).cost;
      if (lineCost === null) actualUnknownCount += 1;
      else actualTotal += lineCost;

      lines.push({
        row,
        qty,
        line_cost: lineCost,
        stock_before: stockBefore,
        stock_after: stockBefore === null ? null : stockBefore - qty,
        skipped: false,
      });
    }

    if (!hasPositiveQuantity) throw new Error('Aucune quantite positive a enregistrer.');
    if (blockers.length) throw new Error(`Validation bloquee: ${[...new Set(blockers)].join(' ; ')}.`);

    const performedDate = req.body.performed_date || new Date().toISOString().slice(0, 10);
    const patientLabel = String(req.body.patient_label || '').trim() || (req.body.patient_id ? 'Patient lie DentoFlow AI' : 'Patient anonymise');
    const [insert] = await conn.query(
      `INSERT INTO performed_acts
         (performed_date, patient_id, patient_label, act_id, rdv_id,
          estimated_total_cost_tnd, actual_total_cost_tnd, comment, created_by)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        performedDate,
        req.body.patient_id || null,
        patientLabel,
        actId,
        req.body.rdv_id || null,
        estimatedSummary.total_cost_tnd,
        actualUnknownCount > 0 ? null : actualTotal,
        String(req.body.comment || '').trim() || null,
        req.user?.username || req.user?.role || null,
      ]
    );
    const performedActId = insert.insertId;

    for (const line of lines.filter(item => !item.skipped)) {
      await conn.query('UPDATE inventory_products SET current_stock = ? WHERE id = ?', [line.stock_after, line.row.product_id]);
      await conn.query(
        `INSERT INTO consumption_logs
           (performed_act_id, log_date, act_id, product_id, quantity, unit,
            measurement_mode, confidence, line_cost_tnd, stock_before, stock_after, comment)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          performedActId,
          performedDate,
          actId,
          line.row.product_id,
          line.qty,
          line.row.unit,
          line.row.measurement_mode,
          line.row.confidence,
          line.line_cost,
          line.stock_before,
          line.stock_after,
          String(req.body.comment || '').trim() || null,
        ]
      );
      await recordInventoryMovement(conn, {
        product_id: line.row.product_id,
        product_name_snapshot: line.row.product_name,
        quantity: line.qty,
        unit: line.row.tracking_unit,
        direction: 'OUT',
        origin: 'PERFORMED_ACT',
        origin_id: performedActId,
        stock_before: line.stock_before,
        stock_after: line.stock_after,
        created_by: req.user?.username || req.user?.role || null,
      });
      await conn.query(
        `UPDATE act_recipes
         SET quantity_per_act = ((quantity_per_act * measurement_count) + ?) / (measurement_count + 1),
             measurement_count = measurement_count + 1
         WHERE id = ?`,
        [line.qty, line.row.id]
      );
    }

    return {
      performed_act_id: performedActId,
      act: { id: act.id, name: act.name, clinical_variant: act.clinical_variant },
      estimated_total_cost_tnd: estimatedSummary.total_cost_tnd,
      actual_total_cost_tnd: actualUnknownCount > 0 ? null : actualTotal,
      actual_partial_cost_tnd: actualTotal,
      unknown_cost_count: actualUnknownCount,
      stock_after: lines.filter(item => !item.skipped).map(line => ({
        product_id: line.row.product_id,
        product_name: line.row.product_name,
        stock_before: line.stock_before,
        stock_after: line.stock_after,
        unit: line.row.tracking_unit,
      })),
      warnings: [...new Set(warnings)],
    };
  });

  const alerts = await refreshAiAlerts(pool);
  res.status(201).json({
    ...result,
    alerts: alerts.slice(0, 10),
    recommendations: result.warnings.length ? result.warnings : ['Stock deduit et moyennes recalculees.'],
  });
}));

router.use((err, _req, res, _next) => {
  res.status(400).json({ error: err.message || 'Erreur acte realise.' });
});

module.exports = router;
