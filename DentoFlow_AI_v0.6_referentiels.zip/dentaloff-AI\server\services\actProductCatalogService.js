const crypto = require('crypto');
const { logAudit } = require('./auditService');

const SOURCE_NAME = 'Inventaire actes-produits fourni utilisateur';

const inventoryMatchers = {
  gants_nitrile: ['Gants'],
  masque_chirurgical: ['Masque chirurgical'],
  canule_aspiration: ['Embout aspiration jetable'],
  carpule_anesthesie: ['Anesthesie carpule'],
  aiguille_dentaire: ['Aiguille dentaire'],
  acide_ortho: ['Acide orthophosphorique gel bleu'],
  adhesif_bonding: ['Adhesif dentaire flacon 5 ml', 'Adhesif / bonding'],
  microbrush: ['Microbrush'],
  composite_seringue: ['Resine / composite A2', 'Composite seringue 3 g reference France'],
  composite_flow: ['Composite seringue 3 g reference France'],
  cvi: ['Ciment de scellement'],
  ciment_resine: ['Ciment resine capsule 16 g', 'Ciment de scellement'],
  aiguille_endo: ['Aiguille dentaire'],
  pointe_papier: ['Papier absorbant endo'],
  gutta_percha: ['Gutta percha'],
  ciment_endo: ['Granulotec'],
  alginate: ['Alginate empreinte 450 g'],
  vps_silicone: ['Silicone empreinte cartouche 50 ml'],
  sachet_sterilisation: ['Sachet sterilisation autoclavable 5x20'],
  solution_enzymatique: ['Solution desinfectante instrumentation 5 L'],
  rouleau_coton: ['Coton salivaire / rouleau coton'],
};

const actCatalog = [
  ['consultation_simple', 'Consultation simple', 'Consultation', 'Consultation', 'standard', 'standard', 'Examen clinique, dossier et orientation'],
  ['consultation_urgence', 'Consultation urgence', 'Consultation', 'Urgence', 'standard', 'standard', 'Douleur, trauma, infection ou acte non programme'],
  ['consultation_complexe', 'Consultation complexe', 'Consultation', 'Plan de traitement', 'standard', 'standard', 'Bilan clinique, devis, consentement, courrier'],
  ['odontogramme', 'Odontogramme', 'Diagnostic', 'Bilan', 'standard', 'standard', 'Cartographie dents, surfaces et statuts'],
  ['charting_parodontal', 'Charting parodontal', 'Parodontologie', 'Diagnostic', 'standard', 'standard', 'Sondage, indice plaque et saignement'],
  ['radio_intraorale', 'Radio intra-orale', 'Radiologie', 'Intra-orale', 'cnam_tn_known', 'standard', 'Retro-alveolaire, bite-wing, radio endodontique'],
  ['radio_panoramique', 'Radiographie panoramique', 'Radiologie', 'Extra-orale', 'cnam_tn_known', 'standard', 'Panoramique et bilan global'],
  ['cbct', 'CBCT', 'Radiologie', '3D', 'modern_out_of_nomenclature', 'modern', 'Imagerie 3D pre-implantaire ou chirurgie'],
  ['scan_intraoral', 'Scan intra-oral', 'Numerique', 'Empreinte numerique', 'modern_out_of_nomenclature', 'modern', 'Fichiers STL PLY OBJ pour prothese ou aligneurs'],
  ['photos_cliniques', 'Photos cliniques', 'Numerique', 'Documentation', 'modern_out_of_nomenclature', 'standard', 'Photos patient, sourire, teinte et communication'],
  ['detartrage_sus_gingival', 'Detartrage sus-gingival', 'Prevention', 'Hygiene', 'standard', 'standard', 'Detartrage, polissage et controle plaque'],
  ['aeropolissage', 'Aeropolissage', 'Prevention', 'Prophylaxie', 'modern_out_of_nomenclature', 'modern', 'Poudre prophylaxie et polissage avance'],
  ['fluor_topique', 'Fluor topique', 'Prevention', 'Prevention carieuse', 'standard', 'standard', 'Gel ou vernis fluore'],
  ['scellement_sillons', 'Scellement de sillons', 'Prevention', 'Pedo / prevention', 'standard', 'standard', 'Sealant, isolation et controle occlusal'],
  ['maintenance_parodontale', 'Maintenance parodontale', 'Parodontologie', 'Maintenance', 'standard', 'standard', 'Suivi perio, detartrage et motivation hygiene'],
  ['obturation_1_face', 'Composite 1 face / classe I simple', 'Soins conservateurs', 'Obturation simple', 'cnam_tn_known', 'standard', 'Restauration composite simple'],
  ['obturation_2_faces', 'Composite 2 faces / classe II', 'Soins conservateurs', 'Obturation composee', 'cnam_tn_known', 'standard', 'Composite avec matrice, coin et collage'],
  ['obturation_3_faces', 'Composite 3 faces ou grosse restauration', 'Soins conservateurs', 'Obturation complexe', 'cnam_tn_known', 'standard', 'Restauration etendue avec protocole adhesif'],
  ['classe_v', 'Restauration cervicale classe V', 'Soins conservateurs', 'Classe V', 'standard', 'standard', 'Restauration cervicale composite ou CVI'],
  ['reconstitution_coronaire', 'Reconstitution coronaire', 'Soins conservateurs', 'Core build-up', 'cnam_tn_known', 'specialized', 'Reconstitution avec tenon ou resine core'],
  ['coiffage_indirect', 'Coiffage indirect / liner', 'Soins conservateurs', 'Fond de cavite', 'standard', 'standard', 'Liner, base protectrice, hydroxyde ou bioceramique'],
  ['pansement_provisoire', 'Pansement provisoire', 'Soins conservateurs', 'Urgence', 'standard', 'standard', 'Cavit, IRM ou obturation temporaire'],
  ['ouverture_chambre', 'Ouverture de chambre', 'Endodontie', 'Urgence pulpaire', 'standard', 'standard', 'Acces endodontique et drainage pulpaire'],
  ['pulpotomie', 'Pulpotomie', 'Endodontie', 'Urgence pulpaire', 'standard', 'standard', 'Dent temporaire ou permanente selon indication'],
  ['endo_incisive_canine', 'Traitement endodontique incisive/canine', 'Endodontie', 'Traitement canalaire', 'standard', 'standard', 'Instrumentation, irrigation, obturation'],
  ['endo_premolaire', 'Traitement endodontique premolaire', 'Endodontie', 'Traitement canalaire', 'standard', 'standard', 'Premolaire, 1 a 2 canaux'],
  ['endo_molaire', 'Traitement endodontique molaire', 'Endodontie', 'Traitement canalaire', 'standard', 'specialized', 'Molaire, plusieurs canaux'],
  ['retraitement_endo', 'Retraitement endodontique', 'Endodontie', 'Retraitement', 'standard', 'specialized', 'Desobturation et reprise canalaire'],
  ['extraction_simple', 'Extraction simple', 'Chirurgie orale', 'Extraction', 'cnam_tn_known', 'standard', 'Extraction avec anesthesie et compression'],
  ['extraction_multiple', 'Extraction multiple', 'Chirurgie orale', 'Extraction', 'cnam_tn_known', 'standard', 'Plusieurs dents, hemostase renforcee'],
  ['extraction_chirurgicale', 'Extraction chirurgicale', 'Chirurgie orale', 'Chirurgie', 'cnam_tn_known', 'specialized', 'Lambeau, alveolectomie, suture'],
  ['dent_incluse', 'Extraction dent incluse/enclavee', 'Chirurgie orale', 'Sagesse', 'cnam_tn_known', 'specialized', 'Chirurgie dent incluse ou germectomie'],
  ['incision_drainage', 'Incision drainage abces', 'Chirurgie orale', 'Abces', 'standard', 'standard', 'Drainage, irrigation, prescription'],
  ['curetage_kyste', 'Curetage kyste peri-apical', 'Chirurgie orale', 'Kystes', 'cnam_tn_known', 'specialized', 'Curetage et hemostase'],
  ['frenectomie', 'Frenectomie', 'Chirurgie orale', 'Muqueuse', 'standard', 'specialized', 'Incision et suture'],
  ['surfacage', 'Surfacage radiculaire', 'Parodontologie', 'Non chirurgical', 'standard', 'standard', 'Detartrage sous-gingival et curetage'],
  ['lambeau_assainissement', 'Lambeau assainissement', 'Parodontologie', 'Chirurgie paro', 'standard', 'specialized', 'Chirurgie parodontale'],
  ['greffe_gingivale', 'Greffe gingivale', 'Parodontologie', 'Greffe', 'standard', 'specialized', 'Greffe muco-gingivale'],
  ['obturation_temporaire_enfant', 'Obturation dent temporaire', 'Pedodontie', 'Soins temporaires', 'standard', 'standard', 'Soin conservateur enfant'],
  ['couronne_pedo', 'Couronne pedodontique preformee', 'Pedodontie', 'Prothese pedo', 'standard', 'standard', 'Couronne preformee enfant'],
  ['couronne_ceramique', 'Couronne ceramique', 'Prothese fixe', 'Couronne', 'standard', 'standard', 'Preparation, empreinte ou scan, provisoire, collage'],
  ['couronne_zircone', 'Couronne zircone', 'Prothese fixe', 'Couronne', 'modern_out_of_nomenclature', 'modern', 'Flux CFAO ou laboratoire'],
  ['couronne_metal_ceramique', 'Couronne ceramo-metallique', 'Prothese fixe', 'Couronne', 'standard', 'standard', 'Empreinte, provisoire, scellement'],
  ['bridge_3_elements', 'Bridge 3 elements', 'Prothese fixe', 'Bridge', 'standard', 'standard', 'Preparation multiple, empreinte et scellement'],
  ['facette_ceramique', 'Facette ceramique', 'Esthetique', 'Facette', 'modern_out_of_nomenclature', 'modern', 'Smile design, preparation, collage'],
  ['inlay_onlay', 'Inlay / onlay', 'Prothese fixe', 'Restauratrice indirecte', 'modern_out_of_nomenclature', 'modern', 'Empreinte ou scan, collage'],
  ['empreinte_alginate', 'Empreinte alginate complete', 'Prothese fixe', 'Empreinte', 'standard', 'standard', 'Empreinte complete alginate'],
  ['empreinte_silicone', 'Empreinte silicone VPS', 'Prothese fixe', 'Empreinte', 'standard', 'standard', 'Empreinte complete ou sectorielle VPS'],
  ['depose_couronne', 'Depose couronne / bridge', 'Prothese fixe', 'Depose', 'standard', 'standard', 'Depose prothetique et provisoire'],
  ['prothese_partielle_resine', 'Prothese partielle resine', 'Prothese amovible', 'PPA resine', 'standard', 'standard', 'Empreinte, occlusion, essayage'],
  ['prothese_complete', 'Prothese complete', 'Prothese amovible', 'Complete', 'standard', 'standard', 'Empreintes primaire/secondaire et montage'],
  ['chassis_metal', 'PPA chassis metallique', 'Prothese amovible', 'Chassis', 'standard', 'specialized', 'Empreinte fonctionnelle et labo'],
  ['reparation_prothese', 'Reparation prothese', 'Prothese amovible', 'Reparation', 'standard', 'standard', 'Ajout dent, crochet, fracture plaque'],
  ['implant_unitaire', 'Pose implant unitaire', 'Implantologie', 'Chirurgie', 'modern_out_of_nomenclature', 'specialized', 'Forage, implant, vis de couverture'],
  ['pilier_cicatrisation', 'Pilier de cicatrisation', 'Implantologie', 'Chirurgie', 'modern_out_of_nomenclature', 'modern', 'Deuxieme temps chirurgical'],
  ['couronne_implant', 'Couronne sur implant', 'Implantologie', 'Prothese implantaire', 'modern_out_of_nomenclature', 'modern', 'Scanbody, Ti-base, vis prothetique'],
  ['greffe_osseuse', 'Greffe osseuse', 'Implantologie', 'Chirurgie avancee', 'modern_out_of_nomenclature', 'specialized', 'Biomateriau et membrane'],
  ['sinus_lift', 'Sinus lift', 'Implantologie', 'Chirurgie avancee', 'modern_out_of_nomenclature', 'specialized', 'Greffe sinusienne'],
  ['guide_chirurgical', 'Guide chirurgical', 'Implantologie', 'Numerique', 'modern_out_of_nomenclature', 'modern', 'Planification et guide imprime'],
  ['diagnostic_odf', 'Diagnostic orthodontique', 'Orthodontie', 'Diagnostic', 'standard', 'standard', 'Photos, empreintes/scans, analyse'],
  ['brackets_pose', 'Pose multi-attaches', 'Orthodontie', 'Fixe', 'standard', 'standard', 'Brackets, arcs, ligatures'],
  ['controle_odf', 'Controle orthodontique', 'Orthodontie', 'Suivi', 'standard', 'standard', 'Activation, elastiques, controle'],
  ['aligneur_setup', 'Setup aligneurs', 'Aligneurs', 'Numerique', 'modern_out_of_nomenclature', 'modern', 'Scan, setup et planification'],
  ['aligneur_livraison', 'Livraison aligneurs', 'Aligneurs', 'Traitement', 'modern_out_of_nomenclature', 'modern', 'Attachments, IPR, gouttieres'],
  ['contention', 'Contention orthodontique', 'Orthodontie', 'Contention', 'standard', 'standard', 'Fil colle ou gouttiere'],
  ['blanchiment_fauteuil', 'Blanchiment au fauteuil', 'Esthetique', 'Blanchiment', 'modern_out_of_nomenclature', 'modern', 'Protection gingivale et gel blanchiment'],
  ['blanchiment_ambulatoire', 'Blanchiment ambulatoire', 'Esthetique', 'Blanchiment', 'modern_out_of_nomenclature', 'modern', 'Gouttieres et seringues'],
  ['mockup', 'Mock-up / wax-up', 'Esthetique', 'Smile design', 'modern_out_of_nomenclature', 'modern', 'Projet esthetique direct ou indirect'],
  ['gingivectomie_laser', 'Gingivectomie laser', 'Esthetique', 'Laser', 'modern_out_of_nomenclature', 'modern', 'Laser muqueuse ou gingival'],
  ['gouttiere_bruxisme', 'Gouttiere bruxisme', 'Occlusodontie', 'Gouttiere', 'standard', 'standard', 'Empreinte ou scan et thermoformage'],
  ['acte_labo_couronne', 'Fabrication couronne laboratoire', 'Actes laboratoire lies', 'Couronne', 'lab_linked', 'modern', 'Acte labo rattache cabinet', 'LAB'],
  ['acte_labo_prothese', 'Fabrication prothese laboratoire', 'Actes laboratoire lies', 'Prothese amovible', 'lab_linked', 'standard', 'Acte labo rattache cabinet', 'LAB'],
];

const productCatalog = [
  ['gants_nitrile', 'Gants nitrile', 'EPI et barrieres', 'Gants', 'paire', 'boite 100', 'CABINET', 'low'],
  ['gants_steriles', 'Gants steriles chirurgicaux', 'EPI et barrieres', 'Gants steriles', 'paire', 'paire sterile', 'CABINET', 'medium'],
  ['masque_chirurgical', 'Masque chirurgical', 'EPI et barrieres', 'Masques', 'unite', 'boite 50', 'CABINET', 'low'],
  ['masque_ffp2', 'Masque FFP2/N95', 'EPI et barrieres', 'Masques', 'unite', 'boite', 'CABINET', 'medium'],
  ['bavoir_patient', 'Bavoir patient', 'EPI et barrieres', 'Protection patient', 'unite', 'paquet', 'CABINET', 'low'],
  ['champ_sterile', 'Champ sterile', 'Chirurgie', 'Sterile', 'unite', 'unite', 'CABINET', 'medium'],
  ['film_barriere', 'Film barriere surfaces', 'EPI et barrieres', 'Protection surfaces', 'unite', 'rouleau', 'CABINET', 'low'],
  ['lunettes_patient', 'Lunettes patient', 'EPI et barrieres', 'Protection patient', 'unite', 'unite', 'CABINET', 'low'],
  ['rouleau_coton', 'Coton salivaire / rouleau coton', 'Aspiration et absorbants', 'Absorbants', 'unite', 'sachet', 'CABINET', 'low'],
  ['compresse_sterile', 'Compresses steriles', 'Chirurgie', 'Absorbants steriles', 'unite', 'boite', 'CABINET', 'medium'],
  ['canule_aspiration', 'Canule aspiration salivaire', 'Aspiration et absorbants', 'Aspiration', 'unite', 'sachet', 'CABINET', 'low'],
  ['embout_hve', 'Embout aspiration HVE jetable', 'Aspiration et absorbants', 'Aspiration', 'unite', 'sachet', 'CABINET', 'low'],
  ['filtre_aspiration', 'Filtre / piege aspiration', 'Aspiration et absorbants', 'Aspiration', 'unite', 'unite', 'CABINET', 'medium'],
  ['gobelet', 'Gobelet patient', 'EPI et barrieres', 'Accessoires', 'unite', 'paquet', 'CABINET', 'low'],
  ['solution_enzymatique', 'Solution enzymatique instruments', 'Sterilisation et desinfection', 'Pre-desinfection', 'ml', 'bidon', 'CABINET', 'medium'],
  ['desinfectant_surface', 'Desinfectant surfaces', 'Sterilisation et desinfection', 'Surfaces', 'ml', 'spray / bidon', 'CABINET', 'medium'],
  ['lingette_desinfectante', 'Lingette desinfectante', 'Sterilisation et desinfection', 'Surfaces', 'unite', 'boite', 'CABINET', 'low'],
  ['sachet_sterilisation', 'Sachet sterilisation autoclavable', 'Sterilisation et desinfection', 'Sachets', 'sachet', 'lot', 'CABINET', 'low'],
  ['rouleau_sterilisation', 'Rouleau sterilisation', 'Sterilisation et desinfection', 'Sachets', 'cm', 'rouleau', 'CABINET', 'medium'],
  ['indicateur_chimique', 'Indicateur chimique sterilisation', 'Sterilisation et desinfection', 'Traceabilite', 'unite', 'boite', 'CABINET', 'medium'],
  ['test_helix', 'Test helix / Bowie-Dick', 'Sterilisation et desinfection', 'Tests', 'unite', 'boite', 'CABINET', 'medium'],
  ['gaine_capteur', 'Gaine capteur radio', 'Radiologie', 'Protection capteur', 'unite', 'boite', 'CABINET', 'low'],
  ['pochette_psp', 'Pochette plaque phosphore', 'Radiologie', 'PSP', 'unite', 'boite', 'CABINET', 'low'],
  ['film_intraoral', 'Film intra-oral', 'Radiologie', 'Film', 'unite', 'boite', 'CABINET', 'medium'],
  ['angulateur_radio', 'Angulateur radio / bite tabs', 'Radiologie', 'Accessoires', 'unite', 'kit', 'CABINET', 'low'],
  ['ecarteur_photo', 'Ecarteur photo', 'Numerique', 'Photo', 'unite', 'unite', 'CABINET', 'low'],
  ['miroir_photo', 'Miroir photo intraoral', 'Numerique', 'Photo', 'unite', 'unite', 'CABINET', 'low'],
  ['embout_scanner', 'Embout scanner intraoral', 'Numerique', 'Scan', 'unite', 'boite', 'CABINET', 'medium'],
  ['carpule_anesthesie', 'Anesthesie carpule', 'Anesthesie', 'Carpules', 'carpule', 'boite 50', 'CABINET', 'high'],
  ['aiguille_dentaire', 'Aiguille dentaire', 'Anesthesie', 'Aiguilles', 'unite', 'boite 100', 'CABINET', 'high'],
  ['anesthesique_topique', 'Anesthesique topique gel/spray', 'Anesthesie', 'Topique', 'ml', 'flacon', 'CABINET', 'medium'],
  ['acide_ortho', 'Acide orthophosphorique 37%', 'Restauration', 'Mordancage', 'ml', 'seringue', 'CABINET', 'medium'],
  ['adhesif_bonding', 'Adhesif / bonding universel', 'Restauration', 'Adhesion', 'ml', 'flacon 5 ml', 'CABINET', 'medium'],
  ['primer', 'Primer', 'Restauration', 'Adhesion', 'ml', 'flacon', 'CABINET', 'medium'],
  ['composite_seringue', 'Composite seringue', 'Restauration', 'Composite', 'g', 'seringue 3-4 g', 'CABINET', 'medium'],
  ['composite_flow', 'Composite flow', 'Restauration', 'Composite', 'g', 'seringue', 'CABINET', 'medium'],
  ['composite_compule', 'Composite compule', 'Restauration', 'Composite', 'compule', 'compule', 'CABINET', 'medium'],
  ['cvi', 'Ciment verre ionomere / CVI', 'Restauration', 'CVI', 'g', 'kit / capsule', 'CABINET', 'medium'],
  ['liner', 'Liner / hydroxyde / base', 'Restauration', 'Fond de cavite', 'g', 'seringue', 'CABINET', 'medium'],
  ['matrice_sectionnelle', 'Matrice sectionnelle', 'Restauration', 'Matrices', 'unite', 'boite', 'CABINET', 'medium'],
  ['matrice_tofflemire', 'Matrice Tofflemire', 'Restauration', 'Matrices', 'unite', 'boite', 'CABINET', 'medium'],
  ['coin_interdentaire', 'Coin interdentaire', 'Restauration', 'Coins', 'unite', 'boite', 'CABINET', 'low'],
  ['anneau_separation', 'Anneau separation', 'Restauration', 'Matrices', 'unite', 'unite', 'CABINET', 'medium'],
  ['microbrush', 'Microbrush / micro-applicateur', 'Restauration', 'Applicateurs', 'unite', 'boite', 'CABINET', 'low'],
  ['disque_polissage', 'Disque polissage', 'Restauration', 'Finition', 'unite', 'boite', 'CABINET', 'medium'],
  ['strip_abrasif', 'Strip abrasif', 'Restauration', 'Finition', 'unite', 'boite', 'CABINET', 'low'],
  ['cavit', 'Cavit / obturation provisoire', 'Restauration', 'Temporaire', 'g', 'pot', 'CABINET', 'medium'],
  ['digue', 'Digue dentaire', 'Endodontie', 'Isolation', 'unite', 'boite', 'CABINET', 'medium'],
  ['crampon_digue', 'Crampon digue', 'Endodontie', 'Isolation', 'unite', 'unite', 'CABINET', 'medium'],
  ['lime_k', 'Lime K / H manuelle', 'Endodontie', 'Instruments', 'unite', 'boite', 'CABINET', 'medium'],
  ['lime_niti', 'Lime NiTi rotative', 'Endodontie', 'Instruments', 'unite', 'set', 'CABINET', 'high'],
  ['naocl', 'Hypochlorite de sodium', 'Endodontie', 'Irrigation', 'ml', 'flacon', 'CABINET', 'medium'],
  ['edta', 'EDTA endodontique', 'Endodontie', 'Irrigation', 'ml', 'flacon', 'CABINET', 'medium'],
  ['aiguille_endo', 'Aiguille endodontique side-vented', 'Endodontie', 'Irrigation', 'unite', 'boite', 'CABINET', 'medium'],
  ['pointe_papier', 'Pointes papier', 'Endodontie', 'Sechage', 'unite', 'boite', 'CABINET', 'medium'],
  ['gutta_percha', 'Gutta-percha', 'Endodontie', 'Obturation', 'unite', 'boite', 'CABINET', 'medium'],
  ['ciment_endo', 'Ciment endodontique / bioceramique', 'Endodontie', 'Obturation', 'g', 'seringue', 'CABINET', 'medium'],
  ['hydroxyde_calcium', 'Hydroxyde de calcium', 'Endodontie', 'Medication', 'g', 'seringue', 'CABINET', 'medium'],
  ['tenon_fibre', 'Tenon fibre', 'Restauration', 'Reconstitution', 'unite', 'boite', 'CABINET', 'medium'],
  ['lame_bistouri', 'Lame bistouri', 'Chirurgie', 'Incision', 'unite', 'boite', 'CABINET', 'high'],
  ['fil_suture', 'Fil de suture', 'Chirurgie', 'Suture', 'unite', 'sachet sterile', 'CABINET', 'high'],
  ['eponge_hemostatique', 'Eponge hemostatique', 'Chirurgie', 'Hemostase', 'unite', 'boite', 'CABINET', 'high'],
  ['serum_phy', 'Serum physiologique', 'Chirurgie', 'Irrigation', 'ml', 'flacon / poche', 'CABINET', 'medium'],
  ['canule_chirurgicale', 'Canule chirurgicale sterile', 'Chirurgie', 'Aspiration', 'unite', 'unite sterile', 'CABINET', 'medium'],
  ['biomateriau_osseux', 'Biomateriau osseux', 'Implantologie', 'Greffe', 'g', 'flacon', 'CABINET', 'high'],
  ['membrane_collagene', 'Membrane collagene', 'Implantologie', 'Greffe', 'unite', 'unite', 'CABINET', 'high'],
  ['pate_prophy', 'Pate prophylactique', 'Prophylaxie', 'Polissage', 'g', 'pot', 'CABINET', 'low'],
  ['cupule_prophy', 'Cupule prophylaxie', 'Prophylaxie', 'Polissage', 'unite', 'boite', 'CABINET', 'low'],
  ['poudre_aeropolissage', 'Poudre aeropolissage', 'Prophylaxie', 'Aeropolissage', 'g', 'flacon', 'CABINET', 'medium'],
  ['vernis_fluore', 'Vernis fluore', 'Prophylaxie', 'Fluor', 'ml', 'unidose / flacon', 'CABINET', 'medium'],
  ['alginate', 'Alginate empreinte', 'Empreinte', 'Alginate', 'g', 'sachet 450 g', 'CABINET', 'medium'],
  ['vps_silicone', 'Silicone empreinte VPS', 'Empreinte', 'VPS', 'ml', 'cartouche 50 ml', 'CABINET', 'medium'],
  ['porte_empreinte', 'Porte-empreinte jetable', 'Empreinte', 'Accessoires', 'unite', 'unite', 'CABINET', 'low'],
  ['embout_melangeur', 'Embout melangeur', 'Empreinte', 'Melange', 'unite', 'sachet', 'CABINET', 'medium'],
  ['silicone_occlusion', 'Silicone occlusion', 'Empreinte', 'Occlusion', 'ml', 'cartouche', 'CABINET', 'medium'],
  ['fil_retracteur', 'Fil retracteur', 'Prothese', 'Retraction', 'cm', 'flacon', 'CABINET', 'medium'],
  ['pate_retraction', 'Pate retraction', 'Prothese', 'Retraction', 'ml', 'capsule', 'CABINET', 'medium'],
  ['bisacryl', 'Bis-acryl provisoire', 'Prothese', 'Provisoire', 'g', 'cartouche', 'CABINET', 'medium'],
  ['ciment_provisoire', 'Ciment provisoire', 'Prothese', 'Scellement provisoire', 'g', 'tube', 'CABINET', 'medium'],
  ['ciment_resine', 'Ciment resine', 'Prothese', 'Scellement', 'g', 'capsule / seringue', 'CABINET', 'medium'],
  ['silane', 'Silane', 'Prothese', 'Collage', 'ml', 'flacon', 'CABINET', 'medium'],
  ['primer_zircone', 'Primer zircone/metal', 'Prothese', 'Collage', 'ml', 'flacon', 'CABINET', 'medium'],
  ['boite_prothese', 'Boite prothetique livraison', 'Prothese', 'Envoi labo', 'unite', 'lot', 'BOTH', 'low'],
  ['fiche_labo', 'Fiche laboratoire', 'Prothese', 'Envoi labo', 'unite', 'carnet / PDF', 'BOTH', 'low'],
  ['implant', 'Implant titane', 'Implantologie', 'Implant', 'unite', 'unite', 'CABINET', 'high'],
  ['vis_couverture', 'Vis de couverture', 'Implantologie', 'Composants', 'unite', 'unite', 'CABINET', 'high'],
  ['pilier_cicatrisation', 'Pilier cicatrisation', 'Implantologie', 'Composants', 'unite', 'unite', 'CABINET', 'high'],
  ['scanbody', 'Scanbody implant', 'Implantologie', 'Empreinte implant', 'unite', 'unite', 'CABINET', 'high'],
  ['tibase', 'Ti-base implant', 'Implantologie', 'Prothese implant', 'unite', 'unite', 'BOTH', 'high'],
  ['vis_prothetique', 'Vis prothetique implant', 'Implantologie', 'Prothese implant', 'unite', 'unite', 'BOTH', 'high'],
  ['resine_guide', 'Resine guide chirurgical', 'Laboratoire lie au cabinet', 'Guide', 'ml', 'bouteille', 'LAB', 'high'],
  ['sleeve_guide', 'Douille / sleeve guide chirurgical', 'Implantologie', 'Guide', 'unite', 'unite', 'BOTH', 'high'],
  ['bracket', 'Bracket orthodontique', 'Orthodontie', 'Fixe', 'unite', 'kit', 'CABINET', 'medium'],
  ['arc_ortho', 'Arc orthodontique', 'Orthodontie', 'Fixe', 'unite', 'unite', 'CABINET', 'medium'],
  ['ligature', 'Ligature orthodontique', 'Orthodontie', 'Fixe', 'unite', 'boite', 'CABINET', 'low'],
  ['elastique_ortho', 'Elastique orthodontique', 'Orthodontie', 'Fixe', 'unite', 'sachet', 'CABINET', 'low'],
  ['composite_attachment', 'Composite attachments aligneurs', 'Aligneurs', 'Attachments', 'g', 'seringue', 'CABINET', 'medium'],
  ['strip_ipr', 'Strip IPR', 'Aligneurs', 'IPR', 'unite', 'set', 'CABINET', 'medium'],
  ['chewie', 'Chewie aligneur', 'Aligneurs', 'Accessoires', 'unite', 'sachet', 'CABINET', 'low'],
  ['plaque_thermoformable', 'Plaque thermoformable', 'Orthodontie', 'Contention', 'unite', 'boite', 'BOTH', 'medium'],
  ['fil_contention', 'Fil contention', 'Orthodontie', 'Contention', 'cm', 'bobine', 'CABINET', 'medium'],
  ['gel_blanchiment', 'Gel blanchiment', 'Esthetique', 'Blanchiment', 'ml', 'seringue', 'CABINET', 'medium'],
  ['barriere_gingivale', 'Barriere gingivale photopolymerisable', 'Esthetique', 'Blanchiment', 'g', 'seringue', 'CABINET', 'medium'],
  ['cire_occlusion', 'Cire occlusion', 'Laboratoire lie au cabinet', 'Occlusion', 'unite', 'boite', 'BOTH', 'low'],
  ['resine_3d_modele', 'Resine 3D modele', 'Laboratoire lie au cabinet', 'Modele 3D', 'ml', 'bouteille', 'LAB', 'medium'],
  ['disque_zircone', 'Disque zircone', 'Laboratoire lie au cabinet', 'CFAO', 'disque', 'disque 98 mm', 'LAB', 'high'],
  ['bloc_disilicate', 'Bloc disilicate lithium', 'Laboratoire lie au cabinet', 'CFAO', 'bloc', 'bloc', 'LAB', 'high'],
];

const recipeLines = [
  ['obturation_1_face', 'gants_nitrile', 2, 2, 2, 'paire', 1, 'bonne'],
  ['obturation_1_face', 'masque_chirurgical', 1, 1, 1, 'unite', 1, 'bonne'],
  ['obturation_1_face', 'bavoir_patient', 1, 1, 1, 'unite', 1, 'moyenne'],
  ['obturation_1_face', 'canule_aspiration', 1, 1, 1, 'unite', 1, 'moyenne'],
  ['obturation_1_face', 'acide_ortho', 0.05, 0.075, 0.1, 'ml', 1, 'moyenne'],
  ['obturation_1_face', 'adhesif_bonding', 0.05, 0.075, 0.1, 'ml', 1, 'moyenne'],
  ['obturation_1_face', 'microbrush', 1, 1, 2, 'unite', 1, 'moyenne'],
  ['obturation_1_face', 'composite_seringue', 0.2, 0.25, 0.3, 'g', 1, 'bonne'],
  ['obturation_1_face', 'disque_polissage', 0.5, 1, 2, 'unite', 0, 'faible'],
  ['obturation_2_faces', 'gants_nitrile', 2, 2, 2, 'paire', 1, 'bonne'],
  ['obturation_2_faces', 'masque_chirurgical', 1, 1, 1, 'unite', 1, 'bonne'],
  ['obturation_2_faces', 'bavoir_patient', 1, 1, 1, 'unite', 1, 'moyenne'],
  ['obturation_2_faces', 'canule_aspiration', 1, 1, 1, 'unite', 1, 'moyenne'],
  ['obturation_2_faces', 'carpule_anesthesie', 0.5, 1, 1.5, 'carpule', 0, 'moyenne'],
  ['obturation_2_faces', 'aiguille_dentaire', 1, 1, 1, 'unite', 0, 'moyenne'],
  ['obturation_2_faces', 'acide_ortho', 0.05, 0.075, 0.1, 'ml', 1, 'moyenne'],
  ['obturation_2_faces', 'adhesif_bonding', 0.05, 0.075, 0.1, 'ml', 1, 'moyenne'],
  ['obturation_2_faces', 'microbrush', 1, 2, 2, 'unite', 1, 'moyenne'],
  ['obturation_2_faces', 'composite_seringue', 0.3, 0.4, 0.5, 'g', 1, 'bonne'],
  ['obturation_2_faces', 'matrice_sectionnelle', 1, 1, 1, 'unite', 1, 'moyenne'],
  ['obturation_2_faces', 'coin_interdentaire', 1, 1, 1, 'unite', 1, 'moyenne'],
  ['obturation_2_faces', 'anneau_separation', 0, 1, 1, 'unite', 0, 'faible'],
  ['obturation_3_faces', 'composite_seringue', 0.5, 0.55, 0.6, 'g', 1, 'bonne'],
  ['obturation_3_faces', 'acide_ortho', 0.075, 0.1, 0.15, 'ml', 1, 'moyenne'],
  ['obturation_3_faces', 'adhesif_bonding', 0.075, 0.1, 0.15, 'ml', 1, 'moyenne'],
  ['obturation_3_faces', 'microbrush', 2, 2, 3, 'unite', 1, 'moyenne'],
  ['obturation_3_faces', 'matrice_sectionnelle', 1, 1, 2, 'unite', 1, 'moyenne'],
  ['classe_v', 'composite_flow', 0.1, 0.2, 0.35, 'g', 1, 'moyenne'],
  ['classe_v', 'adhesif_bonding', 0.05, 0.075, 0.1, 'ml', 1, 'moyenne'],
  ['coiffage_indirect', 'liner', 0.05, 0.1, 0.2, 'g', 1, 'faible'],
  ['pansement_provisoire', 'cavit', 0.2, 0.35, 0.5, 'g', 1, 'moyenne'],
  ['endo_incisive_canine', 'digue', 1, 1, 1, 'unite', 1, 'moyenne'],
  ['endo_incisive_canine', 'lime_k', 2, 4, 6, 'unite', 1, 'faible'],
  ['endo_incisive_canine', 'naocl', 5, 10, 20, 'ml', 1, 'moyenne'],
  ['endo_incisive_canine', 'edta', 1, 2, 5, 'ml', 0, 'faible'],
  ['endo_incisive_canine', 'pointe_papier', 3, 5, 8, 'unite', 1, 'moyenne'],
  ['endo_incisive_canine', 'gutta_percha', 1, 2, 4, 'unite', 1, 'moyenne'],
  ['endo_incisive_canine', 'ciment_endo', 0.05, 0.1, 0.2, 'g', 1, 'faible'],
  ['endo_molaire', 'digue', 1, 1, 1, 'unite', 1, 'moyenne'],
  ['endo_molaire', 'lime_niti', 2, 4, 6, 'unite', 1, 'moyenne'],
  ['endo_molaire', 'naocl', 10, 25, 50, 'ml', 1, 'moyenne'],
  ['endo_molaire', 'edta', 2, 5, 10, 'ml', 0, 'faible'],
  ['endo_molaire', 'aiguille_endo', 1, 2, 4, 'unite', 1, 'moyenne'],
  ['endo_molaire', 'pointe_papier', 8, 12, 20, 'unite', 1, 'moyenne'],
  ['endo_molaire', 'gutta_percha', 4, 8, 14, 'unite', 1, 'moyenne'],
  ['endo_molaire', 'ciment_endo', 0.1, 0.2, 0.4, 'g', 1, 'faible'],
  ['extraction_simple', 'carpule_anesthesie', 1, 1, 2, 'carpule', 1, 'moyenne'],
  ['extraction_simple', 'aiguille_dentaire', 1, 1, 1, 'unite', 1, 'moyenne'],
  ['extraction_simple', 'compresse_sterile', 2, 4, 6, 'unite', 1, 'moyenne'],
  ['extraction_simple', 'canule_aspiration', 1, 1, 1, 'unite', 1, 'moyenne'],
  ['extraction_simple', 'fil_suture', 0, 0.3, 1, 'unite', 0, 'faible'],
  ['extraction_chirurgicale', 'champ_sterile', 1, 1, 2, 'unite', 1, 'moyenne'],
  ['extraction_chirurgicale', 'gants_steriles', 1, 1, 1, 'paire', 1, 'moyenne'],
  ['extraction_chirurgicale', 'lame_bistouri', 1, 1, 1, 'unite', 1, 'moyenne'],
  ['extraction_chirurgicale', 'fil_suture', 1, 1, 2, 'unite', 1, 'moyenne'],
  ['extraction_chirurgicale', 'eponge_hemostatique', 0, 1, 2, 'unite', 0, 'faible'],
  ['detartrage_sus_gingival', 'gants_nitrile', 2, 2, 2, 'paire', 1, 'bonne'],
  ['detartrage_sus_gingival', 'masque_chirurgical', 1, 1, 1, 'unite', 1, 'bonne'],
  ['detartrage_sus_gingival', 'canule_aspiration', 1, 1, 1, 'unite', 1, 'moyenne'],
  ['detartrage_sus_gingival', 'pate_prophy', 0.5, 1, 2, 'g', 0, 'faible'],
  ['detartrage_sus_gingival', 'cupule_prophy', 1, 1, 1, 'unite', 0, 'moyenne'],
  ['aeropolissage', 'poudre_aeropolissage', 2, 4, 8, 'g', 1, 'faible'],
  ['fluor_topique', 'vernis_fluore', 0.1, 0.25, 0.5, 'ml', 1, 'faible'],
  ['empreinte_alginate', 'alginate', 20, 25, 30, 'g', 1, 'bonne'],
  ['empreinte_alginate', 'porte_empreinte', 1, 1, 1, 'unite', 0, 'moyenne'],
  ['couronne_ceramique', 'carpule_anesthesie', 1, 1, 2, 'carpule', 0, 'moyenne'],
  ['couronne_ceramique', 'fil_retracteur', 2, 5, 10, 'cm', 0, 'faible'],
  ['couronne_ceramique', 'vps_silicone', 15, 20, 30, 'ml', 1, 'moyenne'],
  ['couronne_ceramique', 'bisacryl', 0.5, 1, 2, 'g', 0, 'faible'],
  ['couronne_ceramique', 'ciment_resine', 0.2, 0.35, 0.5, 'g', 1, 'moyenne'],
  ['couronne_ceramique', 'silane', 0.02, 0.05, 0.1, 'ml', 0, 'faible'],
  ['bridge_3_elements', 'vps_silicone', 25, 35, 50, 'ml', 1, 'moyenne'],
  ['bridge_3_elements', 'ciment_resine', 0.5, 0.75, 1, 'g', 1, 'moyenne'],
  ['bridge_3_elements', 'fil_retracteur', 8, 15, 25, 'cm', 0, 'faible'],
  ['prothese_complete', 'alginate', 40, 50, 70, 'g', 1, 'moyenne'],
  ['prothese_complete', 'vps_silicone', 30, 45, 65, 'ml', 0, 'faible'],
  ['prothese_complete', 'cire_occlusion', 1, 2, 3, 'unite', 1, 'moyenne'],
  ['implant_unitaire', 'champ_sterile', 2, 3, 5, 'unite', 1, 'moyenne'],
  ['implant_unitaire', 'gants_steriles', 1, 1, 2, 'paire', 1, 'moyenne'],
  ['implant_unitaire', 'carpule_anesthesie', 2, 3, 4, 'carpule', 1, 'moyenne'],
  ['implant_unitaire', 'serum_phy', 100, 250, 500, 'ml', 1, 'moyenne'],
  ['implant_unitaire', 'fil_suture', 1, 1, 2, 'unite', 1, 'moyenne'],
  ['implant_unitaire', 'implant', 1, 1, 1, 'unite', 1, 'bonne'],
  ['implant_unitaire', 'vis_couverture', 1, 1, 1, 'unite', 1, 'bonne'],
  ['greffe_osseuse', 'biomateriau_osseux', 0.25, 0.5, 1, 'g', 1, 'faible'],
  ['greffe_osseuse', 'membrane_collagene', 1, 1, 2, 'unite', 1, 'faible'],
  ['couronne_implant', 'scanbody', 1, 1, 1, 'unite', 0, 'moyenne'],
  ['couronne_implant', 'tibase', 1, 1, 1, 'unite', 1, 'moyenne'],
  ['couronne_implant', 'vis_prothetique', 1, 1, 1, 'unite', 1, 'moyenne'],
  ['brackets_pose', 'acide_ortho', 0.4, 0.8, 1.5, 'ml', 1, 'faible'],
  ['brackets_pose', 'adhesif_bonding', 0.4, 0.8, 1.5, 'ml', 1, 'faible'],
  ['brackets_pose', 'bracket', 20, 20, 28, 'unite', 1, 'moyenne'],
  ['brackets_pose', 'arc_ortho', 1, 2, 2, 'unite', 1, 'moyenne'],
  ['controle_odf', 'elastique_ortho', 2, 8, 20, 'unite', 0, 'faible'],
  ['aligneur_livraison', 'composite_attachment', 0.2, 0.5, 1, 'g', 0, 'faible'],
  ['aligneur_livraison', 'strip_ipr', 0, 1, 4, 'unite', 0, 'faible'],
  ['aligneur_livraison', 'chewie', 1, 2, 4, 'unite', 0, 'faible'],
  ['contention', 'fil_contention', 6, 12, 24, 'cm', 0, 'faible'],
  ['contention', 'plaque_thermoformable', 1, 1, 1, 'unite', 0, 'moyenne'],
  ['blanchiment_fauteuil', 'barriere_gingivale', 0.2, 0.5, 1, 'g', 1, 'faible'],
  ['blanchiment_fauteuil', 'gel_blanchiment', 1, 2, 4, 'ml', 1, 'faible'],
  ['gouttiere_bruxisme', 'alginate', 25, 35, 50, 'g', 0, 'moyenne'],
  ['gouttiere_bruxisme', 'plaque_thermoformable', 1, 1, 2, 'unite', 1, 'moyenne'],
  ['guide_chirurgical', 'resine_guide', 20, 35, 60, 'ml', 1, 'faible'],
  ['acte_labo_couronne', 'disque_zircone', 0.05, 0.08, 0.12, 'disque', 0, 'faible'],
  ['acte_labo_couronne', 'bloc_disilicate', 1, 1, 1, 'bloc', 0, 'faible'],
  ['acte_labo_prothese', 'boite_prothese', 1, 1, 1, 'unite', 0, 'moyenne'],
];

function normalizeName(value) {
  return String(value || '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, ' ')
    .trim();
}

function decimalOrNull(value) {
  if (value === null || value === undefined || value === '') return null;
  const n = Number(value);
  return Number.isFinite(n) ? n : null;
}

function normalizeUnit(value) {
  const unit = normalizeName(value);
  const aliases = {
    unite: 'unite',
    piece: 'unite',
    pieces: 'unite',
    u: 'unite',
    sachet: 'sachet',
    paire: 'paire',
    paires: 'paire',
    carpule: 'carpule',
    carpules: 'carpule',
    g: 'g',
    gramme: 'g',
    grammes: 'g',
    ml: 'ml',
    millilitre: 'ml',
    millilitres: 'ml',
    cm: 'cm',
    centimetre: 'cm',
    centimetres: 'cm',
    compule: 'compule',
    disque: 'disque',
    bloc: 'bloc',
  };
  return aliases[unit] || unit;
}

function unitsMatch(left, right) {
  return normalizeUnit(left) === normalizeUnit(right);
}

async function findExistingInventoryProduct(db, productKey, productName) {
  const [[exact]] = await db.query(
    'SELECT * FROM inventory_products WHERE is_active = 1 AND LOWER(name) = LOWER(?) LIMIT 1',
    [productName]
  );
  if (exact) return exact;

  const candidates = inventoryMatchers[productKey] || [];
  for (const candidate of candidates) {
    const [[row]] = await db.query(
      'SELECT * FROM inventory_products WHERE is_active = 1 AND LOWER(name) = LOWER(?) LIMIT 1',
      [candidate]
    );
    if (row) return row;
  }

  const normalized = normalizeName(productName);
  if (!normalized) return null;
  const [[alias]] = await db.query(
    `SELECT ip.*
     FROM reference_aliases ra
     JOIN inventory_products ip ON ip.id = ra.canonical_id AND ip.is_active = 1
     WHERE ra.entity_type = 'consumable'
       AND ra.normalized_alias = ?
     LIMIT 1`,
    [normalized]
  );
  return alias || null;
}

function estimateRecipeCost(row) {
  const quantityMin = decimalOrNull(row.consumption_min);
  const quantityTypical = decimalOrNull(row.consumption_typical);
  const quantityMax = decimalOrNull(row.consumption_max);
  const packageQuantity = decimalOrNull(row.stock_package_quantity);
  const realPackagePrice = decimalOrNull(row.stock_package_price_tnd);
  const referencePackagePrice = decimalOrNull(row.stock_reference_price_tnd_avg);
  const stockUnit = row.stock_tracking_unit;

  if (!row.stock_product_id) {
    return {
      unit_cost_tnd: null,
      unit_cost_source: null,
      unit_cost_status: 'unavailable',
      estimated_cost_tnd_min: null,
      estimated_cost_tnd_typical: null,
      estimated_cost_tnd_max: null,
      cost_validation_status: 'none',
    };
  }
  if (!unitsMatch(row.unit, stockUnit)) {
    return {
      unit_cost_tnd: null,
      unit_cost_source: `Unite differente: recette ${row.unit || '-'} / stock ${stockUnit || '-'}`,
      unit_cost_status: 'conflict',
      estimated_cost_tnd_min: null,
      estimated_cost_tnd_typical: null,
      estimated_cost_tnd_max: null,
      cost_validation_status: 'conflict',
    };
  }
  if (!packageQuantity || packageQuantity <= 0) {
    return {
      unit_cost_tnd: null,
      unit_cost_source: 'Conditionnement stock manquant',
      unit_cost_status: 'unavailable',
      estimated_cost_tnd_min: null,
      estimated_cost_tnd_typical: null,
      estimated_cost_tnd_max: null,
      cost_validation_status: 'none',
    };
  }

  let packagePrice = null;
  let source = null;
  let status = 'unavailable';
  let validation = 'none';
  if (realPackagePrice && realPackagePrice > 0 && Number(row.stock_is_real_price || 0) === 1) {
    packagePrice = realPackagePrice;
    source = `Prix reel stock: ${row.stock_product_name}`;
    status = 'real_stock';
    validation = 'validated';
  } else if (referencePackagePrice && referencePackagePrice > 0 && row.stock_price_validation_status === 'candidate') {
    packagePrice = referencePackagePrice;
    source = `Prix indicatif candidat: ${row.stock_product_name}`;
    status = 'candidate_reference';
    validation = 'candidate';
  }

  if (!packagePrice) {
    return {
      unit_cost_tnd: null,
      unit_cost_source: 'Prix reel ou indicatif manquant',
      unit_cost_status: 'unavailable',
      estimated_cost_tnd_min: null,
      estimated_cost_tnd_typical: null,
      estimated_cost_tnd_max: null,
      cost_validation_status: 'none',
    };
  }

  const unitCost = packagePrice / packageQuantity;
  return {
    unit_cost_tnd: unitCost,
    unit_cost_source: source,
    unit_cost_status: status,
    estimated_cost_tnd_min: quantityMin === null ? null : quantityMin * unitCost,
    estimated_cost_tnd_typical: quantityTypical === null ? null : quantityTypical * unitCost,
    estimated_cost_tnd_max: quantityMax === null ? null : quantityMax * unitCost,
    cost_validation_status: validation,
  };
}

async function logImport(db, runId, entityType, operation, entityId, label, details = {}) {
  await db.query(
    `INSERT INTO act_product_catalog_import_logs
       (run_id, entity_type, operation, entity_id, label, details_json)
     VALUES (?, ?, ?, ?, ?, ?)`,
    [runId, entityType, operation, entityId || null, label || null, JSON.stringify(details).slice(0, 5000)]
  );
}

async function importActProductCatalog(db, req) {
  const runId = `apc-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`;
  const summary = { run_id: runId, acts: 0, products: 0, recipes: 0, aliases: 0, conflicts: 0 };
  const actIds = new Map();
  const productIds = new Map();

  for (const [key, name, family, subfamily, nomenclature, modernity, context, contextType = 'CABINET'] of actCatalog) {
    const [[existingClinical]] = await db.query(
      'SELECT id FROM clinical_acts WHERE is_active = 1 AND LOWER(name) = LOWER(?) LIMIT 1',
      [name]
    );
    await db.query(
      `INSERT INTO dental_act_catalog
         (act_key, act_name, family, subfamily, nomenclature_status, modernity_status, clinical_context,
          context_type, source_name, validation_status, target_clinical_act_id)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'candidate', ?)
       ON DUPLICATE KEY UPDATE
         act_name = IF(validation_status = 'validated', act_name, VALUES(act_name)),
         family = IF(validation_status = 'validated', family, VALUES(family)),
         subfamily = IF(validation_status = 'validated', subfamily, VALUES(subfamily)),
         clinical_context = IF(validation_status = 'validated', clinical_context, VALUES(clinical_context)),
         target_clinical_act_id = COALESCE(target_clinical_act_id, VALUES(target_clinical_act_id))`,
      [key, name, family, subfamily, nomenclature, modernity, context, contextType, SOURCE_NAME, existingClinical?.id || null]
    );
    const [[act]] = await db.query('SELECT id FROM dental_act_catalog WHERE act_key = ?', [key]);
    actIds.set(key, act.id);
    summary.acts += 1;
  }
  await logImport(db, runId, 'dental_act_catalog', 'updated', null, 'dental_act_catalog', { count: summary.acts });

  for (const [key, name, category, subcategory, unit, typicalPackage, contextType, riskLevel] of productCatalog) {
    const existingProduct = await findExistingInventoryProduct(db, key, name);
    await db.query(
      `INSERT INTO dental_product_catalog
         (product_key, product_name, category, subcategory, tracking_unit, typical_package,
          context_type, risk_level, source_name, validation_status, target_inventory_product_id)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'candidate', ?)
       ON DUPLICATE KEY UPDATE
         product_name = IF(validation_status = 'validated', product_name, VALUES(product_name)),
         category = IF(validation_status = 'validated', category, VALUES(category)),
         subcategory = IF(validation_status = 'validated', subcategory, VALUES(subcategory)),
         tracking_unit = IF(validation_status = 'validated', tracking_unit, VALUES(tracking_unit)),
         typical_package = IF(validation_status = 'validated', typical_package, VALUES(typical_package)),
         target_inventory_product_id = COALESCE(target_inventory_product_id, VALUES(target_inventory_product_id))`,
      [key, name, category, subcategory, unit, typicalPackage, contextType, riskLevel, SOURCE_NAME, existingProduct?.id || null]
    );
    const [[product]] = await db.query('SELECT id FROM dental_product_catalog WHERE product_key = ?', [key]);
    productIds.set(key, product.id);
    summary.products += 1;

    if (existingProduct?.id) {
      await db.query(
        `INSERT INTO reference_aliases
           (entity_type, canonical_id, alias_name, normalized_alias, confidence_score, validated_by_user)
         VALUES ('consumable', ?, ?, ?, 0.8500, 0)
         ON DUPLICATE KEY UPDATE confidence_score = GREATEST(confidence_score, VALUES(confidence_score))`,
        [existingProduct.id, name, normalizeName(name)]
      );
      summary.aliases += 1;
    }
  }
  await logImport(db, runId, 'dental_product_catalog', 'updated', null, 'dental_product_catalog', { count: summary.products });

  for (const [actKey, productKey, min, typical, max, unit, required, confidence] of recipeLines) {
    const actId = actIds.get(actKey);
    const productId = productIds.get(productKey);
    if (!actId || !productId) continue;
    const recipeKey = `${actKey}:${productKey}`;
    await db.query(
      `INSERT INTO act_product_recipes
         (recipe_key, act_catalog_id, product_catalog_id, recipe_variant,
          consumption_min, consumption_typical, consumption_max, unit, required,
          context_type, confidence_level, source_name, validation_status, notes)
       VALUES (?, ?, ?, 'Standard', ?, ?, ?, ?, ?, 'CABINET', ?, ?, 'pending', 'Consommation candidate a recalibrer cabinet')
       ON DUPLICATE KEY UPDATE
         consumption_min = IF(validation_status = 'validated', consumption_min, VALUES(consumption_min)),
         consumption_typical = IF(validation_status = 'validated', consumption_typical, VALUES(consumption_typical)),
         consumption_max = IF(validation_status = 'validated', consumption_max, VALUES(consumption_max)),
         unit = IF(validation_status = 'validated', unit, VALUES(unit)),
         required = IF(validation_status = 'validated', required, VALUES(required)),
         confidence_level = IF(validation_status = 'validated', confidence_level, VALUES(confidence_level))`,
      [recipeKey, actId, productId, min, typical, max, unit, required, confidence, SOURCE_NAME]
    );
    summary.recipes += 1;
  }
  await logImport(db, runId, 'act_product_recipes', 'updated', null, 'act_product_recipes', { count: summary.recipes });

  const costs = await refreshRecipeCostEstimates(db);
  summary.costed_recipes = costs.costed;
  summary.cost_conflicts = costs.conflicts;
  await detectRecipeConflicts(db, summary);
  await logAudit(db, req, { action: 'ACT_PRODUCT_CATALOG_IMPORT', entity_type: 'act_product_catalog', entity_id: runId, details: summary });
  return summary;
}

async function fetchRecipeRowsForCost(db) {
  const [rows] = await db.query(
    `SELECT apr.id, apr.consumption_min, apr.consumption_typical, apr.consumption_max, apr.unit,
            ip.id AS stock_product_id, ip.name AS stock_product_name,
            ip.tracking_unit AS stock_tracking_unit, ip.package_quantity AS stock_package_quantity,
            ip.package_price_tnd AS stock_package_price_tnd,
            ip.reference_price_tnd_avg AS stock_reference_price_tnd_avg,
            ip.price_validation_status AS stock_price_validation_status,
            ip.is_real_price AS stock_is_real_price
     FROM act_product_recipes apr
     JOIN dental_product_catalog dpc ON dpc.id = apr.product_catalog_id
     LEFT JOIN inventory_products ip ON ip.id = dpc.target_inventory_product_id`
  );
  return rows;
}

async function refreshRecipeCostEstimates(db) {
  const rows = await fetchRecipeRowsForCost(db);
  const summary = { costed: 0, conflicts: 0, unavailable: 0 };
  for (const row of rows) {
    const estimate = estimateRecipeCost(row);
    if (estimate.unit_cost_status === 'real_stock' || estimate.unit_cost_status === 'candidate_reference') summary.costed += 1;
    else if (estimate.unit_cost_status === 'conflict') summary.conflicts += 1;
    else summary.unavailable += 1;

    await db.query(
      `UPDATE act_product_recipes
       SET unit_cost_tnd = ?,
           unit_cost_source = ?,
           unit_cost_status = ?,
           estimated_cost_tnd_min = ?,
           estimated_cost_tnd_typical = ?,
           estimated_cost_tnd_max = ?,
           cost_validation_status = ?
       WHERE id = ?`,
      [
        estimate.unit_cost_tnd,
        estimate.unit_cost_source,
        estimate.unit_cost_status,
        estimate.estimated_cost_tnd_min,
        estimate.estimated_cost_tnd_typical,
        estimate.estimated_cost_tnd_max,
        estimate.cost_validation_status,
        row.id,
      ]
    );
  }
  return summary;
}

async function detectRecipeConflicts(db, summary) {
  const [rows] = await db.query(
    `SELECT apr.*, dac.act_name, dpc.product_name, ca.id AS clinical_act_id, ip.id AS inventory_product_id,
            ar.id AS real_recipe_id, ar.quantity_per_act, ar.unit AS real_unit
     FROM act_product_recipes apr
     JOIN dental_act_catalog dac ON dac.id = apr.act_catalog_id
     JOIN dental_product_catalog dpc ON dpc.id = apr.product_catalog_id
     LEFT JOIN clinical_acts ca ON ca.id = dac.target_clinical_act_id
     LEFT JOIN inventory_products ip ON ip.id = dpc.target_inventory_product_id
     LEFT JOIN act_recipes ar ON ar.act_id = ca.id AND ar.product_id = ip.id AND ar.active = 1
     WHERE ar.id IS NOT NULL`
  );
  for (const row of rows) {
    const real = Number(row.quantity_per_act);
    const min = row.consumption_min === null ? null : Number(row.consumption_min);
    const max = row.consumption_max === null ? null : Number(row.consumption_max);
    const unitConflict = normalizeName(row.unit) !== normalizeName(row.real_unit);
    const quantityConflict = Number.isFinite(real) && ((min !== null && real < min) || (max !== null && real > max));
    if (!unitConflict && !quantityConflict) continue;
    const reason = unitConflict ? 'Unite differente recette reelle / referentiel' : 'Quantite reelle hors fourchette candidate';
    await db.query(
      `INSERT INTO reference_conflicts
         (conflict_key, entity_type, entity_id, field_name, current_value, new_value,
          source_current, source_new, severity, status)
       VALUES (?, 'act_product_recipe', ?, ?, ?, ?, 'act_recipes', ?, 'warning', 'pending')
       ON DUPLICATE KEY UPDATE new_value = VALUES(new_value), status = IF(status = 'merged', status, 'pending')`,
      [
        `act_product_recipe:${row.id}:${reason}`,
        row.id,
        unitConflict ? 'unit' : 'quantity_per_act',
        unitConflict ? row.real_unit : row.quantity_per_act,
        unitConflict ? row.unit : `${row.consumption_min}-${row.consumption_typical}-${row.consumption_max}`,
        SOURCE_NAME,
      ]
    );
    await db.query('UPDATE act_product_recipes SET validation_status = ? WHERE id = ? AND validation_status <> ?', ['conflict', row.id, 'validated']);
    summary.conflicts += 1;
  }
}

function buildWhere(query, fields) {
  const where = [];
  const values = [];
  if (query.status) { where.push('validation_status = ?'); values.push(query.status); }
  if (query.family && fields.family) { where.push(`${fields.family} = ?`); values.push(query.family); }
  if (query.category && fields.category) { where.push(`${fields.category} = ?`); values.push(query.category); }
  if (query.q && fields.q) {
    where.push(fields.q.map(field => `${field} LIKE ?`).join(' OR '));
    for (const _field of fields.q) values.push(`%${query.q}%`);
  }
  return { clause: where.length ? `WHERE ${where.map(item => item.includes(' OR ') ? `(${item})` : item).join(' AND ')}` : '', values };
}

async function listActs(db, query = {}) {
  const { clause, values } = buildWhere(query, { family: 'family', q: ['act_name', 'family', 'subfamily'] });
  const limit = Math.min(Number(query.limit || 250), 500);
  const [rows] = await db.query(`SELECT * FROM dental_act_catalog ${clause} ORDER BY family, subfamily, act_name LIMIT ?`, [...values, limit]);
  return rows;
}

async function listProducts(db, query = {}) {
  const { clause, values } = buildWhere(query, { category: 'category', q: ['product_name', 'category', 'subcategory'] });
  const limit = Math.min(Number(query.limit || 250), 500);
  const [rows] = await db.query(`SELECT * FROM dental_product_catalog ${clause} ORDER BY category, subcategory, product_name LIMIT ?`, [...values, limit]);
  return rows;
}

async function listRecipes(db, query = {}) {
  const where = [];
  const values = [];
  if (query.status) { where.push('apr.validation_status = ?'); values.push(query.status); }
  if (query.family) { where.push('dac.family = ?'); values.push(query.family); }
  if (query.category) { where.push('dpc.category = ?'); values.push(query.category); }
  if (query.q) {
    where.push('(dac.act_name LIKE ? OR dpc.product_name LIKE ? OR dac.family LIKE ? OR dpc.category LIKE ?)');
    const like = `%${query.q}%`;
    values.push(like, like, like, like);
  }
  const limit = Math.min(Number(query.limit || 300), 700);
  const [rows] = await db.query(
    `SELECT apr.*, dac.act_key, dac.act_name, dac.family, dac.subfamily,
            dpc.product_key, dpc.product_name, dpc.category, dpc.subcategory,
            ip.id AS stock_product_id, ip.name AS stock_product_name,
            ip.tracking_unit AS stock_tracking_unit, ip.package_quantity AS stock_package_quantity,
            ip.package_price_tnd AS stock_package_price_tnd,
            ip.reference_price_tnd_avg AS stock_reference_price_tnd_avg,
            ip.price_validation_status AS stock_price_validation_status,
            ip.is_real_price AS stock_is_real_price
     FROM act_product_recipes apr
     JOIN dental_act_catalog dac ON dac.id = apr.act_catalog_id
     JOIN dental_product_catalog dpc ON dpc.id = apr.product_catalog_id
     LEFT JOIN inventory_products ip ON ip.id = dpc.target_inventory_product_id
     ${where.length ? `WHERE ${where.join(' AND ')}` : ''}
     ORDER BY dac.family, dac.act_name, dpc.product_name
     LIMIT ?`,
    [...values, limit]
  );
  return rows.map(row => ({ ...row, ...estimateRecipeCost(row) }));
}

async function listLogs(db) {
  const [rows] = await db.query('SELECT * FROM act_product_catalog_import_logs ORDER BY created_at DESC, id DESC LIMIT 200');
  return rows;
}

async function getDashboard(db) {
  const [[acts]] = await db.query("SELECT COUNT(*) total, SUM(validation_status='candidate') candidates, SUM(validation_status='validated') validated, SUM(validation_status='conflict') conflicts FROM dental_act_catalog");
  const [[products]] = await db.query("SELECT COUNT(*) total, SUM(validation_status='candidate') candidates, SUM(validation_status='validated') validated, SUM(validation_status='conflict') conflicts FROM dental_product_catalog");
  const [[recipes]] = await db.query("SELECT COUNT(*) total, SUM(validation_status='pending') pending, SUM(validation_status='validated') validated, SUM(validation_status='conflict') conflicts FROM act_product_recipes");
  return { acts, products, recipes };
}

async function updateStatus(db, table, id, status, req) {
  const allowedTables = new Set(['dental_act_catalog', 'dental_product_catalog']);
  const allowedStatus = new Set(['candidate', 'validated', 'rejected', 'conflict']);
  if (!allowedTables.has(table) || !allowedStatus.has(status)) throw new Error('Validation non autorisee.');
  await db.query(`UPDATE ${table} SET validation_status = ? WHERE id = ?`, [status, id]);
  await logAudit(db, req, { action: 'ACT_PRODUCT_CATALOG_STATUS', entity_type: table, entity_id: id, details: { status } });
  const [[row]] = await db.query(`SELECT * FROM ${table} WHERE id = ?`, [id]);
  return row;
}

async function updateRecipeStatus(db, id, status, req) {
  const allowedStatus = new Set(['pending', 'validated', 'rejected', 'conflict']);
  if (!allowedStatus.has(status)) throw new Error('Validation recette non autorisee.');
  await db.query(
    'UPDATE act_product_recipes SET validation_status = ?, validated_by_user = ? WHERE id = ?',
    [status, status === 'validated' ? 1 : 0, id]
  );
  await logAudit(db, req, { action: 'ACT_PRODUCT_RECIPE_STATUS', entity_type: 'act_product_recipes', entity_id: id, details: { status } });
  const [[row]] = await db.query('SELECT * FROM act_product_recipes WHERE id = ?', [id]);
  return row;
}

async function createProductCandidate(db, productCatalogId, req) {
  const [[product]] = await db.query('SELECT * FROM dental_product_catalog WHERE id = ?', [productCatalogId]);
  if (!product) return null;
  const proposal = {
    name: product.product_name,
    category: product.category,
    sub_category: product.subcategory,
    tracking_unit: product.tracking_unit,
    package_unit: product.tracking_unit,
    typical_package: product.typical_package,
    context_type: product.context_type,
    source: SOURCE_NAME,
    validation_required: true,
  };
  await db.query(
    `INSERT INTO reference_product_candidates
       (source_table, source_id, candidate_name, category, context_type, proposal_json, status, created_by)
     VALUES ('dental_product_catalog', ?, ?, ?, ?, ?, 'candidate', ?)
     ON DUPLICATE KEY UPDATE proposal_json = VALUES(proposal_json), status = IF(status = 'converted', status, 'candidate')`,
    [product.id, product.product_name, product.category, product.context_type, JSON.stringify(proposal), req?.user?.username || req?.user?.role || 'admin']
  );
  await logAudit(db, req, { action: 'DENTAL_PRODUCT_CREATE_REAL_CANDIDATE', entity_type: 'dental_product_catalog', entity_id: product.id, details: proposal });
  const [[candidate]] = await db.query('SELECT * FROM reference_product_candidates WHERE source_table = ? AND source_id = ?', ['dental_product_catalog', product.id]);
  return candidate;
}

module.exports = {
  importActProductCatalog,
  listActs,
  listProducts,
  listRecipes,
  listLogs,
  getDashboard,
  updateStatus,
  updateRecipeStatus,
  createProductCandidate,
};
