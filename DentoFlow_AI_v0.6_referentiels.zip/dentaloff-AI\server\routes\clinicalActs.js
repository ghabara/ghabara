const express = require('express');
const { pool } = require('../db');
const { auth, adminOnly, docteurOnly } = require('../middleware/auth');
const { calculateActCost, refreshAiAlerts } = require('../services/inventoryService');

const router = express.Router();
const asyncHandler = fn => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

function cleanActPayload(body) {
  return {
    name: String(body.name || '').trim(),
    clinical_variant: String(body.clinical_variant || 'Standard').trim() || 'Standard',
    category: String(body.category || '').trim() || null,
    default_duration_minutes: body.default_duration_minutes ? Number(body.default_duration_minutes) : null,
    default_price_tnd: body.default_price_tnd === '' || body.default_price_tnd === undefined ? null : Number(body.default_price_tnd),
    context_type: body.context_type === 'LAB' ? 'LAB' : 'CABINET',
    notes: String(body.notes || '').trim() || null,
  };
}

router.get('/', auth, adminOnly, asyncHandler(async (_req, res) => {
  const [acts] = await pool.query(`
    SELECT a.*,
           COUNT(r.id) AS recipe_line_count
    FROM clinical_acts a
    LEFT JOIN act_recipes r ON r.act_id = a.id
    WHERE a.is_active = 1
    GROUP BY a.id
    ORDER BY a.name, a.clinical_variant
  `);
  const out = [];
  for (const act of acts) {
    const cost = await calculateActCost(pool, act.id);
    out.push({
      ...act,
      cost_summary: {
        total_cost_tnd: cost.total_cost_tnd,
        partial_cost_tnd: cost.partial_cost_tnd,
        unknown_cost_count: cost.unknown_cost_count,
        possible_floor: cost.possible_floor,
        limiting_product: cost.limiting_product,
        reliability_score: cost.reliability_score,
      },
    });
  }
  res.json(out);
}));

router.get('/:id/cost', auth, adminOnly, asyncHandler(async (req, res) => {
  const [[act]] = await pool.query('SELECT * FROM clinical_acts WHERE id = ?', [req.params.id]);
  if (!act) return res.status(404).json({ error: 'Acte introuvable.' });
  const summary = await calculateActCost(pool, req.params.id);
  res.json({ act, ...summary });
}));

router.post('/', auth, docteurOnly, asyncHandler(async (req, res) => {
  const data = cleanActPayload(req.body);
  if (!data.name) return res.status(400).json({ error: 'Nom de l acte requis.' });
  if (data.default_duration_minutes !== null && (!Number.isFinite(data.default_duration_minutes) || data.default_duration_minutes < 0)) {
    return res.status(400).json({ error: 'Duree invalide.' });
  }
  if (data.default_price_tnd !== null && (!Number.isFinite(data.default_price_tnd) || data.default_price_tnd < 0)) {
    return res.status(400).json({ error: 'Prix invalide.' });
  }
  const [result] = await pool.query(
    `INSERT INTO clinical_acts
       (name, clinical_variant, category, default_duration_minutes, default_price_tnd, context_type, notes)
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
    [
      data.name,
      data.clinical_variant,
      data.category,
      data.default_duration_minutes,
      data.default_price_tnd,
      data.context_type,
      data.notes,
    ]
  );
  await refreshAiAlerts(pool);
  const [[act]] = await pool.query('SELECT * FROM clinical_acts WHERE id = ?', [result.insertId]);
  res.status(201).json(act);
}));

router.put('/:id', auth, docteurOnly, asyncHandler(async (req, res) => {
  const data = cleanActPayload(req.body);
  if (!data.name) return res.status(400).json({ error: 'Nom de l acte requis.' });
  await pool.query(
    `UPDATE clinical_acts
     SET name = ?, clinical_variant = ?, category = ?, default_duration_minutes = ?,
         default_price_tnd = ?, context_type = ?, notes = ?, is_active = ?
     WHERE id = ?`,
    [
      data.name,
      data.clinical_variant,
      data.category,
      data.default_duration_minutes,
      data.default_price_tnd,
      data.context_type,
      data.notes,
      req.body.is_active === 0 || req.body.is_active === false ? 0 : 1,
      req.params.id,
    ]
  );
  await refreshAiAlerts(pool);
  const [[act]] = await pool.query('SELECT * FROM clinical_acts WHERE id = ?', [req.params.id]);
  if (!act) return res.status(404).json({ error: 'Acte introuvable.' });
  res.json(act);
}));

router.delete('/:id', auth, docteurOnly, asyncHandler(async (req, res) => {
  await pool.query('UPDATE clinical_acts SET is_active = 0 WHERE id = ?', [req.params.id]);
  await refreshAiAlerts(pool);
  res.json({ ok: true });
}));

router.use((err, _req, res, _next) => {
  res.status(400).json({ error: err.message || 'Erreur actes cliniques.' });
});

module.exports = router;
