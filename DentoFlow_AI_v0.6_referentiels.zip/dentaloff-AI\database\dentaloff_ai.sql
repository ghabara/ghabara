﻿-- ╔══════════════════════════════════════════════════════════╗
-- ║  DentoFlow AI — Base de données MySQL                         ║
-- ║  À importer dans phpMyAdmin (XAMPP)                        ║
-- ╚══════════════════════════════════════════════════════════╝

CREATE DATABASE IF NOT EXISTS dentaloff_ai
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE dentaloff_ai;

-- ── PATIENTS ────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS patients (
  id_patient    VARCHAR(12) PRIMARY KEY,          -- ex : PAT-0001
  prenom        VARCHAR(80)  NOT NULL,
  nom           VARCHAR(80)  NOT NULL,
  age           INT,
  genre         VARCHAR(20),
  tel           VARCHAR(20),
  email         VARCHAR(150) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  created_at    DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- ── ADMINS / DOCTEURS ───────────────────────────────────────
CREATE TABLE IF NOT EXISTS admins (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  username      VARCHAR(60)  NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role          ENUM('admin','docteur','assistant','secretaire') DEFAULT 'admin'
);

-- ── DOSSIERS MÉDICAUX (id_dossier = id_patient) ─────────────
CREATE TABLE IF NOT EXISTS dossiers (
  id_dossier     VARCHAR(12) PRIMARY KEY,         -- = id_patient
  id_patient     VARCHAR(12) NOT NULL,
  groupe_sanguin VARCHAR(10),
  allergies      TEXT,
  antecedents    TEXT,
  created_by     VARCHAR(60) DEFAULT 'admin',
  created_at     DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (id_patient) REFERENCES patients(id_patient) ON DELETE CASCADE
);

-- ── DOCUMENTS DU DOSSIER ────────────────────────────────────
CREATE TABLE IF NOT EXISTS documents (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  id_dossier VARCHAR(12) NOT NULL,
  name       VARCHAR(255),
  type       VARCHAR(100),
  size       VARCHAR(40),
  file_path  VARCHAR(255),
  added_at   DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (id_dossier) REFERENCES dossiers(id_dossier) ON DELETE CASCADE
);

-- ── ORDONNANCES ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS ordonnances (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  id_dossier VARCHAR(12) NOT NULL,
  medecin    VARCHAR(120),
  contenu    TEXT,
  date       DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (id_dossier) REFERENCES dossiers(id_dossier) ON DELETE CASCADE
);

-- ── RENDEZ-VOUS ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS rendez_vous (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  ref         VARCHAR(30),
  id_patient  VARCHAR(12),
  patient_nom VARCHAR(160),
  patient_tel VARCHAR(20),
  patient_email VARCHAR(150),
  service     VARCHAR(120),
  prix        VARCHAR(40),
  date        VARCHAR(20),
  heure       VARCHAR(20),
  statut      ENUM('pending','confirmed','arrived','in_treatment','done','cancelled','no_show') DEFAULT 'pending',
  duration_minutes INT DEFAULT 30,
  practitioner VARCHAR(120) DEFAULT 'Docteur',
  chair       VARCHAR(80) DEFAULT 'Fauteuil 1',
  room        VARCHAR(80),
  notes       TEXT,
  planned_act_id INT,
  created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (id_patient) REFERENCES patients(id_patient) ON DELETE SET NULL
);

-- ── SERVICES & TARIFS ───────────────────────────────────────
CREATE TABLE IF NOT EXISTS services (
  id    INT AUTO_INCREMENT PRIMARY KEY,
  ico   VARCHAR(10),
  name  VARCHAR(120),
  prix  VARCHAR(40),
  descr TEXT
);

-- ── HORAIRES ────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS horaires (
  id        INT AUTO_INCREMENT PRIMARY KEY,
  jour      VARCHAR(20),
  ouverture VARCHAR(10),
  fermeture VARCHAR(10),
  ferme     TINYINT DEFAULT 0
);

-- ── INFOS CABINET ───────────────────────────────────────────
CREATE TABLE IF NOT EXISTS cabinet_info (
  id     INT PRIMARY KEY DEFAULT 1,
  name   VARCHAR(120),
  doctor VARCHAR(120),
  tel    VARCHAR(40),
  email  VARCHAR(150),
  addr   VARCHAR(255)
);

-- ── NOTES PATIENTS (suivi médecin) ──────────────────────────
CREATE TABLE IF NOT EXISTS notes (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  id_patient VARCHAR(12),
  date       VARCHAR(20),
  texte      TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (id_patient) REFERENCES patients(id_patient) ON DELETE CASCADE
);

-- ════════════════════════════════════════════════════════════
--  DONNÉES PAR DÉFAUT
-- ════════════════════════════════════════════════════════════

-- Services (mêmes que le site d'origine)
INSERT INTO services (ico, name, prix, descr) VALUES
('🦷','Soins Dentaires','30 DT','Traitement des caries, dévitalisations et soins conservateurs.'),
('✨','Dentisterie Esthétique','200 DT','Facettes, blanchiment et sourire Hollywood pour un résultat parfait.'),
('🔩','Implantologie','900 DT','Remplacement de dents manquantes par des implants en titane.'),
('👶','Dentiste pour Enfants','20 DT','Soins pédiatriques dans un environnement rassurant et adapté.'),
('🪥','Orthodontie','800 DT','Bagues ou gouttières transparentes pour un sourire harmonieux.'),
('🫀','Chirurgie Dentaire','150 DT','Extractions complexes et chirurgies parodontales avec précision.');

-- Horaires
INSERT INTO horaires (jour, ouverture, fermeture, ferme) VALUES
('Lundi','08:00','18:00',0),
('Mardi','08:00','18:00',0),
('Mercredi','08:00','18:00',0),
('Jeudi','08:00','18:00',0),
('Vendredi','08:00','18:00',0),
('Samedi','08:00','13:00',0),
('Dimanche','','',1);

-- Infos cabinet : Dr. Wael Ghabara — El Mourouj 1, Ben Arous, Tunisie
INSERT INTO cabinet_info (id, name, doctor, tel, email, addr) VALUES
(1, 'DentoFlow AI', 'Dr. Wael Ghabara', '+216 22 369 195', 'w.ghabara@hotmail.fr', 'El Mourouj 1, Ben Arous, Tunisie');

-- NB : les comptes par défaut sont créés automatiquement par le serveur
--      admin / Admin!2026Local et docteur / Docteur!2026Local
--      par le serveur au démarrage, avec un mot de passe haché (bcrypt).

-- ════════════════════════════════════════════════════════════
--  GESTION DE STOCK (consommables)
--  NB : ces tables sont aussi créées automatiquement au démarrage
--       du serveur (migration dans db.js). Ce bloc sert aux imports neufs.
-- ════════════════════════════════════════════════════════════

-- ── PRODUITS CONSOMMABLES (catalogue + stock réel) ──────────
CREATE TABLE IF NOT EXISTS produits (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  nom         VARCHAR(120) NOT NULL,
  type        VARCHAR(80),
  unite       VARCHAR(30)  DEFAULT 'pièce',
  stock_reel  INT NOT NULL DEFAULT 0,          -- = Σ ENTREE − Σ SORTIE
  seuil_secu  INT NOT NULL DEFAULT 100,        -- stock de sécurité (alerte)
  created_at  DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- ── RÉSERVATIONS = PANIER d'un RDV (prévisionnel) ───────────
CREATE TABLE IF NOT EXISTS reservations (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  id_rdv      INT NOT NULL,
  id_produit  INT NOT NULL,
  quantite    INT NOT NULL,
  statut      ENUM('en_attente','confirmee','annulee') DEFAULT 'en_attente',
  created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (id_rdv)     REFERENCES rendez_vous(id) ON DELETE CASCADE,
  FOREIGN KEY (id_produit) REFERENCES produits(id)    ON DELETE CASCADE
);

-- ── JOURNAL DES MOUVEMENTS (immuable, stock réel) ───────────
CREATE TABLE IF NOT EXISTS mouvements (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  id_produit   INT,
  nom_produit  VARCHAR(120),                   -- instantané (traçabilité)
  type_produit VARCHAR(80),
  quantite     INT NOT NULL,
  sens         ENUM('ENTREE','SORTIE') NOT NULL,
  origine      ENUM('RECEPTION','RENDEZVOUS','CORRECTION') NOT NULL,
  id_origine   INT,                            -- id réception ou id RDV
  date_mouv    DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (id_produit) REFERENCES produits(id) ON DELETE SET NULL
);

-- ── MODÈLES PAR SERVICE (réservation auto) ──────────────────
CREATE TABLE IF NOT EXISTS service_consommables (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  service    VARCHAR(120) NOT NULL,
  id_produit INT NOT NULL,
  quantite   INT NOT NULL DEFAULT 1,
  FOREIGN KEY (id_produit) REFERENCES produits(id) ON DELETE CASCADE
);

-- Produits de démonstration
INSERT INTO produits (nom, type, unite, stock_reel, seuil_secu) VALUES
('Gants latex',         'Protection', 'paire',     500, 100),
('Masques chirurgicaux','Protection', 'pièce',     450, 100),
('Compresses stériles', 'Soin',       'sachet',    300, 100),
('Anesthésique local',  'Médicament', 'cartouche', 180, 100),
('Aiguilles dentaires', 'Soin',       'pièce',     220, 100);
