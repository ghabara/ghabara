import React from 'react';

// Capture les erreurs d'affichage et montre le message au lieu d'une page blanche
export default class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { error: null };
  }
  static getDerivedStateFromError(error) {
    return { error };
  }
  componentDidCatch(error, info) {
    console.error('Erreur React :', error, info);
  }
  render() {
    if (this.state.error) {
      return (
        <div style={{ padding: 30, fontFamily: 'monospace', background: '#fff', minHeight: '100vh' }}>
          <h2 style={{ color: '#c62828' }}>⚠️ Une erreur s'est produite</h2>
          <p style={{ color: '#555' }}>Copie ce message (ou fais une capture) et envoie-le :</p>
          <pre style={{ whiteSpace: 'pre-wrap', background: '#fdecea', color: '#b71c1c', padding: 16, borderRadius: 10, fontSize: 13 }}>
{String(this.state.error?.message || this.state.error)}

{this.state.error?.stack}
          </pre>
          <button onClick={() => this.setState({ error: null })}
                  style={{ marginTop: 14, padding: '10px 18px', borderRadius: 10, border: 'none', background: '#2d6a4f', color: '#fff', cursor: 'pointer' }}>
            ← Réessayer
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}
