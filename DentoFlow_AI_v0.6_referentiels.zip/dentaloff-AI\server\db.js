﻿const mysql = require('mysql2/promise');
const bcrypt = require('bcryptjs');
const { runStockAiMigrations } = require('./services/stockAiMigration');
require('dotenv').config();

// Pool de connexions MySQL / MariaDB
const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'dentaloff_ai',
  port: process.env.DB_PORT || 3306,
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
});

const DEFAULT_ADMIN_USERNAME = process.env.DEFAULT_ADMIN_USERNAME || 'admin';
const DEFAULT_ADMIN_PASSWORD = process.env.DEFAULT_ADMIN_PASSWORD || 'Admin!2026Local';
const DEFAULT_DOCTOR_USERNAME = process.env.DEFAULT_DOCTOR_USERNAME || 'docteur';
const DEFAULT_DOCTOR_PASSWORD = process.env.DEFAULT_DOCTOR_PASSWORD || 'Docteur!2026Local';

function assertStrongSeedPassword(name, password) {
  if (!password || password.length < 10 || !/[A-Z]/.test(password) || !/[a-z]/.test(password) || !/\d/.test(password)) {
    throw new Error(`${name} doit contenir au moins 10 caractères avec majuscule, minuscule et chiffre.`);
  }
}

// Au démarrage : crée les comptes par défaut si absents.
async function seed() {
  try {
    assertStrongSeedPassword('DEFAULT_ADMIN_PASSWORD', DEFAULT_ADMIN_PASSWORD);
    assertStrongSeedPassword('DEFAULT_DOCTOR_PASSWORD', DEFAULT_DOCTOR_PASSWORD);

    // Migration : ajoute la colonne patient_email si elle n'existe pas (pour les RDV des visiteurs)
    const [cols] = await pool.query(
      `SELECT COLUMN_NAME FROM information_schema.COLUMNS
       WHERE TABLE_SCHEMA = ? AND TABLE_NAME = 'rendez_vous' AND COLUMN_NAME = 'patient_email'`,
      [process.env.DB_NAME || 'dentaloff_ai']
    );
    if (cols.length === 0) {
      await pool.query("ALTER TABLE rendez_vous ADD COLUMN patient_email VARCHAR(150) AFTER patient_tel");
      console.log('✅ Colonne patient_email ajoutée (RDV visiteurs)');
    }

    // Migration : tables de gestion de stock (créées si absentes)
    await pool.query(`
      CREATE TABLE IF NOT EXISTS produits (
        id          INT AUTO_INCREMENT PRIMARY KEY,
        nom         VARCHAR(120) NOT NULL,
        type        VARCHAR(80),
        unite       VARCHAR(30)  DEFAULT 'pièce',
        stock_reel  INT NOT NULL DEFAULT 0,
        seuil_secu  INT NOT NULL DEFAULT 100,
        created_at  DATETIME DEFAULT CURRENT_TIMESTAMP
      ) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`);

    await pool.query(`
      CREATE TABLE IF NOT EXISTS reservations (
        id          INT AUTO_INCREMENT PRIMARY KEY,
        id_rdv      INT NOT NULL,
        id_produit  INT NOT NULL,
        quantite    INT NOT NULL,
        statut      ENUM('en_attente','confirmee','annulee') DEFAULT 'en_attente',
        created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (id_rdv)     REFERENCES rendez_vous(id) ON DELETE CASCADE,
        FOREIGN KEY (id_produit) REFERENCES produits(id)    ON DELETE CASCADE
      ) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`);

    await pool.query(`
      CREATE TABLE IF NOT EXISTS mouvements (
        id           INT AUTO_INCREMENT PRIMARY KEY,
        id_produit   INT,
        nom_produit  VARCHAR(120),
        type_produit VARCHAR(80),
        quantite     INT NOT NULL,
        sens         ENUM('ENTREE','SORTIE') NOT NULL,
        origine      ENUM('RECEPTION','RENDEZVOUS','CORRECTION') NOT NULL,
        id_origine   INT,
        date_mouv    DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (id_produit) REFERENCES produits(id) ON DELETE SET NULL
      ) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`);

    await pool.query(`
      CREATE TABLE IF NOT EXISTS service_consommables (
        id         INT AUTO_INCREMENT PRIMARY KEY,
        service    VARCHAR(120) NOT NULL,
        id_produit INT NOT NULL,
        quantite   INT NOT NULL DEFAULT 1,
        FOREIGN KEY (id_produit) REFERENCES produits(id) ON DELETE CASCADE
      ) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`);

    // Produits de démonstration (une seule fois)
    const [[{ n }]] = await pool.query('SELECT COUNT(*) AS n FROM produits');
    if (n === 0) {
      await pool.query(
        `INSERT INTO produits (nom, type, unite, stock_reel, seuil_secu) VALUES
         ('Gants latex',        'Protection',  'paire',  500, 100),
         ('Masques chirurgicaux','Protection', 'pièce',  450, 100),
         ('Compresses stériles','Soin',        'sachet', 300, 100),
         ('Anesthésique local', 'Médicament',  'cartouche', 180, 100),
         ('Aiguilles dentaires','Soin',        'pièce',  220, 100)`
      );
      console.log('✅ Produits de stock de démonstration créés');
    }

    await pool.query(`
      UPDATE cabinet_info
      SET name = 'DentoFlow AI',
          doctor = CASE
            WHEN doctor IS NULL OR doctor = '' OR doctor LIKE CONCAT('%', 'Mo', 'lka', '%') OR doctor LIKE CONCAT('%', 'Chou', 'ika', '%') THEN 'Dr. Wael Ghabara'
            ELSE doctor
          END,
          tel = CASE
            WHEN tel IS NULL OR tel = '' OR tel = CONCAT('+216 ', '71 ', '25 ', '98 ', '55') THEN '+216 22 369 195'
            ELSE tel
          END,
          email = CASE
            WHEN email IS NULL OR email = '' OR email LIKE '%denta%' THEN 'w.ghabara@hotmail.fr'
            ELSE email
          END,
          addr = CASE
            WHEN addr IS NULL OR addr = '' OR addr = CONCAT('Tunis', ', Mourouj 1') THEN 'El Mourouj 1, Ben Arous, Tunisie'
            ELSE addr
          END
      WHERE id = 1
    `);

    const [admins] = await pool.query('SELECT id FROM admins LIMIT 1');
    if (admins.length === 0) {
      const hash = await bcrypt.hash(DEFAULT_ADMIN_PASSWORD, 12);
      await pool.query(
        'INSERT INTO admins (username, password_hash, role) VALUES (?,?,?)',
        [DEFAULT_ADMIN_USERNAME, hash, 'admin']
      );
      console.log(`✅ Compte admin créé : ${DEFAULT_ADMIN_USERNAME}`);
    }

    // Compte docteur par défaut (créé une seule fois s'il n'existe aucun docteur)
    const [docteurs] = await pool.query("SELECT id FROM admins WHERE role = 'docteur' LIMIT 1");
    if (docteurs.length === 0) {
      const hashD = await bcrypt.hash(DEFAULT_DOCTOR_PASSWORD, 12);
      await pool.query(
        'INSERT INTO admins (username, password_hash, role) VALUES (?,?,?)',
        [DEFAULT_DOCTOR_USERNAME, hashD, 'docteur']
      );
      console.log(`✅ Compte docteur créé : ${DEFAULT_DOCTOR_USERNAME}`);
    }

    await runStockAiMigrations(pool);
    console.log('Stock AI: migrations et seed de demonstration verifies.');
  } catch (e) {
    console.error('⚠️  Amorçage impossible (la base est-elle importée ?) :', e.message);
  }
}

module.exports = { pool, seed };
