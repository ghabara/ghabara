﻿import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { adminApi, getAdmin, saveAdmin, adminLogout } from '../api';
import StockAiModule from './StockAi';
import ReferencesPanel from './ReferencesPanel.jsx';
import ActProductCatalogPanel from './ActProductCatalogPanel.jsx';
import BrandLogo from '../components/BrandLogo.jsx';
import DentalChart from '../components/dentalChart/DentalChart.jsx';

export default function Admin() {
  const [admin, setAdmin] = useState(getAdmin());
  if (!admin) return <AdminLogin onLogin={(a) => setAdmin(a)} />;
  return <AdminPanel admin={admin} onLogout={() => { adminLogout(); setAdmin(null); }} onUpdate={setAdmin} />;
}

function Brand({ light = false }) {
  return <BrandLogo compact className={light ? 'brand-logo--sidebar' : 'brand-logo--login'} />;
}

/* ─────────────── CONNEXION ADMIN ─────────────── */
function AdminLogin({ onLogin }) {
  const [u, setU] = useState(''); const [p, setP] = useState(''); const [err, setErr] = useState('');
  const submit = async () => {
    setErr('');
    try {
      const { data } = await adminApi.post('/admin/login', { username: u, password: p });
      saveAdmin(data.user, data.token);
      onLogin(data.user);
    } catch (e) { setErr(e.response?.data?.error || 'Erreur de connexion.'); }
  };
  return (
    <div className="admin-login-page">
      <div className="admin-login-card">
        <div className="center" style={{ marginBottom: 22 }}>
          <Brand />
          <h2 className="section-title" style={{ fontSize: 24 }}>Administration</h2>
          <p className="muted">DentoFlow AI - acces reserve</p>
        </div>
        {err && <div className="alert error">{err}</div>}
        <div className="fg"><label>Identifiant</label>
          <input value={u} onChange={e => setU(e.target.value)} placeholder="Identifiant administrateur" /></div>
        <div className="fg"><label>Mot de passe</label>
          <input type="password" value={p} onChange={e => setP(e.target.value)}
                 onKeyDown={e => e.key === 'Enter' && submit()} placeholder="••••••••" /></div>
        <button className="btn btn-primary" style={{ width: '100%' }} onClick={submit}>Se connecter</button>
        <p className="center muted" style={{ marginTop: 16 }}><Link to="/">← Retour au site</Link></p>
      </div>
    </div>
  );
}

/* ─────────────── PANNEAU ADMIN ─────────────── */
function AdminPanel({ admin, onLogout, onUpdate }) {
  const [panel, setPanel] = useState('dashboard');
  const isDocteur = admin.role === 'docteur';
  const nav = [
    ['dashboard', 'Tableau de bord'],
    ['patients', 'Patients'],
    ['rdv', 'Rendez-vous'],
    ['dossiers', 'Dossiers cliniques'],
    ['odontogram', 'Odontogramme'],
    ['clinicalAssistant', 'Cas cliniques assistes'],
    ['digitalWorkflow', 'Workflow numerique'],
    ['labOps', 'Laboratoire'],
    ['stockAi', 'Stock AI'],
    ['harmonization', 'Harmonisation'],
    ['references', 'Referentiels'],
    ['actCatalog', 'Referentiel actes'],
    ['productCatalog', 'Referentiel produits'],
    ['services', 'Services'],
    ['notes', 'Documents & notes'],
    ...(isDocteur ? [['doctor', 'Espace docteur']] : []),
    ['horaires', 'Horaires'],
    ['onlineSync', 'Mise a jour controlee'],
    ['info', 'Paramètres'],
  ];
  const activeLabel = nav.find(([k]) => k === panel)?.[1] || 'Tableau de bord';
  return (
    <div className="admin-shell">
      {/* Sidebar */}
      <aside className="admin-sidebar">
        <Brand light />
        {nav.map(([k, label]) => (
          <button key={k} onClick={() => setPanel(k)}
               className={panel === k ? 'admin-nav-item active' : 'admin-nav-item'}>
            {label}
          </button>
        ))}
        <div className="admin-session">
          <div className="admin-session-label">Connecté : {admin.username}</div>
          <button className="btn btn-green" style={{ width: '100%', marginTop: 10 }} onClick={onLogout}>Déconnexion</button>
        </div>
      </aside>

      {/* Contenu */}
      <main className="admin-main">
        <header className="admin-topbar">
          <div>
            <span className="admin-eyebrow">Plateforme de pilotage intelligent du cabinet dentaire</span>
            <h1>{activeLabel}</h1>
          </div>
          <span className="admin-top-pill">DentoFlow AI</span>
        </header>
        {panel === 'dashboard' && <Dashboard onNavigate={setPanel} />}
        {panel === 'rdv' && <RdvPanel />}
        {panel === 'patients' && <PatientsPanel />}
        {panel === 'dossiers' && <DossiersPanel />}
        {panel === 'odontogram' && <OdontogramPanel />}
        {panel === 'clinicalAssistant' && <ClinicalAssistantPanel />}
        {panel === 'digitalWorkflow' && <DigitalWorkflowPanel />}
        {panel === 'labOps' && <LabOperationsPanel />}
        {panel === 'doctor' && isDocteur && <DoctorPanel admin={admin} onUpdate={onUpdate} />}
        {panel === 'services' && <ServicesPanel />}
        {panel === 'stockAi' && <StockAiModule admin={admin} />}
        {panel === 'harmonization' && <ReferenceHarmonizationPanel />}
        {panel === 'references' && <ReferencesPanel />}
        {panel === 'actCatalog' && <ActProductCatalogPanel key="acts" initialTab="acts" />}
        {panel === 'productCatalog' && <ActProductCatalogPanel key="products" initialTab="products" />}
        {panel === 'onlineSync' && <OnlineSyncPanel />}
        {panel === 'horaires' && <HorairesPanel />}
        {panel === 'notes' && <NotesPanel />}
        {panel === 'info' && <InfoPanel />}
      </main>
    </div>
  );
}

const Title = ({ children, sub }) => (
  <div style={{ marginBottom: 22 }}>
    <h2 className="section-title">{children}</h2>
    {sub && <p className="muted">{sub}</p>}
  </div>
);

function OdontogramPanel() {
  return (
    <>
      <Title sub="Selection dent/surface/statut en brouillon, sans modification du dossier patient.">Odontogramme</Title>
      <DentalChart />
    </>
  );
}

function ClinicalAssistantPanel() {
  return (
    <ControlledModulePanel
      title="Cas cliniques assistes"
      sub="Preparer une suggestion clinique + acte + stock + cout, puis validation humaine obligatoire."
      stages={["Patient/RDV", "Dent", "Cas clinique", "Suggestion", "Validation"]}
      rows={[
        ["Carie / restauration", "Black I-VI et SiSta, suggestion de recette composite"],
        ["Endodontie", "Limes, irrigation, obturation, cout matiere estime"],
        ["Prothese / laboratoire", "Lien plan de traitement, labo, cout interne"],
      ]}
    />
  );
}

function DigitalWorkflowPanel() {
  return (
    <ControlledModulePanel
      title="Workflow numerique"
      sub="Case Box, Order Box, fichiers 3D et communication labo restent en previsualisation avant envoi."
      stages={["Patient", "Photos/Radios", "Scan 3D", "Plan", "Labo", "Validation"]}
      rows={[
        ["Case Box", "Regroupe photos, radios, scans et notes de cas"],
        ["Order Box", "Prepare une demande labo avant validation"],
        ["Case Talk", "Historique d'echange rattache au cas"],
      ]}
    />
  );
}

function OnlineSyncPanel() {
  return (
    <ControlledModulePanel
      title="Mise a jour controlee"
      sub="Les sources externes proposeront uniquement des candidats. Prix reels et regles validees ne sont pas remplaces."
      stages={["Observation", "Candidat", "Conflit", "Revue humaine", "Application"]}
      rows={[
        ["Prix produits", "Observation par pays, devise, source et date"],
        ["Actes et nomenclatures", "CNAM, CCAM ou hors nomenclature separes"],
        ["Equivalences commerciales", "Alias marque/fournisseur avant fusion"],
      ]}
    />
  );
}

function LabOperationsPanel() {
  const [data, setData] = useState(null);
  const [error, setError] = useState('');
  useEffect(() => {
    adminApi.get('/lab/overview').then(r => setData(r.data)).catch(e => setError(e.response?.data?.error || 'Laboratoire indisponible.'));
  }, []);
  return (
    <>
      <Title sub="Suivi cabinet-laboratoire, couts labo et stock laboratoire sans deduction automatique.">Laboratoire</Title>
      {error && <div className="alert error">{error}</div>}
      <div className="dashboard-grid" style={{ marginBottom: 16 }}>
        <Kpi label="Cas labo" value={data?.counts?.cases || 0} />
        <Kpi label="Etapes" value={data?.counts?.steps || 0} />
        <Kpi label="Recettes labo" value={data?.counts?.recipes || 0} />
      </div>
      <ControlledModulePanel
        title="Communication cabinet-laboratoire"
        sub="Brouillon cabinet, fichiers, messages, devis et validation restent tracables."
        stages={["Brouillon", "Envoye", "Analyse", "Fabrication", "Recu", "Valide"]}
        rows={[
          ["Identite masquee", "Option prevue pour partager CASE-YYYY-NNN sans exposer le patient"],
          ["Fichiers numeriques", "STL, PLY, OBJ, PDF, JPG, PNG rattaches au cas"],
          ["Cout labo", "Integre au cout reel seulement apres validation"],
        ]}
      />
    </>
  );
}

function ControlledModulePanel({ title, sub, stages, rows }) {
  return (
    <>
      <Title sub={sub}>{title}</Title>
      <div className="pilotage-summary card">
        <div>
          <span className="admin-eyebrow">Validation humaine obligatoire</span>
          <h3>Brouillon, suggestion, previsualisation, validation, application.</h3>
          <p className="muted">Aucune suggestion IA ne modifie automatiquement le dossier patient, le stock, les prix, les recettes ou les regles de remboursement.</p>
        </div>
        <div className="pilotage-flow">{stages.map(step => <span key={step}>{step}</span>)}</div>
      </div>
      <div className="table-wrap">
        <table>
          <thead><tr><th>Bloc</th><th>Etat controle</th></tr></thead>
          <tbody>{rows.map(([name, state]) => <tr key={name}><td><strong>{name}</strong></td><td className="muted">{state}</td></tr>)}</tbody>
        </table>
      </div>
    </>
  );
}

/* ─────────────── DASHBOARD ─────────────── */
function Dashboard({ onNavigate }) {
  const [data, setData] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    let active = true;
    adminApi.get('/pilotage/overview').then(({ data }) => {
      if (!active) return;
      setData(data);
    }).catch(e => setError(e.response?.data?.error || 'Pilotage indisponible.'));
    return () => { active = false; };
  }, []);

  if (!data) return (
    <>
      <Title sub="Chargement du cockpit cabinet">Tableau de bord</Title>
      {error ? <div className="alert error">{error}</div> : <div className="card muted">Chargement du pilotage intelligent...</div>}
    </>
  );

  const cards = [
    ['Patients suivis', data.patients.total, 'patients', `${data.patients.dossier_count} dossiers cliniques`],
    ["RDV aujourd'hui", data.appointments.today, 'rdv', `${data.appointments.next_7d} sur 7 jours`],
    ['Actes realises ce mois', data.economics.performed_this_month, 'stockAi', 'Declenchent cout et consommation'],
    ['Cout matiere du mois', formatMoney(data.economics.material_cost_month_tnd), 'stockAi', `Moyenne ${formatMoney(data.economics.avg_material_cost_tnd)}`],
    ['Achats du mois', formatMoney(data.economics.purchase_total_month_tnd), 'stockAi', 'Receptions et factures'],
    ['A commander avant rupture', data.inventory.products_to_buy_count, 'stockAi', formatMoney(data.inventory.estimated_purchase_value_tnd)],
    ['Risque critique stock', data.inventory.critical_count, 'stockAi', `${data.inventory.stockout_risk_count} ruptures possibles`],
    ['Couverture moyenne', formatDays(data.inventory.avg_coverage_days), 'stockAi', 'Selon consommations 30/90j'],
    ['Laboratoire ouvert', data.lab.open_count, 'stockAi', `${data.lab.late_count} retards`],
  ];

  return (
    <>
      <Title sub={data.promise}>Tableau de bord</Title>
      <div className="pilotage-summary card">
        <div>
          <span className="admin-eyebrow">{data.positioning}</span>
          <h3>Du rendez-vous a l'achat, un seul cockpit.</h3>
          <p className="muted">La plateforme relie les actes prevus, les actes realises, les recettes de consommables, les couts matiere, les lots, les peremptions et les achats a lancer avant rupture.</p>
        </div>
        <div className="pilotage-flow">
          {['Patient', 'RDV', 'Acte', 'Consommation', 'Cout', 'Achat'].map(step => <span key={step}>{step}</span>)}
        </div>
      </div>
      <div className="dashboard-grid">
        {cards.map(([label, value, target, hint]) => (
          <Kpi key={label} label={label} value={value} hint={hint} onClick={() => onNavigate(target)} />
        ))}
      </div>
      <div className="dashboard-split">
        <div className="card">
          <h3 className="card-title">Produits a traiter en priorite</h3>
          {(data.inventory.urgent_products || []).slice(0, 5).map(p => (
            <div className="dashboard-line" key={p.product_id}>
              <strong>{p.product_name}</strong>
              <span>{p.risk_score}/100 - {p.recommended_quantity} {p.unit}</span>
            </div>
          ))}
          {!data.inventory.urgent_products.length && <p className="muted">Aucun achat prioritaire.</p>}
        </div>
        <div className="card">
          <h3 className="card-title">Actes les plus couteux en matiere</h3>
          {(data.top_acts || []).slice(0, 5).map(a => (
            <div className="dashboard-line" key={a.act_name}>
              <strong>{a.act_name}</strong>
              <span>{a.act_count} actes - {formatMoney(a.total_material_cost_tnd)}</span>
            </div>
          ))}
          {!data.top_acts.length && <p className="muted">Aucun acte realise sur 30 jours.</p>}
        </div>
      </div>
      <div className="dashboard-split">
        <div className="card">
          <h3 className="card-title">Alertes cabinet</h3>
          {(data.alerts || []).slice(0, 5).map(a => (
            <div className="dashboard-line" key={a.id}>
              <strong>{a.message}</strong>
              <span>{a.severity === 'CRITICAL' ? 'Critique' : a.severity === 'WARNING' ? 'A surveiller' : 'Info'}</span>
            </div>
          ))}
          {!data.alerts.length && <p className="muted">Aucune alerte ouverte.</p>}
        </div>
        <div className="card">
          <h3 className="card-title">Derniers mouvements de stock</h3>
          {(data.latest_movements || []).slice(0, 5).map((m, index) => (
            <div className="dashboard-line" key={`${m.product_name_snapshot}-${index}`}>
              <strong>{m.product_name_snapshot}</strong>
              <span>{m.direction} {m.quantity} {m.unit}</span>
            </div>
          ))}
          {!data.latest_movements.length && <p className="muted">Aucun mouvement recent.</p>}
        </div>
      </div>
    </>
  );
}

function formatMoney(value) {
  const n = Number(value || 0);
  return `${n.toFixed(3)} TND`;
}

function formatDays(value) {
  if (value === null || value === undefined) return '-';
  const n = Number(value);
  return Number.isFinite(n) ? `${n.toFixed(1)} j` : '-';
}

const Kpi = ({ label, value, hint, onClick }) => (
  <button className="kpi-card" onClick={onClick}>
    <span className="kpi-value">{value}</span>
    <span className="kpi-label">{label}</span>
    <span className="kpi-hint">{hint}</span>
  </button>
);

function ReferenceHarmonizationPanel() {
  const [data, setData] = useState(null);
  const [tab, setTab] = useState('added');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [message, setMessage] = useState('');

  const load = () => adminApi.get('/reference-harmonization')
    .then(r => setData(r.data))
    .catch(e => setError(e.response?.data?.error || 'Harmonisation indisponible.'));

  useEffect(() => { load(); }, []);

  const run = async () => {
    setBusy(true); setError(''); setMessage('');
    try {
      const { data: result } = await adminApi.post('/reference-harmonization/run');
      setData(result.dashboard);
      setMessage(`Harmonisation terminee : ${result.summary.updated} mises a jour, ${result.summary.probable_duplicates} doublons, ${result.summary.conflicts} conflits.`);
    } catch (e) {
      setError(e.response?.data?.error || 'Erreur pendant l harmonisation.');
    } finally {
      setBusy(false);
    }
  };

  const updateConflict = async (id, status) => {
    await adminApi.patch(`/reference-harmonization/conflicts/${id}`, { status });
    load();
  };
  const updateMapping = async (id, status, action_taken) => {
    await adminApi.patch(`/reference-harmonization/mappings/${id}`, { status, action_taken });
    load();
  };

  const logs = data?.logs || [];
  const mappings = data?.mappings || [];
  const conflicts = data?.conflicts || [];
  const added = logs.filter(row => row.operation === 'added');
  const updated = logs.filter(row => row.operation === 'updated');
  const duplicates = mappings.filter(row => ['pending', 'conflict'].includes(row.status));
  const pendingConflicts = conflicts.filter(row => row.status === 'pending');

  return (
    <>
      <Title sub="Consolider les sources deja integrees sans doublons ni ecrasement dangereux.">Harmonisation des referentiels</Title>
      {error && <div className="alert error">{error}</div>}
      {message && <div className="alert success">{message}</div>}
      <div className="card" style={{ marginBottom: 16 }}>
        <div className="dashboard-line">
          <div>
            <strong>Base unique et tracable</strong>
            <p className="muted" style={{ margin: '4px 0 0' }}>Alias, doublons probables et conflits restent visibles avant validation humaine.</p>
          </div>
          <button className="btn btn-primary" disabled={busy} onClick={run}>{busy ? 'Harmonisation...' : 'Lancer harmonisation'}</button>
        </div>
        <div className="dashboard-grid" style={{ marginTop: 16 }}>
          <Kpi label="Alias" value={data?.counts?.aliases || 0} hint="correspondances" />
          <Kpi label="Mappings a revoir" value={data?.counts?.pending_mappings || 0} hint="doublons probables" />
          <Kpi label="Conflits ouverts" value={data?.counts?.pending_conflicts || 0} hint="validation requise" />
          <Kpi label="Enrichissements" value={data?.counts?.updated_logs || 0} hint="logs mis a jour" />
        </div>
      </div>

      <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 14 }}>
        {[
          ['added', `Donnees ajoutees (${added.length})`],
          ['updated', `Donnees mises a jour (${updated.length})`],
          ['duplicates', `Doublons probables (${duplicates.length})`],
          ['conflicts', `Conflits a valider (${pendingConflicts.length})`],
        ].map(([key, label]) => (
          <button key={key} className={tab === key ? 'btn btn-primary' : 'btn btn-secondary'} onClick={() => setTab(key)}>{label}</button>
        ))}
      </div>

      {tab === 'added' && <ImportLogTable rows={added} empty="Aucune donnee ajoutee par la derniere harmonisation." />}
      {tab === 'updated' && <ImportLogTable rows={updated} empty="Aucune mise a jour recente." />}
      {tab === 'duplicates' && <MappingReviewTable rows={duplicates} onAction={updateMapping} />}
      {tab === 'conflicts' && <ConflictReviewTable rows={pendingConflicts} onAction={updateConflict} />}
    </>
  );
}

function ImportLogTable({ rows, empty }) {
  return (
    <div className="table-wrap">
      <table>
        <thead><tr><th>Date</th><th>Operation</th><th>Type</th><th>Libelle</th><th>Details</th></tr></thead>
        <tbody>
          {rows.map(row => (
            <tr key={row.id}>
              <td className="muted">{formatDateTime(row.created_at)}</td>
              <td>{row.operation}</td>
              <td>{row.entity_type || '-'}</td>
              <td><strong>{row.label || '-'}</strong></td>
              <td className="muted">{shortJson(row.details_json)}</td>
            </tr>
          ))}
          {!rows.length && <tr><td colSpan="5" className="center muted" style={{ padding: 24 }}>{empty}</td></tr>}
        </tbody>
      </table>
    </div>
  );
}

function MappingReviewTable({ rows, onAction }) {
  return (
    <div className="table-wrap">
      <table>
        <thead><tr><th>Source</th><th>Canonique propose</th><th>Score</th><th>Raison</th><th>Actions</th></tr></thead>
        <tbody>
          {rows.map(row => (
            <tr key={row.id}>
              <td><strong>{row.incoming_name}</strong><br /><small className="muted">{row.entity_type}</small></td>
              <td>{row.canonical_name || '-'}</td>
              <td>{Number(row.match_score || 0).toFixed(2)}</td>
              <td className="muted">{row.review_reason || '-'}</td>
              <td style={{ minWidth: 260 }}>
                <button className="btn btn-green" onClick={() => onAction(row.id, 'validated', 'fusion_validee')}>Valider fusion</button>{' '}
                <button className="btn btn-secondary" onClick={() => onAction(row.id, 'ignored', 'ignore')}>Ignorer</button>{' '}
                <button className="btn btn-secondary" onClick={() => onAction(row.id, 'new_entry', 'creer_nouvelle_entree')}>Nouvelle entree</button>
              </td>
            </tr>
          ))}
          {!rows.length && <tr><td colSpan="5" className="center muted" style={{ padding: 24 }}>Aucun doublon probable en attente.</td></tr>}
        </tbody>
      </table>
    </div>
  );
}

function ConflictReviewTable({ rows, onAction }) {
  return (
    <div className="table-wrap">
      <table>
        <thead><tr><th>Champ</th><th>Valeur existante</th><th>Nouvelle valeur</th><th>Source</th><th>Action</th></tr></thead>
        <tbody>
          {rows.map(row => (
            <tr key={row.id}>
              <td><strong>{row.field_name}</strong><br /><small className="muted">{row.entity_type} #{row.entity_id || '-'}</small></td>
              <td>{row.current_value || '-'}</td>
              <td>{row.new_value || '-'}</td>
              <td className="muted">{row.source_current || '-'}<br />{row.source_new || '-'}</td>
              <td style={{ minWidth: 260 }}>
                <button className="btn btn-green" onClick={() => onAction(row.id, 'accepted')}>Remplacer valeur</button>{' '}
                <button className="btn btn-secondary" onClick={() => onAction(row.id, 'rejected')}>Garder existante</button>{' '}
                <button className="btn btn-secondary" onClick={() => onAction(row.id, 'merged')}>Marquer verifie</button>
              </td>
            </tr>
          ))}
          {!rows.length && <tr><td colSpan="5" className="center muted" style={{ padding: 24 }}>Aucun conflit en attente.</td></tr>}
        </tbody>
      </table>
    </div>
  );
}

function shortJson(value) {
  if (!value) return '-';
  try {
    const parsed = JSON.parse(value);
    return Object.entries(parsed).slice(0, 3).map(([k, v]) => `${k}: ${v}`).join(', ');
  } catch {
    return String(value).slice(0, 120);
  }
}

function formatDateTime(value) {
  if (!value) return '-';
  try { return new Date(value).toLocaleString('fr-FR'); }
  catch { return value; }
}

async function downloadDocument(doc) {
  const { data } = await adminApi.get(`/dossiers/documents/${doc.id}/download`, { responseType: 'blob' });
  const url = URL.createObjectURL(data);
  const a = document.createElement('a');
  a.href = url;
  a.download = doc.name || 'document';
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

/* ─────────────── RENDEZ-VOUS ─────────────── */
function RdvPanel() {
  const [rdvs, setRdvs] = useState([]);
  const load = () => adminApi.get('/rdv').then(r => setRdvs(r.data)).catch(() => {});
  useEffect(() => { load(); }, []);
  const setStatus = async (id, statut) => { await adminApi.put(`/rdv/${id}/status`, { statut }); load(); };
  const del = async (id) => { if (confirm('Supprimer ce RDV ?')) { await adminApi.delete(`/rdv/${id}`); load(); } };
  return (
    <>
      <Title sub="Gérez les rendez-vous et leurs statuts">📅 Rendez-vous</Title>
      <div className="table-wrap">
        <table>
          <thead><tr><th>Réf</th><th>Patient</th><th>Service</th><th>Date</th><th>Heure</th><th>Statut</th><th>Actions</th></tr></thead>
          <tbody>
            {rdvs.map(r => (
              <tr key={r.id}>
                <td>{r.ref}</td><td>{r.patient_nom}<br /><small className="muted">{r.id_patient || '👤 Visiteur'} · 📞 {r.patient_tel}{r.patient_email ? ' · ✉️ ' + r.patient_email : ''}</small></td>
                <td>{r.service}</td><td>{r.date}</td><td>{r.heure}</td>
                <td>
                  <select value={r.statut} onChange={e => setStatus(r.id, e.target.value)}
                          style={{ padding: '6px 8px', borderRadius: 8, border: '1.5px solid rgba(82,183,136,.25)' }}>
                    <option value="pending">En attente</option>
                    <option value="confirmed">Confirmé</option>
                    <option value="done">Terminé</option>
                    <option value="cancelled">Annulé</option>
                  </select>
                </td>
                <td><button className="btn-red" onClick={() => del(r.id)}>🗑️</button></td>
              </tr>
            ))}
            {!rdvs.length && <tr><td colSpan="7" className="center muted" style={{ padding: 24 }}>Aucun rendez-vous.</td></tr>}
          </tbody>
        </table>
      </div>
    </>
  );
}

/* ─────────────── PATIENTS ─────────────── */
function PatientsPanel() {
  const [list, setList] = useState([]);
  const load = () => adminApi.get('/patients').then(r => setList(r.data)).catch(() => {});
  useEffect(() => { load(); }, []);
  const del = async (id) => { if (confirm('Supprimer ce patient et son dossier ?')) { await adminApi.delete(`/patients/${id}`); load(); } };
  return (
    <>
      <Title sub="Liste des patients inscrits">👥 Patients</Title>
      <div className="table-wrap">
        <table>
          <thead><tr><th>ID Patient</th><th>Nom</th><th>Email</th><th>Tél</th><th>Âge</th><th>Genre</th><th>RDV</th><th>Action</th></tr></thead>
          <tbody>
            {list.map(p => (
              <tr key={p.id_patient}>
                <td><strong>{p.id_patient}</strong></td><td>{p.prenom} {p.nom}</td><td>{p.email}</td>
                <td>{p.tel}</td><td>{p.age}</td><td>{p.genre}</td>
                <td><span className="badge-status bs-confirmed">{p.rdvCount} RDV</span></td>
                <td><button className="btn-red" onClick={() => del(p.id_patient)}>🗑️</button></td>
              </tr>
            ))}
            {!list.length && <tr><td colSpan="8" className="center muted" style={{ padding: 24 }}>Aucun patient.</td></tr>}
          </tbody>
        </table>
      </div>
    </>
  );
}

/* ─────────────── DOSSIERS MÉDICAUX ─────────────── */
function DossiersPanel() {
  const [list, setList] = useState([]);
  const [open, setOpen] = useState(null);
  const load = () => adminApi.get('/dossiers').then(r => setList(r.data)).catch(() => {});
  useEffect(() => { load(); }, []);

  const create = async (id) => {
    if (!confirm(`Créer le dossier médical ?\nID dossier = ${id} (identique à l'ID patient).`)) return;
    await adminApi.post('/dossiers', { id_patient: id });
    load();
  };

  return (
    <>
      <Title sub="Le dossier est créé manuellement par l'admin. id_dossier = id_patient.">🗂️ Dossiers Médicaux</Title>
      <div className="table-wrap">
        <table>
          <thead><tr><th>ID Dossier / Patient</th><th>Nom</th><th>Email</th><th>Dossier</th><th>Documents</th><th>Action</th></tr></thead>
          <tbody>
            {list.map(p => (
              <tr key={p.id_patient}>
                <td><strong>{p.id_patient}</strong></td><td>{p.prenom} {p.nom}</td><td>{p.email}</td>
                <td>{p.hasDossier ? <span className="badge-status bs-confirmed">Créé</span> : <span className="badge-status bs-pending">Aucun</span>}</td>
                <td>{p.hasDossier ? `${p.docCount} doc(s)` : '—'}</td>
                <td>{p.hasDossier
                  ? <button className="btn btn-secondary" onClick={() => setOpen(p.id_patient)}>📂 Ouvrir</button>
                  : <button className="btn btn-primary" onClick={() => create(p.id_patient)}>➕ Créer le dossier</button>}</td>
              </tr>
            ))}
            {!list.length && <tr><td colSpan="6" className="center muted" style={{ padding: 24 }}>Aucun patient.</td></tr>}
          </tbody>
        </table>
      </div>
      {open && <DossierModal id={open} onClose={() => { setOpen(null); load(); }} />}
    </>
  );
}

function DossierModal({ id, onClose }) {
  const [d, setD] = useState(null);
  const [file, setFile] = useState(null);
  const load = () => adminApi.get(`/dossiers/${id}`).then(r => setD(r.data)).catch(() => {});
  useEffect(() => { load(); }, [id]);
  if (!d) return null;

  const saveFiche = async () => {
    await adminApi.put(`/dossiers/${id}`, { groupe_sanguin: d.groupe_sanguin, allergies: d.allergies, antecedents: d.antecedents });
    alert('Fiche enregistrée.');
  };
  const addDoc = async () => {
    if (!file) return alert('Choisissez un fichier.');
    const fd = new FormData(); fd.append('file', file);
    const { data } = await adminApi.post(`/dossiers/${id}/documents`, fd, { headers: { 'Content-Type': 'multipart/form-data' } });
    setD(data); setFile(null);
  };
  const delDoc = async (docId) => {
    const { data } = await adminApi.delete(`/dossiers/${id}/documents/${docId}`); setD(data);
  };

  return (
    <div className="modal-overlay" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal">
        <button className="modal-close" onClick={onClose}>✕</button>
        <h3>🗂️ Dossier {d.id_dossier}</h3>
        <p className="muted">Patient : <strong>{d.patient?.prenom} {d.patient?.nom}</strong> · {d.patient?.email}</p>

        <h4>🩺 Informations médicales</h4>
        <div className="fg"><label>Groupe sanguin</label>
          <input value={d.groupe_sanguin || ''} onChange={e => setD({ ...d, groupe_sanguin: e.target.value })} placeholder="O+" /></div>
        <div className="fg"><label>Allergies</label>
          <input value={d.allergies || ''} onChange={e => setD({ ...d, allergies: e.target.value })} placeholder="Pénicilline..." /></div>
        <div className="fg"><label>Antécédents</label>
          <textarea rows="3" value={d.antecedents || ''} onChange={e => setD({ ...d, antecedents: e.target.value })} /></div>
        <button className="btn btn-primary" onClick={saveFiche}>💾 Enregistrer la fiche</button>

        <h4>📎 Documents</h4>
        <div className="fg"><input type="file" onChange={e => setFile(e.target.files[0])} /></div>
        <button className="btn btn-secondary" onClick={addDoc}>➕ Ajouter le document</button>
        <div style={{ marginTop: 12 }}>
          {(d.documents || []).map(doc => (
            <div key={doc.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', background: 'var(--g6)', borderRadius: 10, padding: '10px 14px', marginBottom: 8 }}>
              <span style={{ fontSize: 13 }}>📎 {doc.name} <small className="muted">({doc.size})</small></span>
              <span style={{ display: 'flex', gap: 8 }}>
                <button className="btn btn-secondary" style={{ padding: '6px 10px' }} onClick={() => downloadDocument(doc)}>⬇️</button>
                <button className="btn-red" onClick={() => delDoc(doc.id)}>🗑️</button>
              </span>
            </div>
          ))}
          {!(d.documents || []).length && <p className="muted" style={{ fontSize: 13 }}>Aucun document.</p>}
        </div>
      </div>
    </div>
  );
}

/* ─────────────── ESPACE DOCTEUR ─────────────── */
function DocteurIdentifiants({ admin, onUpdate }) {
  const [username, setUsername] = useState(admin?.username || '');
  const [newPassword, setNewPassword] = useState('');
  const [currentPassword, setCurrentPassword] = useState('');
  const [msg, setMsg] = useState(null);
  const [err, setErr] = useState(null);
  const save = async () => {
    setMsg(null); setErr(null);
    if (!currentPassword) return setErr('Saisis ton mot de passe actuel pour confirmer.');
    try {
      const { data } = await adminApi.put('/admin/credentials',
        { username, newPassword: newPassword || undefined, currentPassword });
      saveAdmin(data.user, data.token);
      onUpdate && onUpdate(data.user);
      setNewPassword(''); setCurrentPassword('');
      setMsg('Identifiants mis à jour. Le rôle reste « docteur ».');
      setTimeout(() => setMsg(null), 3500);
    } catch (e) { setErr(e.response?.data?.error || 'Erreur.'); }
  };
  return (
    <div className="form-card">
      <h3>🔑 Mes identifiants</h3>
      {msg && <div className="alert success">{msg}</div>}
      {err && <div className="alert error">{err}</div>}
      <div className="form-row2">
        <div className="fg"><label>Identifiant (login)</label>
          <input value={username} onChange={e => setUsername(e.target.value)} /></div>
        <div className="fg"><label>Nouveau mot de passe <small className="muted">(vide = inchangé)</small></label>
          <input type="password" value={newPassword} onChange={e => setNewPassword(e.target.value)} /></div>
      </div>
      <div className="fg"><label>Mot de passe actuel (confirmation)</label>
        <input type="password" value={currentPassword} onChange={e => setCurrentPassword(e.target.value)} /></div>
      <button className="btn btn-primary" onClick={save}>💾 Enregistrer mes identifiants</button>
    </div>
  );
}

function DoctorPanel({ admin, onUpdate }) {
  const [list, setList] = useState([]);
  const [open, setOpen] = useState(null);
  const [showSettings, setShowSettings] = useState(false);
  const load = () => adminApi.get('/dossiers').then(r => setList(r.data)).catch(() => {});
  useEffect(() => { load(); }, []);
  return (
    <>
      <Title sub="Consultez les fiches/dossiers et délivrez des ordonnances. Une ordonnance nécessite un dossier créé par l'admin.">👨‍⚕️ Espace Docteur</Title>
      <div style={{ marginBottom: 16 }}>
        <button className={showSettings ? 'btn btn-primary' : 'btn btn-secondary'} onClick={() => setShowSettings(v => !v)}>⚙️ Paramètres (login / mot de passe)</button>
      </div>
      {showSettings && <DocteurIdentifiants admin={admin} onUpdate={onUpdate} />}
      <div className="table-wrap">
        <table>
          <thead><tr><th>ID Patient</th><th>Patient</th><th>Âge</th><th>Dossier</th><th>Ordonnances</th><th>Action</th></tr></thead>
          <tbody>
            {list.map(p => (
              <tr key={p.id_patient}>
                <td><strong>{p.id_patient}</strong></td>
                <td>{p.prenom} {p.nom}<br /><small className="muted">{p.email}</small></td>
                <td>{p.age}</td>
                <td>{p.hasDossier ? <span className="badge-status bs-confirmed">Créé</span> : <span className="badge-status bs-pending">Aucun dossier</span>}</td>
                <td>{p.hasDossier ? p.ordCount : '—'}</td>
                <td>{p.hasDossier
                  ? <button className="btn btn-secondary" onClick={() => setOpen(p.id_patient)}>🩺 Consulter</button>
                  : <small className="muted">Dossier requis</small>}</td>
              </tr>
            ))}
            {!list.length && <tr><td colSpan="6" className="center muted" style={{ padding: 24 }}>Aucun patient.</td></tr>}
          </tbody>
        </table>
      </div>
      {open && <DoctorModal id={open} onClose={() => { setOpen(null); load(); }} />}
      <DocteurStock />
    </>
  );
}

/* ── Gestion sensible du stock (docteur uniquement) ── */
function DocteurStock() {
  const [list, setList] = useState([]);
  const [corr, setCorr] = useState({});
  const [editId, setEditId] = useState(null);
  const [edit, setEdit] = useState({});
  const [showEdit, setShowEdit] = useState(false);
  const [showJournal, setShowJournal] = useState(false);
  const [msg, setMsg] = useState(null);
  const flash = (t) => { setMsg(t); setTimeout(() => setMsg(null), 2800); };
  const load = () => adminApi.get('/produits').then(r => setList(r.data)).catch(() => {});
  useEffect(() => { load(); }, []);
  const correction = async (id) => {
    const raw = corr[id];
    if (raw === '' || raw === undefined || isNaN(parseInt(raw, 10))) return alert('Nouvelle quantité invalide.');
    try {
      await adminApi.post(`/produits/${id}/correction`, { nouvelle_quantite: parseInt(raw, 10) });
      setCorr({ ...corr, [id]: '' }); flash('Correction enregistrée (inscrite en rouge au journal).'); load();
    } catch (e) { alert(e.response?.data?.error || 'Erreur.'); }
  };
  const del = async (id) => { if (confirm('Supprimer ce produit ?')) { await adminApi.delete(`/produits/${id}`); load(); } };
  const startEdit = (p) => { setEditId(p.id); setEdit({ nom: p.nom, type: p.type, unite: p.unite, seuil_secu: p.seuil_secu }); };
  const saveEdit = async (id) => { await adminApi.put(`/produits/${id}`, edit); setEditId(null); load(); };
  const inp = { width: '100%', padding: '10px 12px', borderRadius: 10, border: '1.5px solid rgba(82,183,136,.25)' };
  return (
    <div className="card" style={{ marginTop: 18 }}>
      <h3 style={{ marginTop: 0 }}>📦 Gestion sensible du stock</h3>
      <p className="muted" style={{ fontSize: 13 }}>Correction, modification, suppression de produits et journal de traçabilité — réservé au docteur.</p>
      {msg && <div className="alert success">{msg}</div>}
      <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', margin: '12px 0' }}>
        <button className={showEdit ? 'btn btn-primary' : 'btn btn-secondary'} onClick={() => setShowEdit(v => !v)}>✎ Modifier le stock</button>
        <button className={showJournal ? 'btn btn-primary' : 'btn btn-secondary'} onClick={() => setShowJournal(v => !v)}>📜 Journal de traçabilité</button>
      </div>

      {showEdit && (
        <div className="table-wrap">
          <table>
            <thead><tr><th>Produit</th><th>Stock réel</th><th>Prévis.</th><th>Seuil</th><th>Correction (=)</th><th>Modifier</th><th></th></tr></thead>
            <tbody>
              {list.map(p => editId === p.id ? (
                <tr key={p.id}><td colSpan="7">
                  <div className="form-row2">
                    <div className="fg"><label>Nom</label><input style={inp} value={edit.nom || ''} onChange={e => setEdit({ ...edit, nom: e.target.value })} /></div>
                    <div className="fg"><label>Type</label><input style={inp} value={edit.type || ''} onChange={e => setEdit({ ...edit, type: e.target.value })} /></div>
                  </div>
                  <div className="form-row2">
                    <div className="fg"><label>Unité</label><input style={inp} value={edit.unite || ''} onChange={e => setEdit({ ...edit, unite: e.target.value })} /></div>
                    <div className="fg"><label>Seuil de sécurité</label><input style={inp} type="number" value={edit.seuil_secu || ''} onChange={e => setEdit({ ...edit, seuil_secu: e.target.value })} /></div>
                  </div>
                  <div style={{ display: 'flex', gap: 8, marginTop: 10 }}>
                    <button className="btn btn-green" onClick={() => saveEdit(p.id)}>💾 Enregistrer</button>
                    <button className="btn btn-secondary" onClick={() => setEditId(null)}>Annuler</button>
                  </div>
                </td></tr>
              ) : (
                <tr key={p.id}>
                  <td><strong>{p.nom}</strong> <small className="muted">/ {p.unite}</small></td>
                  <td>{p.stock_reel}</td>
                  <td className="muted">{p.previsionnel}</td>
                  <td className="muted">{p.seuil_secu}</td>
                  <td>
                    <div style={{ display: 'flex', gap: 6 }}>
                      <input type="number" min="0" value={corr[p.id] ?? ''} onChange={e => setCorr({ ...corr, [p.id]: e.target.value })}
                             style={{ width: 70, padding: '6px 8px', borderRadius: 8, border: '1.5px solid #ffcdd2' }} placeholder="réel" />
                      <button className="btn-red" style={{ padding: '6px 12px' }} title="Corriger le stock réel" onClick={() => correction(p.id)}>✎</button>
                    </div>
                  </td>
                  <td><button className="btn btn-secondary" onClick={() => startEdit(p)}>Modifier</button></td>
                  <td><button className="btn-red" onClick={() => del(p.id)}>🗑️</button></td>
                </tr>
              ))}
              {!list.length && <tr><td colSpan="7" className="center muted" style={{ padding: 24 }}>Aucun produit.</td></tr>}
            </tbody>
          </table>
        </div>
      )}

      {showJournal && (
        <div className="card" style={{ background: '#fff', marginTop: 12 }}>
          <h4 style={{ marginTop: 0 }}>📜 Journal de traçabilité</h4>
          <JournalTab />
        </div>
      )}
    </div>
  );
}

function DoctorModal({ id, onClose }) {
  const [d, setD] = useState(null);
  const [med, setMed] = useState('Dr. Wael Ghabara');
  const [txt, setTxt] = useState('');
  const load = () => adminApi.get(`/dossiers/${id}`).then(r => setD(r.data)).catch(() => {});
  useEffect(() => { load(); }, [id]);
  if (!d) return null;
  const p = d.patient || {};

  const add = async () => {
    if (!txt.trim()) return alert('Saisissez la prescription.');
    const { data } = await adminApi.post(`/dossiers/${id}/ordonnances`, { medecin: med, contenu: txt });
    setD(data); setTxt('');
  };
  const del = async (oid) => { const { data } = await adminApi.delete(`/dossiers/${id}/ordonnances/${oid}`); setD(data); };

  return (
    <div className="modal-overlay" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal">
        <button className="modal-close" onClick={onClose}>✕</button>
        <h3>🩺 Fiche patient — {d.id_dossier}</h3>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '6px 16px', background: 'var(--g6)', borderRadius: 12, padding: 16, fontSize: 13, marginTop: 10 }}>
          <div><span className="muted">Nom :</span> <strong>{p.prenom} {p.nom}</strong></div>
          <div><span className="muted">Âge :</span> {p.age} ans</div>
          <div><span className="muted">Genre :</span> {p.genre}</div>
          <div><span className="muted">Tél :</span> {p.tel}</div>
          <div style={{ gridColumn: '1/3' }}><span className="muted">Groupe sanguin :</span> {d.groupe_sanguin || '—'}</div>
          <div style={{ gridColumn: '1/3' }}><span className="muted">Allergies :</span> {d.allergies || '—'}</div>
          <div style={{ gridColumn: '1/3' }}><span className="muted">Antécédents :</span> {d.antecedents || '—'}</div>
        </div>

        <h4>📎 Documents</h4>
        {(d.documents || []).map(doc => (
          <button key={doc.id} className="btn btn-secondary" style={{ marginRight: 8, marginBottom: 8, padding: '6px 12px' }}
                  onClick={() => downloadDocument(doc)}>📎 {doc.name}</button>
        ))}
        {!(d.documents || []).length && <p className="muted" style={{ fontSize: 13 }}>Aucun document.</p>}

        <h4>💊 Ordonnances</h4>
        {(d.ordonnances || []).map(o => (
          <div key={o.id} style={{ background: 'var(--g6)', borderRadius: 10, padding: 12, marginBottom: 8 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, fontWeight: 600, color: 'var(--g1)' }}>
              <span>📋 {new Date(o.date).toLocaleDateString('fr-FR')} — {o.medecin}</span>
              <button className="btn-red" onClick={() => del(o.id)}>🗑️</button>
            </div>
            <div style={{ whiteSpace: 'pre-wrap', fontSize: 13, marginTop: 6 }}>{o.contenu}</div>
          </div>
        ))}
        {!(d.ordonnances || []).length && <p className="muted" style={{ fontSize: 13 }}>Aucune ordonnance.</p>}

        <h4>✍️ Nouvelle ordonnance</h4>
        <div className="fg"><label>Médecin</label><input value={med} onChange={e => setMed(e.target.value)} /></div>
        <div className="fg"><label>Prescription</label>
          <textarea rows="4" value={txt} onChange={e => setTxt(e.target.value)} placeholder="Médicaments, posologie, durée..." /></div>
        <button className="btn btn-primary" onClick={add}>💊 Délivrer l'ordonnance</button>
      </div>
    </div>
  );
}

/* ─────────────── SERVICES ─────────────── */
function ServicesPanel() {
  const [list, setList] = useState([]);
  const [consos, setConsos] = useState([]);
  const [produits, setProduits] = useState([]);
  const [n, setN] = useState({ ico: '🦷', name: '', prix: '', descr: '' });
  const [editId, setEditId] = useState(null);
  const [edit, setEdit] = useState({});
  const [addConso, setAddConso] = useState({});
  const loadServices = () => adminApi.get('/services').then(r => setList(r.data)).catch(() => {});
  const loadConsos = () => adminApi.get('/service-consommables').then(r => setConsos(r.data)).catch(() => {});
  const loadProduits = () => adminApi.get('/produits').then(r => setProduits(r.data)).catch(() => {});
  useEffect(() => { loadServices(); loadConsos(); loadProduits(); }, []);
  const add = async () => {
    if (!n.name) return alert('Nom requis.');
    const { data } = await adminApi.post('/services', n); setList(data); setN({ ico: '🦷', name: '', prix: '', descr: '' });
  };
  const del = async (id) => { if (!confirm('Supprimer ce service ?')) return; const { data } = await adminApi.delete(`/services/${id}`); setList(data); loadConsos(); };
  const startEdit = (s) => { setEditId(s.id); setEdit({ ico: s.ico, name: s.name, prix: s.prix, descr: s.descr }); };
  const saveEdit = async (id) => { const { data } = await adminApi.put(`/services/${id}`, edit); setList(data); setEditId(null); loadConsos(); };
  const addConsoLine = async (serviceName) => {
    const a = addConso[serviceName] || {};
    if (!a.id_produit) return alert('Choisis un consommable.');
    await adminApi.post('/service-consommables', { service: serviceName, id_produit: a.id_produit, quantite: parseInt(a.quantite, 10) || 1 });
    setAddConso({ ...addConso, [serviceName]: { id_produit: '', quantite: 1 } }); loadConsos();
  };
  const delConsoLine = async (id) => { await adminApi.delete(`/service-consommables/${id}`); loadConsos(); };
  const consosOf = (name) => consos.filter(c => c.service === name);
  const inp = { width: '100%', padding: '10px 12px', borderRadius: 10, border: '1.5px solid rgba(82,183,136,.25)' };
  return (
    <>
      <Title sub="Prestations affichées sur l'accueil + consommables réservés automatiquement à chaque RDV">🦷 Services</Title>
      <div className="form-card">
        <h3>➕ Ajouter un service</h3>
        <div className="form-row2">
          <div className="fg"><label>Icône</label><input value={n.ico} onChange={e => setN({ ...n, ico: e.target.value })} /></div>
          <div className="fg"><label>Nom</label><input value={n.name} onChange={e => setN({ ...n, name: e.target.value })} placeholder="Soin" /></div>
        </div>
        <div className="form-row2">
          <div className="fg"><label>Prix</label><input value={n.prix} onChange={e => setN({ ...n, prix: e.target.value })} placeholder="60 DT" /></div>
          <div className="fg"><label>Description</label><input value={n.descr} onChange={e => setN({ ...n, descr: e.target.value })} /></div>
        </div>
        <button className="btn btn-primary" onClick={add}>Ajouter</button>
      </div>

      {list.map(s => (
        <div key={s.id} className="card" style={{ marginBottom: 16 }}>
          {editId === s.id ? (
            <div>
              <div className="form-row2">
                <div className="fg"><label>Icône</label><input style={inp} value={edit.ico || ''} onChange={e => setEdit({ ...edit, ico: e.target.value })} /></div>
                <div className="fg"><label>Nom</label><input style={inp} value={edit.name || ''} onChange={e => setEdit({ ...edit, name: e.target.value })} /></div>
              </div>
              <div className="form-row2">
                <div className="fg"><label>Prix</label><input style={inp} value={edit.prix || ''} onChange={e => setEdit({ ...edit, prix: e.target.value })} /></div>
                <div className="fg"><label>Description</label><input style={inp} value={edit.descr || ''} onChange={e => setEdit({ ...edit, descr: e.target.value })} /></div>
              </div>
              <div style={{ display: 'flex', gap: 8, marginTop: 10 }}>
                <button className="btn btn-green" onClick={() => saveEdit(s.id)}>💾 Enregistrer</button>
                <button className="btn btn-secondary" onClick={() => setEditId(null)}>Annuler</button>
              </div>
            </div>
          ) : (
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <span style={{ fontSize: 26 }}>{s.ico}</span>
              <div style={{ flex: 1 }}>
                <strong>{s.name}</strong> <span className="muted">— {s.prix}</span>
                {s.descr && <div className="muted" style={{ fontSize: 13 }}>{s.descr}</div>}
              </div>
              <button className="btn btn-secondary" onClick={() => startEdit(s)}>✎ Modifier</button>
              <button className="btn-red" onClick={() => del(s.id)}>🗑️</button>
            </div>
          )}

          <div style={{ marginTop: 14, paddingTop: 14, borderTop: '1px solid rgba(82,183,136,.15)' }}>
            <h4 style={{ margin: '0 0 8px' }}>🧩 Consommables réservés automatiquement par RDV</h4>
            {consosOf(s.name).length === 0 && <p className="muted" style={{ fontSize: 13, margin: '0 0 8px' }}>Aucun consommable défini pour ce service.</p>}
            {consosOf(s.name).map(c => (
              <div key={c.id} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '4px 0' }}>
                <span style={{ flex: 1 }}>{c.nom} <small className="muted">/ {c.unite}</small></span>
                <span className="badge-status" style={{ background: 'var(--g5)', color: 'var(--g2)' }}>×{c.quantite}</span>
                <button className="btn-red" style={{ padding: '4px 10px' }} onClick={() => delConsoLine(c.id)}>✕</button>
              </div>
            ))}
            <div style={{ display: 'flex', gap: 8, marginTop: 10, flexWrap: 'wrap', alignItems: 'flex-end' }}>
              <select value={(addConso[s.name] || {}).id_produit || ''} onChange={e => setAddConso({ ...addConso, [s.name]: { ...(addConso[s.name] || {}), id_produit: e.target.value } })}
                      style={{ ...inp, width: 'auto', flex: 1, minWidth: 160 }}>
                <option value="">— Consommable —</option>
                {produits.map(p => <option key={p.id} value={p.id}>{p.nom}</option>)}
              </select>
              <input type="number" min="1" placeholder="qté" value={(addConso[s.name] || {}).quantite || ''} onChange={e => setAddConso({ ...addConso, [s.name]: { ...(addConso[s.name] || {}), quantite: e.target.value } })}
                     style={{ ...inp, width: 80 }} />
              <button className="btn btn-primary" onClick={() => addConsoLine(s.name)}>Ajouter</button>
            </div>
          </div>
        </div>
      ))}
    </>
  );
}

/* ─────────────── HORAIRES ─────────────── */
function HorairesPanel() {
  const [list, setList] = useState([]);
  useEffect(() => { adminApi.get('/horaires').then(r => setList(r.data)).catch(() => {}); }, []);
  const upd = (i, k, v) => { const c = [...list]; c[i] = { ...c[i], [k]: v }; setList(c); };
  const save = async () => { await adminApi.put('/horaires', { horaires: list }); alert('Horaires enregistrés.'); };
  return (
    <>
      <Title sub="Horaires affichés sur la page d'accueil">🕐 Horaires</Title>
      <div className="card">
        {list.map((h, i) => (
          <div key={h.id} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '8px 0', borderBottom: '1px solid rgba(82,183,136,.12)' }}>
            <span style={{ width: 110, fontWeight: 500 }}>{h.jour}</span>
            <input value={h.ouverture || ''} onChange={e => upd(i, 'ouverture', e.target.value)} placeholder="08:00" style={{ width: 90, padding: 8, borderRadius: 8, border: '1.5px solid rgba(82,183,136,.25)' }} disabled={h.ferme} />
            <span>→</span>
            <input value={h.fermeture || ''} onChange={e => upd(i, 'fermeture', e.target.value)} placeholder="18:00" style={{ width: 90, padding: 8, borderRadius: 8, border: '1.5px solid rgba(82,183,136,.25)' }} disabled={h.ferme} />
            <label style={{ marginLeft: 'auto', fontSize: 13, display: 'flex', gap: 6, alignItems: 'center' }}>
              <input type="checkbox" checked={!!h.ferme} onChange={e => upd(i, 'ferme', e.target.checked ? 1 : 0)} /> Fermé
            </label>
          </div>
        ))}
        <button className="btn btn-primary" style={{ marginTop: 16 }} onClick={save}>💾 Enregistrer</button>
      </div>
    </>
  );
}

/* ─────────────── NOTES ─────────────── */
function NotesPanel() {
  const [notes, setNotes] = useState([]);
  const [patients, setPatients] = useState([]);
  const [n, setN] = useState({ id_patient: '', texte: '' });
  const load = () => {
    adminApi.get('/notes').then(r => setNotes(r.data)).catch(() => {});
    adminApi.get('/patients').then(r => setPatients(r.data)).catch(() => {});
  };
  useEffect(() => { load(); }, []);
  const add = async () => {
    if (!n.id_patient || !n.texte) return alert('Patient et note requis.');
    const { data } = await adminApi.post('/notes', n); setNotes(data); setN({ id_patient: '', texte: '' });
  };
  return (
    <>
      <Title sub="Notes de suivi visibles par le patient dans son espace">📝 Notes patients</Title>
      <div className="form-card">
        <h3>➕ Nouvelle note</h3>
        <div className="fg"><label>Patient</label>
          <select value={n.id_patient} onChange={e => setN({ ...n, id_patient: e.target.value })}>
            <option value="">— Choisir —</option>
            {patients.map(p => <option key={p.id_patient} value={p.id_patient}>{p.id_patient} — {p.prenom} {p.nom}</option>)}
          </select></div>
        <div className="fg"><label>Note</label><textarea rows="3" value={n.texte} onChange={e => setN({ ...n, texte: e.target.value })} /></div>
        <button className="btn btn-primary" onClick={add}>Ajouter</button>
      </div>
      <div className="table-wrap">
        <table>
          <thead><tr><th>Patient</th><th>Date</th><th>Note</th></tr></thead>
          <tbody>
            {notes.map(x => <tr key={x.id}><td><strong>{x.id_patient}</strong></td><td>{x.date}</td><td>{x.texte}</td></tr>)}
            {!notes.length && <tr><td colSpan="3" className="center muted" style={{ padding: 24 }}>Aucune note.</td></tr>}
          </tbody>
        </table>
      </div>
    </>
  );
}

/* ─────────────── INFOS CABINET ─────────────── */
function InfoPanel() {
  const [info, setInfo] = useState({ name: '', doctor: '', tel: '', email: '', addr: '' });
  useEffect(() => { adminApi.get('/info').then(r => setInfo(r.data || {})).catch(() => {}); }, []);
  const save = async () => { const { data } = await adminApi.put('/info', info); setInfo(data); alert('Informations enregistrées.'); };
  return (
    <>
      <Title sub="Coordonnées affichées sur tout le site">ℹ️ Infos cabinet</Title>
      <div className="card" style={{ maxWidth: 520 }}>
        <div className="fg"><label>Nom du cabinet</label><input value={info.name || ''} onChange={e => setInfo({ ...info, name: e.target.value })} /></div>
        <div className="fg"><label>Médecin</label><input value={info.doctor || ''} onChange={e => setInfo({ ...info, doctor: e.target.value })} /></div>
        <div className="fg"><label>Téléphone</label><input value={info.tel || ''} onChange={e => setInfo({ ...info, tel: e.target.value })} /></div>
        <div className="fg"><label>Email</label><input value={info.email || ''} onChange={e => setInfo({ ...info, email: e.target.value })} /></div>
        <div className="fg"><label>Adresse</label><input value={info.addr || ''} onChange={e => setInfo({ ...info, addr: e.target.value })} /></div>
        <button className="btn btn-primary" onClick={save}>💾 Enregistrer</button>
      </div>
    </>
  );
}

/* ═══════════════════════════════════════════════════════════
 *  STOCK — produits / réception / paniers / modèles / journal
 * ═══════════════════════════════════════════════════════════ */
function StockPanel() {
  const [tab, setTab] = useState('produits');
  const tabs = [
    ['produits', '📦 Produits & réception'],
    ['paniers',  '🧺 Paniers (RDV)'],
  ];
  return (
    <>
      <Title sub="Réception des consommables et paniers des rendez-vous">📦 Gestion de stock</Title>
      <div style={{ display: 'flex', gap: 8, marginBottom: 20, flexWrap: 'wrap' }}>
        {tabs.map(([k, l]) => (
          <button key={k} onClick={() => setTab(k)}
                  className={tab === k ? 'btn btn-primary' : 'btn btn-secondary'} style={{ fontSize: 13 }}>{l}</button>
        ))}
      </div>
      {tab === 'produits' && <ProduitsTab />}
      {tab === 'paniers'  && <PaniersTab />}
    </>
  );
}

const ResaBadge = ({ statut }) => {
  const map = {
    en_attente: ['#fff3e0', '#e65100', 'En attente'],
    confirmee:  ['var(--g5)', 'var(--g2)', 'Confirmée'],
    annulee:    ['#eceff1', '#607d8b', 'Annulée'],
  };
  const [bg, col, txt] = map[statut] || map.en_attente;
  return <span className="badge-status" style={{ background: bg, color: col }}>{txt}</span>;
};

/* ── Produits & réception (vue admin : entrées de stock) ── */
function ProduitsTab() {
  const [list, setList] = useState([]);
  const [autre, setAutre] = useState({ nom: '', type: '', unite: 'pièce', quantite: '' });
  const [showAutre, setShowAutre] = useState(false);
  const [recep, setRecep] = useState({});
  const [msg, setMsg] = useState(null);
  const flash = (t) => { setMsg(t); setTimeout(() => setMsg(null), 2800); };
  const load = () => adminApi.get('/produits').then(r => setList(r.data)).catch(() => {});
  useEffect(() => { load(); }, []);
  const reception = async (id) => {
    const q = parseInt(recep[id], 10);
    if (!q || q <= 0) return alert('Quantité reçue invalide.');
    await adminApi.post(`/produits/${id}/reception`, { quantite: q });
    setRecep({ ...recep, [id]: '' }); flash(`Réception enregistrée (+${q}).`); load();
  };
  const receptionAutre = async () => {
    if (!autre.nom) return alert('Nom du produit requis.');
    const q = parseInt(autre.quantite, 10);
    if (!q || q <= 0) return alert('Quantité reçue invalide.');
    try {
      await adminApi.post('/produits/reception-autre', { nom: autre.nom, type: autre.type, unite: autre.unite, quantite: q });
      setAutre({ nom: '', type: '', unite: 'pièce', quantite: '' }); setShowAutre(false);
      flash(`Nouveau produit réceptionné (+${q}).`); load();
    } catch (e) { alert(e.response?.data?.error || 'Erreur.'); }
  };
  return (
    <>
      {msg && <div className="alert success">{msg}</div>}
      <div style={{ marginBottom: 16 }}>
        <button className={showAutre ? 'btn btn-primary' : 'btn btn-secondary'} onClick={() => setShowAutre(v => !v)}>➕ Réception d'un nouveau produit (Autre)</button>
      </div>
      {showAutre && (
        <div className="form-card">
          <h3>➕ Réception — nouveau produit</h3>
          <div className="form-row2">
            <div className="fg"><label>Nom</label><input value={autre.nom} onChange={e => setAutre({ ...autre, nom: e.target.value })} placeholder="Gants latex" /></div>
            <div className="fg"><label>Type / catégorie</label><input value={autre.type} onChange={e => setAutre({ ...autre, type: e.target.value })} placeholder="Protection" /></div>
          </div>
          <div className="form-row2">
            <div className="fg"><label>Unité</label><input value={autre.unite} onChange={e => setAutre({ ...autre, unite: e.target.value })} placeholder="pièce" /></div>
            <div className="fg"><label>Quantité reçue</label><input type="number" min="1" value={autre.quantite} onChange={e => setAutre({ ...autre, quantite: e.target.value })} /></div>
          </div>
          <button className="btn btn-green" onClick={receptionAutre}>Réceptionner</button>
        </div>
      )}
      <div className="table-wrap">
        <table>
          <thead><tr><th>Produit</th><th>Type</th><th>Stock réel</th><th>Réservé</th><th>Prévisionnel</th><th>Seuil</th><th>Réception (+)</th></tr></thead>
          <tbody>
            {list.map(p => (
              <tr key={p.id} style={p.alerte ? { background: '#fff8f6' } : {}}>
                <td><strong>{p.nom}</strong> <small className="muted">/ {p.unite}</small></td>
                <td className="muted">{p.type}</td>
                <td>{p.stock_reel}</td>
                <td className="muted">{p.reserve}</td>
                <td>
                  <strong style={{ color: p.alerte ? '#c62828' : 'var(--g2)' }}>{p.previsionnel}</strong>
                  {p.alerte && <span className="badge-status" style={{ background: '#fdecea', color: '#c62828', marginLeft: 8 }}>⚠ bas</span>}
                </td>
                <td className="muted">{p.seuil_secu}</td>
                <td>
                  <div style={{ display: 'flex', gap: 6 }}>
                    <input type="number" min="1" value={recep[p.id] || ''} onChange={e => setRecep({ ...recep, [p.id]: e.target.value })}
                           style={{ width: 70, padding: '6px 8px', borderRadius: 8, border: '1.5px solid rgba(82,183,136,.25)' }} placeholder="qté" />
                    <button className="btn btn-green" style={{ padding: '6px 12px' }} onClick={() => reception(p.id)}>↻</button>
                  </div>
                </td>
              </tr>
            ))}
            {!list.length && <tr><td colSpan="7" className="center muted" style={{ padding: 24 }}>Aucun produit. Réceptionnez un nouveau produit via « Autre ».</td></tr>}
          </tbody>
        </table>
      </div>
      <p className="muted" style={{ marginTop: 12, fontSize: 13 }}>ℹ️ La correction, la modification et la suppression de produits se font dans l'espace docteur.</p>
    </>
  );
}

/* ── Paniers (RDV) ── */
function PaniersTab() {
  const [rdvs, setRdvs] = useState([]);
  const [produits, setProduits] = useState([]);
  const [sel, setSel] = useState('');
  const [panier, setPanier] = useState([]);
  const [add, setAdd] = useState({ id_produit: '', quantite: 1 });
  const [msg, setMsg] = useState(null);
  const loadProduits = () => adminApi.get('/produits').then(r => setProduits(r.data)).catch(() => {});
  useEffect(() => { adminApi.get('/rdv').then(r => setRdvs(r.data)).catch(() => {}); loadProduits(); }, []);
  const loadPanier = (id) => { if (!id) return setPanier([]); adminApi.get(`/rdv/${id}/panier`).then(r => setPanier(r.data)).catch(() => {}); };
  const choose = (id) => { setSel(id); loadPanier(id); };
  const addLine = async () => {
    if (!sel) return alert('Choisis d’abord un rendez-vous.');
    if (!add.id_produit) return alert('Choisis un produit.');
    await adminApi.post(`/rdv/${sel}/panier`, add);
    setAdd({ id_produit: '', quantite: 1 }); loadPanier(sel);
  };
  const removeLine = async (lineId) => {
    try { await adminApi.delete(`/panier/${lineId}`); loadPanier(sel); }
    catch (e) { alert(e.response?.data?.error || 'Erreur.'); }
  };
  const confirmer = async () => {
    if (!confirm('Confirmer le panier ?\nCela génère la SORTIE de stock réelle (action irréversible).')) return;
    try {
      const { data } = await adminApi.post(`/rdv/${sel}/panier/confirmer`);
      setMsg(`✅ ${data.lignes_confirmees} ligne(s) confirmée(s) — sortie de stock effectuée, RDV marqué terminé.`);
      loadPanier(sel); loadProduits();
      setTimeout(() => setMsg(null), 4000);
    } catch (e) { alert(e.response?.data?.error || 'Erreur de confirmation.'); }
  };
  const enAttente = panier.filter(l => l.statut === 'en_attente');
  return (
    <>
      {msg && <div className="alert success">{msg}</div>}
      <div className="form-card">
        <h3>🗓️ Choisir un rendez-vous</h3>
        <div className="fg">
          <select value={sel} onChange={e => choose(e.target.value)}
                  style={{ width: '100%', padding: '10px 12px', borderRadius: 10, border: '1.5px solid rgba(82,183,136,.25)' }}>
            <option value="">— Sélectionner un RDV —</option>
            {rdvs.map(r => (
              <option key={r.id} value={r.id}>{r.ref} · {r.patient_nom} · {r.service} · {r.date} {r.heure} [{r.statut}]</option>
            ))}
          </select>
        </div>
      </div>

      {sel && (
        <>
          <div className="form-card">
            <h3>➕ Ajouter un consommable au panier</h3>
            <div className="form-row2">
              <div className="fg"><label>Produit</label>
                <select value={add.id_produit} onChange={e => setAdd({ ...add, id_produit: e.target.value })}
                        style={{ width: '100%', padding: '10px 12px', borderRadius: 10, border: '1.5px solid rgba(82,183,136,.25)' }}>
                  <option value="">— Choisir —</option>
                  {produits.map(p => <option key={p.id} value={p.id}>{p.nom} (prév. {p.previsionnel})</option>)}
                </select>
              </div>
              <div className="fg"><label>Quantité</label>
                <input type="number" min="1" value={add.quantite} onChange={e => setAdd({ ...add, quantite: e.target.value })} /></div>
            </div>
            <button className="btn btn-primary" onClick={addLine}>Réserver</button>
            <p className="muted" style={{ marginTop: 10, fontSize: 13 }}>La réservation baisse le <strong>prévisionnel</strong> mais pas le stock réel. Le stock réel ne bouge qu’à la confirmation.</p>
          </div>

          <div className="table-wrap" style={{ marginBottom: 18 }}>
            <table>
              <thead><tr><th>Consommable</th><th>Type</th><th>Quantité</th><th>Statut</th><th></th></tr></thead>
              <tbody>
                {panier.map(l => (
                  <tr key={l.id}>
                    <td><strong>{l.nom}</strong> <small className="muted">/ {l.unite}</small></td>
                    <td className="muted">{l.type}</td>
                    <td>{l.quantite}</td>
                    <td><ResaBadge statut={l.statut} /></td>
                    <td>{l.statut === 'en_attente'
                      ? <button className="btn-red" onClick={() => removeLine(l.id)}>Retirer</button>
                      : <span className="muted">—</span>}</td>
                  </tr>
                ))}
                {!panier.length && <tr><td colSpan="5" className="center muted" style={{ padding: 24 }}>Panier vide pour ce rendez-vous.</td></tr>}
              </tbody>
            </table>
          </div>

          <button className="btn btn-green" disabled={!enAttente.length} onClick={confirmer}>
            ✅ Confirmer le panier ({enAttente.length} ligne{enAttente.length > 1 ? 's' : ''}) → sortie de stock
          </button>
        </>
      )}
    </>
  );
}

/* ── Journal des mouvements (traçabilité, stock réel) ── */
function JournalTab() {
  const [list, setList] = useState([]);
  const [sens, setSens] = useState('');
  const load = () => adminApi.get('/mouvements' + (sens ? `?sens=${sens}` : '')).then(r => setList(r.data)).catch(() => {});
  useEffect(() => { load(); }, [sens]);
  const fmt = (d) => new Date(d).toLocaleString('fr-FR');
  const origine = { RECEPTION: 'Réception', RENDEZVOUS: 'Rendez-vous', CORRECTION: 'Correction' };
  return (
    <>
      <div style={{ display: 'flex', gap: 8, marginBottom: 16 }}>
        {[['', 'Tout'], ['ENTREE', 'Entrées'], ['SORTIE', 'Sorties']].map(([k, l]) => (
          <button key={k} onClick={() => setSens(k)} className={sens === k ? 'btn btn-primary' : 'btn btn-secondary'} style={{ fontSize: 13 }}>{l}</button>
        ))}
      </div>
      <p className="muted" style={{ marginBottom: 14, fontSize: 13 }}>Le journal ne contient que des faits réels (réceptions et sorties confirmées). Les réservations prévisionnelles n’y figurent pas.</p>
      <div className="table-wrap">
        <table>
          <thead><tr><th>Date</th><th>Sens</th><th>Produit</th><th>Quantité</th><th>Origine</th><th>Réf.</th></tr></thead>
          <tbody>
            {list.map(m => (
              <tr key={m.id} style={m.origine === 'CORRECTION' ? { background: '#fff5f5' } : {}}>
                <td className="muted">{fmt(m.date_mouv)}</td>
                <td>{m.origine === 'CORRECTION'
                  ? <span className="badge-status" style={{ background: '#fdecea', color: '#c62828' }}>⚠ Correctif {m.sens === 'ENTREE' ? '+' : '−'}{m.quantite}</span>
                  : <span className="badge-status" style={m.sens === 'ENTREE'
                      ? { background: 'var(--g5)', color: 'var(--g2)' }
                      : { background: '#fdecea', color: '#c62828' }}>{m.sens === 'ENTREE' ? '↘ Entrée' : '↗ Sortie'}</span>}</td>
                <td>{m.nom_produit} {m.type_produit && <small className="muted">/ {m.type_produit}</small>}</td>
                <td>{m.quantite}</td>
                <td style={m.origine === 'CORRECTION' ? { color: '#c62828', fontWeight: 600 } : {}} className={m.origine === 'CORRECTION' ? '' : 'muted'}>{origine[m.origine] || m.origine}</td>
                <td className="muted">{m.id_origine ? `#${m.id_origine}` : '—'}</td>
              </tr>
            ))}
            {!list.length && <tr><td colSpan="6" className="center muted" style={{ padding: 24 }}>Aucun mouvement enregistré.</td></tr>}
          </tbody>
        </table>
      </div>
    </>
  );
}
