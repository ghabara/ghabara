const express = require('express');
const { pool } = require('../db');
const { auth, adminOnly } = require('../middleware/auth');

const router = express.Router();
const asyncHandler = fn => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

router.get('/audit-logs', auth, adminOnly, asyncHandler(async (req, res) => {
  const where = [];
  const params = [];
  if (req.query.patient_id) {
    where.push('patient_id = ?');
    params.push(req.query.patient_id);
  }
  if (req.query.action) {
    where.push('action = ?');
    params.push(req.query.action);
  }
  if (req.query.entity_type) {
    where.push('entity_type = ?');
    params.push(req.query.entity_type);
  }
  const [rows] = await pool.query(
    `SELECT id, actor, actor_role, action, entity_type, entity_id, patient_id,
            ip_address, user_agent, details_json, created_at
     FROM audit_logs
     ${where.length ? `WHERE ${where.join(' AND ')}` : ''}
     ORDER BY created_at DESC, id DESC
     LIMIT 500`,
    params
  );
  res.json(rows);
}));

router.use((err, _req, res, _next) => {
  res.status(400).json({ error: err.message || 'Erreur securite.' });
});

module.exports = router;
