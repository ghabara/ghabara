﻿import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import api, { getUser, logout } from '../api';
import BrandLogo from '../components/BrandLogo.jsx';

export default function Profil() {
  const user = getUser();
  const navigate = useNavigate();
  const [rdvs, setRdvs] = useState([]);
  const [notes, setNotes] = useState([]);
  const [tab, setTab] = useState('rdv');

  const load = () => {
    api.get('/rdv/me').then(r => setRdvs(r.data)).catch(() => {});
    api.get('/notes/me').then(r => setNotes(r.data)).catch(() => {});
  };
  useEffect(() => { load(); }, []);

  const cancel = async (id) => {
    if (!confirm('Annuler ce rendez-vous ?')) return;
    await api.put(`/rdv/${id}`, { statut: 'cancelled' });
    load();
  };

  const statusBadge = (s) => {
    const map = { pending: ['bs-pending', 'En attente'], confirmed: ['bs-confirmed', 'Confirmé'], done: ['bs-done', 'Terminé'], cancelled: ['bs-cancelled', 'Annulé'] };
    const [cls, label] = map[s] || ['bs-pending', s];
    return <span className={`badge-status ${cls}`}>{label}</span>;
  };

  const active = rdvs.filter(r => r.statut !== 'cancelled').length;

  return (
    <div>
      <nav className="navbar"><div className="navbar-inner">
        <Link to="/" className="brand-link"><BrandLogo compact className="brand-logo--nav" /></Link>
        <div className="nav-links">
          <Link to="/">Accueil</Link>
          <Link to="/rdv" className="btn btn-primary" style={{ padding: '10px 18px' }}>📅 Nouveau RDV</Link>
          <a style={{ cursor: 'pointer' }} onClick={() => { logout(); navigate('/'); }}>Déconnexion</a>
        </div>
      </div></nav>

      <div style={{ maxWidth: 1000, margin: '0 auto', padding: '40px 24px' }}>
        {/* En-tête patient */}
        <div className="card" style={{ display: 'flex', alignItems: 'center', gap: 18, marginBottom: 24 }}>
          <div style={{ width: 64, height: 64, borderRadius: '50%', background: 'var(--g2)', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 26, fontFamily: "'Playfair Display', serif" }}>
            {user.prenom?.[0]}{user.nom?.[0]}
          </div>
          <div>
            <h2 style={{ fontFamily: "'Playfair Display', serif", color: 'var(--g1)' }}>{user.prenom} {user.nom}</h2>
            <p className="muted">ID : <strong>{user.id_patient}</strong> · {user.email} · {user.tel}</p>
          </div>
        </div>

        {/* Stats */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(150px,1fr))', gap: 14, marginBottom: 24 }}>
          <Stat label="RDV actifs" val={active} />
          <Stat label="Total RDV" val={rdvs.length} />
          <Stat label="Notes médicales" val={notes.length} />
        </div>

        {/* Onglets */}
        <div style={{ display: 'flex', gap: 8, marginBottom: 16 }}>
          <button className={`btn ${tab === 'rdv' ? 'btn-primary' : 'btn-secondary'}`} onClick={() => setTab('rdv')}>📅 Mes rendez-vous</button>
          <button className={`btn ${tab === 'notes' ? 'btn-primary' : 'btn-secondary'}`} onClick={() => setTab('notes')}>📝 Notes du médecin</button>
        </div>

        {tab === 'rdv' && (
          <div className="table-wrap">
            <table>
              <thead><tr><th>Réf</th><th>Service</th><th>Date</th><th>Heure</th><th>Statut</th><th>Action</th></tr></thead>
              <tbody>
                {rdvs.map(r => (
                  <tr key={r.id}>
                    <td>{r.ref}</td><td>{r.service}</td><td>{r.date}</td><td>{r.heure}</td>
                    <td>{statusBadge(r.statut)}</td>
                    <td>{r.statut !== 'cancelled' && r.statut !== 'done'
                      ? <button className="btn-red" onClick={() => cancel(r.id)}>Annuler</button> : '—'}</td>
                  </tr>
                ))}
                {!rdvs.length && <tr><td colSpan="6" className="center muted" style={{ padding: 24 }}>Aucun rendez-vous.</td></tr>}
              </tbody>
            </table>
          </div>
        )}

        {tab === 'notes' && (
          <div className="card">
            {notes.length ? notes.map(n => (
              <div key={n.id} style={{ background: 'var(--g6)', borderRadius: 12, padding: 16, marginBottom: 12 }}>
                <div style={{ fontSize: 12, color: 'var(--g2)', fontWeight: 600 }}>📋 {n.date}</div>
                <div style={{ marginTop: 6, whiteSpace: 'pre-wrap' }}>{n.texte}</div>
              </div>
            )) : <p className="muted center">Aucune note pour le moment.</p>}
          </div>
        )}
      </div>
    </div>
  );
}

function Stat({ label, val }) {
  return (
    <div className="card" style={{ padding: 18 }}>
      <div className="muted" style={{ fontSize: 12 }}>{label}</div>
      <div style={{ fontSize: 30, fontWeight: 700, color: 'var(--g1)' }}>{val}</div>
    </div>
  );
}
