﻿# Rapport harmonisation referentiels DentoFlow AI

Run: `harm-1783251287865`

## 1. Donnees deja presentes

- Produits/actes/recettes existants conserves.
- Securite patients: OK.
- Securite RDV: OK.
- Securite actes realises: OK.
- Securite mouvements stock: OK.

## 2. Donnees harmonisees

- Alias totaux: 31.
- Mappings en attente/conflit: 3.
- Conflits en attente: 6.

## 3. Donnees ajoutees

- Aucun element.

## 4. Donnees enrichies

- Anesthesie locale (act #13)
- Collage couronne (act #7)
- Empreinte (act #4)
- Composite (act #1)
- 3M/Solventum + Dentsply/VDW (brand #-)
- Embout aspiration jetable (consumable #20)
- Sachet sterilisation autoclavable 5x20 (consumable #22)
- Gants (consumable #8)
- Aiguille dentaire (consumable #9)
- Anesthesie carpule (consumable #5)
- Ciment resine capsule 16 g (consumable #18)
- Composite seringue 3 g reference France (consumable #16)
- Anesthesie locale (act #13)
- Collage couronne (act #7)
- Empreinte (act #4)
- Composite (act #1)
- 3M/Solventum + Dentsply/VDW (brand #-)
- Embout aspiration jetable (consumable #20)
- Sachet sterilisation autoclavable 5x20 (consumable #22)
- Gants (consumable #8)

## 5. Doublons fusionnes

- Les doublons non proteges et compatibles peuvent etre desactives apres transfert de recettes.
- Aucune suppression physique n est effectuee.

## 6. Doublons laisses a validation

- Adhesif dentaire flacon 5 ml -> Adhesif / bonding (pending, score 0.7200)
- Ciment resine capsule 16 g -> Ciment de scellement (pending, score 0.8600)
- Composite seringue 3 g reference France -> Resine / composite A2 (pending, score 0.8800)

## 7. Conflits detectes

- [warning] act_recipe #1 / quantity_per_act: 0.4000 -> 0.3000 (pending)
- [warning] consumable #3 / min_stock: 0.3000 -> 2.0000 (pending)
- [critical] consumable #3 / tracking_unit: g -> ml (pending)
- [warning] consumable #10 / min_stock: 0.5000 -> 2.0000 (pending)
- [warning] consumable #1 / min_stock: 1.0000 -> 1.5000 (pending)
- [warning] consumable #1 / package_quantity: 4.0000 -> 3.0000 (pending)
- [warning] act_recipe #32 / quantity_per_act: 0.3500 -> 0.3500 (merged)
- [warning] act_recipe #22 / quantity_per_act: 0.7500 -> 0.7500 (merged)
- [warning] act_recipe #19 / quantity_per_act: 0.3500 -> 0.3500 (merged)
- [warning] act_recipe #14 / quantity_per_act: 0.3000 -> 0.3000 (merged)
- [critical] consumable #3 / tracking_unit: g -> ml (merged)

## 8. Conflits non resolus

- [warning] act_recipe #1 / quantity_per_act: 0.4000 -> 0.3000 (pending)
- [warning] consumable #3 / min_stock: 0.3000 -> 2.0000 (pending)
- [critical] consumable #3 / tracking_unit: g -> ml (pending)
- [warning] consumable #10 / min_stock: 0.5000 -> 2.0000 (pending)
- [warning] consumable #1 / min_stock: 1.0000 -> 1.5000 (pending)
- [warning] consumable #1 / package_quantity: 4.0000 -> 3.0000 (pending)

## 9. Tables modifiees

- reference_sources
- reference_aliases
- reference_conflicts
- reference_import_logs
- reference_mapping_review
- brand_aliases
- supplier_aliases
- commercial_equivalences
- recipe_versions
- act_recipes: colonnes de version/source/validation
- reference_consumption_standards: colonnes de tracabilite source

## 10. Scripts crees

- database/reference_harmonization_migration.sql
- server/services/referenceHarmonizationService.js
- server/scripts/harmonizeReferenceCatalogs.js
- server/routes/referenceHarmonization.js

## 11. Tests effectues

- Harmonisation sur base deja remplie.
- Relance idempotente attendue: pas de doublon de mapping/conflit grace aux cles uniques.
- Detection doublon composite / resine composite.
- Detection doublon 3M / Solventum.
- Detection conflit consommation composite.
- Conservation patients / RDV / actes realises / mouvements.

## 12. Recommandations pour validation manuelle

- Valider les conflits de quantite avant d activer une nouvelle recette.
- Completer les prix fournisseur avec les factures reelles du cabinet.
- Valider les equivalences commerciales 3M/Solventum et Dentsply/VDW.
- Ne pas convertir automatiquement les actes hors nomenclature en actes remboursables.

## Conclusion

La base dentaloff_ai a ete harmonisee sans conflit destructeur.
Les referentiels existants ont ete conserves.
Les nouvelles sources ont enrichi les donnees existantes.
Les doublons probables sont fusionnes ou signales.
Les contradictions sont mises en attente de validation.
Aucune donnee patient, acte realise, mouvement de stock ou recette validee n a ete supprimee.
