USE dentaloff_ai;

-- References extraites du PDF :
-- "Rapport analytique sur la consommation des produits dentaires professionnels (France)"
-- Objectif : enrichir Stock AI avec des standards France utilisables par les recettes,
-- les alertes et les propositions d'achat.

CREATE TABLE IF NOT EXISTS reference_consumption_standards (
  id INT AUTO_INCREMENT PRIMARY KEY,
  standard_key VARCHAR(120) NOT NULL,
  source_document VARCHAR(160) NOT NULL,
  source_page INT NULL,
  category VARCHAR(120) NOT NULL,
  product_label VARCHAR(160) NOT NULL,
  act_context VARCHAR(160) NOT NULL DEFAULT '',
  manufacturer_example VARCHAR(160) NULL,
  package_description VARCHAR(255) NULL,
  package_quantity_min DECIMAL(12,4) NULL,
  package_quantity_max DECIMAL(12,4) NULL,
  package_unit VARCHAR(30) NULL,
  usage_min DECIMAL(12,4) NULL,
  usage_typical DECIMAL(12,4) NULL,
  usage_max DECIMAL(12,4) NULL,
  usage_unit VARCHAR(30) NULL,
  patients_covered_min DECIMAL(12,4) NULL,
  patients_covered_typical DECIMAL(12,4) NULL,
  patients_covered_max DECIMAL(12,4) NULL,
  uncertainty TEXT NULL,
  notes TEXT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_reference_consumption_standard (standard_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS reference_market_indicators (
  id INT AUTO_INCREMENT PRIMARY KEY,
  source_document VARCHAR(160) NOT NULL,
  indicator_key VARCHAR(120) NOT NULL,
  label VARCHAR(200) NOT NULL,
  value_min DECIMAL(18,4) NULL,
  value_typical DECIMAL(18,4) NULL,
  value_max DECIMAL(18,4) NULL,
  unit VARCHAR(60) NULL,
  year_label VARCHAR(40) NULL,
  source_page INT NULL,
  notes TEXT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_reference_market_indicator (indicator_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO reference_market_indicators
(source_document, indicator_key, label, value_min, value_typical, value_max, unit, year_label, source_page, notes)
VALUES
('Rapport analytique consommation produits dentaires France 2024','dentistes_liberaux_france','Chirurgiens-dentistes liberaux en France',35700,35700,35700,'praticiens','2024',1,'Ordre de grandeur utilise pour les projections cabinet.'),
('Rapport analytique consommation produits dentaires France 2024','population_suivie_annuelle','Part de la population prise en charge chaque annee',50,50,50,'pourcent','2024',1,'Environ un patient sur deux consulte annuellement.'),
('Rapport analytique consommation produits dentaires France 2024','depenses_soins_dentaires_liberaux','Soins dentaires en cabinet liberal',13.2,13.2,13.2,'milliards EUR','2024',1,'Base macro-economique du rapport.'),
('Rapport analytique consommation produits dentaires France 2024','part_protheses','Part protheses dentaires',42,42,42,'pourcent','2024',4,'Repartition indicative des depenses.'),
('Rapport analytique consommation produits dentaires France 2024','part_soins_conservateurs','Part soins conservateurs',23,23,23,'pourcent','2024',4,'Repartition indicative des depenses.'),
('Rapport analytique consommation produits dentaires France 2024','part_orthodontie','Part orthodontie',20,20,20,'pourcent','2024',4,'Repartition indicative des depenses.'),
('Rapport analytique consommation produits dentaires France 2024','part_radiologie_consultations','Part radiologie et consultations',5,5,5,'pourcent','2024',4,'Repartition indicative des depenses.'),
('Rapport analytique consommation produits dentaires France 2024','implants_annuels_france','Implants poses par an en France',1000000,1000000,1000000,'implants/an','2024',2,'Ordre de grandeur national.'),
('Rapport analytique consommation produits dentaires France 2024','protheses_annuelles_france','Protheses dentaires annuelles en France',10000000,10500000,11000000,'protheses/an','2024',2,'Couronnes, bridges et protheses amovibles.'),
('Rapport analytique consommation produits dentaires France 2024','tva_consommables_standard','TVA consommables standards',20,20,20,'pourcent','2024',4,'Composites, adhesifs, ciments, hygiene et sterilisation.'),
('Rapport analytique consommation produits dentaires France 2024','tva_actes_dentaires','TVA actes dentaires et protheses incluses',0,0,0,'pourcent','2024',4,'Actes dentaires hors TVA selon le rapport.')
ON DUPLICATE KEY UPDATE
label=VALUES(label), value_min=VALUES(value_min), value_typical=VALUES(value_typical),
value_max=VALUES(value_max), unit=VALUES(unit), year_label=VALUES(year_label),
source_page=VALUES(source_page), notes=VALUES(notes);

INSERT INTO reference_consumption_standards
(standard_key, source_document, category, product_label, act_context, manufacturer_example,
 package_description, package_quantity_min, package_quantity_max, package_unit,
 usage_min, usage_typical, usage_max, usage_unit,
 patients_covered_min, patients_covered_typical, patients_covered_max,
 uncertainty, notes, source_page)
VALUES
('empreinte_alginate_empreinte_empreinte_complete','Rapport analytique consommation produits dentaires France 2024','Empreinte','Alginate empreinte','Empreinte complete','Alginoplast (DMG)','Pot 450 g',450,450,'g',25,27.5,30,'g',15,15,20,'Variable selon empreinte complete ou partielle.','Pot 450 g couvrant environ 15-20 patients.',1),
('empreinte_silicone_empreinte_vps_empreinte_complete','Rapport analytique consommation produits dentaires France 2024','Empreinte','Silicone empreinte VPS','Empreinte complete','3M Express','Cartouche double 50 ml',50,50,'ml',15,17.5,20,'ml',2,2.5,3,'Variable selon type et taille de porte-empreinte.','Cartouche 50 ml couvrant environ 2-3 empreintes.',1),
('restauratrice_composite_seringue_restauration_classe_i_ii','Rapport analytique consommation produits dentaires France 2024','Restauratrice','Composite seringue','Restauration classe I-II','3M Filtek Z250','Seringue 2.7-3.5 g; reference 3 g',2.7,3.5,'g',0.2,0.3,0.4,'g',8,10,12,'Restauration volumineuse possible 0.5-0.6 g.','Consommation typique 0.3 g par restauration.',1),
('restauratrice_composite_compule_restauration_unitaire','Rapport analytique consommation produits dentaires France 2024','Restauratrice','Composite compule','Restauration unitaire','3M Filtek Z250','Compule 0.2 g',0.2,0.2,'g',0.2,0.2,0.2,'g',1,1,1,'Une compule est generalement dediee a une restauration.','Format unitaire.',2),
('collage_ciment_resine_scellement_couronne_unitaire','Rapport analytique consommation produits dentaires France 2024','Collage','Ciment resine','Scellement couronne unitaire','3M RelyX Unicem','Capsules 16 g, environ 50 x 0.32 g',16,16,'g',0.2,0.35,0.5,'g',30,50,80,'Tres variable selon morphologie et type de prothese.','Valeur typique retenue 0.35 g par couronne.',2),
('collage_ciment_resine_scellement_bridge_ou_onlay','Rapport analytique consommation produits dentaires France 2024','Collage','Ciment resine','Scellement bridge ou onlay','3M RelyX Unicem','Capsules 16 g',16,16,'g',0.5,0.75,1,'g',16,25,32,'Bridge/onlay plus consommateur qu une couronne unitaire.','Fourchette 0.5-1 g.',2),
('anesthesie_cartouche_anesthesique_anesthesie_locale','Rapport analytique consommation produits dentaires France 2024','Anesthesie','Cartouche anesthesique','Anesthesie locale','Septanest / Xylocaine','Boite 50 cartouches 1.7-1.8 ml',50,50,'carpule',1,1,1,'carpule',40,50,60,'Plusieurs cartouches possibles pour actes multiples.','Boite 50 pour environ 50 patients.',2),
('usage_unique_aiguille_injection_patient_avec_anesthesie','Rapport analytique consommation produits dentaires France 2024','Usage unique','Aiguille injection','Patient avec anesthesie','SteriLance (Terumo)','Boite 100 unites',100,100,'unite',1,1,1,'unite',100,100,100,'Usage 1:1 par patient anesthesie.','Une aiguille par patient.',2),
('usage_unique_embout_aspiration_patient_standard','Rapport analytique consommation produits dentaires France 2024','Usage unique','Embout aspiration','Patient standard','Reference generique','Paquet 500 unites',500,500,'unite',1,1,1,'unite',500,500,500,'Selon acte, aspiration non systematique.','Un tip par patient typiquement.',2),
('usage_unique_gants_patient_standard','Rapport analytique consommation produits dentaires France 2024','Usage unique','Gants','Patient standard','Reference generique','Boite 100 paires',100,100,'paire',2,2,2,'paire',50,50,50,'Depend de la duree et du nombre d intervenants.','Deux paires par patient.',2),
('usage_unique_masque_chirurgical_patient_standard','Rapport analytique consommation produits dentaires France 2024','Usage unique','Masque chirurgical','Patient standard','Reference generique','Conditionnement a confirmer',NULL,NULL,'unite',1,1,1,'unite',NULL,NULL,NULL,'Conditionnement non precise dans le rapport.','Un masque par patient dans l estimation.',2),
('sterilisation_sachet_autoclavable_5x20_set_instruments_patient','Rapport analytique consommation produits dentaires France 2024','Sterilisation','Sachet autoclavable 5x20','Set instruments patient','MELAG','Rouleau 1000 sachets',1000,1000,'sachet',1,1,1,'sachet',1000,1000,1000,'Directement lie au nombre de sets instruments.','Un sachet par patient.',3),
('sterilisation_solution_desinfectante_cycle_de_sterilisation','Rapport analytique consommation produits dentaires France 2024','Sterilisation','Solution desinfectante','Cycle de sterilisation','Glutaraldehyde 5 L','Bidon 5 L',5,5,'L',0.5,0.75,1,'L',100,200,300,'Depend du nombre d instruments traites par cycle.','5 L couvrent environ 10-20 cycles.',3),
('restauratrice_adhesif_dentaire_collage_composite_ou_prothese','Rapport analytique consommation produits dentaires France 2024','Restauratrice','Adhesif dentaire','Collage composite ou prothese','3M Scotchbond / Ivoclar Excite','Flacon 5-7 ml',5,7,'ml',0.05,0.075,0.1,'ml',50,100,150,'Forte variabilite selon nombre de dents traitees.','Quelques gouttes par dent.',3),
('prothese_couronne_prothetique_flux_cabinet','Rapport analytique consommation produits dentaires France 2024','Prothese','Couronne prothetique','Flux cabinet','Reference generique','Fabrication sur mesure',NULL,NULL,NULL,1,1,1,'cas',1,1,1,'Associe une empreinte et un scellement.','La prothese elle-meme est fabriquee au cas par cas.',2)
ON DUPLICATE KEY UPDATE
source_document=VALUES(source_document), category=VALUES(category), product_label=VALUES(product_label),
act_context=VALUES(act_context), manufacturer_example=VALUES(manufacturer_example),
package_description=VALUES(package_description), package_quantity_min=VALUES(package_quantity_min),
package_quantity_max=VALUES(package_quantity_max), package_unit=VALUES(package_unit),
usage_min=VALUES(usage_min), usage_typical=VALUES(usage_typical), usage_max=VALUES(usage_max),
usage_unit=VALUES(usage_unit), patients_covered_min=VALUES(patients_covered_min),
patients_covered_typical=VALUES(patients_covered_typical), patients_covered_max=VALUES(patients_covered_max),
uncertainty=VALUES(uncertainty), notes=VALUES(notes), source_page=VALUES(source_page);

INSERT INTO inventory_products
(name, category, sub_category, tracking_unit, package_quantity, package_unit,
 package_price_tnd, current_stock, min_stock, max_stock, supplier_alias, source_type, context_type, notes)
VALUES
('Alginate empreinte 450 g','Empreinte','Alginate','g',450,'g',NULL,900,150,1800,'Fournisseur a completer','Rapport France 2024','CABINET','Rapport France 2024: 25-30 g par empreinte complete; pot 450 g couvre 15-20 patients.'),
('Silicone empreinte cartouche 50 ml','Empreinte','Silicone VPS','ml',50,'ml',NULL,150,50,300,'Fournisseur a completer','Rapport France 2024','CABINET','Rapport France 2024: 15-20 ml par empreinte complete; cartouche 50 ml couvre 2-3 patients.'),
('Composite seringue 3 g reference France','Restauratrice','Composite','g',3,'g',NULL,9,1.5,18,'Fournisseur a completer','Rapport France 2024','CABINET','Rapport France 2024: 0.2-0.4 g par restauration moyenne; seringue 3 g couvre 8-12 patients.'),
('Composite compule 0.2 g','Restauratrice','Composite','compule',1,'compule',NULL,20,5,100,'Fournisseur a completer','Rapport France 2024','CABINET','Rapport France 2024: une compule 0.2 g pour une restauration.'),
('Ciment resine capsule 16 g','Collage','Ciment resine','g',16,'g',NULL,16,2,32,'Fournisseur a completer','Rapport France 2024','CABINET','Rapport France 2024: 0.2-0.5 g par couronne, 0.5-1 g par bridge/onlay; capsules 16 g.'),
('Adhesif dentaire flacon 5 ml','Restauratrice','Adhesif','ml',5,'ml',NULL,10,2,20,'Fournisseur a completer','Rapport France 2024','CABINET','Rapport France 2024: 0.05-0.1 ml par dent, flacon 5-7 ml.'),
('Embout aspiration jetable','Usage unique','Aspiration','unite',500,'unite',NULL,500,100,1000,'Fournisseur a completer','Rapport France 2024','CABINET','Rapport France 2024: 1 tip aspiration par patient; paquet 500.'),
('Masque chirurgical','Usage unique','Protection','unite',50,'unite',NULL,100,50,500,'Fournisseur a completer','Rapport France 2024','CABINET','Rapport France 2024: 1 masque par patient; conditionnement local a confirmer.'),
('Sachet sterilisation autoclavable 5x20','Sterilisation','Sachet','sachet',1000,'sachet',NULL,1000,200,3000,'Fournisseur a completer','Rapport France 2024','CABINET','Rapport France 2024: 1 sachet par set patient; rouleau 1000.'),
('Solution desinfectante instrumentation 5 L','Sterilisation','Desinfectant','L',5,'L',NULL,5,1,15,'Fournisseur a completer','Rapport France 2024','CABINET','Rapport France 2024: 0.5-1 L par cycle, 5 L couvre 10-20 cycles.'),
('Coton salivaire / rouleau coton','Usage unique','Coton','unite',NULL,'unite',NULL,300,60,1000,'Fournisseur a completer','Rapport France 2024','CABINET','Rapport France 2024: coton cite parmi les dispositifs a usage unique; consommation locale a mesurer.'),
('Anesthesie carpule','Anesthesie','Cartouche','carpule',50,'carpule',NULL,40,10,150,'Fournisseur a completer','Rapport France 2024','CABINET','Rapport France 2024: boite 50 cartouches 1.7-1.8 ml; 1 cartouche par patient en moyenne.'),
('Aiguille dentaire','Anesthesie','Aiguille injection','unite',100,'unite',NULL,80,20,300,'Fournisseur a completer','Rapport France 2024','CABINET','Rapport France 2024: 1 aiguille par patient avec anesthesie; boite 100.'),
('Gants','Usage unique','Protection','paire',100,'paire',NULL,100,20,500,'Fournisseur a completer','Rapport France 2024','BOTH','Rapport France 2024: 2 paires par patient; boite 100 paires couvre environ 50 patients.')
ON DUPLICATE KEY UPDATE
category=VALUES(category),
sub_category=COALESCE(inventory_products.sub_category, VALUES(sub_category)),
package_quantity=COALESCE(inventory_products.package_quantity, VALUES(package_quantity)),
package_unit=COALESCE(inventory_products.package_unit, VALUES(package_unit)),
package_price_tnd=COALESCE(inventory_products.package_price_tnd, VALUES(package_price_tnd)),
current_stock=IF(inventory_products.current_stock IS NULL OR inventory_products.current_stock=0, VALUES(current_stock), inventory_products.current_stock),
min_stock=IF(inventory_products.min_stock IS NULL OR inventory_products.min_stock=0, VALUES(min_stock), inventory_products.min_stock),
max_stock=COALESCE(inventory_products.max_stock, VALUES(max_stock)),
supplier_alias=COALESCE(inventory_products.supplier_alias, VALUES(supplier_alias)),
source_type=CASE WHEN inventory_products.source_type LIKE '%Rapport France 2024%' THEN inventory_products.source_type ELSE CONCAT_WS(' + ', NULLIF(inventory_products.source_type,''), VALUES(source_type)) END,
context_type=VALUES(context_type),
notes=CASE WHEN inventory_products.notes LIKE '%Rapport France 2024%' THEN inventory_products.notes ELSE CONCAT_WS(' | ', NULLIF(inventory_products.notes,''), VALUES(notes)) END,
is_active=1;

INSERT INTO clinical_acts
(name, clinical_variant, category, default_duration_minutes, default_price_tnd, notes)
VALUES
('Composite','Rapport France - restauration moyenne','Restauratrice',45,120,'Rapport France 2024: restauration classe I-II, 0.2-0.4 g composite, 0.3 g typique.'),
('Empreinte','Rapport France - alginate complete','Prothese',30,80,'Rapport France 2024: empreinte complete alginate 25-30 g.'),
('Empreinte','Rapport France - silicone','Prothese',30,110,'Rapport France 2024: empreinte silicone 15-20 ml.'),
('Scellement couronne','Rapport France - couronne unitaire','Prothese',45,160,'Rapport France 2024: scellement couronne 0.2-0.5 g ciment.'),
('Scellement bridge/onlay','Rapport France - bridge onlay','Prothese',60,220,'Rapport France 2024: scellement bridge ou onlay 0.5-1 g ciment.'),
('Anesthesie locale','Rapport France - patient moyen','Anesthesie',10,30,'Rapport France 2024: 1 cartouche et 1 aiguille par patient en moyenne.'),
('Set patient usage unique','Rapport France - standard','Usage unique',5,15,'Rapport France 2024: 1 tip aspiration, 2 paires de gants, 1 masque, 1 sachet sterilisation.'),
('Sterilisation cycle','Rapport France - instrumentation','Sterilisation',20,20,'Rapport France 2024: 0.5-1 L de solution par cycle.'),
('Prothese couronne','Rapport France - flux cabinet','Prothese',60,450,'Rapport France 2024: une couronne mobilise une empreinte et un scellement.')
ON DUPLICATE KEY UPDATE
category=VALUES(category), default_duration_minutes=COALESCE(clinical_acts.default_duration_minutes, VALUES(default_duration_minutes)),
default_price_tnd=COALESCE(clinical_acts.default_price_tnd, VALUES(default_price_tnd)),
notes=CASE WHEN clinical_acts.notes LIKE '%Rapport France 2024%' THEN clinical_acts.notes ELSE CONCAT_WS(' | ', NULLIF(clinical_acts.notes,''), VALUES(notes)) END,
is_active=1;

INSERT INTO act_recipes
(act_id, product_id, recipe_variant, quantity_per_act, unit, measurement_mode, confidence, source_note)
SELECT a.id, p.id, 'Standard', x.qty, x.unit, x.mode, x.confidence, x.source_note
FROM (
  SELECT 'Composite' act_name, 'Rapport France - restauration moyenne' act_variant, 'Composite seringue 3 g reference France' product_name, 0.3 qty, 'g' unit, 'estimation' mode, 'moyenne' confidence, 'Rapport France 2024: 0.2-0.4 g' source_note
  UNION ALL SELECT 'Composite','Rapport France - restauration moyenne','Adhesif dentaire flacon 5 ml',0.075,'ml','estimation','faible','Rapport France 2024: 0.05-0.1 ml'
  UNION ALL SELECT 'Composite','Rapport France - restauration moyenne','Microbrush',1,'unite','comptage','moyenne','Applicateur associe au collage'
  UNION ALL SELECT 'Empreinte','Rapport France - alginate complete','Alginate empreinte 450 g',27.5,'g','estimation','moyenne','Rapport France 2024: 25-30 g'
  UNION ALL SELECT 'Empreinte','Rapport France - silicone','Silicone empreinte cartouche 50 ml',17.5,'ml','estimation','moyenne','Rapport France 2024: 15-20 ml'
  UNION ALL SELECT 'Scellement couronne','Rapport France - couronne unitaire','Ciment resine capsule 16 g',0.35,'g','estimation','moyenne','Rapport France 2024: 0.2-0.5 g'
  UNION ALL SELECT 'Scellement couronne','Rapport France - couronne unitaire','Adhesif dentaire flacon 5 ml',0.075,'ml','estimation','faible','Collage si protocole adhesif'
  UNION ALL SELECT 'Scellement couronne','Rapport France - couronne unitaire','Microbrush',1,'unite','comptage','moyenne','Applicateur associe au collage'
  UNION ALL SELECT 'Scellement bridge/onlay','Rapport France - bridge onlay','Ciment resine capsule 16 g',0.75,'g','estimation','moyenne','Rapport France 2024: 0.5-1 g'
  UNION ALL SELECT 'Anesthesie locale','Rapport France - patient moyen','Anesthesie carpule',1,'carpule','estimation','moyenne','Rapport France 2024: 1 cartouche'
  UNION ALL SELECT 'Anesthesie locale','Rapport France - patient moyen','Aiguille dentaire',1,'unite','comptage','moyenne','Rapport France 2024: 1 aiguille'
  UNION ALL SELECT 'Set patient usage unique','Rapport France - standard','Embout aspiration jetable',1,'unite','comptage','moyenne','Rapport France 2024: 1 tip'
  UNION ALL SELECT 'Set patient usage unique','Rapport France - standard','Gants',2,'paire','comptage','moyenne','Rapport France 2024: 2 paires'
  UNION ALL SELECT 'Set patient usage unique','Rapport France - standard','Masque chirurgical',1,'unite','comptage','moyenne','Rapport France 2024: 1 masque'
  UNION ALL SELECT 'Set patient usage unique','Rapport France - standard','Sachet sterilisation autoclavable 5x20',1,'sachet','comptage','moyenne','Rapport France 2024: 1 sachet'
  UNION ALL SELECT 'Set patient usage unique','Rapport France - standard','Coton salivaire / rouleau coton',1,'unite','estimation','faible','Coton cite, quantite a mesurer'
  UNION ALL SELECT 'Sterilisation cycle','Rapport France - instrumentation','Solution desinfectante instrumentation 5 L',0.75,'L','estimation','faible','Rapport France 2024: 0.5-1 L par cycle'
  UNION ALL SELECT 'Prothese couronne','Rapport France - flux cabinet','Alginate empreinte 450 g',27.5,'g','estimation','moyenne','1 empreinte pour couronne'
  UNION ALL SELECT 'Prothese couronne','Rapport France - flux cabinet','Ciment resine capsule 16 g',0.35,'g','estimation','moyenne','1 scellement couronne'
) x
JOIN clinical_acts a ON a.name = x.act_name AND a.clinical_variant = x.act_variant
JOIN inventory_products p ON p.name = x.product_name
ON DUPLICATE KEY UPDATE
quantity_per_act=VALUES(quantity_per_act), unit=VALUES(unit),
measurement_mode=VALUES(measurement_mode), confidence=VALUES(confidence),
source_note=VALUES(source_note);

INSERT INTO documents_index
(title, doc_type, tags, summary, source_path, is_external)
SELECT
  'Rapport consommation produits dentaires professionnels France',
  'reference_pdf',
  'stock-ai,consommation,france,produits-dentaires',
  'Standards de consommation par acte, conditionnements typiques, patients couverts, fiscalite et indicateurs France 2024.',
  'C:/Users/wghab/Downloads/app gc/Rapport analytique sur la consommation des produits dentaires professionnels (France).pdf',
  1
FROM DUAL
WHERE NOT EXISTS (
  SELECT 1 FROM documents_index
  WHERE title = 'Rapport consommation produits dentaires professionnels France'
    AND source_path = 'C:/Users/wghab/Downloads/app gc/Rapport analytique sur la consommation des produits dentaires professionnels (France).pdf'
);
