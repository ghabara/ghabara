USE dentaloff_ai;

CREATE TABLE IF NOT EXISTS online_price_observations (
  id INT AUTO_INCREMENT PRIMARY KEY,
  product_id INT NULL,
  observed_name VARCHAR(220) NOT NULL,
  country VARCHAR(80) NOT NULL,
  currency VARCHAR(12) NOT NULL,
  observed_price DECIMAL(12,3) NULL,
  source_name VARCHAR(180) NOT NULL,
  source_url VARCHAR(500) NULL,
  source_type VARCHAR(80) NOT NULL DEFAULT 'online_observation',
  effective_date DATE NULL,
  retrieved_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  confidence_score DECIMAL(5,4) NOT NULL DEFAULT 0.5000,
  status ENUM('candidate','conflict','validated','rejected') NOT NULL DEFAULT 'candidate',
  validated TINYINT(1) NOT NULL DEFAULT 0,
  active TINYINT(1) NOT NULL DEFAULT 1,
  KEY idx_online_price_product (product_id),
  KEY idx_online_price_country (country, currency),
  KEY idx_online_price_status (status)
);

CREATE TABLE IF NOT EXISTS online_reference_candidates (
  id INT AUTO_INCREMENT PRIMARY KEY,
  entity_type VARCHAR(60) NOT NULL,
  candidate_name VARCHAR(220) NOT NULL,
  country VARCHAR(80) NOT NULL,
  code_system VARCHAR(80) NULL,
  code VARCHAR(80) NULL,
  source_name VARCHAR(180) NOT NULL,
  source_url VARCHAR(500) NULL,
  source_type VARCHAR(80) NOT NULL DEFAULT 'online_candidate',
  effective_date DATE NULL,
  retrieved_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  confidence_score DECIMAL(5,4) NOT NULL DEFAULT 0.5000,
  status ENUM('candidate','conflict','validated','rejected') NOT NULL DEFAULT 'candidate',
  validated TINYINT(1) NOT NULL DEFAULT 0,
  active TINYINT(1) NOT NULL DEFAULT 1,
  UNIQUE KEY uq_online_candidate (entity_type, candidate_name, country, source_name),
  KEY idx_online_candidate_status (status)
);
