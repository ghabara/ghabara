const express = require('express');
const { pool } = require('../db');
const { auth, adminOnly, docteurOnly } = require('../middleware/auth');
const {
  importReferencePack,
  listLabConsumables,
  listInternationalPrices,
  listDentalActPrices,
  listLabActPrices,
  listReferenceConflicts,
  listImportLogs,
  updateValidation,
  resolveConflict,
  createProductCandidate,
  createAlias,
  getReferenceDashboard,
} = require('../services/referenceImportService');

const router = express.Router();
const asyncHandler = fn => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

router.get('/dashboard', auth, adminOnly, asyncHandler(async (_req, res) => {
  res.json(await getReferenceDashboard(pool));
}));

router.post('/import', auth, docteurOnly, asyncHandler(async (req, res) => {
  res.json(await importReferencePack(pool, req));
}));

router.get('/lab-consumables', auth, adminOnly, asyncHandler(async (req, res) => {
  res.json(await listLabConsumables(pool, req.query));
}));

router.post('/lab-consumables/import', auth, docteurOnly, asyncHandler(async (req, res) => {
  res.json(await importReferencePack(pool, req));
}));

router.post('/lab-consumables/:id/validate', auth, docteurOnly, asyncHandler(async (req, res) => {
  const row = await updateValidation(pool, 'lab_consumable_reference', req.params.id, 'validated', req);
  if (!row) return res.status(404).json({ error: 'Reference introuvable.' });
  res.json(row);
}));

router.post('/lab-consumables/:id/reject', auth, docteurOnly, asyncHandler(async (req, res) => {
  const row = await updateValidation(pool, 'lab_consumable_reference', req.params.id, 'rejected', req);
  if (!row) return res.status(404).json({ error: 'Reference introuvable.' });
  res.json(row);
}));

router.post('/lab-consumables/:id/create-product-candidate', auth, docteurOnly, asyncHandler(async (req, res) => {
  const row = await createProductCandidate(pool, 'lab_consumable_reference', req.params.id, req);
  if (!row) return res.status(404).json({ error: 'Reference introuvable.' });
  res.json(row);
}));

router.get('/international-prices', auth, adminOnly, asyncHandler(async (req, res) => {
  res.json(await listInternationalPrices(pool, req.query));
}));

router.post('/international-prices/import', auth, docteurOnly, asyncHandler(async (req, res) => {
  res.json(await importReferencePack(pool, req));
}));

router.post('/international-prices/:id/validate', auth, docteurOnly, asyncHandler(async (req, res) => {
  const row = await updateValidation(pool, 'international_price_references', req.params.id, 'validated', req);
  if (!row) return res.status(404).json({ error: 'Prix introuvable.' });
  res.json(row);
}));

router.post('/international-prices/:id/reject', auth, docteurOnly, asyncHandler(async (req, res) => {
  const row = await updateValidation(pool, 'international_price_references', req.params.id, 'rejected', req);
  if (!row) return res.status(404).json({ error: 'Prix introuvable.' });
  res.json(row);
}));

router.post('/international-prices/:id/create-product-candidate', auth, docteurOnly, asyncHandler(async (req, res) => {
  const row = await createProductCandidate(pool, 'international_price_references', req.params.id, req);
  if (!row) return res.status(404).json({ error: 'Prix introuvable.' });
  res.json(row);
}));

router.get('/dental-act-prices', auth, adminOnly, asyncHandler(async (req, res) => {
  res.json(await listDentalActPrices(pool, req.query));
}));

router.post('/dental-act-prices/import', auth, docteurOnly, asyncHandler(async (req, res) => {
  res.json(await importReferencePack(pool, req));
}));

router.post('/dental-act-prices/:id/validate', auth, docteurOnly, asyncHandler(async (req, res) => {
  const row = await updateValidation(pool, 'dental_act_price_references', req.params.id, 'validated', req);
  if (!row) return res.status(404).json({ error: 'Tarif acte introuvable.' });
  res.json(row);
}));

router.post('/dental-act-prices/:id/reject', auth, docteurOnly, asyncHandler(async (req, res) => {
  const row = await updateValidation(pool, 'dental_act_price_references', req.params.id, 'rejected', req);
  if (!row) return res.status(404).json({ error: 'Tarif acte introuvable.' });
  res.json(row);
}));

router.get('/lab-act-prices', auth, adminOnly, asyncHandler(async (req, res) => {
  res.json(await listLabActPrices(pool, req.query));
}));

router.post('/lab-act-prices/import', auth, docteurOnly, asyncHandler(async (req, res) => {
  res.json(await importReferencePack(pool, req));
}));

router.post('/lab-act-prices/:id/validate', auth, docteurOnly, asyncHandler(async (req, res) => {
  const row = await updateValidation(pool, 'lab_act_price_references', req.params.id, 'validated', req);
  if (!row) return res.status(404).json({ error: 'Tarif laboratoire introuvable.' });
  res.json(row);
}));

router.post('/lab-act-prices/:id/reject', auth, docteurOnly, asyncHandler(async (req, res) => {
  const row = await updateValidation(pool, 'lab_act_price_references', req.params.id, 'rejected', req);
  if (!row) return res.status(404).json({ error: 'Tarif laboratoire introuvable.' });
  res.json(row);
}));

router.get('/conflicts', auth, adminOnly, asyncHandler(async (_req, res) => {
  res.json(await listReferenceConflicts(pool));
}));

router.post('/conflicts/:id/resolve', auth, docteurOnly, asyncHandler(async (req, res) => {
  const row = await resolveConflict(pool, req.params.id, req.body.source_table, req.body.status, req);
  if (!row) return res.status(404).json({ error: 'Conflit introuvable.' });
  res.json(row);
}));

router.get('/import-logs', auth, adminOnly, asyncHandler(async (_req, res) => {
  res.json(await listImportLogs(pool));
}));

router.post('/aliases', auth, docteurOnly, asyncHandler(async (req, res) => {
  const { entity_type, canonical_id, alias_name, country } = req.body || {};
  if (!entity_type || !alias_name) return res.status(400).json({ error: 'entity_type et alias_name sont obligatoires.' });
  res.json(await createAlias(pool, entity_type, canonical_id, alias_name, country, req));
}));

module.exports = router;
