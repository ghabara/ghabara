const express = require('express');
const { pool } = require('../db');
const { buildInventoryInsights } = require('../services/inventoryService');
const { auth, adminOnly } = require('../middleware/auth');
const {
  buildForecast,
  detectAnomalies,
  normalizeProductText,
  parseNaturalCommand,
  suggestRecipe,
} = require('../services/aiService');

const router = express.Router();
const asyncHandler = fn => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

async function loadProducts() {
  const [products] = await pool.query('SELECT * FROM inventory_products WHERE is_active = 1 ORDER BY name');
  return products;
}

router.post('/normalize-product', auth, adminOnly, asyncHandler(async (req, res) => {
  const products = await loadProducts();
  const proposal = normalizeProductText(req.body.text || req.body.input || '', products);
  res.json({
    provider: 'local-rules',
    proposal,
    requires_validation: true,
  });
}));

router.post('/suggest-recipe', auth, adminOnly, asyncHandler(async (req, res) => {
  const products = await loadProducts();
  const proposal = suggestRecipe({
    act_name: req.body.act_name || req.body.name,
    clinical_variant: req.body.clinical_variant || req.body.variant,
    context: req.body.context,
    products,
  });
  res.json({ ...proposal, requires_validation: true });
}));

router.post('/parse-command', auth, adminOnly, asyncHandler(async (req, res) => {
  const [acts] = await pool.query('SELECT * FROM clinical_acts WHERE is_active = 1 ORDER BY name');
  const draft = parseNaturalCommand(req.body.text || req.body.command || '', acts);
  res.json(draft);
}));


router.get('/inventory-insights', auth, adminOnly, asyncHandler(async (_req, res) => {
  const insights = await buildInventoryInsights(pool);
  res.json(insights);
}));

router.get('/anomalies', auth, adminOnly, asyncHandler(async (_req, res) => {
  const anomalies = await detectAnomalies(pool);
  res.json(anomalies);
}));

router.get('/forecast', auth, adminOnly, asyncHandler(async (_req, res) => {
  const forecast = await buildForecast(pool);
  res.json(forecast);
}));

router.use((err, _req, res, _next) => {
  res.status(400).json({ error: err.message || 'Erreur IA.' });
});

module.exports = router;
