export default function DentalTooth({ number, color, active, statusLabel, onSelect }) {
  return (
    <button
      type="button"
      className={active ? 'tooth-button active' : 'tooth-button'}
      onClick={() => onSelect(number)}
      title={`Dent ${number} - ${statusLabel}`}
    >
      <svg viewBox="0 0 42 54" aria-hidden="true" className="tooth-svg">
        <path
          d="M21 3C12 3 7 9 7 17c0 5 1.6 8.5 2.4 13.2C10.6 37.5 12 51 17 51c2.6 0 3.2-5 3.6-10.3.1-1.7 2.7-1.7 2.8 0C23.8 46 24.4 51 27 51c5 0 6.4-13.5 7.6-20.8C35.4 25.5 37 22 37 17c0-8-5-14-16-14z"
          fill={color}
          stroke="currentColor"
          strokeWidth="2"
        />
        <path d="M13 17h16M15 25h12" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" opacity=".55" />
      </svg>
      <span>{number}</span>
    </button>
  );
}
