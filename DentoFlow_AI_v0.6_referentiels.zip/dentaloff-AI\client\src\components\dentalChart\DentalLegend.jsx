import { toothStatuses } from './dentalChartConfig';

export default function DentalLegend() {
  return (
    <div className="dental-legend">
      {toothStatuses.map(([key, label, color]) => (
        <span key={key} className="dental-legend-item">
          <i style={{ background: color }} />
          {label}
        </span>
      ))}
    </div>
  );
}
