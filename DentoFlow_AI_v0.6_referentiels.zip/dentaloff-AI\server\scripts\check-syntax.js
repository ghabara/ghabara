const { spawnSync } = require('child_process');
const fs = require('fs');
const path = require('path');

const roots = ['index.js', 'db.js', 'routes', 'services', 'middleware'];

function collectJsFiles(entry) {
  const absolute = path.join(__dirname, '..', entry);
  if (!fs.existsSync(absolute)) return [];
  const stat = fs.statSync(absolute);
  if (stat.isFile()) return absolute.endsWith('.js') ? [absolute] : [];
  return fs.readdirSync(absolute, { withFileTypes: true }).flatMap(item => {
    const child = path.join(entry, item.name);
    return item.isDirectory() ? collectJsFiles(child) : (item.name.endsWith('.js') ? [path.join(__dirname, '..', child)] : []);
  });
}

const files = roots.flatMap(collectJsFiles);
let failed = false;

for (const file of files) {
  const result = spawnSync(process.execPath, ['--check', file], { stdio: 'inherit' });
  if (result.status !== 0) failed = true;
}

if (failed) process.exit(1);
console.log(`Syntaxe OK: ${files.length} fichiers JavaScript verifies.`);
