﻿import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import api, { getUser } from '../api';
import BrandLogo from '../components/BrandLogo.jsx';

const SLOTS = ['08:30', '09:00', '09:30', '10:00', '10:30', '11:00', '11:30', '14:00', '14:30', '15:00', '15:30', '16:00', '16:30', '17:00'];

export default function Rdv() {
  const user = getUser();
  const [services, setServices] = useState([]);
  const [step, setStep] = useState(1);
  const [svc, setSvc] = useState(null);
  const [date, setDate] = useState('');
  const [taken, setTaken] = useState([]);
  const [heure, setHeure] = useState('');
  const [guest, setGuest] = useState({ prenom: '', nom: '', tel: '', email: '' });
  const [confirmed, setConfirmed] = useState(null);
  const [alert, setAlert] = useState(null);

  useEffect(() => {
    api.get('/services').then(r => {
      setServices(r.data);
      const pre = JSON.parse(sessionStorage.getItem('dc_preselect') || 'null');
      if (pre) {
        const found = r.data.find(s => s.name === pre.service);
        if (found) setSvc(found);
        sessionStorage.removeItem('dc_preselect');
      }
    }).catch(() => {});
  }, []);

  useEffect(() => {
    if (date) api.get('/rdv/taken', { params: { date } }).then(r => setTaken(r.data)).catch(() => setTaken([]));
  }, [date]);

  const next = () => {
    if (step === 1 && !svc) return setAlert('Choisissez un service.');
    if (step === 2 && !date) return setAlert('Choisissez une date.');
    if (step === 3 && !heure) return setAlert('Choisissez un créneau.');
    setAlert(null); setStep(step + 1);
  };

  const confirm = async () => {
    setAlert(null);
    const payload = { service: svc.name, prix: svc.prix, date, heure };
    if (!user) {
      const prenom = guest.prenom.trim(), nom = guest.nom.trim(), tel = guest.tel.trim(), email = guest.email.trim();
      if (!prenom || !nom || !tel) return setAlert('Nom, prénom et téléphone sont obligatoires.');
      if (tel.replace(/\D/g, '').length !== 8) return setAlert('Le téléphone doit contenir exactement 8 chiffres.');
      if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) return setAlert('Adresse e-mail invalide.');
      Object.assign(payload, { prenom, nom, tel, email });
    }
    try {
      const { data } = await api.post('/rdv', payload);
      setConfirmed(data);
    } catch (e) {
      setAlert(e.response?.data?.error || 'Erreur lors de la réservation.');
    }
  };

  if (confirmed) {
    const qrData = `DentoFlow AI\nRéf: ${confirmed.ref}\nPatient: ${confirmed.patient_nom}\nService: ${confirmed.service}\nDate: ${confirmed.date} ${confirmed.heure}`;
    const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=220x220&data=${encodeURIComponent(qrData)}&color=0f2c22&bgcolor=faf7f0&margin=10`;
    return (
      <Wrap>
        <div className="dc-halo" style={{ maxWidth: 470, margin: '0 auto' }}>
          <div className="dc-card dc-reveal dc-d1" style={{ textAlign: 'center' }}>
            <div className="dc-bigemoji">🎉</div>
            <h2 style={{ fontFamily: "'Fraunces',serif", fontWeight: 600, fontSize: 28, color: 'var(--ink)' }}>Rendez-vous confirmé</h2>
            <p className="dc-muted" style={{ margin: '8px 0' }}>Référence : <strong style={{ color: 'var(--ink)' }}>{confirmed.ref}</strong></p>
            <img src={qrUrl} alt="QR du rendez-vous" className="dc-qr" />
            <div className="dc-recap">
              <div>🦷 <strong>{confirmed.service}</strong> — {confirmed.prix}</div>
              <div>📅 {confirmed.date} à {confirmed.heure}</div>
              <div>⏳ Statut : en attente de confirmation</div>
            </div>
            <div style={{ display: 'flex', gap: 10, justifyContent: 'center', marginTop: 22, flexWrap: 'wrap' }}>
              <Link to="/profil" className="dc-btn dc-btn-solid">Mes rendez-vous</Link>
              <Link to="/" className="dc-btn dc-btn-soft">Accueil</Link>
            </div>
          </div>
        </div>
      </Wrap>
    );
  }

  return (
    <Wrap>
      <div style={{ maxWidth: 720, margin: '0 auto' }}>
        <div className="dc-head" style={{ margin: '0 auto 26px', textAlign: 'center' }}>
          <span className="dc-eyebrow" style={{ justifyContent: 'center' }}>Réservation en ligne</span>
          <h2 className="dc-display" style={{ fontSize: 36, color: 'var(--ink)', marginTop: 12 }}>Prendre un rendez-vous</h2>
        </div>

        <div className="dc-progress">
          {[1, 2, 3, 4].map(i => <span key={i} className={'dot' + (i <= step ? ' on' : '')} />)}
        </div>

        {alert && <div className="dc-alert error">{alert}</div>}
        {!user && <div className="dc-alert info">Pas besoin de compte : réservez en tant que visiteur. <Link to="/login" style={{ fontWeight: 700 }}>Se connecter</Link> (optionnel).</div>}

        <div className="dc-card">
          {step === 1 && (
            <div className="dc-step">
              <h3>Choisissez un soin</h3>
              <div className="dc-choices">
                {services.map(s => (
                  <div key={s.id} className={'dc-choice' + (svc?.id === s.id ? ' sel' : '')} onClick={() => setSvc(s)}>
                    <div className="ico">{s.ico}</div>
                    <div className="nm">{s.name}</div>
                    <div className="pr">{s.prix}</div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="dc-step">
              <h3>Choisissez une date</h3>
              <div className="dc-field">
                <input type="date" value={date} min={new Date().toISOString().slice(0, 10)}
                       onChange={e => setDate(e.target.value)} />
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="dc-step">
              <h3>Choisissez un créneau</h3>
              <div className="dc-slots">
                {SLOTS.map(t => {
                  const busy = taken.includes(t);
                  return (
                    <button key={t} className={'dc-slot' + (heure === t ? ' sel' : '')} disabled={busy} onClick={() => setHeure(t)}>
                      {t}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {step === 4 && (
            <div className="dc-step">
              <h3>Vos informations & confirmation</h3>
              <div className="dc-summary" style={{ marginBottom: 18 }}>
                <div>🦷 Soin : <strong>{svc?.name}</strong> ({svc?.prix})</div>
                <div>📅 Date : <strong>{date}</strong></div>
                <div>🕐 Heure : <strong>{heure}</strong></div>
              </div>
              {user ? (
                <p className="dc-muted">👤 Réservation au nom de <strong>{user.prenom} {user.nom}</strong> ({user.id_patient}).</p>
              ) : (
                <>
                  <p className="dc-muted" style={{ marginBottom: 12 }}>Vos coordonnées — l'e-mail est <strong>facultatif</strong> :</p>
                  <div className="dc-row2">
                    <div className="dc-field"><label>Prénom <span className="req">*</span></label>
                      <input value={guest.prenom} onChange={e => setGuest({ ...guest, prenom: e.target.value })} placeholder="Mohamed" /></div>
                    <div className="dc-field"><label>Nom <span className="req">*</span></label>
                      <input value={guest.nom} onChange={e => setGuest({ ...guest, nom: e.target.value })} placeholder="Ben Ali" /></div>
                  </div>
                  <div className="dc-row2">
                    <div className="dc-field"><label>Téléphone <span className="req">*</span></label>
                      <input value={guest.tel} onChange={e => setGuest({ ...guest, tel: e.target.value })} placeholder="8 chiffres" /></div>
                    <div className="dc-field"><label>E-mail (facultatif)</label>
                      <input type="email" value={guest.email} onChange={e => setGuest({ ...guest, email: e.target.value })} placeholder="vous@email.com" /></div>
                  </div>
                </>
              )}
            </div>
          )}

          <div className="dc-nav-step">
            {step > 1
              ? <button className="dc-btn dc-btn-soft" onClick={() => setStep(step - 1)}>← Retour</button>
              : <Link to="/" className="dc-btn dc-btn-soft">Annuler</Link>}
            {step < 4
              ? <button className="dc-btn dc-btn-solid" onClick={next}>Continuer →</button>
              : <button className="dc-btn dc-btn-gold" onClick={confirm}>Confirmer le rendez-vous</button>}
          </div>
        </div>
      </div>
    </Wrap>
  );
}

function Wrap({ children }) {
  return (
    <div className="dc">
      <nav className="dc-nav">
        <div className="dc-wrap">
          <Link to="/" className="brand-link"><BrandLogo compact className="brand-logo--nav" /></Link>
          <div className="dc-navlinks">
            <Link to="/" className="plain">Accueil</Link>
            <Link to="/profil" className="plain">Mon espace</Link>
          </div>
        </div>
      </nav>
      <div style={{ padding: '52px 24px' }}>{children}</div>
    </div>
  );
}
