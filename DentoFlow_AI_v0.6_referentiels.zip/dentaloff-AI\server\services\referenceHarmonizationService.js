﻿const { refreshAiAlerts } = require('./inventoryService');

const SOURCE_KEY = 'rapport_france_consumption_2024';
const SOURCE_TITLE = 'Rapport analytique consommation produits dentaires France 2024';

function normalizeName(value) {
  return String(value || '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, ' ')
    .trim()
    .replace(/\s+/g, ' ');
}

function keyFrom(...parts) {
  return normalizeName(parts.join(' '))
    .replace(/\s+/g, '_')
    .slice(0, 180);
}

async function tableExists(pool, tableName) {
  const dbName = process.env.DB_NAME || 'dentaloff_ai';
  const [rows] = await pool.query(
    `SELECT TABLE_NAME
     FROM information_schema.TABLES
     WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ?`,
    [dbName, tableName]
  );
  return rows.length > 0;
}

async function columnExists(pool, tableName, columnName) {
  const dbName = process.env.DB_NAME || 'dentaloff_ai';
  const [rows] = await pool.query(
    `SELECT COLUMN_NAME
     FROM information_schema.COLUMNS
     WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?`,
    [dbName, tableName, columnName]
  );
  return rows.length > 0;
}

async function addColumnIfMissing(pool, tableName, columnName, ddl) {
  if (await tableExists(pool, tableName) && !(await columnExists(pool, tableName, columnName))) {
    await pool.query(`ALTER TABLE ${tableName} ADD COLUMN ${ddl}`);
  }
}

async function ensureHarmonizationSchema(pool) {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS reference_sources (
      id INT AUTO_INCREMENT PRIMARY KEY,
      source_key VARCHAR(120) NOT NULL,
      title VARCHAR(220) NOT NULL,
      source_type VARCHAR(80) NOT NULL DEFAULT 'reference',
      country VARCHAR(80) NULL,
      system_name VARCHAR(120) NULL,
      source_path VARCHAR(255) NULL,
      source_date DATE NULL,
      notes TEXT NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      UNIQUE KEY uq_reference_source_key (source_key)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS reference_aliases (
      id INT AUTO_INCREMENT PRIMARY KEY,
      entity_type ENUM('act','consumable','brand','supplier','rule') NOT NULL,
      canonical_id INT NULL,
      alias_name VARCHAR(220) NOT NULL,
      normalized_alias VARCHAR(220) NOT NULL,
      source_id INT NULL,
      country VARCHAR(80) NULL,
      confidence_score DECIMAL(5,4) NOT NULL DEFAULT 0.5000,
      validated_by_user TINYINT(1) NOT NULL DEFAULT 0,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      UNIQUE KEY uq_reference_alias (entity_type, canonical_id, normalized_alias),
      KEY idx_reference_alias_normalized (normalized_alias),
      CONSTRAINT fk_reference_alias_source FOREIGN KEY (source_id) REFERENCES reference_sources(id) ON DELETE SET NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS reference_conflicts (
      id INT AUTO_INCREMENT PRIMARY KEY,
      conflict_key VARCHAR(180) NOT NULL,
      entity_type VARCHAR(60) NOT NULL,
      entity_id INT NULL,
      field_name VARCHAR(120) NOT NULL,
      current_value TEXT NULL,
      new_value TEXT NULL,
      source_current VARCHAR(180) NULL,
      source_new VARCHAR(180) NULL,
      conflict_type VARCHAR(80) NOT NULL,
      severity ENUM('info','warning','critical') NOT NULL DEFAULT 'warning',
      suggested_resolution TEXT NULL,
      status ENUM('pending','accepted','rejected','merged') NOT NULL DEFAULT 'pending',
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      resolved_at DATETIME NULL,
      UNIQUE KEY uq_reference_conflict_key (conflict_key),
      KEY idx_reference_conflict_status (status),
      KEY idx_reference_conflict_entity (entity_type, entity_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS reference_import_logs (
      id INT AUTO_INCREMENT PRIMARY KEY,
      run_id VARCHAR(80) NOT NULL,
      source_id INT NULL,
      operation ENUM('added','updated','unchanged','duplicate','conflict','error') NOT NULL,
      entity_type VARCHAR(60) NULL,
      entity_id INT NULL,
      label VARCHAR(220) NULL,
      details_json TEXT NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      KEY idx_reference_import_run (run_id),
      KEY idx_reference_import_operation (operation),
      CONSTRAINT fk_reference_import_source FOREIGN KEY (source_id) REFERENCES reference_sources(id) ON DELETE SET NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS reference_mapping_review (
      id INT AUTO_INCREMENT PRIMARY KEY,
      entity_type ENUM('act','consumable','brand','supplier','rule') NOT NULL,
      source_id INT NULL,
      incoming_name VARCHAR(220) NOT NULL,
      normalized_incoming VARCHAR(220) NOT NULL,
      canonical_id INT NULL,
      canonical_name VARCHAR(220) NULL,
      match_score DECIMAL(5,4) NOT NULL DEFAULT 0.5000,
      review_reason TEXT NULL,
      status ENUM('pending','validated','ignored','new_entry','conflict') NOT NULL DEFAULT 'pending',
      action_taken VARCHAR(120) NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      UNIQUE KEY uq_reference_mapping_review (entity_type, normalized_incoming, canonical_id),
      KEY idx_reference_mapping_status (status),
      CONSTRAINT fk_reference_mapping_source FOREIGN KEY (source_id) REFERENCES reference_sources(id) ON DELETE SET NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS brand_aliases (
      id INT AUTO_INCREMENT PRIMARY KEY,
      canonical_brand VARCHAR(160) NOT NULL,
      alias_name VARCHAR(160) NOT NULL,
      normalized_alias VARCHAR(160) NOT NULL,
      source_id INT NULL,
      confidence_score DECIMAL(5,4) NOT NULL DEFAULT 0.8000,
      validated_by_user TINYINT(1) NOT NULL DEFAULT 0,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      UNIQUE KEY uq_brand_alias (canonical_brand, normalized_alias),
      CONSTRAINT fk_brand_alias_source FOREIGN KEY (source_id) REFERENCES reference_sources(id) ON DELETE SET NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS supplier_aliases (
      id INT AUTO_INCREMENT PRIMARY KEY,
      canonical_supplier VARCHAR(160) NOT NULL,
      alias_name VARCHAR(160) NOT NULL,
      normalized_alias VARCHAR(160) NOT NULL,
      source_id INT NULL,
      confidence_score DECIMAL(5,4) NOT NULL DEFAULT 0.8000,
      validated_by_user TINYINT(1) NOT NULL DEFAULT 0,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      UNIQUE KEY uq_supplier_alias (canonical_supplier, normalized_alias),
      CONSTRAINT fk_supplier_alias_source FOREIGN KEY (source_id) REFERENCES reference_sources(id) ON DELETE SET NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS commercial_equivalences (
      id INT AUTO_INCREMENT PRIMARY KEY,
      entity_type ENUM('brand','consumable','supplier') NOT NULL DEFAULT 'brand',
      canonical_name VARCHAR(180) NOT NULL,
      equivalent_name VARCHAR(180) NOT NULL,
      normalized_equivalent VARCHAR(180) NOT NULL,
      source_id INT NULL,
      confidence_score DECIMAL(5,4) NOT NULL DEFAULT 0.8000,
      validation_status ENUM('pending','validated','rejected') NOT NULL DEFAULT 'pending',
      notes TEXT NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      UNIQUE KEY uq_commercial_equivalence (entity_type, canonical_name, normalized_equivalent),
      CONSTRAINT fk_commercial_equivalence_source FOREIGN KEY (source_id) REFERENCES reference_sources(id) ON DELETE SET NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS recipe_versions (
      id INT AUTO_INCREMENT PRIMARY KEY,
      act_id INT NOT NULL,
      version_label VARCHAR(120) NOT NULL DEFAULT 'Standard',
      source_id INT NULL,
      validated TINYINT(1) NOT NULL DEFAULT 0,
      active TINYINT(1) NOT NULL DEFAULT 0,
      notes TEXT NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      UNIQUE KEY uq_recipe_version (act_id, version_label, source_id),
      CONSTRAINT fk_recipe_version_act FOREIGN KEY (act_id) REFERENCES clinical_acts(id) ON DELETE CASCADE,
      CONSTRAINT fk_recipe_version_source FOREIGN KEY (source_id) REFERENCES reference_sources(id) ON DELETE SET NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`);

  await addColumnIfMissing(pool, 'reference_consumption_standards', 'standard_key', 'standard_key VARCHAR(120) NULL');
  await addColumnIfMissing(pool, 'reference_consumption_standards', 'confidence_level', "confidence_level VARCHAR(30) NULL DEFAULT 'estimation'");
  await addColumnIfMissing(pool, 'reference_consumption_standards', 'source_country', "source_country VARCHAR(80) NULL DEFAULT 'France'");
  await addColumnIfMissing(pool, 'reference_consumption_standards', 'source_note', 'source_note VARCHAR(255) NULL');
  await addColumnIfMissing(pool, 'act_recipes', 'source_id', 'source_id INT NULL');
  await addColumnIfMissing(pool, 'act_recipes', 'version_label', 'version_label VARCHAR(120) NULL');
  await addColumnIfMissing(pool, 'act_recipes', 'validated', 'validated TINYINT(1) NOT NULL DEFAULT 0');
  await addColumnIfMissing(pool, 'act_recipes', 'active', 'active TINYINT(1) NOT NULL DEFAULT 1');
  await addColumnIfMissing(pool, 'act_recipes', 'quantity_min', 'quantity_min DECIMAL(12,4) NULL');
  await addColumnIfMissing(pool, 'act_recipes', 'quantity_max', 'quantity_max DECIMAL(12,4) NULL');
  await addColumnIfMissing(pool, 'act_recipes', 'factor_loss', 'factor_loss DECIMAL(8,4) NULL DEFAULT 0');
  await addColumnIfMissing(pool, 'act_recipes', 'required', 'required TINYINT(1) NOT NULL DEFAULT 1');
}

async function upsertSource(pool) {
  await pool.query(
    `INSERT INTO reference_sources
       (source_key, title, source_type, country, system_name, source_path, notes)
     VALUES (?, ?, 'pdf_report', 'France', 'Rapport consommation France', ?, ?)
     ON DUPLICATE KEY UPDATE
       title = VALUES(title),
       source_type = VALUES(source_type),
       country = VALUES(country),
       system_name = VALUES(system_name),
       source_path = VALUES(source_path),
       notes = VALUES(notes)`,
    [
      SOURCE_KEY,
      SOURCE_TITLE,
      'C:/Users/wghab/Downloads/app gc/Rapport analytique sur la consommation des produits dentaires professionnels (France).pdf',
      'Source de calibration clinique, non verite universelle. Les consommations reelles du cabinet restent prioritaires.',
    ]
  );
  const [[source]] = await pool.query('SELECT * FROM reference_sources WHERE source_key = ?', [SOURCE_KEY]);
  return source;
}

function createSummary(runId) {
  return {
    run_id: runId,
    added: 0,
    updated: 0,
    unchanged: 0,
    probable_duplicates: 0,
    conflicts: 0,
    errors: 0,
    details: [],
  };
}

async function logOperation(pool, summary, sourceId, operation, entityType, entityId, label, details = {}) {
  await pool.query(
    `INSERT INTO reference_import_logs
       (run_id, source_id, operation, entity_type, entity_id, label, details_json)
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
    [
      summary.run_id,
      sourceId,
      operation,
      entityType,
      entityId || null,
      label || null,
      JSON.stringify(details),
    ]
  );
  if (operation === 'added') summary.added += 1;
  if (operation === 'updated') summary.updated += 1;
  if (operation === 'unchanged') summary.unchanged += 1;
  if (operation === 'duplicate') summary.probable_duplicates += 1;
  if (operation === 'conflict') summary.conflicts += 1;
  if (operation === 'error') summary.errors += 1;
  summary.details.push({ operation, entity_type: entityType, entity_id: entityId, label, details });
}

async function getProductByName(pool, name) {
  const [[row]] = await pool.query('SELECT * FROM inventory_products WHERE name = ?', [name]);
  return row || null;
}

async function getActByName(pool, name, variant) {
  const [[row]] = await pool.query('SELECT * FROM clinical_acts WHERE name = ? AND clinical_variant = ?', [name, variant]);
  return row || null;
}

function valueIsMissing(value) {
  return value === null || value === undefined || value === '';
}

function normalizedValue(value) {
  if (value === null || value === undefined) return '';
  return String(value).trim();
}

async function upsertAlias(pool, sourceId, entityType, canonicalId, aliasName, country, score, validated = 0) {
  await pool.query(
    `INSERT INTO reference_aliases
       (entity_type, canonical_id, alias_name, normalized_alias, source_id, country, confidence_score, validated_by_user)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)
     ON DUPLICATE KEY UPDATE
       alias_name = VALUES(alias_name),
       source_id = COALESCE(reference_aliases.source_id, VALUES(source_id)),
       country = COALESCE(reference_aliases.country, VALUES(country)),
       confidence_score = GREATEST(reference_aliases.confidence_score, VALUES(confidence_score))`,
    [entityType, canonicalId || null, aliasName, normalizeName(aliasName), sourceId, country || null, score, validated]
  );
}

async function upsertMappingReview(pool, sourceId, row) {
  await pool.query(
    `INSERT INTO reference_mapping_review
       (entity_type, source_id, incoming_name, normalized_incoming, canonical_id, canonical_name,
        match_score, review_reason, status, action_taken)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
     ON DUPLICATE KEY UPDATE
       canonical_name = VALUES(canonical_name),
       match_score = GREATEST(reference_mapping_review.match_score, VALUES(match_score)),
       review_reason = VALUES(review_reason),
       status = CASE
         WHEN reference_mapping_review.status IN ('validated','ignored','new_entry') THEN reference_mapping_review.status
         ELSE VALUES(status)
       END,
       action_taken = COALESCE(reference_mapping_review.action_taken, VALUES(action_taken))`,
    [
      row.entity_type,
      sourceId,
      row.incoming_name,
      normalizeName(row.incoming_name),
      row.canonical_id || null,
      row.canonical_name || null,
      row.match_score || 0.5,
      row.review_reason || null,
      row.status || 'pending',
      row.action_taken || null,
    ]
  );
}

async function upsertConflict(pool, summary, sourceId, conflict) {
  const conflictKey = keyFrom(
    conflict.entity_type,
    conflict.entity_id || 'none',
    conflict.field_name,
    conflict.source_new || SOURCE_TITLE,
    conflict.conflict_type,
    conflict.current_value,
    conflict.new_value
  );
  const [result] = await pool.query(
    `INSERT INTO reference_conflicts
       (conflict_key, entity_type, entity_id, field_name, current_value, new_value,
        source_current, source_new, conflict_type, severity, suggested_resolution, status)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending')
     ON DUPLICATE KEY UPDATE
       current_value = VALUES(current_value),
       new_value = VALUES(new_value),
       source_current = VALUES(source_current),
       source_new = VALUES(source_new),
       severity = VALUES(severity),
       suggested_resolution = VALUES(suggested_resolution)`,
    [
      conflictKey,
      conflict.entity_type,
      conflict.entity_id || null,
      conflict.field_name,
      normalizedValue(conflict.current_value),
      normalizedValue(conflict.new_value),
      conflict.source_current || null,
      conflict.source_new || SOURCE_TITLE,
      conflict.conflict_type,
      conflict.severity || 'warning',
      conflict.suggested_resolution || null,
    ]
  );
  await logOperation(pool, summary, sourceId, 'conflict', conflict.entity_type, conflict.entity_id, conflict.field_name, {
    inserted_or_updated: result.affectedRows,
    conflict_type: conflict.conflict_type,
    severity: conflict.severity || 'warning',
  });
}

async function compareAndEnrichProduct(pool, summary, sourceId, canonical, incoming, options = {}) {
  const safeFields = ['sub_category', 'package_quantity', 'package_unit', 'max_stock', 'supplier_alias'];
  const conflictFields = options.conflictFields || ['tracking_unit', 'package_quantity', 'min_stock'];
  const updates = [];
  const params = [];

  for (const field of conflictFields) {
    if (!valueIsMissing(canonical[field]) && !valueIsMissing(incoming[field]) && String(canonical[field]) !== String(incoming[field])) {
      await upsertConflict(pool, summary, sourceId, {
        entity_type: 'consumable',
        entity_id: canonical.id,
        field_name: field,
        current_value: canonical[field],
        new_value: incoming[field],
        source_current: canonical.source_type || 'DentoFlow AI existant',
        source_new: incoming.source_type || SOURCE_TITLE,
        conflict_type: field === 'tracking_unit' ? 'UNIT_MISMATCH' : 'REFERENCE_VALUE_DIFF',
        severity: field === 'tracking_unit' ? 'critical' : 'warning',
        suggested_resolution: 'Valider manuellement avant de remplacer la valeur existante.',
      });
    }
  }

  for (const field of safeFields) {
    if (valueIsMissing(canonical[field]) && !valueIsMissing(incoming[field])) {
      updates.push(`${field} = ?`);
      params.push(incoming[field]);
    }
  }

  if (canonical.source_type && !canonical.source_type.includes('Rapport France 2024')) {
    updates.push("source_type = CONCAT_WS(' + ', NULLIF(source_type, ''), 'Rapport France 2024')");
  }
  if (incoming.notes && (!canonical.notes || !canonical.notes.includes('Rapport France 2024'))) {
    updates.push("notes = CONCAT_WS(' | ', NULLIF(notes, ''), ?)");
    params.push(incoming.notes);
  }

  if (updates.length) {
    params.push(canonical.id);
    await pool.query(`UPDATE inventory_products SET ${updates.join(', ')} WHERE id = ?`, params);
    await logOperation(pool, summary, sourceId, 'updated', 'consumable', canonical.id, canonical.name, { fields: updates.length });
  } else {
    await logOperation(pool, summary, sourceId, 'unchanged', 'consumable', canonical.id, canonical.name, { reason: 'no safe field to enrich' });
  }
}

async function protectedUsageCount(pool, productId) {
  const tables = [
    ['inventory_movements', 'product_id'],
    ['inventory_purchases', 'product_id'],
    ['inventory_lots', 'product_id'],
    ['consumption_logs', 'product_id'],
    ['lab_recipes', 'product_id'],
    ['lab_consumption_logs', 'product_id'],
  ];
  let total = 0;
  for (const [table, column] of tables) {
    if (await tableExists(pool, table)) {
      const [[row]] = await pool.query(`SELECT COUNT(*) AS n FROM ${table} WHERE ${column} = ?`, [productId]);
      total += Number(row.n || 0);
    }
  }
  return total;
}

async function mergeProductAliasIfSafe(pool, summary, sourceId, canonicalName, duplicateName, score = 0.9) {
  const canonical = await getProductByName(pool, canonicalName);
  const duplicate = await getProductByName(pool, duplicateName);
  if (!canonical || !duplicate || canonical.id === duplicate.id) return;

  await upsertAlias(pool, sourceId, 'consumable', canonical.id, duplicate.name, 'France', score, 0);
  await upsertMappingReview(pool, sourceId, {
    entity_type: 'consumable',
    incoming_name: duplicate.name,
    canonical_id: canonical.id,
    canonical_name: canonical.name,
    match_score: score,
    review_reason: 'Doublon probable detecte par harmonisation; fusion automatique seulement si non protege.',
    status: 'pending',
  });
  await logOperation(pool, summary, sourceId, 'duplicate', 'consumable', duplicate.id, duplicate.name, { canonical_id: canonical.id });

  await compareAndEnrichProduct(pool, summary, sourceId, canonical, duplicate);

  if (normalizeName(canonical.tracking_unit) !== normalizeName(duplicate.tracking_unit)) {
    await logOperation(pool, summary, sourceId, 'unchanged', 'consumable', canonical.id, canonical.name, {
      reason: 'unit mismatch already tracked as conflict',
      duplicate_id: duplicate.id,
    });
    return;
  }

  const protectedCount = await protectedUsageCount(pool, duplicate.id);
  if (protectedCount > 0) {
    await upsertConflict(pool, summary, sourceId, {
      entity_type: 'consumable',
      entity_id: duplicate.id,
      field_name: 'merge_status',
      current_value: 'duplicate has protected history',
      new_value: `merge into ${canonical.name}`,
      source_current: duplicate.name,
      source_new: canonical.name,
      conflict_type: 'PROTECTED_HISTORY',
      severity: 'critical',
      suggested_resolution: 'Fusion manuelle seulement apres controle des mouvements/achats/lots.',
    });
    return;
  }

  const [duplicateRecipes] = await pool.query('SELECT * FROM act_recipes WHERE product_id = ? AND active = 1', [duplicate.id]);
  for (const recipe of duplicateRecipes) {
    const [[existing]] = await pool.query(
      `SELECT * FROM act_recipes
       WHERE act_id = ? AND product_id = ? AND recipe_variant = ?`,
      [recipe.act_id, canonical.id, recipe.recipe_variant]
    );
    if (existing) {
      if (String(existing.quantity_per_act) === String(recipe.quantity_per_act) && normalizeName(existing.unit) === normalizeName(recipe.unit)) {
        await pool.query(
          `UPDATE act_recipes
           SET active = 0,
               source_note = CONCAT_WS(' | ', NULLIF(source_note, ''), ?)
           WHERE id = ?`,
          [`Doublon exact desactive: recette transferee vers ${canonical.name}.`, recipe.id]
        );
      } else {
        await upsertConflict(pool, summary, sourceId, {
          entity_type: 'act_recipe',
          entity_id: existing.id,
          field_name: 'quantity_per_act',
          current_value: existing.quantity_per_act,
          new_value: recipe.quantity_per_act,
          source_current: existing.source_note || canonical.name,
          source_new: recipe.source_note || duplicate.name,
          conflict_type: 'RECIPE_DUPLICATE',
          severity: 'warning',
          suggested_resolution: 'Comparer les deux recettes et choisir la version active.',
        });
      }
    } else {
      await pool.query('UPDATE act_recipes SET product_id = ? WHERE id = ?', [canonical.id, recipe.id]);
    }
  }

  const [[remaining]] = await pool.query('SELECT COUNT(*) AS n FROM act_recipes WHERE product_id = ? AND active = 1', [duplicate.id]);
  if (Number(remaining.n || 0) === 0) {
    await pool.query(
      `UPDATE inventory_products
       SET is_active = 0,
           notes = CONCAT_WS(' | ', NULLIF(notes, ''), ?)
       WHERE id = ?`,
      [`Doublon probable harmonise vers ${canonical.name}; conserve pour tracabilite.`, duplicate.id]
    );
    await logOperation(pool, summary, sourceId, 'updated', 'consumable', duplicate.id, duplicate.name, {
      action: 'deactivated_duplicate_after_recipe_transfer',
      canonical_id: canonical.id,
    });
  }
}

async function upsertBrandAlias(pool, sourceId, canonical, aliasName, score = 0.9) {
  await pool.query(
    `INSERT INTO brand_aliases
       (canonical_brand, alias_name, normalized_alias, source_id, confidence_score)
     VALUES (?, ?, ?, ?, ?)
     ON DUPLICATE KEY UPDATE confidence_score = GREATEST(confidence_score, VALUES(confidence_score))`,
    [canonical, aliasName, normalizeName(aliasName), sourceId, score]
  );
  await pool.query(
    `INSERT INTO commercial_equivalences
       (entity_type, canonical_name, equivalent_name, normalized_equivalent, source_id, confidence_score, validation_status, notes)
     VALUES ('brand', ?, ?, ?, ?, ?, 'pending', ?)
     ON DUPLICATE KEY UPDATE confidence_score = GREATEST(confidence_score, VALUES(confidence_score)), notes = VALUES(notes)`,
    [canonical, aliasName, normalizeName(aliasName), sourceId, score, 'Equivalence commerciale a valider humainement.']
  );
}

async function enrichActAliases(pool, summary, sourceId) {
  const actAliases = [
    ['Composite', 'Acte restaurateur standard', ['Composite photopolymerisable', 'Resine composite', 'Composite A2', 'Filtek Z250']],
    ['Empreinte', 'Standard', ['Empreinte complete', 'Empreinte alginate', 'Empreinte silicone']],
    ['Collage couronne', 'Standard', ['Scellement couronne', 'Couronne unitaire', 'RelyX Unicem']],
    ['Anesthesie locale', 'Rapport France - patient moyen', ['Anesthesie patient', 'Injection anesthesique', 'Septanest']],
  ];
  for (const [name, variant, aliases] of actAliases) {
    const act = await getActByName(pool, name, variant);
    if (!act) continue;
    for (const alias of aliases) {
      await upsertAlias(pool, sourceId, 'act', act.id, alias, 'France', 0.75, 0);
    }
    await logOperation(pool, summary, sourceId, 'updated', 'act', act.id, name, { aliases: aliases.length });
  }
}

async function detectRecipeConflicts(pool, summary, sourceId) {
  const canonicalComposite = await getProductByName(pool, 'Resine / composite A2');
  if (canonicalComposite) {
    const [[current]] = await pool.query(
      `SELECT r.*, a.name, a.clinical_variant
       FROM act_recipes r
       JOIN clinical_acts a ON a.id = r.act_id
       WHERE a.name = 'Composite'
         AND a.clinical_variant = 'Acte restaurateur standard'
         AND r.product_id = ?
       LIMIT 1`,
      [canonicalComposite.id]
    );
    const [[france]] = await pool.query(
      `SELECT r.*, a.name, a.clinical_variant
       FROM act_recipes r
       JOIN clinical_acts a ON a.id = r.act_id
       WHERE a.name = 'Composite'
         AND a.clinical_variant = 'Rapport France - restauration moyenne'
         AND r.product_id = ?
       LIMIT 1`,
      [canonicalComposite.id]
    );
    if (current && france && String(current.quantity_per_act) !== String(france.quantity_per_act)) {
      await upsertConflict(pool, summary, sourceId, {
        entity_type: 'act_recipe',
        entity_id: current.id,
        field_name: 'quantity_per_act',
        current_value: current.quantity_per_act,
        new_value: france.quantity_per_act,
        source_current: current.source_note || 'Recette cabinet existante',
        source_new: france.source_note || SOURCE_TITLE,
        conflict_type: 'CONSUMPTION_ESTIMATE_DIFF',
        severity: 'warning',
        suggested_resolution: 'Garder la recette cabinet active; utiliser le rapport France comme calibration a valider.',
      });
    }
  }
}

async function annotateRecipeVersions(pool, sourceId) {
  await pool.query(
    `UPDATE act_recipes
     SET source_id = ?, version_label = COALESCE(version_label, 'Rapport France'), active = 0
     WHERE source_note LIKE '%Rapport France%'`,
    [sourceId]
  );
  await pool.query(
    `UPDATE act_recipes
     SET version_label = COALESCE(version_label, recipe_variant), active = COALESCE(active, 1)
     WHERE source_note NOT LIKE '%Rapport France%' OR source_note IS NULL`
  );
  await pool.query(
    `INSERT INTO recipe_versions
       (act_id, version_label, source_id, validated, active, notes)
     SELECT grouped.act_id, grouped.version_label, grouped.source_id, 0, grouped.active,
            'Version creee par harmonisation des referentiels'
     FROM (
       SELECT act_id,
              COALESCE(version_label, recipe_variant, 'Standard') AS version_label,
              source_id,
              MAX(active) AS active
       FROM act_recipes
       GROUP BY act_id, COALESCE(version_label, recipe_variant, 'Standard'), source_id
     ) grouped
     WHERE NOT EXISTS (
       SELECT 1
       FROM recipe_versions rv
       WHERE rv.act_id = grouped.act_id
         AND rv.version_label = grouped.version_label
         AND (
           (rv.source_id IS NULL AND grouped.source_id IS NULL)
           OR rv.source_id = grouped.source_id
         )
     )`
  );
}

async function harmonizeReferenceCatalogs(pool, options = {}) {
  await ensureHarmonizationSchema(pool);
  const source = await upsertSource(pool);
  const runId = `harm-${Date.now()}`;
  const summary = createSummary(runId);

  const [[before]] = await pool.query(
    `SELECT
       (SELECT COUNT(*) FROM patients) AS patients,
       (SELECT COUNT(*) FROM rendez_vous) AS rdv,
       (SELECT COUNT(*) FROM performed_acts) AS performed_acts,
       (SELECT COUNT(*) FROM inventory_movements) AS movements`
  );

  try {
    await annotateRecipeVersions(pool, source.id);

    const products = await pool.query('SELECT * FROM inventory_products WHERE source_type LIKE ?', ['%Rapport France%']);
    await logOperation(pool, summary, source.id, 'unchanged', 'source', source.id, SOURCE_TITLE, {
      france_reference_products_seen: products[0].length,
    });

    await mergeProductAliasIfSafe(pool, summary, source.id, 'Resine / composite A2', 'Composite seringue 3 g reference France', 0.88);
    await mergeProductAliasIfSafe(pool, summary, source.id, 'Ciment de scellement', 'Ciment resine capsule 16 g', 0.86);
    await mergeProductAliasIfSafe(pool, summary, source.id, 'Adhesif / bonding', 'Adhesif dentaire flacon 5 ml', 0.72);

    for (const [canonical, aliases] of [
      ['Anesthesie carpule', ['Cartouche anesthesique', 'Septanest', 'Xylocaine']],
      ['Aiguille dentaire', ['Aiguille injection', 'SteriLance', 'Aiguille jetable Terumo']],
      ['Gants', ['Gants medicaux', 'Gants nitrile', 'Gants latex']],
      ['Sachet sterilisation autoclavable 5x20', ['Sachet sterilisation', 'Sachet autoclavable', 'Rouleau MELAG']],
      ['Embout aspiration jetable', ['Tip aspiration', 'Embout aspiration', 'Canule aspiration jetable']],
    ]) {
      const product = await getProductByName(pool, canonical);
      if (!product) continue;
      for (const alias of aliases) await upsertAlias(pool, source.id, 'consumable', product.id, alias, 'France', 0.78, 0);
      await logOperation(pool, summary, source.id, 'updated', 'consumable', product.id, canonical, { aliases: aliases.length });
    }

    await upsertBrandAlias(pool, source.id, 'Solventum', '3M Oral Care', 0.95);
    await upsertBrandAlias(pool, source.id, 'Solventum', '3M ESPE', 0.95);
    await upsertBrandAlias(pool, source.id, 'Dentsply Sirona', 'VDW', 0.82);
    await upsertBrandAlias(pool, source.id, 'Dentsply Sirona', 'Dentsply Sirona / VDW', 0.9);
    await logOperation(pool, summary, source.id, 'updated', 'brand', null, '3M/Solventum + Dentsply/VDW', { aliases: 4 });

    await enrichActAliases(pool, summary, source.id);
    await detectRecipeConflicts(pool, summary, source.id);
    await refreshAiAlerts(pool);

    const [[after]] = await pool.query(
      `SELECT
         (SELECT COUNT(*) FROM patients) AS patients,
         (SELECT COUNT(*) FROM rendez_vous) AS rdv,
         (SELECT COUNT(*) FROM performed_acts) AS performed_acts,
         (SELECT COUNT(*) FROM inventory_movements) AS movements`
    );
    summary.safety = {
      patients_unchanged: before.patients === after.patients,
      rdv_unchanged: before.rdv === after.rdv,
      performed_acts_unchanged: before.performed_acts === after.performed_acts,
      movements_unchanged: before.movements === after.movements,
      before,
      after,
    };
    if (options.actor) {
      await pool.query(
        `INSERT INTO audit_logs (actor, actor_role, action, entity_type, entity_id, details_json)
         VALUES (?, ?, 'REFERENCE_HARMONIZATION_RUN', 'reference_catalog', ?, ?)`,
        [options.actor.username || 'system', options.actor.role || null, runId, JSON.stringify(summary.safety)]
      );
    }
  } catch (error) {
    await logOperation(pool, summary, source.id, 'error', 'script', null, 'harmonizeReferenceCatalogs', { error: error.message });
    throw error;
  }

  return summary;
}

async function getHarmonizationDashboard(pool) {
  await ensureHarmonizationSchema(pool);
  const [logs] = await pool.query(
    `SELECT l.*, s.title AS source_title
     FROM reference_import_logs l
     LEFT JOIN reference_sources s ON s.id = l.source_id
     ORDER BY l.created_at DESC, l.id DESC
     LIMIT 120`
  );
  const [conflicts] = await pool.query(
    `SELECT *
     FROM reference_conflicts
     ORDER BY FIELD(status, 'pending', 'merged', 'accepted', 'rejected'), created_at DESC, id DESC
     LIMIT 120`
  );
  const [mappings] = await pool.query(
    `SELECT *
     FROM reference_mapping_review
     ORDER BY FIELD(status, 'conflict', 'pending', 'validated', 'ignored', 'new_entry'), updated_at DESC, id DESC
     LIMIT 120`
  );
  const [aliases] = await pool.query(
    `SELECT a.*, s.title AS source_title
     FROM reference_aliases a
     LEFT JOIN reference_sources s ON s.id = a.source_id
     ORDER BY a.created_at DESC, a.id DESC
     LIMIT 120`
  );
  const [[counts]] = await pool.query(
    `SELECT
       (SELECT COUNT(*) FROM reference_aliases) AS aliases,
       (SELECT COUNT(*) FROM reference_conflicts WHERE status = 'pending') AS pending_conflicts,
       (SELECT COUNT(*) FROM reference_mapping_review WHERE status IN ('pending','conflict')) AS pending_mappings,
       (SELECT COUNT(*) FROM reference_import_logs WHERE operation = 'added') AS added_logs,
       (SELECT COUNT(*) FROM reference_import_logs WHERE operation = 'updated') AS updated_logs`
  );
  return { counts, logs, conflicts, mappings, aliases };
}

async function updateConflictStatus(pool, id, status, user) {
  if (!['pending', 'accepted', 'rejected', 'merged'].includes(status)) {
    const error = new Error('Statut conflit invalide.');
    error.status = 400;
    throw error;
  }
  await pool.query(
    `UPDATE reference_conflicts
     SET status = ?, resolved_at = CASE WHEN ? = 'pending' THEN NULL ELSE NOW() END
     WHERE id = ?`,
    [status, status, id]
  );
  await pool.query(
    `INSERT INTO audit_logs (actor, actor_role, action, entity_type, entity_id, details_json)
     VALUES (?, ?, 'REFERENCE_CONFLICT_STATUS', 'reference_conflict', ?, ?)`,
    [user?.username || 'admin', user?.role || null, id, JSON.stringify({ status })]
  );
  const [[row]] = await pool.query('SELECT * FROM reference_conflicts WHERE id = ?', [id]);
  return row;
}

async function updateMappingStatus(pool, id, status, actionTaken, user) {
  if (!['pending', 'validated', 'ignored', 'new_entry', 'conflict'].includes(status)) {
    const error = new Error('Statut mapping invalide.');
    error.status = 400;
    throw error;
  }
  await pool.query(
    `UPDATE reference_mapping_review
     SET status = ?, action_taken = COALESCE(?, action_taken)
     WHERE id = ?`,
    [status, actionTaken || null, id]
  );
  await pool.query(
    `INSERT INTO audit_logs (actor, actor_role, action, entity_type, entity_id, details_json)
     VALUES (?, ?, 'REFERENCE_MAPPING_STATUS', 'reference_mapping_review', ?, ?)`,
    [user?.username || 'admin', user?.role || null, id, JSON.stringify({ status, action_taken: actionTaken || null })]
  );
  const [[row]] = await pool.query('SELECT * FROM reference_mapping_review WHERE id = ?', [id]);
  return row;
}

module.exports = {
  SOURCE_KEY,
  SOURCE_TITLE,
  normalizeName,
  ensureHarmonizationSchema,
  harmonizeReferenceCatalogs,
  getHarmonizationDashboard,
  updateConflictStatus,
  updateMappingStatus,
};
