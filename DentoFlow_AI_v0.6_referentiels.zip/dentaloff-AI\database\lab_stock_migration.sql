USE dentaloff_ai;

ALTER TABLE inventory_products
  ADD COLUMN IF NOT EXISTS context_type ENUM('CABINET','LAB','BOTH') NOT NULL DEFAULT 'CABINET';

CREATE TABLE IF NOT EXISTS lab_stock_categories (
  id INT AUTO_INCREMENT PRIMARY KEY,
  category_name VARCHAR(140) NOT NULL UNIQUE,
  family VARCHAR(120) NOT NULL,
  active TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT IGNORE INTO lab_stock_categories (category_name, family) VALUES
('Disques zircone', 'Materiaux CFAO'),
('Blocs lithium disilicate', 'Materiaux CFAO'),
('PMMA', 'Materiaux CFAO'),
('Resine modele', 'Resines 3D'),
('Resine guide chirurgical', 'Resines 3D'),
('Resine gouttiere', 'Resines 3D'),
('Dents prothetiques', 'Prothese amovible'),
('Alliage Co-Cr', 'Metallurgie'),
('Poudres ceramiques', 'Ceramique'),
('Scan bodies', 'Implantologie prothetique'),
('Ti-bases', 'Implantologie prothetique'),
('Platre type IV', 'Modeles et empreintes'),
('Fraises de fraisage', 'Usinage finition'),
('Boites prothetiques', 'Emballage tracabilite');
