const express = require('express');
const { pool } = require('../db');
const { auth, adminOnly, docteurOnly } = require('../middleware/auth');
const {
  calculateActCost,
  decimalOrNull,
  refreshAiAlerts,
  unitsMatch,
} = require('../services/inventoryService');

const router = express.Router();
const asyncHandler = fn => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

function cleanRecipePayload(body) {
  return {
    act_id: Number(body.act_id),
    product_id: Number(body.product_id),
    recipe_variant: String(body.recipe_variant || 'Standard').trim() || 'Standard',
    quantity_per_act: decimalOrNull(body.quantity_per_act),
    unit: String(body.unit || '').trim(),
    measurement_mode: String(body.measurement_mode || 'estimation').trim() || 'estimation',
    confidence: String(body.confidence || 'moyenne').trim() || 'moyenne',
    measurement_count: Number.isFinite(Number(body.measurement_count)) ? Number(body.measurement_count) : undefined,
    source_note: String(body.source_note || '').trim() || null,
  };
}

router.get('/', auth, adminOnly, asyncHandler(async (req, res) => {
  const params = [];
  const where = [];
  if (req.query.act_id) {
    where.push('r.act_id = ?');
    params.push(req.query.act_id);
  }
  const [rows] = await pool.query(
    `SELECT r.*,
            a.name AS act_name,
            a.clinical_variant,
            p.name AS product_name,
            p.tracking_unit,
            p.package_quantity,
            p.package_price_tnd,
            p.current_stock,
            p.min_stock
     FROM act_recipes r
     JOIN clinical_acts a ON a.id = r.act_id
     JOIN inventory_products p ON p.id = r.product_id
     ${where.length ? `WHERE ${where.join(' AND ')}` : ''}
     ORDER BY a.name, a.clinical_variant, r.recipe_variant, p.name`,
    params
  );
  res.json(rows.map(row => ({
    ...row,
    unit_match: unitsMatch(row.unit, row.tracking_unit),
  })));
}));

router.get('/act/:actId/cost', auth, adminOnly, asyncHandler(async (req, res) => {
  const [[act]] = await pool.query('SELECT * FROM clinical_acts WHERE id = ?', [req.params.actId]);
  if (!act) return res.status(404).json({ error: 'Acte introuvable.' });
  const summary = await calculateActCost(pool, req.params.actId);
  res.json({ act, ...summary });
}));

router.post('/', auth, docteurOnly, asyncHandler(async (req, res) => {
  const data = cleanRecipePayload(req.body);
  if (!data.act_id || !data.product_id || data.quantity_per_act === null || data.quantity_per_act <= 0 || !data.unit) {
    return res.status(400).json({ error: 'Acte, produit, quantite et unite sont requis.' });
  }
  const [[product]] = await pool.query('SELECT * FROM inventory_products WHERE id = ?', [data.product_id]);
  if (!product) return res.status(404).json({ error: 'Produit introuvable.' });
  const [result] = await pool.query(
    `INSERT INTO act_recipes
       (act_id, product_id, recipe_variant, quantity_per_act, unit,
        measurement_mode, confidence, source_note)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      data.act_id,
      data.product_id,
      data.recipe_variant,
      data.quantity_per_act,
      data.unit,
      data.measurement_mode,
      data.confidence,
      data.source_note,
    ]
  );
  await refreshAiAlerts(pool);
  const [[recipe]] = await pool.query('SELECT * FROM act_recipes WHERE id = ?', [result.insertId]);
  res.status(201).json({
    ...recipe,
    warning: unitsMatch(data.unit, product.tracking_unit) ? null : 'Unite recette differente de l unite produit.',
  });
}));

router.put('/:id', auth, docteurOnly, asyncHandler(async (req, res) => {
  const data = cleanRecipePayload(req.body);
  if (!data.act_id || !data.product_id || data.quantity_per_act === null || data.quantity_per_act <= 0 || !data.unit) {
    return res.status(400).json({ error: 'Acte, produit, quantite et unite sont requis.' });
  }
  await pool.query(
    `UPDATE act_recipes
     SET act_id = ?, product_id = ?, recipe_variant = ?, quantity_per_act = ?,
         unit = ?, measurement_mode = ?, confidence = ?, source_note = ?
     WHERE id = ?`,
    [
      data.act_id,
      data.product_id,
      data.recipe_variant,
      data.quantity_per_act,
      data.unit,
      data.measurement_mode,
      data.confidence,
      data.source_note,
      req.params.id,
    ]
  );
  await refreshAiAlerts(pool);
  const [[recipe]] = await pool.query('SELECT * FROM act_recipes WHERE id = ?', [req.params.id]);
  if (!recipe) return res.status(404).json({ error: 'Recette introuvable.' });
  res.json(recipe);
}));

router.delete('/:id', auth, docteurOnly, asyncHandler(async (req, res) => {
  await pool.query('DELETE FROM act_recipes WHERE id = ?', [req.params.id]);
  await refreshAiAlerts(pool);
  res.json({ ok: true });
}));

router.use((err, _req, res, _next) => {
  if (err.code === 'ER_DUP_ENTRY') {
    return res.status(409).json({ error: 'Doublon refuse: meme acte, meme produit et meme variante.' });
  }
  res.status(400).json({ error: err.message || 'Erreur recettes.' });
});

module.exports = router;
