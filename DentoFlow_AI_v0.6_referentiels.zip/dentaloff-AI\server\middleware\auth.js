const jwt = require('jsonwebtoken');
const crypto = require('crypto');

let SECRET = process.env.JWT_SECRET;
if (!SECRET || SECRET === 'change_this_with_a_long_random_secret' || /secret_change_me$/i.test(SECRET)) {
  SECRET = crypto.randomBytes(48).toString('hex');
  console.warn('JWT_SECRET absent ou faible : secret temporaire généré pour cette session.');
}

// Génère un jeton
function sign(payload) {
  return jwt.sign(payload, SECRET, { expiresIn: '7d' });
}

// Vérifie qu'un jeton valide est présent
function auth(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) return res.status(401).json({ error: 'Non authentifié' });
  try {
    req.user = jwt.verify(token, SECRET);
    next();
  } catch {
    return res.status(401).json({ error: 'Session expirée' });
  }
}

// Authentification FACULTATIVE : remplit req.user si un jeton est présent,
// mais laisse passer les visiteurs non connectés.
function optionalAuth(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (token) { try { req.user = jwt.verify(token, SECRET); } catch { /* ignore */ } }
  next();
}

// Autorisation par rôles. Les rôles assistant/secretaire sont prévus pour l'extension
// cabinet, même si le seed MVP crée seulement admin et docteur.
function requireRoles(...roles) {
  return (req, res, next) => {
    if (!req.user || !roles.includes(req.user.role)) {
      return res.status(403).json({ error: 'Accès refusé pour ce rôle.' });
    }
    next();
  };
}

// Réservé au personnel du cabinet
function adminOnly(req, res, next) {
  return requireRoles('admin', 'docteur', 'assistant', 'secretaire')(req, res, next);
}

// Réservé au docteur et à l'admin pour les corrections sensibles
function docteurOnly(req, res, next) {
  return requireRoles('docteur', 'admin')(req, res, next);
}

module.exports = { sign, auth, optionalAuth, adminOnly, docteurOnly, requireRoles, SECRET };
