const express = require('express');
const { pool } = require('../db');
const { auth, adminOnly, docteurOnly } = require('../middleware/auth');
const {
  buildInventoryInsights,
  calculateUnitCost,
  decimalOrNull,
  expirationStatus,
  recordInventoryMovement,
  refreshAiAlerts,
  withTransaction,
} = require('../services/inventoryService');
const {
  backfillReferencePrices,
  validateReferencePrice,
} = require('../services/inventoryReferencePriceService');

const router = express.Router();

const asyncHandler = fn => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

function cleanProductPayload(body) {
  return {
    name: String(body.name || '').trim(),
    category: String(body.category || 'A classer').trim() || 'A classer',
    sub_category: String(body.sub_category || '').trim() || null,
    tracking_unit: String(body.tracking_unit || 'unite').trim() || 'unite',
    package_quantity: decimalOrNull(body.package_quantity),
    package_unit: String(body.package_unit || '').trim() || null,
    package_price_tnd: decimalOrNull(body.package_price_tnd),
    current_stock: decimalOrNull(body.current_stock),
    min_stock: decimalOrNull(body.min_stock),
    max_stock: decimalOrNull(body.max_stock),
    reserved_stock: decimalOrNull(body.reserved_stock),
    storage_location: String(body.storage_location || '').trim() || null,
    barcode: String(body.barcode || '').trim() || null,
    lot_strategy: body.lot_strategy === 'LOT_FEFO' ? 'LOT_FEFO' : 'GLOBAL',
    supplier_alias: String(body.supplier_alias || '').trim() || null,
    supplier_lead_days: decimalOrNull(body.supplier_lead_days),
    expiration_date: body.expiration_date || null,
    lot_number: String(body.lot_number || '').trim() || null,
    source_type: String(body.source_type || 'A completer').trim() || 'A completer',
    context_type: ['CABINET', 'LAB', 'BOTH'].includes(body.context_type) ? body.context_type : 'CABINET',
    notes: String(body.notes || '').trim() || null,
  };
}

function productView(product) {
  const unitCost = calculateUnitCost(product);
  const stock = decimalOrNull(product.current_stock);
  const min = decimalOrNull(product.min_stock);
  const realPriceMissing = decimalOrNull(product.package_price_tnd) === null || decimalOrNull(product.package_price_tnd) <= 0;
  const packageQuantityMissing = decimalOrNull(product.package_quantity) === null || decimalOrNull(product.package_quantity) <= 0;
  const referencePriceAvailable = decimalOrNull(product.reference_price_tnd_avg) !== null && product.price_validation_status === 'candidate';
  return {
    ...product,
    unit_cost_tnd: unitCost,
    expiration_status: expirationStatus(product.expiration_date),
    is_low_stock: stock !== null && min !== null && stock <= min,
    has_missing_price: unitCost === null,
    real_price_missing: realPriceMissing,
    package_quantity_missing: packageQuantityMissing,
    has_reference_price_candidate: referencePriceAvailable,
  };
}

router.get('/dashboard', auth, adminOnly, asyncHandler(async (_req, res) => {
  await refreshAiAlerts(pool);
  const [[products]] = await pool.query(`
    SELECT
      COUNT(*) AS product_count,
      SUM(CASE
        WHEN package_price_tnd IS NOT NULL AND package_quantity IS NOT NULL AND package_quantity > 0
        THEN COALESCE(current_stock, 0) * (package_price_tnd / package_quantity)
        ELSE 0
      END) AS estimated_stock_value_tnd,
      SUM(CASE WHEN current_stock IS NOT NULL AND min_stock IS NOT NULL AND current_stock <= min_stock THEN 1 ELSE 0 END) AS low_stock_count,
      SUM(CASE WHEN package_price_tnd IS NULL OR package_price_tnd <= 0 THEN 1 ELSE 0 END) AS missing_real_price_count,
      SUM(CASE WHEN package_quantity IS NULL OR package_quantity <= 0 THEN 1 ELSE 0 END) AS missing_package_quantity_count,
      SUM(CASE WHEN package_price_tnd IS NULL OR package_price_tnd <= 0 OR package_quantity IS NULL OR package_quantity <= 0 THEN 1 ELSE 0 END) AS missing_price_count,
      SUM(CASE
        WHEN (package_price_tnd IS NULL OR package_price_tnd <= 0)
         AND reference_price_tnd_avg IS NOT NULL
         AND price_validation_status = 'candidate'
        THEN 1 ELSE 0 END) AS reference_price_candidate_count,
      SUM(CASE
        WHEN (package_price_tnd IS NULL OR package_price_tnd <= 0)
         AND (reference_price_tnd_avg IS NULL OR price_validation_status <> 'candidate')
        THEN 1 ELSE 0 END) AS no_price_reference_count,
      SUM(CASE WHEN expiration_date IS NOT NULL AND expiration_date <= DATE_ADD(CURDATE(), INTERVAL 30 DAY) THEN 1 ELSE 0 END) AS expiration_soon_count
    FROM inventory_products
    WHERE is_active = 1
  `);
  const [[recipes]] = await pool.query(`
    SELECT COUNT(*) AS incomplete_count
    FROM clinical_acts a
    LEFT JOIN act_recipes r ON r.act_id = a.id
    WHERE a.is_active = 1 AND r.id IS NULL
  `);
  const [[performed]] = await pool.query(`
    SELECT COUNT(*) AS performed_this_month,
           AVG(actual_total_cost_tnd) AS average_actual_cost_tnd
    FROM performed_acts
    WHERE performed_date >= DATE_FORMAT(CURDATE(), '%Y-%m-01')
  `);
  const [alerts] = await pool.query(`
    SELECT *
    FROM ai_alerts
    WHERE status = 'OPEN'
    ORDER BY FIELD(severity, 'CRITICAL', 'WARNING', 'INFO'), created_at DESC
    LIMIT 10
  `);
  const [movements] = await pool.query(`
    SELECT *
    FROM inventory_movements
    ORDER BY created_at DESC, id DESC
    LIMIT 8
  `);
  res.json({
    ...products,
    recipes_incomplete_count: recipes?.incomplete_count || 0,
    performed_this_month: performed?.performed_this_month || 0,
    average_actual_cost_tnd: performed?.average_actual_cost_tnd || null,
    alerts,
    latest_movements: movements,
  });
}));

router.post('/products/backfill-reference-prices', auth, docteurOnly, asyncHandler(async (req, res) => {
  const summary = await backfillReferencePrices(pool, req);
  await refreshAiAlerts(pool);
  res.json(summary);
}));

router.post('/products/:id/validate-reference-price', auth, docteurOnly, asyncHandler(async (req, res) => {
  const product = await validateReferencePrice(pool, req.params.id, req);
  if (!product) return res.status(404).json({ error: 'Produit introuvable.' });
  await refreshAiAlerts(pool);
  res.json(productView(product));
}));

router.get('/products', auth, adminOnly, asyncHandler(async (req, res) => {
  const includeInactive = req.query.includeInactive === '1';
  const [rows] = await pool.query(
    `SELECT *
     FROM inventory_products
     ${includeInactive ? '' : 'WHERE is_active = 1'}
     ORDER BY is_active DESC, name`
  );
  res.json(rows.map(productView));
}));

router.post('/products', auth, docteurOnly, asyncHandler(async (req, res) => {
  const data = cleanProductPayload(req.body);
  if (!data.name) return res.status(400).json({ error: 'Nom du produit requis.' });
  if (data.package_quantity !== null && data.package_quantity < 0) return res.status(400).json({ error: 'Conditionnement invalide.' });
  if (data.current_stock !== null && data.current_stock < 0) return res.status(400).json({ error: 'Stock negatif refuse a la creation.' });
  if (data.min_stock !== null && data.min_stock < 0) return res.status(400).json({ error: 'Seuil minimum invalide.' });
  if (data.max_stock !== null && data.max_stock < 0) return res.status(400).json({ error: 'Seuil maximum invalide.' });
  if (data.reserved_stock !== null && data.reserved_stock < 0) return res.status(400).json({ error: 'Stock reserve invalide.' });

  const [result] = await pool.query(
    `INSERT INTO inventory_products
       (name, category, sub_category, tracking_unit, package_quantity, package_unit,
        package_price_tnd, current_stock, min_stock, max_stock, reserved_stock, storage_location, barcode, lot_strategy,
        supplier_alias, supplier_lead_days, expiration_date, lot_number, source_type, context_type, notes)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      data.name,
      data.category,
      data.sub_category,
      data.tracking_unit,
      data.package_quantity,
      data.package_unit,
      data.package_price_tnd,
      data.current_stock ?? 0,
      data.min_stock ?? 0,
      data.max_stock,
      data.reserved_stock ?? 0,
      data.storage_location,
      data.barcode,
      data.lot_strategy,
      data.supplier_alias,
      data.supplier_lead_days,
      data.expiration_date,
      data.lot_number,
      data.source_type,
      data.context_type,
      data.notes,
    ]
  );
  await refreshAiAlerts(pool);
  const [[product]] = await pool.query('SELECT * FROM inventory_products WHERE id = ?', [result.insertId]);
  res.status(201).json(productView(product));
}));

router.put('/products/:id', auth, docteurOnly, asyncHandler(async (req, res) => {
  const data = cleanProductPayload(req.body);
  if (!data.name) return res.status(400).json({ error: 'Nom du produit requis.' });
  await pool.query(
    `UPDATE inventory_products
     SET name = ?, category = ?, sub_category = ?, tracking_unit = ?, package_quantity = ?,
         package_unit = ?, package_price_tnd = ?, current_stock = ?, min_stock = ?,
         max_stock = ?, reserved_stock = ?, storage_location = ?, barcode = ?, lot_strategy = ?,
         supplier_alias = ?, supplier_lead_days = ?, expiration_date = ?, lot_number = ?,
         source_type = ?, context_type = ?, notes = ?, is_active = ?
     WHERE id = ?`,
    [
      data.name,
      data.category,
      data.sub_category,
      data.tracking_unit,
      data.package_quantity,
      data.package_unit,
      data.package_price_tnd,
      data.current_stock ?? 0,
      data.min_stock ?? 0,
      data.max_stock,
      data.reserved_stock ?? 0,
      data.storage_location,
      data.barcode,
      data.lot_strategy,
      data.supplier_alias,
      data.supplier_lead_days,
      data.expiration_date,
      data.lot_number,
      data.source_type,
      data.context_type,
      data.notes,
      req.body.is_active === 0 || req.body.is_active === false ? 0 : 1,
      req.params.id,
    ]
  );
  await refreshAiAlerts(pool);
  const [[product]] = await pool.query('SELECT * FROM inventory_products WHERE id = ?', [req.params.id]);
  if (!product) return res.status(404).json({ error: 'Produit introuvable.' });
  res.json(productView(product));
}));

router.delete('/products/:id', auth, docteurOnly, asyncHandler(async (req, res) => {
  await pool.query('UPDATE inventory_products SET is_active = 0 WHERE id = ?', [req.params.id]);
  await refreshAiAlerts(pool);
  res.json({ ok: true });
}));

router.post('/products/:id/correction', auth, docteurOnly, asyncHandler(async (req, res) => {
  const newStock = decimalOrNull(req.body.new_stock ?? req.body.current_stock);
  if (newStock === null || newStock < 0) return res.status(400).json({ error: 'Nouvelle quantite invalide.' });
  const comment = String(req.body.comment || '').trim();
  const result = await withTransaction(pool, async (conn) => {
    const [[product]] = await conn.query('SELECT * FROM inventory_products WHERE id = ? FOR UPDATE', [req.params.id]);
    if (!product) throw new Error('Produit introuvable.');
    const stockBefore = decimalOrNull(product.current_stock) ?? 0;
    const delta = newStock - stockBefore;
    if (delta === 0) throw new Error('Le stock est deja a cette valeur.');
    await conn.query('UPDATE inventory_products SET current_stock = ? WHERE id = ?', [newStock, product.id]);
    await recordInventoryMovement(conn, {
      product_id: product.id,
      product_name_snapshot: product.name,
      quantity: Math.abs(delta),
      unit: product.tracking_unit,
      direction: delta > 0 ? 'IN' : 'OUT',
      origin: 'CORRECTION',
      stock_before: stockBefore,
      stock_after: newStock,
      created_by: req.user?.username || req.user?.role || null,
    });
    if (comment) {
      await conn.query(
        `INSERT INTO ai_alerts (type, severity, entity_type, entity_id, message, recommendation, status)
         VALUES ('CORRECTION', 'INFO', 'inventory_product', ?, ?, ?, 'RESOLVED')`,
        [product.id, `Correction stock: ${product.name}`, comment]
      );
    }
    return { product_id: product.id, stock_before: stockBefore, stock_after: newStock, delta };
  });
  await refreshAiAlerts(pool);
  res.json(result);
}));


router.get('/insights', auth, adminOnly, asyncHandler(async (_req, res) => {
  const insights = await buildInventoryInsights(pool);
  res.json(insights);
}));

router.get('/products/:id/lots', auth, adminOnly, asyncHandler(async (req, res) => {
  const [rows] = await pool.query(
    `SELECT *
     FROM inventory_lots
     WHERE product_id = ?
     ORDER BY CASE WHEN expiration_date IS NULL THEN 1 ELSE 0 END, expiration_date ASC, created_at DESC`,
    [req.params.id]
  );
  res.json(rows);
}));

router.post('/products/:id/lots', auth, docteurOnly, asyncHandler(async (req, res) => {
  const quantity = decimalOrNull(req.body.quantity_current ?? req.body.quantity_initial);
  const lotNumber = String(req.body.lot_number || '').trim();
  if (!lotNumber || quantity === null || quantity < 0) {
    return res.status(400).json({ error: 'Lot et quantite valides requis.' });
  }
  const [[product]] = await pool.query('SELECT id FROM inventory_products WHERE id = ? AND is_active = 1', [req.params.id]);
  if (!product) return res.status(404).json({ error: 'Produit introuvable.' });
  const [result] = await pool.query(
    `INSERT INTO inventory_lots
       (product_id, lot_number, quantity_current, quantity_initial, expiration_date, storage_location, comment)
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
    [
      req.params.id,
      lotNumber,
      quantity,
      decimalOrNull(req.body.quantity_initial) ?? quantity,
      req.body.expiration_date || null,
      String(req.body.storage_location || '').trim() || null,
      String(req.body.comment || '').trim() || null,
    ]
  );
  await refreshAiAlerts(pool);
  const [[lot]] = await pool.query('SELECT * FROM inventory_lots WHERE id = ?', [result.insertId]);
  res.status(201).json(lot);
}));

router.put('/lots/:id/status', auth, docteurOnly, asyncHandler(async (req, res) => {
  const allowed = ['ACTIVE', 'QUARANTINE', 'EXPIRED', 'CONSUMED', 'DISCARDED', 'CORRECTED'];
  const status = String(req.body.status || '').toUpperCase();
  if (!allowed.includes(status)) return res.status(400).json({ error: 'Statut lot invalide.' });
  await pool.query('UPDATE inventory_lots SET status = ?, comment = COALESCE(?, comment) WHERE id = ?', [status, String(req.body.comment || '').trim() || null, req.params.id]);
  await refreshAiAlerts(pool);
  res.json({ ok: true });
}));

router.get('/movements', auth, docteurOnly, asyncHandler(async (req, res) => {
  const where = [];
  const params = [];
  if (req.query.product_id) {
    where.push('product_id = ?');
    params.push(req.query.product_id);
  }
  if (req.query.direction) {
    where.push('direction = ?');
    params.push(req.query.direction);
  }
  if (req.query.origin) {
    where.push('origin = ?');
    params.push(req.query.origin);
  }
  const [rows] = await pool.query(
    `SELECT *
     FROM inventory_movements
     ${where.length ? `WHERE ${where.join(' AND ')}` : ''}
     ORDER BY created_at DESC, id DESC
     LIMIT 500`,
    params
  );
  res.json(rows);
}));

router.get('/alerts', auth, adminOnly, asyncHandler(async (_req, res) => {
  await refreshAiAlerts(pool);
  const [rows] = await pool.query(`
    SELECT *
    FROM ai_alerts
    WHERE status = 'OPEN'
    ORDER BY FIELD(severity, 'CRITICAL', 'WARNING', 'INFO'), created_at DESC
    LIMIT 300
  `);
  res.json(rows);
}));

router.use((err, _req, res, _next) => {
  res.status(400).json({ error: err.message || 'Erreur inventaire.' });
});

module.exports = router;
