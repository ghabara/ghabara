const express = require('express');
const path = require('path');
const fs = require('fs');
const multer = require('multer');
const { pool } = require('../db');
const { auth, adminOnly } = require('../middleware/auth');
const { logAudit } = require('../services/auditService');
const router = express.Router();

// Stockage des documents sur le disque (server/uploads)
const uploadDir = path.join(__dirname, '..', 'uploads');
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });
const ALLOWED_MIME_TYPES = new Set([
  'application/pdf',
  'image/jpeg',
  'image/png',
  'image/webp',
]);

function safeStoredName(originalName) {
  const ext = path.extname(originalName || '').toLowerCase();
  const allowedExt = ['.pdf', '.jpg', '.jpeg', '.png', '.webp'].includes(ext) ? ext : '';
  return `${Date.now()}-${Math.random().toString(36).slice(2, 10)}${allowedExt}`;
}

function safeUploadPath(filePath) {
  const resolved = path.resolve(uploadDir, path.basename(filePath || ''));
  if (!resolved.startsWith(path.resolve(uploadDir) + path.sep)) {
    throw new Error('Chemin de document invalide.');
  }
  return resolved;
}

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadDir),
  filename: (req, file, cb) => cb(null, safeStoredName(file.originalname)),
});
const upload = multer({
  storage,
  limits: { fileSize: 10 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    if (!ALLOWED_MIME_TYPES.has(file.mimetype)) {
      return cb(new Error('Type de fichier non autorisé.'));
    }
    return cb(null, true);
  },
});

// Construit un objet dossier complet (fiche + documents + ordonnances)
async function buildDossier(id_dossier) {
  const [[d]] = await pool.query('SELECT * FROM dossiers WHERE id_dossier = ?', [id_dossier]);
  if (!d) return null;
  const [docs] = await pool.query('SELECT * FROM documents WHERE id_dossier = ? ORDER BY added_at DESC', [id_dossier]);
  const [ords] = await pool.query('SELECT * FROM ordonnances WHERE id_dossier = ? ORDER BY date DESC', [id_dossier]);
  return { ...d, documents: docs, ordonnances: ords };
}

// ── Liste : tous les patients + état de leur dossier ────────
router.get('/', auth, adminOnly, async (req, res) => {
  const [patients] = await pool.query('SELECT id_patient, prenom, nom, age, genre, tel, email FROM patients ORDER BY id_patient');
  const [dossiers] = await pool.query('SELECT id_dossier FROM dossiers');
  const [dc] = await pool.query('SELECT id_dossier, COUNT(*) n FROM documents GROUP BY id_dossier');
  const [oc] = await pool.query('SELECT id_dossier, COUNT(*) n FROM ordonnances GROUP BY id_dossier');
  const has = new Set(dossiers.map(d => d.id_dossier));
  const dmap = {}; dc.forEach(x => dmap[x.id_dossier] = x.n);
  const omap = {}; oc.forEach(x => omap[x.id_dossier] = x.n);
  res.json(patients.map(p => ({
    ...p,
    hasDossier: has.has(p.id_patient),
    docCount: dmap[p.id_patient] || 0,
    ordCount: omap[p.id_patient] || 0,
  })));
});

// ── Détail d'un dossier (fiche patient incluse) ─────────────
router.get('/:id', auth, adminOnly, async (req, res) => {
  const dossier = await buildDossier(req.params.id);
  if (!dossier) return res.status(404).json({ error: "Aucun dossier (il doit être créé par l'admin)." });
  const [[p]] = await pool.query('SELECT id_patient, prenom, nom, age, genre, tel, email FROM patients WHERE id_patient = ?', [req.params.id]);
  await logAudit(pool, req, { action: 'DOSSIER_VIEW', entity_type: 'dossier', entity_id: req.params.id, patient_id: req.params.id });
  res.json({ ...dossier, patient: p });
});

// ── Création STRICTEMENT manuelle par l'admin ───────────────
router.post('/', auth, adminOnly, async (req, res) => {
  const { id_patient } = req.body;
  const [[p]] = await pool.query('SELECT id_patient FROM patients WHERE id_patient = ?', [id_patient]);
  if (!p) return res.status(404).json({ error: 'Patient introuvable.' });
  const [[exist]] = await pool.query('SELECT id_dossier FROM dossiers WHERE id_dossier = ?', [id_patient]);
  if (exist) return res.status(409).json({ error: 'Ce dossier existe déjà.' });

  // id_dossier = id_patient
  await pool.query(
    'INSERT INTO dossiers (id_dossier, id_patient, created_by) VALUES (?,?,?)',
    [id_patient, id_patient, req.user.username || 'admin']
  );
  await logAudit(pool, req, { action: 'DOSSIER_CREATE', entity_type: 'dossier', entity_id: id_patient, patient_id: id_patient });
  res.status(201).json(await buildDossier(id_patient));
});

// ── Mise à jour de la fiche médicale ────────────────────────
router.put('/:id', auth, adminOnly, async (req, res) => {
  const { groupe_sanguin, allergies, antecedents } = req.body;
  await pool.query(
    'UPDATE dossiers SET groupe_sanguin=?, allergies=?, antecedents=? WHERE id_dossier=?',
    [groupe_sanguin || '', allergies || '', antecedents || '', req.params.id]
  );
  await logAudit(pool, req, { action: 'DOSSIER_UPDATE', entity_type: 'dossier', entity_id: req.params.id, patient_id: req.params.id });
  res.json(await buildDossier(req.params.id));
});

// ── DOCUMENTS ───────────────────────────────────────────────
router.post('/:id/documents', auth, adminOnly, upload.single('file'), async (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'Aucun fichier.' });
  await pool.query(
    'INSERT INTO documents (id_dossier, name, type, size, file_path) VALUES (?,?,?,?,?)',
    [req.params.id, req.file.originalname, req.file.mimetype, (req.file.size / 1024).toFixed(0) + ' Ko', req.file.filename]
  );
  await logAudit(pool, req, { action: 'DOCUMENT_UPLOAD', entity_type: 'document', entity_id: req.file.originalname, patient_id: req.params.id, details: { type: req.file.mimetype, size: req.file.size } });
  res.status(201).json(await buildDossier(req.params.id));
});

router.delete('/:id/documents/:docId', auth, adminOnly, async (req, res) => {
  const [[doc]] = await pool.query('SELECT file_path FROM documents WHERE id = ?', [req.params.docId]);
  if (doc && doc.file_path) {
    const fp = safeUploadPath(doc.file_path);
    if (fs.existsSync(fp)) fs.unlinkSync(fp);
  }
  await pool.query('DELETE FROM documents WHERE id = ?', [req.params.docId]);
  await logAudit(pool, req, { action: 'DOCUMENT_DELETE', entity_type: 'document', entity_id: req.params.docId, patient_id: req.params.id });
  res.json(await buildDossier(req.params.id));
});

router.get('/documents/:docId/download', auth, adminOnly, async (req, res) => {
  const [[doc]] = await pool.query('SELECT * FROM documents WHERE id = ?', [req.params.docId]);
  if (!doc || !doc.file_path) return res.status(404).json({ error: 'Document introuvable.' });

  const fp = safeUploadPath(doc.file_path);
  if (!fs.existsSync(fp)) return res.status(404).json({ error: 'Fichier introuvable.' });

  res.type(doc.type || 'application/octet-stream');
  await logAudit(pool, req, { action: 'DOCUMENT_DOWNLOAD', entity_type: 'document', entity_id: req.params.docId, patient_id: doc.id_dossier });
  res.download(fp, doc.name || path.basename(fp));
});

// ── ORDONNANCES (espace docteur) ────────────────────────────
router.post('/:id/ordonnances', auth, adminOnly, async (req, res) => {
  const { medecin, contenu } = req.body;
  if (!contenu) return res.status(400).json({ error: 'Prescription vide.' });
  await pool.query(
    'INSERT INTO ordonnances (id_dossier, medecin, contenu) VALUES (?,?,?)',
    [req.params.id, medecin || 'Médecin', contenu]
  );
  await logAudit(pool, req, { action: 'ORDONNANCE_CREATE', entity_type: 'ordonnance', entity_id: null, patient_id: req.params.id });
  res.status(201).json(await buildDossier(req.params.id));
});

router.delete('/:id/ordonnances/:ordId', auth, adminOnly, async (req, res) => {
  await pool.query('DELETE FROM ordonnances WHERE id = ?', [req.params.ordId]);
  await logAudit(pool, req, { action: 'ORDONNANCE_DELETE', entity_type: 'ordonnance', entity_id: req.params.ordId, patient_id: req.params.id });
  res.json(await buildDossier(req.params.id));
});

module.exports = router;
