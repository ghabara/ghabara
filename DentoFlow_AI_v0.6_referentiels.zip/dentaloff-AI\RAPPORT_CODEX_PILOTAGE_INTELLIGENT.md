﻿# Rapport Codex — DentoFlow AI V0.4 Pilotage intelligent

## Addendum V0.4 — Repositionnement plateforme

La reprise de codage confirme le positionnement suivant :

```text
DentoFlow AI n'est pas seulement une application de stock.
C'est une plateforme de pilotage intelligent du cabinet dentaire, avec un moteur fort :
savoir ce que chaque acte consomme, combien il coûte, et quoi acheter avant d'être en rupture.
```

Ajouts V0.4 :

- Nouvelle route cockpit : `GET /api/pilotage/overview`.
- Agrégation backend du pilotage cabinet : patients, dossiers, RDV, actes, coût matière, achats, alertes, labo, plans de traitement.
- Dashboard admin branché sur cette route unique au lieu de calculs dispersés côté React.
- Module renommé visuellement en **Pilotage & Stock AI**.
- Onglet Pilotage IA enrichi avec :
  - produits à commander ;
  - budget d'achat suggéré ;
  - couverture moyenne ;
  - péremption à 90 jours ;
  - coût unitaire ;
  - valeur estimée de l'achat recommandé.
- Documentation alignée avec le positionnement plateforme.

## 1. Objectif réalisé

La version livrée transforme davantage **DentoFlow AI** en plateforme de pilotage intelligent du cabinet dentaire, et pas seulement en logiciel de stock.

Objectif métier renforcé :

```text
Patient / RDV / acte prévu → acte réalisé → recette par acte → consommation automatique → coût matière → mouvements de stock → lots / péremption → alertes → liste d'achat → pilotage IA local
```

Aucun code de grands projets open source externes n'a été copié. Les références fonctionnelles ont été utilisées comme modèles métier : InvenTree pour le stock, EasyAppointments pour le planning, OpenEMR pour sécurité/audit, Apexo pour logique dentaire, SENAITE pour labo, PharmaSpot pour lots/péremption, scikit-learn comme inspiration de scoring progressif.

## 2. Principales améliorations

### A. Sécurité et audit

- Ajout d'un service `auditService.js`.
- Ajout de la table `audit_logs`.
- Ajout d'une route de consultation des logs : `/api/security/audit-logs`.
- Ajout d'un middleware de rôles : `requireRoles(...)`.
- Rôles prévus : `admin`, `docteur`, `assistant`, `secretaire`.
- Audit ajouté sur :
  - consultation dossier patient ;
  - création/modification dossier ;
  - upload/téléchargement/suppression document ;
  - ordonnances ;
  - rendez-vous ;
  - plans de traitement ;
  - cas laboratoire ;
  - changement d'identifiants admin/docteur.
- Mot de passe docteur/admin renforcé : au moins 10 caractères, majuscule, minuscule et chiffre.

### B. Stock AI avancé

- Produits enrichis avec :
  - `max_stock` ;
  - `reserved_stock` ;
  - `storage_location` ;
  - `barcode` ;
  - `lot_strategy`.
- Ajout d'une table `inventory_lots`.
- Support des lots avec :
  - numéro de lot ;
  - date de péremption ;
  - quantité initiale/restante ;
  - emplacement ;
  - statut actif/périmé/jeté/perdu/corrigé.
- Les achats peuvent créer automatiquement un lot si `lot_number` ou `expiration_date` est fourni.
- Alertes IA ajoutées :
  - surstock ;
  - lot bientôt périmé ;
  - lot périmé ;
  - rupture / stock faible conservées.
- Préparation de logique FEFO via `lot_strategy = LOT_FEFO`.

### C. Pilotage IA local

- Ajout d'un endpoint : `/api/ai/inventory-insights`.
- Ajout d'un endpoint miroir : `/api/inventory/insights`.
- Scoring local par produit :
  - risque rupture ;
  - risque péremption ;
  - risque surstock ;
  - absence de prix ;
  - couverture estimée en jours ;
  - consommation 30/90 jours ;
  - quantité recommandée à commander.
- Ajout d'un onglet frontend **Pilotage IA** dans Stock AI.
- Ajout d'un KPI **Risque critique** dans le dashboard Stock AI.

### D. Rendez-vous améliorés

- Statuts enrichis :
  - `pending`, `confirmed`, `arrived`, `in_treatment`, `done`, `cancelled`, `no_show`.
- Ajout des champs :
  - durée ;
  - praticien ;
  - fauteuil ;
  - salle ;
  - notes ;
  - acte prévu lié.
- Détection de conflit par date + heure + fauteuil.
- Un rendez-vous terminé peut être relié à un acte prévu.

### E. Plans de traitement dentaires

- Nouvelle route : `/api/treatment-plans`.
- Nouvelles tables :
  - `treatment_plans` ;
  - `treatment_plan_items`.
- Un patient peut avoir plusieurs plans.
- Un plan peut contenir plusieurs actes prévus.
- Un acte prévu contient : dent, quadrant, catégorie, statut, prix prévu, coût matière estimé.
- Statuts prévus : planned, accepted, in_progress, completed, cancelled.

### F. Laboratoire de prothèse

- Module laboratoire remplacé par un vrai workflow.
- Tables renforcées :
  - `lab_cases` ;
  - `lab_case_events`.
- Route : `/api/lab/overview`.
- Route : `/api/lab/cases`.
- Route : `/api/lab/cases/:id/events`.
- Statuts :
  - draft ;
  - sent ;
  - in_progress ;
  - received ;
  - try_in ;
  - validated ;
  - delivered ;
  - cancelled.
- Champs ajoutés : laboratoire externe, teinte, matériau, coût labo, date d'envoi, date retour prévue, date réception.

### G. Interface Stock AI

- Nouvelle logique d'affichage : **Plateforme de pilotage du cabinet**.
- Ajout de l'onglet **Pilotage IA**.
- Formulaire produit enrichi avec lot, emplacement, stock réservé, seuil maximum, code-barres.
- Tableau produits enrichi avec stock utile et traçabilité.
- Achats enrichis avec date de péremption et emplacement.
- Admin et docteur peuvent gérer Stock AI.

## 3. Fichiers ajoutés

```text
server/services/auditService.js
server/routes/security.js
server/routes/treatmentPlans.js
database/pilotage_intelligent_migration.sql
RAPPORT_CODEX_PILOTAGE_INTELLIGENT.md
```

## 4. Fichiers modifiés principaux

```text
client/src/pages/StockAi.jsx
client/src/pages/Admin.jsx
server/index.js
server/package.json
server/middleware/auth.js
server/routes/ai.js
server/routes/auth.js
server/routes/dossiers.js
server/routes/inventory.js
server/routes/lab.js
server/routes/purchases.js
server/routes/rdv.js
server/services/inventoryService.js
server/services/stockAiMigration.js
database/dentaloff_ai.sql
```

## 5. Tests exécutés

### Backend

```bash
cd server
npm ci
npm run check
npm audit --audit-level=moderate
```

Résultat : OK, 0 vulnérabilité détectée.

### Frontend

```bash
cd client
npm ci
npm run build
npm audit --audit-level=moderate
```

Résultat : OK, build Vite réussi, 0 vulnérabilité détectée.

### Démarrage serveur sans MySQL actif

```bash
cd server
timeout 6 npm start
```

Résultat : le serveur démarre, mais la connexion MySQL échoue dans cet environnement car aucun serveur MySQL/MariaDB n'est lancé sur `127.0.0.1:3306`.

Message attendu dans cet environnement :

```text
Amorçage impossible : connect ECONNREFUSED 127.0.0.1:3306
Serveur DentoFlow AI sur http://localhost:4000
```

## 6. Vérifications supplémentaires

- Anciennes marques visibles : non trouvées dans le code livré hors dépendances.
- Aucun dossier `node_modules` inclus dans le livrable final.
- Aucun fichier `.env` réel ajouté.
- Aucun code direct de InvenTree, EasyAppointments, OpenEMR, Apexo, SENAITE ou PharmaSpot n'a été copié.

## 7. Installation locale recommandée

```bash
# 1. Base de données
# Lancer XAMPP/MySQL ou MariaDB
# Créer/importer la base dentaloff_ai

# 2. Import SQL
mysql -u root -p dentaloff_ai < database/dentaloff_ai.sql
mysql -u root -p dentaloff_ai < database/stock_ai_migration.sql
mysql -u root -p dentaloff_ai < database/pilotage_intelligent_migration.sql
mysql -u root -p dentaloff_ai < database/reference_harmonization_migration.sql
mysql -u root -p dentaloff_ai < database/rapport_france_consumption_seed.sql
# facultatif
mysql -u root -p dentaloff_ai < database/stock_ai_demo_seed.sql

# 3. Serveur
cd server
cp .env.example .env
npm ci
npm start

# 4. Client
cd ../client
npm ci
npm run dev
```

## 8. Limites restantes

- Base MySQL locale testée sur MariaDB isolée en port `3390`.
- Rapport France intégré en base : 24 produits, 16 actes, 32 recettes, 15 standards de consommation et 11 indicateurs de marché/fiscalité après import.
- Les prix fournisseur absents du PDF restent à compléter avec les factures réelles du cabinet, afin de ne pas inventer de coûts d'achat.
- Les migrations SQL manuelles utilisent parfois `ADD COLUMN IF NOT EXISTS`, à vérifier selon la version MySQL/MariaDB. Le mécanisme serveur `stockAiMigration.js` reste plus sûr car il vérifie `information_schema`.
- Les permissions sont posées côté middleware, mais un durcissement plus fin par action restera nécessaire avant production.
- Le module frontend laboratoire reste encore simple : le backend est prêt, mais l'interface peut être améliorée dans une prochaine passe.
- L'IA reste locale, explicable, non médicale et à validation humaine.

## 9. Verdict

```text
Fonctionnel en local : oui, sous réserve de MySQL actif.
Build frontend : OK.
Serveur backend : OK.
Audit npm : OK, 0 vulnérabilité détectée.
MySQL : non testé réellement dans cet environnement.
Sécurité minimale : renforcée, mais encore à durcir avant production.
Prêt production médicale : non, pas avant tests MySQL réels, sauvegardes, audit complet, gestion fine des droits et validation sécurité.
```
