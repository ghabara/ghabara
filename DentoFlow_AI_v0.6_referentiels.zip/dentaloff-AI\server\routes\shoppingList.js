const express = require('express');
const { pool } = require('../db');
const { auth, adminOnly } = require('../middleware/auth');
const { buildShoppingList } = require('../services/inventoryService');

const router = express.Router();
const asyncHandler = fn => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

router.get('/', auth, adminOnly, asyncHandler(async (_req, res) => {
  const suggestions = await buildShoppingList(pool);
  res.json(suggestions);
}));

router.use((err, _req, res, _next) => {
  res.status(400).json({ error: err.message || 'Erreur liste achat.' });
});

module.exports = router;
