const express = require('express');
const { pool } = require('../db');
const { auth, adminOnly } = require('../middleware/auth');
const { buildInventoryInsights } = require('../services/inventoryService');

const router = express.Router();
const asyncHandler = fn => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

function num(value) {
  const n = Number(value || 0);
  return Number.isFinite(n) ? n : 0;
}

router.get('/overview', auth, adminOnly, asyncHandler(async (_req, res) => {
  const [
    [[patients]],
    [[dossiers]],
    [[appointments]],
    [[performed]],
    [[purchases]],
    [[lab]],
    [[plans]],
    [topActs],
    [alerts],
    [movements],
  ] = await Promise.all([
    pool.query('SELECT COUNT(*) AS total FROM patients'),
    pool.query('SELECT COUNT(*) AS total FROM dossiers'),
    pool.query(`
      SELECT
        SUM(CASE WHEN date = DATE_FORMAT(CURDATE(), '%Y-%m-%d') THEN 1 ELSE 0 END) AS today,
        SUM(CASE WHEN date >= DATE_FORMAT(CURDATE(), '%Y-%m-%d') AND date < DATE_FORMAT(DATE_ADD(CURDATE(), INTERVAL 7 DAY), '%Y-%m-%d') THEN 1 ELSE 0 END) AS next_7d,
        SUM(CASE WHEN statut IN ('pending','confirmed','arrived','in_treatment') THEN 1 ELSE 0 END) AS active,
        SUM(CASE WHEN statut = 'pending' THEN 1 ELSE 0 END) AS pending,
        SUM(CASE WHEN statut = 'done' AND date >= DATE_FORMAT(CURDATE(), '%Y-%m-01') THEN 1 ELSE 0 END) AS done_this_month,
        SUM(CASE WHEN statut = 'no_show' AND date >= DATE_FORMAT(CURDATE(), '%Y-%m-01') THEN 1 ELSE 0 END) AS no_show_this_month
      FROM rendez_vous
    `),
    pool.query(`
      SELECT
        COUNT(*) AS month_count,
        COALESCE(SUM(actual_total_cost_tnd), 0) AS material_cost_month_tnd,
        AVG(actual_total_cost_tnd) AS avg_material_cost_tnd
      FROM performed_acts
      WHERE performed_date >= DATE_FORMAT(CURDATE(), '%Y-%m-01')
    `),
    pool.query(`
      SELECT
        COUNT(*) AS month_count,
        COALESCE(SUM(total_price_tnd), 0) AS purchase_total_month_tnd
      FROM inventory_purchases
      WHERE purchase_date >= DATE_FORMAT(CURDATE(), '%Y-%m-01')
    `),
    pool.query(`
      SELECT
        COUNT(*) AS total,
        SUM(CASE WHEN status NOT IN ('delivered','cancelled') THEN 1 ELSE 0 END) AS open_count,
        SUM(CASE WHEN due_date IS NOT NULL AND due_date < CURDATE() AND status NOT IN ('delivered','cancelled') THEN 1 ELSE 0 END) AS late_count,
        COALESCE(SUM(CASE WHEN status NOT IN ('cancelled') THEN lab_cost_tnd ELSE 0 END), 0) AS lab_cost_total_tnd
      FROM lab_cases
    `),
    pool.query(`
      SELECT
        COUNT(*) AS total,
        SUM(CASE WHEN status IN ('accepted','in_progress') THEN 1 ELSE 0 END) AS active_count,
        COALESCE(SUM(estimated_total_tnd), 0) AS estimated_total_tnd
      FROM treatment_plans
    `),
    pool.query(`
      SELECT a.name AS act_name,
             COUNT(pa.id) AS act_count,
             COALESCE(SUM(pa.actual_total_cost_tnd), 0) AS total_material_cost_tnd,
             AVG(pa.actual_total_cost_tnd) AS avg_material_cost_tnd
      FROM performed_acts pa
      JOIN clinical_acts a ON a.id = pa.act_id
      WHERE pa.performed_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
      GROUP BY a.id, a.name
      ORDER BY total_material_cost_tnd DESC, act_count DESC
      LIMIT 5
    `),
    pool.query(`
      SELECT id, type, severity, message, recommendation
      FROM ai_alerts
      WHERE status = 'OPEN'
      ORDER BY FIELD(severity, 'CRITICAL', 'WARNING', 'INFO'), created_at DESC
      LIMIT 6
    `),
    pool.query(`
      SELECT product_name_snapshot, direction, quantity, unit, origin, created_at
      FROM inventory_movements
      ORDER BY created_at DESC, id DESC
      LIMIT 6
    `),
  ]);

  const insights = await buildInventoryInsights(pool);
  const urgentProducts = (insights.products || []).filter(row => row.risk_score >= 70 || row.recommended_quantity > 0).slice(0, 6);
  const materialCost = num(performed.material_cost_month_tnd);
  const purchaseTotal = num(purchases.purchase_total_month_tnd);

  res.json({
    generated_at: new Date().toISOString(),
    positioning: 'Plateforme de pilotage intelligent du cabinet dentaire',
    promise: 'Savoir ce que chaque acte consomme, combien il coute, et quoi acheter avant la rupture.',
    patients: {
      total: num(patients.total),
      dossier_count: num(dossiers.total),
    },
    appointments: {
      today: num(appointments.today),
      next_7d: num(appointments.next_7d),
      active: num(appointments.active),
      pending: num(appointments.pending),
      done_this_month: num(appointments.done_this_month),
      no_show_this_month: num(appointments.no_show_this_month),
    },
    economics: {
      performed_this_month: num(performed.month_count),
      material_cost_month_tnd: Number(materialCost.toFixed(3)),
      avg_material_cost_tnd: performed.avg_material_cost_tnd === null ? null : Number(num(performed.avg_material_cost_tnd).toFixed(3)),
      purchase_total_month_tnd: Number(purchaseTotal.toFixed(3)),
      purchase_vs_material_delta_tnd: Number((purchaseTotal - materialCost).toFixed(3)),
    },
    inventory: {
      ...insights.summary,
      urgent_products: urgentProducts,
    },
    lab: {
      total: num(lab.total),
      open_count: num(lab.open_count),
      late_count: num(lab.late_count),
      lab_cost_total_tnd: Number(num(lab.lab_cost_total_tnd).toFixed(3)),
    },
    treatment_plans: {
      total: num(plans.total),
      active_count: num(plans.active_count),
      estimated_total_tnd: Number(num(plans.estimated_total_tnd).toFixed(3)),
    },
    top_acts: topActs.map(row => ({
      act_name: row.act_name,
      act_count: num(row.act_count),
      total_material_cost_tnd: Number(num(row.total_material_cost_tnd).toFixed(3)),
      avg_material_cost_tnd: row.avg_material_cost_tnd === null ? null : Number(num(row.avg_material_cost_tnd).toFixed(3)),
    })),
    alerts,
    latest_movements: movements,
  });
}));

router.use((err, _req, res, _next) => {
  res.status(400).json({ error: err.message || 'Erreur pilotage cabinet.' });
});

module.exports = router;
