const { refreshAiAlerts } = require('./inventoryService');

async function columnExists(pool, tableName, columnName) {
  const dbName = process.env.DB_NAME || 'dentaloff_ai';
  const [rows] = await pool.query(
    `SELECT COLUMN_NAME
     FROM information_schema.COLUMNS
     WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?`,
    [dbName, tableName, columnName]
  );
  return rows.length > 0;
}

async function addColumnIfMissing(pool, tableName, columnName, ddl) {
  if (!(await columnExists(pool, tableName, columnName))) {
    await pool.query(`ALTER TABLE ${tableName} ADD COLUMN ${ddl}`);
  }
}

async function runStockAiMigrations(pool) {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS inventory_products (
      id INT AUTO_INCREMENT PRIMARY KEY,
      name VARCHAR(160) NOT NULL,
      category VARCHAR(100) NOT NULL DEFAULT 'A classer',
      sub_category VARCHAR(120) NULL,
      tracking_unit VARCHAR(30) NOT NULL DEFAULT 'unite',
      package_quantity DECIMAL(12,4) NULL,
      package_unit VARCHAR(30) NULL,
      package_price_tnd DECIMAL(12,3) NULL,
      current_stock DECIMAL(12,4) NULL DEFAULT 0,
      min_stock DECIMAL(12,4) NULL DEFAULT 0,
      max_stock DECIMAL(12,4) NULL,
      reserved_stock DECIMAL(12,4) NULL DEFAULT 0,
      storage_location VARCHAR(120) NULL,
      barcode VARCHAR(120) NULL,
      lot_strategy ENUM('GLOBAL','LOT_FEFO') NOT NULL DEFAULT 'GLOBAL',
      supplier_alias VARCHAR(120) NULL,
      supplier_lead_days INT NULL,
      expiration_date DATE NULL,
      lot_number VARCHAR(80) NULL,
      source_type VARCHAR(80) NOT NULL DEFAULT 'A completer',
      context_type ENUM('CABINET','LAB','BOTH') NOT NULL DEFAULT 'CABINET',
      notes TEXT NULL,
      is_active TINYINT(1) NOT NULL DEFAULT 1,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      UNIQUE KEY uq_inventory_product_name (name)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS inventory_lots (
      id INT AUTO_INCREMENT PRIMARY KEY,
      product_id INT NOT NULL,
      lot_number VARCHAR(80) NOT NULL,
      quantity_current DECIMAL(12,4) NOT NULL DEFAULT 0,
      quantity_initial DECIMAL(12,4) NULL,
      expiration_date DATE NULL,
      purchase_id INT NULL,
      status ENUM('ACTIVE','QUARANTINE','EXPIRED','CONSUMED','DISCARDED','CORRECTED') NOT NULL DEFAULT 'ACTIVE',
      storage_location VARCHAR(120) NULL,
      comment TEXT NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      KEY idx_inventory_lots_product (product_id),
      KEY idx_inventory_lots_expiration (expiration_date),
      CONSTRAINT fk_inventory_lot_product FOREIGN KEY (product_id) REFERENCES inventory_products(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS clinical_acts (
      id INT AUTO_INCREMENT PRIMARY KEY,
      name VARCHAR(120) NOT NULL,
      clinical_variant VARCHAR(120) NOT NULL DEFAULT 'Standard',
      category VARCHAR(100) NULL,
      default_duration_minutes INT NULL,
      default_price_tnd DECIMAL(12,3) NULL,
      context_type ENUM('CABINET','LAB') NOT NULL DEFAULT 'CABINET',
      notes TEXT NULL,
      is_active TINYINT(1) NOT NULL DEFAULT 1,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      UNIQUE KEY uq_clinical_act_variant (name, clinical_variant)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS act_recipes (
      id INT AUTO_INCREMENT PRIMARY KEY,
      act_id INT NOT NULL,
      product_id INT NOT NULL,
      recipe_variant VARCHAR(120) NOT NULL DEFAULT 'Standard',
      quantity_per_act DECIMAL(12,4) NOT NULL,
      unit VARCHAR(30) NOT NULL,
      measurement_mode VARCHAR(50) NOT NULL DEFAULT 'estimation',
      confidence VARCHAR(30) NOT NULL DEFAULT 'moyenne',
      measurement_count INT NOT NULL DEFAULT 0,
      source_note VARCHAR(255) NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      UNIQUE KEY uq_act_recipe_variant (act_id, product_id, recipe_variant),
      CONSTRAINT fk_act_recipe_act FOREIGN KEY (act_id) REFERENCES clinical_acts(id) ON DELETE CASCADE,
      CONSTRAINT fk_act_recipe_product FOREIGN KEY (product_id) REFERENCES inventory_products(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS performed_acts (
      id INT AUTO_INCREMENT PRIMARY KEY,
      performed_date DATE NOT NULL,
      patient_id VARCHAR(12) NULL,
      patient_label VARCHAR(120) NOT NULL DEFAULT 'Patient anonymise',
      act_id INT NOT NULL,
      rdv_id INT NULL,
      estimated_total_cost_tnd DECIMAL(12,3) NULL,
      actual_total_cost_tnd DECIMAL(12,3) NULL,
      comment TEXT NULL,
      created_by VARCHAR(80) NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      CONSTRAINT fk_performed_act_act FOREIGN KEY (act_id) REFERENCES clinical_acts(id) ON DELETE CASCADE,
      CONSTRAINT fk_performed_act_patient FOREIGN KEY (patient_id) REFERENCES patients(id_patient) ON DELETE SET NULL,
      CONSTRAINT fk_performed_act_rdv FOREIGN KEY (rdv_id) REFERENCES rendez_vous(id) ON DELETE SET NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS consumption_logs (
      id INT AUTO_INCREMENT PRIMARY KEY,
      performed_act_id INT NULL,
      log_date DATE NOT NULL,
      act_id INT NOT NULL,
      product_id INT NOT NULL,
      quantity DECIMAL(12,4) NOT NULL,
      unit VARCHAR(30) NOT NULL,
      measurement_mode VARCHAR(50) NOT NULL,
      confidence VARCHAR(30) NOT NULL DEFAULT 'moyenne',
      line_cost_tnd DECIMAL(12,3) NULL,
      stock_before DECIMAL(12,4) NULL,
      stock_after DECIMAL(12,4) NULL,
      comment TEXT NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      CONSTRAINT fk_consumption_performed_act FOREIGN KEY (performed_act_id) REFERENCES performed_acts(id) ON DELETE SET NULL,
      CONSTRAINT fk_consumption_act FOREIGN KEY (act_id) REFERENCES clinical_acts(id) ON DELETE CASCADE,
      CONSTRAINT fk_consumption_product FOREIGN KEY (product_id) REFERENCES inventory_products(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS inventory_purchases (
      id INT AUTO_INCREMENT PRIMARY KEY,
      purchase_date DATE NOT NULL,
      supplier VARCHAR(120) NOT NULL,
      product_id INT NOT NULL,
      quantity_purchased DECIMAL(12,4) NOT NULL,
      unit VARCHAR(30) NOT NULL,
      total_price_tnd DECIMAL(12,3) NOT NULL,
      package_price_tnd DECIMAL(12,3) NULL,
      invoice_number VARCHAR(80) NULL,
      lot_number VARCHAR(80) NULL,
      expiration_date DATE NULL,
      comment TEXT NULL,
      updated_package_price TINYINT(1) NOT NULL DEFAULT 0,
      stock_after DECIMAL(12,4) NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      CONSTRAINT fk_inventory_purchase_product FOREIGN KEY (product_id) REFERENCES inventory_products(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS inventory_movements (
      id INT AUTO_INCREMENT PRIMARY KEY,
      product_id INT NULL,
      product_name_snapshot VARCHAR(160) NULL,
      quantity DECIMAL(12,4) NOT NULL,
      unit VARCHAR(30) NOT NULL,
      direction ENUM('IN','OUT') NOT NULL,
      origin ENUM('PURCHASE','PERFORMED_ACT','RDV_RESERVATION','CORRECTION','LAB_CASE') NOT NULL,
      origin_id INT NULL,
      stock_before DECIMAL(12,4) NULL,
      stock_after DECIMAL(12,4) NULL,
      created_by VARCHAR(80) NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      CONSTRAINT fk_inventory_movement_product FOREIGN KEY (product_id) REFERENCES inventory_products(id) ON DELETE SET NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS ai_alerts (
      id INT AUTO_INCREMENT PRIMARY KEY,
      type VARCHAR(50) NOT NULL,
      severity VARCHAR(20) NOT NULL DEFAULT 'INFO',
      entity_type VARCHAR(50) NULL,
      entity_id INT NULL,
      message TEXT NOT NULL,
      recommendation TEXT NULL,
      status VARCHAR(20) NOT NULL DEFAULT 'OPEN',
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      resolved_at DATETIME NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS reference_consumption_standards (
      id INT AUTO_INCREMENT PRIMARY KEY,
      standard_key VARCHAR(120) NOT NULL,
      source_document VARCHAR(160) NOT NULL,
      source_page INT NULL,
      category VARCHAR(120) NOT NULL,
      product_label VARCHAR(160) NOT NULL,
      act_context VARCHAR(160) NOT NULL DEFAULT '',
      manufacturer_example VARCHAR(160) NULL,
      package_description VARCHAR(255) NULL,
      package_quantity_min DECIMAL(12,4) NULL,
      package_quantity_max DECIMAL(12,4) NULL,
      package_unit VARCHAR(30) NULL,
      usage_min DECIMAL(12,4) NULL,
      usage_typical DECIMAL(12,4) NULL,
      usage_max DECIMAL(12,4) NULL,
      usage_unit VARCHAR(30) NULL,
      patients_covered_min DECIMAL(12,4) NULL,
      patients_covered_typical DECIMAL(12,4) NULL,
      patients_covered_max DECIMAL(12,4) NULL,
      uncertainty TEXT NULL,
      notes TEXT NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      UNIQUE KEY uq_reference_consumption_standard (standard_key)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS reference_market_indicators (
      id INT AUTO_INCREMENT PRIMARY KEY,
      source_document VARCHAR(160) NOT NULL,
      indicator_key VARCHAR(120) NOT NULL,
      label VARCHAR(200) NOT NULL,
      value_min DECIMAL(18,4) NULL,
      value_typical DECIMAL(18,4) NULL,
      value_max DECIMAL(18,4) NULL,
      unit VARCHAR(60) NULL,
      year_label VARCHAR(40) NULL,
      source_page INT NULL,
      notes TEXT NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      UNIQUE KEY uq_reference_market_indicator (indicator_key)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS audit_logs (
      id BIGINT AUTO_INCREMENT PRIMARY KEY,
      actor VARCHAR(120) NULL,
      actor_role VARCHAR(40) NULL,
      action VARCHAR(80) NOT NULL,
      entity_type VARCHAR(80) NULL,
      entity_id VARCHAR(80) NULL,
      patient_id VARCHAR(12) NULL,
      ip_address VARCHAR(64) NULL,
      user_agent VARCHAR(255) NULL,
      details_json TEXT NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      KEY idx_audit_patient (patient_id),
      KEY idx_audit_entity (entity_type, entity_id),
      KEY idx_audit_action (action),
      CONSTRAINT fk_audit_patient FOREIGN KEY (patient_id) REFERENCES patients(id_patient) ON DELETE SET NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS treatment_plans (
      id INT AUTO_INCREMENT PRIMARY KEY,
      patient_id VARCHAR(12) NOT NULL,
      title VARCHAR(160) NOT NULL,
      status ENUM('draft','proposed','accepted','in_progress','completed','cancelled') NOT NULL DEFAULT 'draft',
      estimated_total_tnd DECIMAL(12,3) NULL,
      notes TEXT NULL,
      created_by VARCHAR(80) NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      CONSTRAINT fk_treatment_plan_patient FOREIGN KEY (patient_id) REFERENCES patients(id_patient) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS treatment_plan_items (
      id INT AUTO_INCREMENT PRIMARY KEY,
      plan_id INT NOT NULL,
      act_id INT NULL,
      tooth_number VARCHAR(20) NULL,
      quadrant VARCHAR(20) NULL,
      label VARCHAR(160) NOT NULL,
      status ENUM('planned','accepted','performed','cancelled') NOT NULL DEFAULT 'planned',
      estimated_price_tnd DECIMAL(12,3) NULL,
      estimated_material_cost_tnd DECIMAL(12,3) NULL,
      performed_act_id INT NULL,
      display_order INT NOT NULL DEFAULT 0,
      notes TEXT NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      CONSTRAINT fk_treatment_item_plan FOREIGN KEY (plan_id) REFERENCES treatment_plans(id) ON DELETE CASCADE,
      CONSTRAINT fk_treatment_item_act FOREIGN KEY (act_id) REFERENCES clinical_acts(id) ON DELETE SET NULL,
      CONSTRAINT fk_treatment_item_performed FOREIGN KEY (performed_act_id) REFERENCES performed_acts(id) ON DELETE SET NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS documents_index (
      id INT AUTO_INCREMENT PRIMARY KEY,
      document_id INT NULL,
      patient_id VARCHAR(12) NULL,
      product_id INT NULL,
      title VARCHAR(180) NOT NULL,
      doc_type VARCHAR(80) NULL,
      tags VARCHAR(255) NULL,
      summary TEXT NULL,
      source_path VARCHAR(255) NULL,
      is_external TINYINT(1) NOT NULL DEFAULT 0,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      CONSTRAINT fk_doc_index_document FOREIGN KEY (document_id) REFERENCES documents(id) ON DELETE SET NULL,
      CONSTRAINT fk_doc_index_patient FOREIGN KEY (patient_id) REFERENCES patients(id_patient) ON DELETE SET NULL,
      CONSTRAINT fk_doc_index_product FOREIGN KEY (product_id) REFERENCES inventory_products(id) ON DELETE SET NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS lab_cases (
      id INT AUTO_INCREMENT PRIMARY KEY,
      patient_id VARCHAR(12) NULL,
      dentist_client_id INT NULL,
      performed_act_id INT NULL,
      case_code VARCHAR(80) NOT NULL,
      prosthesis_type VARCHAR(120) NOT NULL,
      external_lab_name VARCHAR(160) NULL,
      status VARCHAR(40) NOT NULL DEFAULT 'draft',
      shade VARCHAR(40) NULL,
      material VARCHAR(120) NULL,
      tooth_numbers VARCHAR(120) NULL,
      sent_date DATE NULL,
      due_date DATE NULL,
      received_date DATE NULL,
      lab_cost_tnd DECIMAL(12,3) NULL,
      notes TEXT NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      CONSTRAINT fk_lab_case_patient FOREIGN KEY (patient_id) REFERENCES patients(id_patient) ON DELETE SET NULL,
      CONSTRAINT fk_lab_case_performed_act FOREIGN KEY (performed_act_id) REFERENCES performed_acts(id) ON DELETE SET NULL,
      UNIQUE KEY uq_lab_case_code (case_code)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS lab_case_events (
      id INT AUTO_INCREMENT PRIMARY KEY,
      lab_case_id INT NOT NULL,
      previous_status VARCHAR(40) NULL,
      new_status VARCHAR(40) NOT NULL,
      event_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      actor VARCHAR(120) NULL,
      notes TEXT NULL,
      CONSTRAINT fk_lab_case_event_case FOREIGN KEY (lab_case_id) REFERENCES lab_cases(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS lab_steps (
      id INT AUTO_INCREMENT PRIMARY KEY,
      lab_case_id INT NOT NULL,
      step_name VARCHAR(120) NOT NULL,
      status VARCHAR(40) NOT NULL DEFAULT 'todo',
      started_at DATETIME NULL,
      completed_at DATETIME NULL,
      assigned_to VARCHAR(120) NULL,
      notes TEXT NULL,
      CONSTRAINT fk_lab_step_case FOREIGN KEY (lab_case_id) REFERENCES lab_cases(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS lab_recipes (
      id INT AUTO_INCREMENT PRIMARY KEY,
      prosthesis_type VARCHAR(120) NOT NULL,
      step_name VARCHAR(120) NULL,
      product_id INT NOT NULL,
      quantity_per_case DECIMAL(12,4) NOT NULL,
      unit VARCHAR(30) NOT NULL,
      cost_tnd DECIMAL(12,3) NULL,
      notes TEXT NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      CONSTRAINT fk_lab_recipe_product FOREIGN KEY (product_id) REFERENCES inventory_products(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS lab_consumption_logs (
      id INT AUTO_INCREMENT PRIMARY KEY,
      lab_case_id INT NOT NULL,
      product_id INT NOT NULL,
      quantity DECIMAL(12,4) NOT NULL,
      unit VARCHAR(30) NOT NULL,
      line_cost_tnd DECIMAL(12,3) NULL,
      stock_before DECIMAL(12,4) NULL,
      stock_after DECIMAL(12,4) NULL,
      comment TEXT NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      CONSTRAINT fk_lab_consumption_case FOREIGN KEY (lab_case_id) REFERENCES lab_cases(id) ON DELETE CASCADE,
      CONSTRAINT fk_lab_consumption_product FOREIGN KEY (product_id) REFERENCES inventory_products(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`);

  try { await pool.query("ALTER TABLE admins MODIFY COLUMN role ENUM('admin','docteur','assistant','secretaire') DEFAULT 'admin'"); } catch (e) { console.warn('Role admin non modifie:', e.message); }
  try { await pool.query("ALTER TABLE rendez_vous MODIFY COLUMN statut ENUM('pending','confirmed','arrived','in_treatment','done','cancelled','no_show') DEFAULT 'pending'"); } catch (e) { console.warn('Statuts RDV non modifies:', e.message); }

  await addColumnIfMissing(pool, 'inventory_products', 'context_type', "context_type ENUM('CABINET','LAB','BOTH') NOT NULL DEFAULT 'CABINET'");
  await addColumnIfMissing(pool, 'inventory_products', 'supplier_lead_days', 'supplier_lead_days INT NULL');
  await addColumnIfMissing(pool, 'inventory_products', 'max_stock', 'max_stock DECIMAL(12,4) NULL');
  await addColumnIfMissing(pool, 'inventory_products', 'reserved_stock', 'reserved_stock DECIMAL(12,4) NULL DEFAULT 0');
  await addColumnIfMissing(pool, 'inventory_products', 'storage_location', 'storage_location VARCHAR(120) NULL');
  await addColumnIfMissing(pool, 'inventory_products', 'barcode', 'barcode VARCHAR(120) NULL');
  await addColumnIfMissing(pool, 'inventory_products', 'lot_strategy', "lot_strategy ENUM('GLOBAL','LOT_FEFO') NOT NULL DEFAULT 'GLOBAL'");
  await addColumnIfMissing(pool, 'performed_acts', 'patient_id', 'patient_id VARCHAR(12) NULL');
  await addColumnIfMissing(pool, 'performed_acts', 'rdv_id', 'rdv_id INT NULL');
  await addColumnIfMissing(pool, 'consumption_logs', 'stock_before', 'stock_before DECIMAL(12,4) NULL');
  await addColumnIfMissing(pool, 'rendez_vous', 'duration_minutes', 'duration_minutes INT NULL DEFAULT 30');
  await addColumnIfMissing(pool, 'rendez_vous', 'practitioner', "practitioner VARCHAR(120) NULL DEFAULT 'Docteur'");
  await addColumnIfMissing(pool, 'rendez_vous', 'chair', "chair VARCHAR(80) NULL DEFAULT 'Fauteuil 1'");
  await addColumnIfMissing(pool, 'rendez_vous', 'room', 'room VARCHAR(80) NULL');
  await addColumnIfMissing(pool, 'rendez_vous', 'notes', 'notes TEXT NULL');
  await addColumnIfMissing(pool, 'rendez_vous', 'planned_act_id', 'planned_act_id INT NULL');
  await addColumnIfMissing(pool, 'lab_cases', 'performed_act_id', 'performed_act_id INT NULL');
  await addColumnIfMissing(pool, 'lab_cases', 'external_lab_name', 'external_lab_name VARCHAR(160) NULL');
  await addColumnIfMissing(pool, 'lab_cases', 'material', 'material VARCHAR(120) NULL');
  await addColumnIfMissing(pool, 'lab_cases', 'sent_date', 'sent_date DATE NULL');
  await addColumnIfMissing(pool, 'lab_cases', 'received_date', 'received_date DATE NULL');
  await addColumnIfMissing(pool, 'lab_cases', 'lab_cost_tnd', 'lab_cost_tnd DECIMAL(12,3) NULL');

  await seedStockAiDemo(pool);
  await seedFranceConsumptionReference(pool);
  await refreshAiAlerts(pool);
}

async function seedStockAiDemo(pool) {
  const [[productCount]] = await pool.query('SELECT COUNT(*) AS n FROM inventory_products');
  if (productCount.n === 0) {
    await pool.query(
      `INSERT INTO inventory_products
       (name, category, sub_category, tracking_unit, package_quantity, package_unit,
        package_price_tnd, current_stock, min_stock, supplier_alias, source_type, notes, context_type)
       VALUES
       ('Resine / composite A2', 'Restauratrice', 'Composite', 'g', 4, 'g', 45.000, 8, 1, 'Fournisseur a completer', 'Demo Stock AI', 'Consommation initiale 0.400 g par composite.', 'CABINET'),
       ('Acide orthophosphorique gel bleu', 'Restauratrice', 'Mordancage', 'g', NULL, 'g', NULL, 5, 0.5, 'Fournisseur a completer', 'Demo Stock AI', 'Prix et conditionnement a completer.', 'CABINET'),
       ('Adhesif / bonding', 'Restauratrice', 'Adhesif', 'g', NULL, 'g', NULL, 3, 0.3, 'Fournisseur a completer', 'Demo Stock AI', 'Prix et conditionnement a completer.', 'CABINET'),
       ('Microbrush', 'Usage unique', 'Application', 'unite', 100, 'unite', 18.000, 80, 20, 'Fournisseur a completer', 'Demo Stock AI', 'Moyenne initiale 1.09 unite par composite.', 'CABINET'),
       ('Anesthesie carpule', 'Anesthesie', NULL, 'carpule', 50, 'carpule', 75.000, 40, 10, 'Fournisseur a completer', 'Demo Stock AI', 'Endo 1.20 carpule, extraction 1.10 carpule.', 'CABINET'),
       ('Resine dual / automix', 'Reconstitution', 'Automix', 'g', 9, 'g', 65.000, 9, 1.5, 'Fournisseur a completer', 'Demo Stock AI', 'Reconstitution coronaire 1.65 g.', 'CABINET'),
       ('Embout automix jete', 'Usage unique', 'Embout', 'unite', 20, 'unite', 12.000, 20, 5, 'Fournisseur a completer', 'Demo Stock AI', 'Perte embout suivie separement.', 'CABINET'),
       ('Gants', 'Usage unique', 'Protection', 'paire', 100, 'paire', 16.000, 100, 20, 'Fournisseur a completer', 'Demo Stock AI', 'Produit non encore relie a toutes les recettes.', 'BOTH'),
       ('Aiguille dentaire', 'Anesthesie', NULL, 'unite', 100, 'unite', NULL, 80, 20, 'Fournisseur a completer', 'Demo Stock AI', 'A compter par acte avec anesthesie.', 'CABINET'),
       ('Ciment de scellement', 'Collage', 'Scellement', 'g', NULL, 'g', NULL, 4, 0.5, 'Fournisseur a completer', 'Demo Stock AI', 'Produit a mesurer pour collage couronne.', 'CABINET'),
       ('Papier absorbant endo', 'Endodontie', NULL, 'unite', NULL, 'unite', NULL, 60, 15, 'Fournisseur a completer', 'Demo Stock AI', 'A ajouter aux recettes endo quand mesure.', 'CABINET'),
       ('Gutta percha', 'Endodontie', NULL, 'unite', NULL, 'unite', NULL, 50, 10, 'Fournisseur a completer', 'Demo Stock AI', 'A ajouter aux recettes endo quand mesure.', 'CABINET'),
       ('Granulotec', 'Endodontie', NULL, 'g', NULL, 'g', NULL, 2, 0.5, 'Fournisseur a completer', 'Demo Stock AI', 'A ajouter aux recettes endo quand mesure.', 'CABINET')`
    );
  }

  const [[actCount]] = await pool.query('SELECT COUNT(*) AS n FROM clinical_acts');
  if (actCount.n === 0) {
    await pool.query(
      `INSERT INTO clinical_acts
       (name, clinical_variant, category, default_duration_minutes, default_price_tnd, notes)
       VALUES
       ('Composite', 'Acte restaurateur standard', 'Restauratrice', 45, 120.000, 'Composite + acide + adhesif + microbrush.'),
       ('Endo', 'Standard', 'Endodontie', 75, 220.000, 'Anesthesie suivie en carpules pour le MVP.'),
       ('Extraction', 'Simple', 'Chirurgie', 35, 100.000, 'Anesthesie suivie en carpules.'),
       ('Empreinte', 'Standard', 'Prothese', 30, 80.000, 'Recette a completer selon materiau.'),
       ('Detartrage / desinfection', 'Standard', 'Parodontologie', 40, 90.000, 'Recette a completer selon consommables suivis.'),
       ('Reconstitution coronaire', 'Resine dual / automix', 'Restauratrice', 50, 150.000, 'Resine dual + embout.'),
       ('Collage couronne', 'Standard', 'Prothese', 45, 160.000, 'Acide, adhesif, ciment, microbrush, embout si utilise.')`
    );
  }

  const [[recipeCount]] = await pool.query('SELECT COUNT(*) AS n FROM act_recipes');
  if (recipeCount.n === 0) {
    const recipes = [
      ['Composite', 'Resine / composite A2', 0.4, 'g', 'pesee', 'bonne', 'V0.2 Stock AI'],
      ['Composite', 'Acide orthophosphorique gel bleu', 0.1, 'g', 'pesee', 'bonne', 'V0.2 Stock AI'],
      ['Composite', 'Adhesif / bonding', 0.019, 'g', 'pesee', 'bonne', 'V0.2 Stock AI'],
      ['Composite', 'Microbrush', 1.09, 'unite', 'comptage', 'bonne', 'V0.2 Stock AI'],
      ['Endo', 'Anesthesie carpule', 1.2, 'carpule', 'estimation', 'moyenne', 'V0.2 Stock AI'],
      ['Extraction', 'Anesthesie carpule', 1.1, 'carpule', 'estimation', 'moyenne', 'V0.2 Stock AI'],
      ['Reconstitution coronaire', 'Resine dual / automix', 1.65, 'g', 'pesee', 'moyenne', 'Plage 1.5 a 1.8 g'],
      ['Reconstitution coronaire', 'Embout automix jete', 1, 'unite', 'comptage', 'moyenne', 'Perte embout separee'],
      ['Collage couronne', 'Acide orthophosphorique gel bleu', 0.1, 'g', 'estimation', 'faible', 'A mesurer au cabinet'],
      ['Collage couronne', 'Adhesif / bonding', 0.019, 'g', 'estimation', 'faible', 'A mesurer au cabinet'],
      ['Collage couronne', 'Ciment de scellement', 0.3, 'g', 'estimation', 'faible', 'A mesurer au cabinet'],
      ['Collage couronne', 'Microbrush', 1, 'unite', 'comptage', 'moyenne', 'A mesurer au cabinet'],
      ['Collage couronne', 'Embout automix jete', 1, 'unite', 'comptage', 'moyenne', 'Si embout automix utilise'],
    ];
    for (const [actName, productName, qty, unit, mode, confidence, source] of recipes) {
      await pool.query(
        `INSERT IGNORE INTO act_recipes
         (act_id, product_id, quantity_per_act, unit, measurement_mode, confidence, source_note)
         SELECT a.id, p.id, ?, ?, ?, ?, ?
         FROM clinical_acts a, inventory_products p
         WHERE a.name = ? AND p.name = ?`,
        [qty, unit, mode, confidence, source, actName, productName]
      );
    }
  }
}

async function seedFranceConsumptionReference(pool) {
  const source = 'Rapport analytique consommation produits dentaires France 2024';

  const marketIndicators = [
    ['dentistes_liberaux_france', 'Chirurgiens-dentistes liberaux en France', 35700, 35700, 35700, 'praticiens', '2024', 1, 'Ordre de grandeur utilise pour les projections cabinet.'],
    ['population_suivie_annuelle', 'Part de la population prise en charge chaque annee', 50, 50, 50, 'pourcent', '2024', 1, 'Environ un patient sur deux consulte annuellement.'],
    ['depenses_soins_dentaires_liberaux', 'Soins dentaires en cabinet liberal', 13.2, 13.2, 13.2, 'milliards EUR', '2024', 1, 'Base macro-economique du rapport.'],
    ['part_protheses', 'Part protheses dentaires', 42, 42, 42, 'pourcent', '2024', 4, 'Repartition indicative des depenses.'],
    ['part_soins_conservateurs', 'Part soins conservateurs', 23, 23, 23, 'pourcent', '2024', 4, 'Repartition indicative des depenses.'],
    ['part_orthodontie', 'Part orthodontie', 20, 20, 20, 'pourcent', '2024', 4, 'Repartition indicative des depenses.'],
    ['part_radiologie_consultations', 'Part radiologie et consultations', 5, 5, 5, 'pourcent', '2024', 4, 'Repartition indicative des depenses.'],
    ['implants_annuels_france', 'Implants poses par an en France', 1000000, 1000000, 1000000, 'implants/an', '2024', 2, 'Ordre de grandeur national.'],
    ['protheses_annuelles_france', 'Protheses dentaires annuelles en France', 10000000, 10500000, 11000000, 'protheses/an', '2024', 2, 'Couronnes, bridges et protheses amovibles.'],
    ['tva_consommables_standard', 'TVA consommables standards', 20, 20, 20, 'pourcent', '2024', 4, 'Composites, adhesifs, ciments, hygiene et sterilisation.'],
    ['tva_actes_dentaires', 'TVA actes dentaires et protheses incluses', 0, 0, 0, 'pourcent', '2024', 4, 'Actes dentaires hors TVA selon le rapport.'],
  ];

  for (const indicator of marketIndicators) {
    await pool.query(
      `INSERT INTO reference_market_indicators
         (source_document, indicator_key, label, value_min, value_typical, value_max, unit, year_label, source_page, notes)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
       ON DUPLICATE KEY UPDATE
         label = VALUES(label),
         value_min = VALUES(value_min),
         value_typical = VALUES(value_typical),
         value_max = VALUES(value_max),
         unit = VALUES(unit),
         year_label = VALUES(year_label),
         source_page = VALUES(source_page),
         notes = VALUES(notes)`,
      [source, ...indicator]
    );
  }

  const standards = [
    ['Empreinte', 'Alginate empreinte', 'Empreinte complete', 'Alginoplast (DMG)', 'Pot 450 g', 450, 450, 'g', 25, 27.5, 30, 'g', 15, 15, 20, 'Variable selon empreinte complete ou partielle.', 'Pot 450 g couvrant environ 15-20 patients.', 1],
    ['Empreinte', 'Silicone empreinte VPS', 'Empreinte complete', '3M Express', 'Cartouche double 50 ml', 50, 50, 'ml', 15, 17.5, 20, 'ml', 2, 2.5, 3, 'Variable selon type et taille de porte-empreinte.', 'Cartouche 50 ml couvrant environ 2-3 empreintes.', 1],
    ['Restauratrice', 'Composite seringue', 'Restauration classe I-II', '3M Filtek Z250', 'Seringue 2.7-3.5 g; reference 3 g', 2.7, 3.5, 'g', 0.2, 0.3, 0.4, 'g', 8, 10, 12, 'Restauration volumineuse possible 0.5-0.6 g.', 'Consommation typique 0.3 g par restauration.', 1],
    ['Restauratrice', 'Composite compule', 'Restauration unitaire', '3M Filtek Z250', 'Compule 0.2 g', 0.2, 0.2, 'g', 0.2, 0.2, 0.2, 'g', 1, 1, 1, 'Une compule est generalement dediee a une restauration.', 'Format unitaire.', 2],
    ['Collage', 'Ciment resine', 'Scellement couronne unitaire', '3M RelyX Unicem', 'Capsules 16 g, environ 50 x 0.32 g', 16, 16, 'g', 0.2, 0.35, 0.5, 'g', 30, 50, 80, 'Tres variable selon morphologie et type de prothese.', 'Valeur typique retenue 0.35 g par couronne.', 2],
    ['Collage', 'Ciment resine', 'Scellement bridge ou onlay', '3M RelyX Unicem', 'Capsules 16 g', 16, 16, 'g', 0.5, 0.75, 1, 'g', 16, 25, 32, 'Bridge/onlay plus consommateur qu une couronne unitaire.', 'Fourchette 0.5-1 g.', 2],
    ['Anesthesie', 'Cartouche anesthesique', 'Anesthesie locale', 'Septanest / Xylocaine', 'Boite 50 cartouches 1.7-1.8 ml', 50, 50, 'carpule', 1, 1, 1, 'carpule', 40, 50, 60, 'Plusieurs cartouches possibles pour actes multiples.', 'Boite 50 pour environ 50 patients.', 2],
    ['Usage unique', 'Aiguille injection', 'Patient avec anesthesie', 'SteriLance (Terumo)', 'Boite 100 unites', 100, 100, 'unite', 1, 1, 1, 'unite', 100, 100, 100, 'Usage 1:1 par patient anesthesie.', 'Une aiguille par patient.', 2],
    ['Usage unique', 'Embout aspiration', 'Patient standard', 'Reference generique', 'Paquet 500 unites', 500, 500, 'unite', 1, 1, 1, 'unite', 500, 500, 500, 'Selon acte, aspiration non systematique.', 'Un tip par patient typiquement.', 2],
    ['Usage unique', 'Gants', 'Patient standard', 'Reference generique', 'Boite 100 paires', 100, 100, 'paire', 2, 2, 2, 'paire', 50, 50, 50, 'Depend de la duree et du nombre d intervenants.', 'Deux paires par patient.', 2],
    ['Usage unique', 'Masque chirurgical', 'Patient standard', 'Reference generique', 'Conditionnement a confirmer', null, null, 'unite', 1, 1, 1, 'unite', null, null, null, 'Conditionnement non precise dans le rapport.', 'Un masque par patient dans l estimation.', 2],
    ['Sterilisation', 'Sachet autoclavable 5x20', 'Set instruments patient', 'MELAG', 'Rouleau 1000 sachets', 1000, 1000, 'sachet', 1, 1, 1, 'sachet', 1000, 1000, 1000, 'Directement lie au nombre de sets instruments.', 'Un sachet par patient.', 3],
    ['Sterilisation', 'Solution desinfectante', 'Cycle de sterilisation', 'Glutaraldehyde 5 L', 'Bidon 5 L', 5, 5, 'L', 0.5, 0.75, 1, 'L', 100, 200, 300, 'Depend du nombre d instruments traites par cycle.', '5 L couvrent environ 10-20 cycles.', 3],
    ['Restauratrice', 'Adhesif dentaire', 'Collage composite ou prothese', '3M Scotchbond / Ivoclar Excite', 'Flacon 5-7 ml', 5, 7, 'ml', 0.05, 0.075, 0.1, 'ml', 50, 100, 150, 'Forte variabilite selon nombre de dents traitees.', 'Quelques gouttes par dent.', 3],
    ['Prothese', 'Couronne prothetique', 'Flux cabinet', 'Reference generique', 'Fabrication sur mesure', null, null, null, 1, 1, 1, 'cas', 1, 1, 1, 'Associe une empreinte et un scellement.', 'La prothese elle-meme est fabriquee au cas par cas.', 2],
  ];

  for (const standard of standards) {
    const standardKey = makeReferenceKey(standard[0], standard[1], standard[2]);
    await pool.query(
      `INSERT INTO reference_consumption_standards
         (standard_key, source_document, category, product_label, act_context, manufacturer_example,
          package_description, package_quantity_min, package_quantity_max, package_unit,
          usage_min, usage_typical, usage_max, usage_unit,
          patients_covered_min, patients_covered_typical, patients_covered_max,
          uncertainty, notes, source_page)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
       ON DUPLICATE KEY UPDATE
          source_document = VALUES(source_document),
          category = VALUES(category),
          product_label = VALUES(product_label),
          act_context = VALUES(act_context),
          manufacturer_example = VALUES(manufacturer_example),
          package_description = VALUES(package_description),
          package_quantity_min = VALUES(package_quantity_min),
          package_quantity_max = VALUES(package_quantity_max),
          package_unit = VALUES(package_unit),
          usage_min = VALUES(usage_min),
          usage_typical = VALUES(usage_typical),
          usage_max = VALUES(usage_max),
          usage_unit = VALUES(usage_unit),
          patients_covered_min = VALUES(patients_covered_min),
          patients_covered_typical = VALUES(patients_covered_typical),
          patients_covered_max = VALUES(patients_covered_max),
          uncertainty = VALUES(uncertainty),
          notes = VALUES(notes),
          source_page = VALUES(source_page)`,
      [standardKey, source, ...standard]
    );
  }

  const products = [
    ['Alginate empreinte 450 g', 'Empreinte', 'Alginate', 'g', 450, 'g', null, 900, 150, 1800, 'Fournisseur a completer', 'Rapport France 2024', 'CABINET', 'Rapport France 2024: 25-30 g par empreinte complete; pot 450 g couvre 15-20 patients.'],
    ['Silicone empreinte cartouche 50 ml', 'Empreinte', 'Silicone VPS', 'ml', 50, 'ml', null, 150, 50, 300, 'Fournisseur a completer', 'Rapport France 2024', 'CABINET', 'Rapport France 2024: 15-20 ml par empreinte complete; cartouche 50 ml couvre 2-3 patients.'],
    ['Composite seringue 3 g reference France', 'Restauratrice', 'Composite', 'g', 3, 'g', null, 9, 1.5, 18, 'Fournisseur a completer', 'Rapport France 2024', 'CABINET', 'Rapport France 2024: 0.2-0.4 g par restauration moyenne; seringue 3 g couvre 8-12 patients.'],
    ['Composite compule 0.2 g', 'Restauratrice', 'Composite', 'compule', 1, 'compule', null, 20, 5, 100, 'Fournisseur a completer', 'Rapport France 2024', 'CABINET', 'Rapport France 2024: une compule 0.2 g pour une restauration.'],
    ['Ciment resine capsule 16 g', 'Collage', 'Ciment resine', 'g', 16, 'g', null, 16, 2, 32, 'Fournisseur a completer', 'Rapport France 2024', 'CABINET', 'Rapport France 2024: 0.2-0.5 g par couronne, 0.5-1 g par bridge/onlay; capsules 16 g.'],
    ['Adhesif dentaire flacon 5 ml', 'Restauratrice', 'Adhesif', 'ml', 5, 'ml', null, 10, 2, 20, 'Fournisseur a completer', 'Rapport France 2024', 'CABINET', 'Rapport France 2024: 0.05-0.1 ml par dent, flacon 5-7 ml.'],
    ['Embout aspiration jetable', 'Usage unique', 'Aspiration', 'unite', 500, 'unite', null, 500, 100, 1000, 'Fournisseur a completer', 'Rapport France 2024', 'CABINET', 'Rapport France 2024: 1 tip aspiration par patient; paquet 500.'],
    ['Masque chirurgical', 'Usage unique', 'Protection', 'unite', 50, 'unite', null, 100, 50, 500, 'Fournisseur a completer', 'Rapport France 2024', 'CABINET', 'Rapport France 2024: 1 masque par patient; conditionnement local a confirmer.'],
    ['Sachet sterilisation autoclavable 5x20', 'Sterilisation', 'Sachet', 'sachet', 1000, 'sachet', null, 1000, 200, 3000, 'Fournisseur a completer', 'Rapport France 2024', 'CABINET', 'Rapport France 2024: 1 sachet par set patient; rouleau 1000.'],
    ['Solution desinfectante instrumentation 5 L', 'Sterilisation', 'Desinfectant', 'L', 5, 'L', null, 5, 1, 15, 'Fournisseur a completer', 'Rapport France 2024', 'CABINET', 'Rapport France 2024: 0.5-1 L par cycle, 5 L couvre 10-20 cycles.'],
    ['Coton salivaire / rouleau coton', 'Usage unique', 'Coton', 'unite', null, 'unite', null, 300, 60, 1000, 'Fournisseur a completer', 'Rapport France 2024', 'CABINET', 'Rapport France 2024: coton cite parmi les dispositifs a usage unique; consommation locale a mesurer.'],
    ['Anesthesie carpule', 'Anesthesie', 'Cartouche', 'carpule', 50, 'carpule', null, 40, 10, 150, 'Fournisseur a completer', 'Rapport France 2024', 'CABINET', 'Rapport France 2024: boite 50 cartouches 1.7-1.8 ml; 1 cartouche par patient en moyenne.'],
    ['Aiguille dentaire', 'Anesthesie', 'Aiguille injection', 'unite', 100, 'unite', null, 80, 20, 300, 'Fournisseur a completer', 'Rapport France 2024', 'CABINET', 'Rapport France 2024: 1 aiguille par patient avec anesthesie; boite 100.'],
    ['Gants', 'Usage unique', 'Protection', 'paire', 100, 'paire', null, 100, 20, 500, 'Fournisseur a completer', 'Rapport France 2024', 'BOTH', 'Rapport France 2024: 2 paires par patient; boite 100 paires couvre environ 50 patients.'],
  ];

  for (const product of products) {
    await upsertReferenceProduct(pool, product);
  }

  const acts = [
    ['Composite', 'Rapport France - restauration moyenne', 'Restauratrice', 45, 120, 'Rapport France 2024: restauration classe I-II, 0.2-0.4 g composite, 0.3 g typique.'],
    ['Empreinte', 'Rapport France - alginate complete', 'Prothese', 30, 80, 'Rapport France 2024: empreinte complete alginate 25-30 g.'],
    ['Empreinte', 'Rapport France - silicone', 'Prothese', 30, 110, 'Rapport France 2024: empreinte silicone 15-20 ml.'],
    ['Scellement couronne', 'Rapport France - couronne unitaire', 'Prothese', 45, 160, 'Rapport France 2024: scellement couronne 0.2-0.5 g ciment.'],
    ['Scellement bridge/onlay', 'Rapport France - bridge onlay', 'Prothese', 60, 220, 'Rapport France 2024: scellement bridge ou onlay 0.5-1 g ciment.'],
    ['Anesthesie locale', 'Rapport France - patient moyen', 'Anesthesie', 10, 30, 'Rapport France 2024: 1 cartouche et 1 aiguille par patient en moyenne.'],
    ['Set patient usage unique', 'Rapport France - standard', 'Usage unique', 5, 15, 'Rapport France 2024: 1 tip aspiration, 2 paires de gants, 1 masque, 1 sachet sterilisation.'],
    ['Sterilisation cycle', 'Rapport France - instrumentation', 'Sterilisation', 20, 20, 'Rapport France 2024: 0.5-1 L de solution par cycle.'],
    ['Prothese couronne', 'Rapport France - flux cabinet', 'Prothese', 60, 450, 'Rapport France 2024: une couronne mobilise une empreinte et un scellement.'],
  ];

  for (const act of acts) {
    await upsertReferenceAct(pool, act);
  }

  const recipes = [
    ['Composite', 'Rapport France - restauration moyenne', 'Composite seringue 3 g reference France', 'Standard', 0.3, 'g', 'estimation', 'moyenne', 'Rapport France 2024: 0.2-0.4 g'],
    ['Composite', 'Rapport France - restauration moyenne', 'Adhesif dentaire flacon 5 ml', 'Standard', 0.075, 'ml', 'estimation', 'faible', 'Rapport France 2024: 0.05-0.1 ml'],
    ['Composite', 'Rapport France - restauration moyenne', 'Microbrush', 'Standard', 1, 'unite', 'comptage', 'moyenne', 'Applicateur associe au collage'],
    ['Empreinte', 'Rapport France - alginate complete', 'Alginate empreinte 450 g', 'Standard', 27.5, 'g', 'estimation', 'moyenne', 'Rapport France 2024: 25-30 g'],
    ['Empreinte', 'Rapport France - silicone', 'Silicone empreinte cartouche 50 ml', 'Standard', 17.5, 'ml', 'estimation', 'moyenne', 'Rapport France 2024: 15-20 ml'],
    ['Scellement couronne', 'Rapport France - couronne unitaire', 'Ciment resine capsule 16 g', 'Standard', 0.35, 'g', 'estimation', 'moyenne', 'Rapport France 2024: 0.2-0.5 g'],
    ['Scellement couronne', 'Rapport France - couronne unitaire', 'Adhesif dentaire flacon 5 ml', 'Standard', 0.075, 'ml', 'estimation', 'faible', 'Collage si protocole adhesif'],
    ['Scellement couronne', 'Rapport France - couronne unitaire', 'Microbrush', 'Standard', 1, 'unite', 'comptage', 'moyenne', 'Applicateur associe au collage'],
    ['Scellement bridge/onlay', 'Rapport France - bridge onlay', 'Ciment resine capsule 16 g', 'Standard', 0.75, 'g', 'estimation', 'moyenne', 'Rapport France 2024: 0.5-1 g'],
    ['Anesthesie locale', 'Rapport France - patient moyen', 'Anesthesie carpule', 'Standard', 1, 'carpule', 'estimation', 'moyenne', 'Rapport France 2024: 1 cartouche'],
    ['Anesthesie locale', 'Rapport France - patient moyen', 'Aiguille dentaire', 'Standard', 1, 'unite', 'comptage', 'moyenne', 'Rapport France 2024: 1 aiguille'],
    ['Set patient usage unique', 'Rapport France - standard', 'Embout aspiration jetable', 'Standard', 1, 'unite', 'comptage', 'moyenne', 'Rapport France 2024: 1 tip'],
    ['Set patient usage unique', 'Rapport France - standard', 'Gants', 'Standard', 2, 'paire', 'comptage', 'moyenne', 'Rapport France 2024: 2 paires'],
    ['Set patient usage unique', 'Rapport France - standard', 'Masque chirurgical', 'Standard', 1, 'unite', 'comptage', 'moyenne', 'Rapport France 2024: 1 masque'],
    ['Set patient usage unique', 'Rapport France - standard', 'Sachet sterilisation autoclavable 5x20', 'Standard', 1, 'sachet', 'comptage', 'moyenne', 'Rapport France 2024: 1 sachet'],
    ['Set patient usage unique', 'Rapport France - standard', 'Coton salivaire / rouleau coton', 'Standard', 1, 'unite', 'estimation', 'faible', 'Coton cite, quantite a mesurer'],
    ['Sterilisation cycle', 'Rapport France - instrumentation', 'Solution desinfectante instrumentation 5 L', 'Standard', 0.75, 'L', 'estimation', 'faible', 'Rapport France 2024: 0.5-1 L par cycle'],
    ['Prothese couronne', 'Rapport France - flux cabinet', 'Alginate empreinte 450 g', 'Standard', 27.5, 'g', 'estimation', 'moyenne', '1 empreinte pour couronne'],
    ['Prothese couronne', 'Rapport France - flux cabinet', 'Ciment resine capsule 16 g', 'Standard', 0.35, 'g', 'estimation', 'moyenne', '1 scellement couronne'],
  ];

  for (const recipe of recipes) {
    await upsertReferenceRecipe(pool, recipe);
  }

  await pool.query(
    `INSERT INTO documents_index
       (title, doc_type, tags, summary, source_path, is_external)
     SELECT ?, ?, ?, ?, ?, 1
     FROM DUAL
     WHERE NOT EXISTS (
       SELECT 1 FROM documents_index
       WHERE title = ? AND source_path = ?
     )`,
    [
      'Rapport consommation produits dentaires professionnels France',
      'reference_pdf',
      'stock-ai,consommation,france,produits-dentaires',
      'Standards de consommation par acte, conditionnements typiques, patients couverts, fiscalite et indicateurs France 2024.',
      'C:\\Users\\wghab\\Downloads\\app gc\\Rapport analytique sur la consommation des produits dentaires professionnels (France).pdf',
      'Rapport consommation produits dentaires professionnels France',
      'C:\\Users\\wghab\\Downloads\\app gc\\Rapport analytique sur la consommation des produits dentaires professionnels (France).pdf',
    ]
  );
}

async function upsertReferenceProduct(pool, product) {
  await pool.query(
    `INSERT INTO inventory_products
       (name, category, sub_category, tracking_unit, package_quantity, package_unit,
        package_price_tnd, current_stock, min_stock, max_stock, supplier_alias,
        source_type, context_type, notes)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
     ON DUPLICATE KEY UPDATE
       category = VALUES(category),
       sub_category = COALESCE(inventory_products.sub_category, VALUES(sub_category)),
       package_quantity = COALESCE(inventory_products.package_quantity, VALUES(package_quantity)),
       package_unit = COALESCE(inventory_products.package_unit, VALUES(package_unit)),
       package_price_tnd = COALESCE(inventory_products.package_price_tnd, VALUES(package_price_tnd)),
       current_stock = IF(inventory_products.current_stock IS NULL OR inventory_products.current_stock = 0, VALUES(current_stock), inventory_products.current_stock),
       min_stock = IF(inventory_products.min_stock IS NULL OR inventory_products.min_stock = 0, VALUES(min_stock), inventory_products.min_stock),
       max_stock = COALESCE(inventory_products.max_stock, VALUES(max_stock)),
       supplier_alias = COALESCE(inventory_products.supplier_alias, VALUES(supplier_alias)),
       source_type = CASE
         WHEN inventory_products.source_type LIKE '%Rapport France 2024%' THEN inventory_products.source_type
         ELSE CONCAT_WS(' + ', NULLIF(inventory_products.source_type, ''), VALUES(source_type))
       END,
       context_type = VALUES(context_type),
       notes = CASE
         WHEN inventory_products.notes LIKE '%Rapport France 2024%' THEN inventory_products.notes
         ELSE CONCAT_WS(' | ', NULLIF(inventory_products.notes, ''), VALUES(notes))
       END,
       is_active = 1`,
    product
  );
}

async function upsertReferenceAct(pool, act) {
  await pool.query(
    `INSERT INTO clinical_acts
       (name, clinical_variant, category, default_duration_minutes, default_price_tnd, notes)
     VALUES (?, ?, ?, ?, ?, ?)
     ON DUPLICATE KEY UPDATE
       category = VALUES(category),
       default_duration_minutes = COALESCE(clinical_acts.default_duration_minutes, VALUES(default_duration_minutes)),
       default_price_tnd = COALESCE(clinical_acts.default_price_tnd, VALUES(default_price_tnd)),
       notes = CASE
         WHEN clinical_acts.notes LIKE '%Rapport France 2024%' THEN clinical_acts.notes
         ELSE CONCAT_WS(' | ', NULLIF(clinical_acts.notes, ''), VALUES(notes))
       END,
       is_active = 1`,
    act
  );
}

async function upsertReferenceRecipe(pool, recipe) {
  const [actName, actVariant, productName, recipeVariant, qty, unit, mode, confidence, sourceNote] = recipe;
  await pool.query(
    `INSERT INTO act_recipes
       (act_id, product_id, recipe_variant, quantity_per_act, unit, measurement_mode, confidence, source_note)
     SELECT a.id, p.id, ?, ?, ?, ?, ?, ?
     FROM clinical_acts a, inventory_products p
     WHERE a.name = ? AND a.clinical_variant = ? AND p.name = ?
     ON DUPLICATE KEY UPDATE
       quantity_per_act = VALUES(quantity_per_act),
       unit = VALUES(unit),
       measurement_mode = VALUES(measurement_mode),
       confidence = VALUES(confidence),
       source_note = VALUES(source_note)`,
    [recipeVariant, qty, unit, mode, confidence, sourceNote, actName, actVariant, productName]
  );
}

function makeReferenceKey(...parts) {
  return parts
    .join('|')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '_')
    .replace(/^_+|_+$/g, '')
    .slice(0, 120);
}

module.exports = { runStockAiMigrations };
