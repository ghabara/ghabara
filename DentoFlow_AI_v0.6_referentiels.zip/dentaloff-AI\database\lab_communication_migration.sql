USE dentaloff_ai;

CREATE TABLE IF NOT EXISTS lab_partners (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(160) NOT NULL,
  contact_name VARCHAR(160) NULL,
  email VARCHAR(180) NULL,
  phone VARCHAR(60) NULL,
  address VARCHAR(255) NULL,
  active TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_lab_partner_name (name)
);

CREATE TABLE IF NOT EXISTS lab_orders (
  id INT AUTO_INCREMENT PRIMARY KEY,
  case_id INT NULL,
  partner_id INT NULL,
  public_case_code VARCHAR(80) NOT NULL,
  patient_masked TINYINT(1) NOT NULL DEFAULT 1,
  work_type VARCHAR(140) NULL,
  tooth_ref VARCHAR(40) NULL,
  shade VARCHAR(40) NULL,
  material VARCHAR(120) NULL,
  status VARCHAR(60) NOT NULL DEFAULT 'draft',
  estimated_cost_tnd DECIMAL(12,3) NULL,
  accepted_cost_tnd DECIMAL(12,3) NULL,
  created_by INT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_lab_public_case_code (public_case_code),
  KEY idx_lab_orders_case (case_id),
  KEY idx_lab_orders_partner (partner_id)
);

CREATE TABLE IF NOT EXISTS lab_order_status_history (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_id INT NOT NULL,
  status VARCHAR(60) NOT NULL,
  note TEXT NULL,
  actor_role VARCHAR(60) NULL,
  actor_id INT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  KEY idx_lab_status_order (order_id)
);

CREATE TABLE IF NOT EXISTS lab_case_messages (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_id INT NOT NULL,
  sender_role VARCHAR(60) NOT NULL,
  sender_id INT NULL,
  message TEXT NOT NULL,
  patient_identity_visible TINYINT(1) NOT NULL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  KEY idx_lab_messages_order (order_id)
);

CREATE TABLE IF NOT EXISTS lab_case_files (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_id INT NOT NULL,
  original_name VARCHAR(255) NOT NULL,
  stored_path VARCHAR(255) NOT NULL,
  file_type VARCHAR(40) NOT NULL,
  file_size_bytes BIGINT NULL,
  patient_identity_visible TINYINT(1) NOT NULL DEFAULT 0,
  uploaded_by INT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  KEY idx_lab_files_order (order_id)
);

CREATE TABLE IF NOT EXISTS lab_notifications (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_id INT NULL,
  recipient_role VARCHAR(60) NOT NULL,
  message VARCHAR(255) NOT NULL,
  read_at DATETIME NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  KEY idx_lab_notifications_order (order_id)
);
