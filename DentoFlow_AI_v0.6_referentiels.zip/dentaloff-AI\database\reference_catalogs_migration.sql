USE dentaloff_ai;

CREATE TABLE IF NOT EXISTS countries_reference (
  id INT AUTO_INCREMENT PRIMARY KEY,
  country VARCHAR(120) NOT NULL,
  iso_code VARCHAR(8) NOT NULL,
  currency VARCHAR(12) NOT NULL,
  region VARCHAR(120) NULL,
  active TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_countries_reference_country (country),
  UNIQUE KEY uq_countries_reference_iso (iso_code)
);

CREATE TABLE IF NOT EXISTS lab_consumable_reference (
  id INT AUTO_INCREMENT PRIMARY KEY,
  canonical_name VARCHAR(255) NOT NULL,
  category VARCHAR(120) NOT NULL,
  subcategory VARCHAR(120) NULL,
  context_type ENUM('LAB','CABINET','BOTH') DEFAULT 'LAB',
  typical_use TEXT NULL,
  purchase_unit VARCHAR(120) NULL,
  storage_unit VARCHAR(120) NULL,
  packaging VARCHAR(255) NULL,
  material_type VARCHAR(120) NULL,
  standards TEXT NULL,
  certifications TEXT NULL,
  storage_notes TEXT NULL,
  waste_notes TEXT NULL,
  price_min DECIMAL(12,3) NULL,
  price_max DECIMAL(12,3) NULL,
  price_currency VARCHAR(12) NULL,
  source_name VARCHAR(255) NULL,
  source_file VARCHAR(255) NULL,
  source_page VARCHAR(50) NULL,
  source_quality ENUM('verified_public','to_confirm_supplier','estimated','uncertain') DEFAULT 'to_confirm_supplier',
  validation_status ENUM('candidate','validated','rejected','conflict') DEFAULT 'candidate',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_lab_consumable_reference (canonical_name, category, subcategory)
);

CREATE TABLE IF NOT EXISTS international_price_references (
  id INT AUTO_INCREMENT PRIMARY KEY,
  entity_type ENUM('product','lab_consumable','cabinet_consumable') NOT NULL,
  entity_id INT NULL,
  candidate_name VARCHAR(255) NOT NULL,
  category VARCHAR(120) NULL,
  brand VARCHAR(120) NULL,
  manufacturer VARCHAR(120) NULL,
  country VARCHAR(120) NOT NULL,
  currency VARCHAR(12) NOT NULL,
  price_min DECIMAL(12,3) NULL,
  price_avg DECIMAL(12,3) NULL,
  price_max DECIMAL(12,3) NULL,
  price_usd DECIMAL(12,3) NULL,
  price_eur DECIMAL(12,3) NULL,
  unit VARCHAR(80) NULL,
  packaging VARCHAR(255) NULL,
  tax_included BOOLEAN DEFAULT NULL,
  shipping_included BOOLEAN DEFAULT NULL,
  source_name VARCHAR(255) NULL,
  source_file VARCHAR(255) NULL,
  source_page VARCHAR(50) NULL,
  source_url VARCHAR(500) NULL,
  observed_at DATETIME NULL,
  effective_date DATE NULL,
  confidence_score DECIMAL(5,2) NULL,
  validation_status ENUM('candidate','validated','rejected','conflict') DEFAULT 'candidate',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_international_price_reference (entity_type, candidate_name, country, currency, unit)
);

CREATE TABLE IF NOT EXISTS international_price_history (
  id INT AUTO_INCREMENT PRIMARY KEY,
  price_reference_id INT NOT NULL,
  price_avg DECIMAL(12,3) NULL,
  price_usd DECIMAL(12,3) NULL,
  price_eur DECIMAL(12,3) NULL,
  observed_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  source_name VARCHAR(255) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  KEY idx_price_history_reference (price_reference_id)
);

CREATE TABLE IF NOT EXISTS international_price_conflicts (
  id INT AUTO_INCREMENT PRIMARY KEY,
  entity_type VARCHAR(80) NOT NULL,
  entity_id INT NULL,
  candidate_name VARCHAR(255) NOT NULL,
  country VARCHAR(120) NOT NULL,
  field_name VARCHAR(120) NOT NULL,
  current_value VARCHAR(255) NULL,
  candidate_value VARCHAR(255) NULL,
  conflict_reason VARCHAR(255) NOT NULL,
  severity ENUM('info','warning','critical') NOT NULL DEFAULT 'warning',
  status ENUM('pending','accepted','rejected','resolved') NOT NULL DEFAULT 'pending',
  source_name VARCHAR(255) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  resolved_at DATETIME NULL,
  UNIQUE KEY uq_price_conflict (entity_type, candidate_name, country, field_name, conflict_reason),
  KEY idx_price_conflicts_status (status)
);

CREATE TABLE IF NOT EXISTS exchange_rate_references (
  id INT AUTO_INCREMENT PRIMARY KEY,
  base_currency VARCHAR(12) NOT NULL,
  target_currency VARCHAR(12) NOT NULL,
  rate DECIMAL(16,6) NOT NULL,
  effective_date DATE NOT NULL,
  source_name VARCHAR(255) NOT NULL,
  confidence_score DECIMAL(5,2) DEFAULT 0.80,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_exchange_rate (base_currency, target_currency, effective_date, source_name)
);

CREATE TABLE IF NOT EXISTS dental_act_global_catalog (
  id INT AUTO_INCREMENT PRIMARY KEY,
  act_key VARCHAR(160) NOT NULL,
  act_name VARCHAR(255) NOT NULL,
  family VARCHAR(120) NULL,
  description TEXT NULL,
  modernity_status ENUM('standard','modern','specialized') NOT NULL DEFAULT 'standard',
  active TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_dental_act_key (act_key)
);

CREATE TABLE IF NOT EXISTS dental_act_local_aliases (
  id INT AUTO_INCREMENT PRIMARY KEY,
  act_id INT NOT NULL,
  country VARCHAR(120) NOT NULL,
  local_name VARCHAR(255) NOT NULL,
  code_system VARCHAR(80) NULL,
  code VARCHAR(80) NULL,
  reimbursement_status VARCHAR(120) NULL,
  source_name VARCHAR(255) NULL,
  validation_status ENUM('candidate','validated','rejected','conflict') DEFAULT 'candidate',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_dental_act_alias (act_id, country, local_name, code_system, code),
  KEY idx_dental_act_alias_country (country)
);

CREATE TABLE IF NOT EXISTS dental_act_price_references (
  id INT AUTO_INCREMENT PRIMARY KEY,
  act_id INT NOT NULL,
  country VARCHAR(120) NOT NULL,
  currency VARCHAR(12) NOT NULL,
  price_type ENUM('clinical_average','conventional_tariff','public_tariff','insurance_base','reimbursement','private_indicative','out_of_nomenclature') NOT NULL,
  price_min DECIMAL(12,3) NULL,
  price_avg DECIMAL(12,3) NULL,
  price_max DECIMAL(12,3) NULL,
  reimbursement_rate DECIMAL(6,3) NULL,
  patient_remaining DECIMAL(12,3) NULL,
  source_name VARCHAR(255) NULL,
  source_file VARCHAR(255) NULL,
  source_page VARCHAR(50) NULL,
  source_url VARCHAR(500) NULL,
  effective_date DATE NULL,
  observed_at DATETIME NULL,
  confidence_score DECIMAL(5,2) NULL,
  validation_status ENUM('candidate','validated','rejected','conflict') DEFAULT 'candidate',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_dental_act_price (act_id, country, currency, price_type, source_name),
  KEY idx_dental_act_price_country (country)
);

CREATE TABLE IF NOT EXISTS dental_act_price_conflicts (
  id INT AUTO_INCREMENT PRIMARY KEY,
  act_id INT NULL,
  country VARCHAR(120) NOT NULL,
  price_type VARCHAR(80) NOT NULL,
  current_value VARCHAR(255) NULL,
  candidate_value VARCHAR(255) NULL,
  conflict_reason VARCHAR(255) NOT NULL,
  severity ENUM('info','warning','critical') NOT NULL DEFAULT 'warning',
  status ENUM('pending','accepted','rejected','resolved') NOT NULL DEFAULT 'pending',
  source_name VARCHAR(255) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  resolved_at DATETIME NULL,
  UNIQUE KEY uq_dental_act_price_conflict (act_id, country, price_type, conflict_reason),
  KEY idx_dental_act_price_conflict_status (status)
);

CREATE TABLE IF NOT EXISTS dental_act_price_import_logs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  run_id VARCHAR(80) NOT NULL,
  entity_type VARCHAR(80) NOT NULL,
  operation ENUM('added','updated','unchanged','duplicate','conflict','error','validated','rejected','resolved') NOT NULL,
  entity_id INT NULL,
  label VARCHAR(255) NULL,
  details_json TEXT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  KEY idx_dental_act_import_run (run_id),
  KEY idx_dental_act_import_operation (operation)
);

CREATE TABLE IF NOT EXISTS lab_act_price_references (
  id INT AUTO_INCREMENT PRIMARY KEY,
  act_key VARCHAR(160) NOT NULL,
  act_name VARCHAR(255) NOT NULL,
  country VARCHAR(120) NOT NULL,
  currency VARCHAR(12) NOT NULL,
  price_type ENUM('lab_b2b','clinical_proxy','internal_cost_estimate') NOT NULL DEFAULT 'lab_b2b',
  price_min DECIMAL(12,3) NULL,
  price_avg DECIMAL(12,3) NULL,
  price_max DECIMAL(12,3) NULL,
  price_usd DECIMAL(12,3) NULL,
  source_name VARCHAR(255) NULL,
  source_file VARCHAR(255) NULL,
  source_page VARCHAR(50) NULL,
  confidence_score DECIMAL(5,2) NULL,
  validation_status ENUM('candidate','validated','rejected','conflict') DEFAULT 'candidate',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_lab_act_price_reference (act_key, country, currency, price_type, source_name),
  KEY idx_lab_act_price_country (country)
);

CREATE TABLE IF NOT EXISTS reference_product_candidates (
  id INT AUTO_INCREMENT PRIMARY KEY,
  source_table VARCHAR(80) NOT NULL,
  source_id INT NOT NULL,
  candidate_name VARCHAR(255) NOT NULL,
  category VARCHAR(120) NULL,
  context_type ENUM('LAB','CABINET','BOTH') NOT NULL DEFAULT 'LAB',
  target_product_id INT NULL,
  proposal_json TEXT NULL,
  status ENUM('candidate','validated','rejected','converted','conflict') NOT NULL DEFAULT 'candidate',
  created_by VARCHAR(120) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_reference_product_candidate (source_table, source_id, candidate_name)
);
