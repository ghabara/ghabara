const { buildShoppingList, refreshAiAlerts } = require('./inventoryService');

const NUMBER_WORDS = {
  un: 1,
  une: 1,
  deux: 2,
  trois: 3,
  quatre: 4,
  cinq: 5,
  six: 6,
  sept: 7,
  huit: 8,
  neuf: 9,
  dix: 10,
};

function parseDecimal(value) {
  if (!value) return null;
  const parsed = Number(String(value).replace(',', '.'));
  return Number.isFinite(parsed) ? parsed : null;
}

function normalizeProductText(text, products = []) {
  const input = String(text || '').trim();
  const lower = input.toLowerCase();
  const measurementText = lower.replace(/\b[abcd][1-4](?:[,.]5)?\b/g, ' ');
  const priceMatch = measurementText.match(/(\d+(?:[,.]\d+)?)\s*(?:d|dt|tnd|dinar|dinars)\b/);
  const qtyMatch = measurementText.match(/(\d+(?:[,.]\d+)?)\s*(g|ml|carpules?|unites?|unités?|paires?|sachets?|seringues?|embouts?|cartouches?|blocs?|disques?|boites?|boîtes?)\b/);
  const expMatch = lower.match(/(?:exp|peremption|péremption)\s*(\d{1,2})[\/-](\d{4})|(\d{4})-(\d{2})-(\d{2})/);
  const supplierAlias = extractSupplierAlias(input);
  const lotMatch = lower.match(/(?:lot|n lot|numero lot)\s*[:#-]?\s*([a-z0-9_-]+)/i);

  let expirationDate = null;
  if (expMatch) {
    if (expMatch[1] && expMatch[2]) expirationDate = `${expMatch[2]}-${String(expMatch[1]).padStart(2, '0')}-01`;
    if (expMatch[3] && expMatch[4] && expMatch[5]) expirationDate = `${expMatch[3]}-${expMatch[4]}-${expMatch[5]}`;
  }

  let name = input
    .replace(/\b(?:boite|boÃ®te|boites|boÃ®tes)\s+\d+(?:[,.]\d+)?\s*(?:g|ml|carpules?|unites?|unitÃ©s?|paires?|sachets?|seringues?|embouts?|cartouches?|blocs?|disques?)\b/gi, '')
    .replace(/\b\d+(?:[,.]\d+)?\s*(?:g|ml|carpules?|unites?|unitÃ©s?|paires?|sachets?|seringues?|embouts?|cartouches?|blocs?|disques?|boites?|boÃ®tes?)\b/gi, '')
    .replace(/(\d+(?:[,.]\d+)?)\s*(?:d|dt|tnd|dinar|dinars)\b/gi, '')
    .replace(/(?:exp|peremption|péremption)\s*\d{1,2}[\/-]\d{4}/gi, '')
    .replace(/fournisseur\s+.+?(?=\s+(?:exp|peremption|pÃ©remption|lot|n lot|numero lot|\d+(?:[,.]\d+)?\s*(?:d|dt|tnd|dinar|dinars|g|ml))\b|$)/gi, '')
    .replace(/(?:lot|n lot|numero lot)\s*[:#-]?\s*[a-z0-9_-]+/gi, '')
    .replace(/\s+/g, ' ')
    .trim();
  if (!name) name = input;

  const category = guessCategory(name);
  const duplicateCandidates = products
    .filter(product => similarityToken(product.name, name) >= 0.35)
    .slice(0, 5)
    .map(product => ({ id: product.id, name: product.name, tracking_unit: product.tracking_unit }));

  const warnings = [];
  if (!priceMatch) warnings.push('Prix non detecte.');
  if (!qtyMatch) warnings.push('Conditionnement non detecte.');
  if (duplicateCandidates.length) warnings.push('Produits similaires detectes.');

  return {
    name,
    category,
    tracking_unit: normalizeDetectedUnit(qtyMatch?.[2]) || 'unite',
    package_quantity: parseDecimal(qtyMatch?.[1]),
    package_unit: normalizeDetectedUnit(qtyMatch?.[2]) || null,
    package_price_tnd: parseDecimal(priceMatch?.[1]),
    supplier_alias: supplierAlias,
    expiration_date: expirationDate,
    lot_number: lotMatch ? lotMatch[1].trim() : null,
    warnings,
    duplicate_candidates: duplicateCandidates,
  };
}

function extractSupplierAlias(text) {
  const match = String(text || '').match(/fournisseur\s+(.+?)(?=\s+(?:exp|peremption|pÃ©remption|lot|n lot|numero lot|\d+(?:[,.]\d+)?\s*(?:d|dt|tnd|dinar|dinars|g|ml))\b|$)/i);
  return match ? match[1].trim() : null;
}

function normalizeDetectedUnit(unit) {
  if (!unit) return null;
  const clean = unit.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  if (clean.startsWith('unite')) return 'unite';
  if (clean.startsWith('boite')) return 'boite';
  if (clean.endsWith('s')) return clean.slice(0, -1);
  return clean;
}

function guessCategory(name) {
  const lower = String(name || '').toLowerCase();
  if (/composite|resine|adhesif|bonding|acide/.test(lower)) return 'Restauratrice';
  if (/anesth|carpule|aiguille/.test(lower)) return 'Anesthesie';
  if (/endo|gutta|papier|granulo/.test(lower)) return 'Endodontie';
  if (/gant|microbrush|embout|compresse/.test(lower)) return 'Usage unique';
  if (/ciment|scellement|couronne/.test(lower)) return 'Collage / prothese';
  return 'A classer';
}

function similarityToken(a, b) {
  const aTokens = new Set(String(a || '').toLowerCase().split(/\W+/).filter(Boolean));
  const bTokens = new Set(String(b || '').toLowerCase().split(/\W+/).filter(Boolean));
  if (!aTokens.size || !bTokens.size) return 0;
  let intersection = 0;
  for (const token of aTokens) if (bTokens.has(token)) intersection += 1;
  return intersection / Math.max(aTokens.size, bTokens.size);
}

function suggestRecipe({ act_name, clinical_variant, products = [] }) {
  const label = `${act_name || ''} ${clinical_variant || ''}`.toLowerCase();
  let templates = [];
  if (/composite/.test(label)) {
    templates = [
      ['composite', 0.4, 'g', 'bonne', 'Matrice restauratrice principale.'],
      ['acide', 0.1, 'g', 'moyenne', 'Mordancage.'],
      ['adhesif|bonding', 0.019, 'g', 'moyenne', 'Adhesion.'],
      ['microbrush', 1, 'unite', 'bonne', 'Application.'],
    ];
    if (/classe\s*ii|class\s*ii/.test(label)) templates.push(['matrice|coin', 1, 'unite', 'faible', 'Variante classe II.']);
  } else if (/extraction/.test(label)) {
    templates = [
      ['anesth|carpule', 1.1, 'carpule', 'moyenne', 'Anesthesie locale.'],
      ['aiguille', 1, 'unite', 'moyenne', 'Injection.'],
      ['compresse', 2, 'unite', 'faible', 'Hemostase.'],
      ['gant', 1, 'paire', 'bonne', 'Protection.'],
    ];
  } else if (/endo/.test(label)) {
    templates = [
      ['anesth|carpule', 1.2, 'carpule', 'moyenne', 'Anesthesie.'],
      ['papier', 3, 'unite', 'faible', 'Sechage canalaire.'],
      ['gutta', 2, 'unite', 'faible', 'Obturation.'],
    ];
  } else if (/collage|couronne|scellement/.test(label)) {
    templates = [
      ['acide', 0.1, 'g', 'faible', 'Preparation.'],
      ['adhesif|bonding', 0.019, 'g', 'faible', 'Adhesion.'],
      ['ciment', 0.3, 'g', 'faible', 'Scellement.'],
      ['microbrush', 1, 'unite', 'moyenne', 'Application.'],
      ['embout', 1, 'unite', 'moyenne', 'Embout automix si utilise.'],
    ];
  }

  if (!templates.length) {
    return {
      suggestions: [],
      missing_products: [],
      note: 'Aucun gabarit local fiable pour cet acte. Creer une recette manuelle puis laisser la moyenne se recalculer.',
    };
  }

  const suggestions = [];
  const missingProducts = [];
  for (const [pattern, quantity, unit, confidence, justification] of templates) {
    const regex = new RegExp(pattern, 'i');
    const product = products.find(item => regex.test(item.name));
    if (product) {
      suggestions.push({
        product_id: product.id,
        product_name: product.name,
        quantity_per_act: quantity,
        unit,
        confidence,
        justification,
      });
    } else {
      missingProducts.push({
        label: pattern.split('|')[0],
        quantity_per_act: quantity,
        unit,
        justification,
      });
    }
  }
  return { suggestions, missing_products: missingProducts, note: 'Proposition a valider par le praticien avant enregistrement.' };
}

function parseNaturalCommand(text, acts = []) {
  const input = String(text || '').toLowerCase();
  const detectedDate = detectDate(input);
  const detectedActs = [];
  for (const act of acts) {
    const aliases = buildActAliases(act.name);
    for (const alias of aliases) {
      const regex = new RegExp(`(?:(\\d+|${Object.keys(NUMBER_WORDS).join('|')})\\s+)?${alias}s?\\b`, 'i');
      const match = input.match(regex);
      if (match) {
        detectedActs.push({
          act_id: act.id,
          name: act.name,
          clinical_variant: act.clinical_variant,
          quantity: parseQuantity(match[1]) || 1,
        });
        break;
      }
    }
  }
  return {
    detected_date: detectedDate,
    detected_acts: detectedActs,
    ambiguities: detectedActs.length ? [] : ['Aucun acte reconnu avec le catalogue actuel.'],
    summary: detectedActs.length
      ? detectedActs.map(item => `${item.quantity} x ${item.name}`).join(', ')
      : 'Aucune action proposee.',
    requires_validation: true,
  };
}

function buildActAliases(name) {
  const lower = String(name || '').toLowerCase();
  const aliases = [lower.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')];
  if (lower.includes('composite')) aliases.push('composite');
  if (lower.includes('extraction')) aliases.push('extraction');
  if (lower.includes('endo')) aliases.push('endo', 'endodontie');
  if (lower.includes('collage')) aliases.push('collage couronne', 'collage');
  if (lower.includes('reconstitution')) aliases.push('reconstitution');
  if (lower.includes('detartrage') || lower.includes('détartrage')) aliases.push('detartrage', 'détartrage');
  return [...new Set(aliases)];
}

function parseQuantity(value) {
  if (!value) return null;
  if (NUMBER_WORDS[value]) return NUMBER_WORDS[value];
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}

function detectDate(text) {
  const today = new Date();
  const date = new Date(today);
  if (/hier/.test(text)) date.setDate(date.getDate() - 1);
  if (/demain/.test(text)) date.setDate(date.getDate() + 1);
  const iso = text.match(/\b(20\d{2})-(\d{2})-(\d{2})\b/);
  if (iso) return iso[0];
  return date.toISOString().slice(0, 10);
}

async function detectAnomalies(pool) {
  const generated = await refreshAiAlerts(pool);
  const [overRows] = await pool.query(`
    SELECT cl.*, p.name AS product_name, a.name AS act_name, r.quantity_per_act
    FROM consumption_logs cl
    JOIN inventory_products p ON p.id = cl.product_id
    JOIN clinical_acts a ON a.id = cl.act_id
    LEFT JOIN act_recipes r ON r.act_id = cl.act_id AND r.product_id = cl.product_id
    WHERE cl.created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
      AND r.quantity_per_act IS NOT NULL
      AND cl.quantity > r.quantity_per_act * 1.5
    ORDER BY cl.created_at DESC
    LIMIT 30
  `);
  return {
    generated_alerts: generated,
    overconsumption: overRows.map(row => ({
      type: 'OVERCONSUMPTION',
      product_name: row.product_name,
      act_name: row.act_name,
      quantity: row.quantity,
      expected: row.quantity_per_act,
      message: `${row.product_name}: consommation superieure a 150% de la moyenne pour ${row.act_name}.`,
    })),
  };
}

async function buildForecast(pool) {
  const suggestions = await buildShoppingList(pool);
  return suggestions.map(item => ({
    product_id: item.product_id,
    product_name: item.product_name,
    consumption_30d: item.used_30d,
    average_per_day: item.avg_per_day_30d,
    days_remaining: item.days_before_break,
    probable_break_date: item.days_before_break === null ? null : futureDate(item.days_before_break),
    purchase_priority: item.priority,
    recommended_quantity: item.recommended_quantity,
    unit: item.tracking_unit,
  }));
}

function futureDate(days) {
  const date = new Date();
  date.setDate(date.getDate() + Math.ceil(days));
  return date.toISOString().slice(0, 10);
}

module.exports = {
  normalizeProductText,
  suggestRecipe,
  parseNaturalCommand,
  detectAnomalies,
  buildForecast,
};
