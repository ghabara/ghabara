# Modifications Stock AI

Le module stock historique est conserve seulement en compatibilite interne. L'interface principale expose maintenant `Stock AI`.

## Changements principaux

- Catalogue produits enrichi : conditionnement, prix, fournisseur, lot, peremption, seuil minimum.
- Recettes par acte : consommables et quantites par soin.
- Actes realises : deduction automatique du stock apres validation.
- Achats : reception, mouvements et mise a jour des couts.
- Alertes : stock bas, peremption proche, prix manquant, recettes incompletes.
- Assistant local : brouillons et suggestions avec validation humaine.

## Fichiers utiles

- `database/dentaloff_ai.sql`
- `database/stock_ai_migration.sql`
- `database/stock_ai_demo_seed.sql`
- `server/routes/inventory.js`
- `server/routes/performedActs.js`
- `server/services/aiService.js`
- `client/src/pages/StockAi.jsx`
