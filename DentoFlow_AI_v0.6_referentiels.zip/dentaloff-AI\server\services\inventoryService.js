const GENERATED_ALERT_TYPES = [
  'LOW_STOCK',
  'EXPIRATION_SOON',
  'MISSING_PRICE',
  'UNIT_MISMATCH',
  'RECIPE_INCOMPLETE',
  'STOCK_NEGATIVE',
  'OVERSTOCK',
  'LOT_EXPIRATION',
  'LOT_EXPIRED',
];

function decimalOrNull(value) {
  if (value === null || value === undefined || value === '') return null;
  const normalized = String(value).replace(',', '.').trim();
  if (!normalized) return null;
  const parsed = Number(normalized);
  return Number.isFinite(parsed) ? parsed : null;
}

function normalizeUnit(unit) {
  const raw = String(unit || '').trim().toLowerCase();
  const folded = raw.normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  const map = {
    unite: 'unite',
    unites: 'unite',
    piece: 'unite',
    pieces: 'unite',
    paire: 'paire',
    paires: 'paire',
    carpule: 'carpule',
    carpules: 'carpule',
    capsule: 'capsule',
    capsules: 'capsule',
    sachet: 'sachet',
    sachets: 'sachet',
    seringue: 'seringue',
    seringues: 'seringue',
    embout: 'embout',
    embouts: 'embout',
    cartouche: 'cartouche',
    cartouches: 'cartouche',
    bloc: 'bloc',
    blocs: 'bloc',
    disque: 'disque',
    disques: 'disque',
    boite: 'boite',
    boites: 'boite',
    gramme: 'g',
    grammes: 'g',
    millilitre: 'ml',
    millilitres: 'ml',
  };
  return map[folded] || folded;
}

function unitsMatch(recipeUnit, productUnit) {
  return normalizeUnit(recipeUnit) === normalizeUnit(productUnit);
}

function calculateUnitCost(product) {
  const price = decimalOrNull(product?.package_price_tnd);
  const qty = decimalOrNull(product?.package_quantity);
  if (price === null || qty === null || qty <= 0) return null;
  return price / qty;
}

function calculateRecipeLineCost(product, quantity, recipeUnit) {
  const qty = decimalOrNull(quantity);
  if (qty === null || qty < 0) {
    return { cost: null, code: 'INVALID_QUANTITY', message: 'Quantite invalide.' };
  }
  if (!unitsMatch(recipeUnit, product?.tracking_unit)) {
    return {
      cost: null,
      code: 'UNIT_MISMATCH',
      message: `Unite recette (${recipeUnit}) differente de l'unite produit (${product?.tracking_unit || '-'})`,
    };
  }
  const unitCost = calculateUnitCost(product);
  if (unitCost === null) {
    return { cost: null, code: 'MISSING_PRICE', message: 'Prix ou conditionnement manquant.' };
  }
  return { cost: qty * unitCost, code: null, message: null };
}

function expirationStatus(dateValue) {
  if (!dateValue) return null;
  const date = new Date(dateValue);
  if (Number.isNaN(date.getTime())) return null;
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const expiry = new Date(date);
  expiry.setHours(0, 0, 0, 0);
  if (expiry < today) return 'EXPIRED';
  const soon = new Date(today);
  soon.setDate(soon.getDate() + 30);
  return expiry <= soon ? 'SOON' : null;
}

function confidenceWeight(value) {
  const normalized = String(value || '').toLowerCase();
  if (['bonne', 'good', 'haute', 'high'].includes(normalized)) return 1;
  if (['moyenne', 'medium'].includes(normalized)) return 0.65;
  if (['faible', 'low'].includes(normalized)) return 0.35;
  return 0.5;
}

async function withTransaction(pool, fn) {
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    const result = await fn(conn);
    await conn.commit();
    return result;
  } catch (error) {
    await conn.rollback();
    throw error;
  } finally {
    conn.release();
  }
}

async function fetchRecipeRows(db, actId, { forUpdate = false } = {}) {
  const lock = forUpdate ? ' FOR UPDATE' : '';
  const [rows] = await db.query(
    `SELECT r.*,
            a.name AS act_name,
            a.clinical_variant,
            a.category AS act_category,
            p.name AS product_name,
            p.category AS product_category,
            p.sub_category,
            p.tracking_unit,
            p.package_quantity,
            p.package_unit,
            p.package_price_tnd,
            p.current_stock,
            p.min_stock,
            p.supplier_alias,
            p.expiration_date,
            p.lot_number,
            p.is_active
     FROM act_recipes r
     JOIN clinical_acts a ON a.id = r.act_id
     JOIN inventory_products p ON p.id = r.product_id
     WHERE r.act_id = ? AND p.is_active = 1
     ORDER BY r.recipe_variant, p.name${lock}`,
    [actId]
  );
  return rows;
}

function summarizeRecipeRows(rows) {
  let partialCost = 0;
  let unknownCostCount = 0;
  let possibleRaw = null;
  let possibleUnknown = false;
  let limitingProduct = null;
  const missing = [];
  const warnings = [];
  const costBlockers = [];
  const lineItems = [];
  let confidenceTotal = 0;

  for (const row of rows) {
    const qty = decimalOrNull(row.quantity_per_act) ?? 0;
    const unitOk = unitsMatch(row.unit, row.tracking_unit);
    const line = calculateRecipeLineCost(row, qty, row.unit);
    const currentStock = decimalOrNull(row.current_stock);
    const minStock = decimalOrNull(row.min_stock);
    confidenceTotal += confidenceWeight(row.confidence);

    if (line.cost === null) {
      unknownCostCount += 1;
      costBlockers.push(`${row.product_name}: ${line.message}`);
    } else {
      partialCost += line.cost;
    }

    if (!unitOk) {
      warnings.push(`${row.product_name}: unite incoherente`);
      possibleUnknown = true;
    } else if (currentStock === null) {
      missing.push(`${row.product_name}: stock a completer`);
      possibleUnknown = true;
    } else if (qty > 0) {
      const possibleForProduct = currentStock / qty;
      if (possibleRaw === null || possibleForProduct < possibleRaw) {
        possibleRaw = possibleForProduct;
        limitingProduct = row.product_name;
      }
      if (currentStock < qty) missing.push(`${row.product_name}: stock insuffisant`);
    } else {
      possibleUnknown = true;
      warnings.push(`${row.product_name}: consommation moyenne a completer`);
    }

    if (currentStock !== null && minStock !== null && currentStock <= minStock) {
      warnings.push(`${row.product_name}: stock bas`);
    }

    const expiry = expirationStatus(row.expiration_date);
    if (expiry === 'EXPIRED') warnings.push(`${row.product_name}: perime`);
    if (expiry === 'SOON') warnings.push(`${row.product_name}: peremption proche`);

    lineItems.push({
      recipe_id: row.id,
      product_id: row.product_id,
      product_name: row.product_name,
      quantity_per_act: qty,
      unit: row.unit,
      tracking_unit: row.tracking_unit,
      unit_cost_tnd: calculateUnitCost(row),
      line_cost_tnd: line.cost,
      issue_code: line.code,
      current_stock: currentStock,
      possible_for_product: unitOk && currentStock !== null && qty > 0 ? Math.floor(currentStock / qty) : null,
    });
  }

  return {
    total_cost_tnd: unknownCostCount > 0 ? null : partialCost,
    partial_cost_tnd: partialCost,
    unknown_cost_count: unknownCostCount,
    cost_blockers: [...new Set(costBlockers)],
    possible_raw: possibleUnknown ? null : possibleRaw,
    possible_floor: possibleUnknown || possibleRaw === null ? null : Math.max(0, Math.floor(possibleRaw)),
    limiting_product: possibleUnknown ? null : limitingProduct,
    missing: [...new Set(missing)],
    warnings: [...new Set(warnings)],
    reliability_score: rows.length ? Number((confidenceTotal / rows.length).toFixed(2)) : 0,
    lines: lineItems,
  };
}

async function calculateActCost(db, actId) {
  const rows = await fetchRecipeRows(db, actId);
  return summarizeRecipeRows(rows);
}

async function recordInventoryMovement(conn, movement) {
  await conn.query(
    `INSERT INTO inventory_movements
       (product_id, product_name_snapshot, quantity, unit, direction, origin, origin_id,
        stock_before, stock_after, created_by)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      movement.product_id,
      movement.product_name_snapshot,
      movement.quantity,
      movement.unit,
      movement.direction,
      movement.origin,
      movement.origin_id ?? null,
      movement.stock_before ?? null,
      movement.stock_after ?? null,
      movement.created_by ?? null,
    ]
  );
}

async function insertAiAlert(db, alert) {
  await db.query(
    `INSERT INTO ai_alerts
       (type, severity, entity_type, entity_id, message, recommendation, status)
     VALUES (?, ?, ?, ?, ?, ?, 'OPEN')`,
    [
      alert.type,
      alert.severity || 'INFO',
      alert.entity_type,
      alert.entity_id ?? null,
      alert.message,
      alert.recommendation || null,
    ]
  );
}

async function refreshAiAlerts(db) {
  const alerts = [];
  const [products] = await db.query('SELECT * FROM inventory_products WHERE is_active = 1');
  for (const product of products) {
    const stock = decimalOrNull(product.current_stock);
    const min = decimalOrNull(product.min_stock);
    if (stock !== null && stock < 0) {
      alerts.push({
        type: 'STOCK_NEGATIVE',
        severity: 'CRITICAL',
        entity_type: 'inventory_product',
        entity_id: product.id,
        message: `${product.name}: stock negatif (${stock}).`,
        recommendation: 'Verifier le journal et enregistrer une correction tracee.',
      });
    }
    if (stock !== null && min !== null && stock <= min) {
      alerts.push({
        type: 'LOW_STOCK',
        severity: stock <= 0 ? 'CRITICAL' : 'WARNING',
        entity_type: 'inventory_product',
        entity_id: product.id,
        message: `${product.name}: stock bas (${stock} ${product.tracking_unit}, seuil ${min}).`,
        recommendation: 'Prevoir un achat ou verifier la consommation recente.',
      });
    }
    if (calculateUnitCost(product) === null) {
      const hasReferenceCandidate = product.reference_price_tnd_avg && product.price_validation_status === 'candidate';
      alerts.push({
        type: 'MISSING_PRICE',
        severity: 'INFO',
        entity_type: 'inventory_product',
        entity_id: product.id,
        message: hasReferenceCandidate
          ? `${product.name}: prix reel manquant, prix indicatif disponible a valider.`
          : `${product.name}: prix reel ou quantite de conditionnement manquant.`,
        recommendation: hasReferenceCandidate
          ? 'Verifier la source indicative puis valider le prix comme prix d achat si conforme.'
          : 'Completer la fiche pour calculer le cout matiere.',
      });
    }
    const expiry = expirationStatus(product.expiration_date);
    if (expiry) {
      alerts.push({
        type: 'EXPIRATION_SOON',
        severity: expiry === 'EXPIRED' ? 'CRITICAL' : 'WARNING',
        entity_type: 'inventory_product',
        entity_id: product.id,
        message: `${product.name}: ${expiry === 'EXPIRED' ? 'produit perime' : 'peremption proche'}.`,
        recommendation: expiry === 'EXPIRED' ? 'Isoler le lot avant tout usage.' : 'Consommer prudemment avant de racheter massivement.',
      });
    }

    const max = decimalOrNull(product.max_stock);
    if (stock !== null && max !== null && max > 0 && stock > max) {
      alerts.push({
        type: 'OVERSTOCK',
        severity: 'INFO',
        entity_type: 'inventory_product',
        entity_id: product.id,
        message: `${product.name}: stock superieur au maximum (${stock}/${max}).`,
        recommendation: 'Verifier le rythme de consommation avant nouvel achat.',
      });
    }
  }

  const [lotRows] = await db.query(
    `SELECT l.*, p.name AS product_name
     FROM inventory_lots l
     JOIN inventory_products p ON p.id = l.product_id
     WHERE l.status IN ('ACTIVE','QUARANTINE') AND p.is_active = 1`
  );
  for (const lot of lotRows) {
    const expiry = expirationStatus(lot.expiration_date);
    if (expiry) {
      alerts.push({
        type: expiry === 'EXPIRED' ? 'LOT_EXPIRED' : 'LOT_EXPIRATION',
        severity: expiry === 'EXPIRED' ? 'CRITICAL' : 'WARNING',
        entity_type: 'inventory_lot',
        entity_id: lot.id,
        message: `${lot.product_name} lot ${lot.lot_number}: ${expiry === 'EXPIRED' ? 'lot perime' : 'peremption proche'}.`,
        recommendation: expiry === 'EXPIRED' ? 'Mettre le lot en quarantaine ou le marquer jete.' : 'Appliquer FEFO: utiliser ce lot avant les lots plus recents.',
      });
    }
  }

  const [unitRows] = await db.query(
    `SELECT r.id, r.unit, p.tracking_unit, p.name AS product_name, a.name AS act_name
     FROM act_recipes r
     JOIN inventory_products p ON p.id = r.product_id
     JOIN clinical_acts a ON a.id = r.act_id
     WHERE p.is_active = 1`
  );
  for (const row of unitRows) {
    if (!unitsMatch(row.unit, row.tracking_unit)) {
      alerts.push({
        type: 'UNIT_MISMATCH',
        severity: 'WARNING',
        entity_type: 'act_recipe',
        entity_id: row.id,
        message: `${row.act_name} / ${row.product_name}: recette en ${row.unit}, produit en ${row.tracking_unit}.`,
        recommendation: 'Corriger la recette ou creer une conversion validee.',
      });
    }
  }

  const [emptyActs] = await db.query(
    `SELECT a.id, a.name, a.clinical_variant
     FROM clinical_acts a
     LEFT JOIN act_recipes r ON r.act_id = a.id
     WHERE a.is_active = 1
     GROUP BY a.id
     HAVING COUNT(r.id) = 0`
  );
  for (const act of emptyActs) {
    alerts.push({
      type: 'RECIPE_INCOMPLETE',
      severity: 'INFO',
      entity_type: 'clinical_act',
      entity_id: act.id,
      message: `${act.name} (${act.clinical_variant || 'Standard'}): aucune recette.`,
      recommendation: 'Ajouter les consommables moyens avant de calculer le cout.',
    });
  }

  const [openRows] = await db.query(
    `SELECT id, type, entity_type, entity_id, message
     FROM ai_alerts
     WHERE status = 'OPEN' AND type IN (${GENERATED_ALERT_TYPES.map(() => '?').join(',')})`,
    GENERATED_ALERT_TYPES
  );
  const currentKeys = new Set(alerts.map(alertKey));
  const openKeys = new Set(openRows.map(alertKey));

  for (const row of openRows) {
    if (!currentKeys.has(alertKey(row))) {
      await db.query('UPDATE ai_alerts SET status = ?, resolved_at = NOW() WHERE id = ?', ['RESOLVED', row.id]);
    }
  }

  for (const alert of alerts) {
    if (!openKeys.has(alertKey(alert))) {
      await insertAiAlert(db, alert);
    }
  }
  return alerts;
}

function alertKey(alert) {
  return [
    alert.type,
    alert.entity_type || '',
    alert.entity_id === null || alert.entity_id === undefined ? '' : alert.entity_id,
    alert.message || '',
  ].join('|');
}

async function buildShoppingList(db) {
  const [products] = await db.query('SELECT * FROM inventory_products WHERE is_active = 1 ORDER BY name');
  const [consumption] = await db.query(
    `SELECT product_id,
            SUM(CASE WHEN log_date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY) THEN quantity ELSE 0 END) AS used_7d,
            SUM(CASE WHEN log_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY) THEN quantity ELSE 0 END) AS used_30d
     FROM consumption_logs
     WHERE log_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
     GROUP BY product_id`
  );
  const [frequentRows] = await db.query(
    `SELECT r.product_id, COUNT(pa.id) AS act_count
     FROM performed_acts pa
     JOIN act_recipes r ON r.act_id = pa.act_id
     WHERE pa.performed_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
     GROUP BY r.product_id`
  );
  const consumptionByProduct = new Map(consumption.map(row => [row.product_id, row]));
  const frequentByProduct = new Map(frequentRows.map(row => [row.product_id, Number(row.act_count || 0)]));

  const suggestions = [];
  for (const product of products) {
    const stock = decimalOrNull(product.current_stock) ?? 0;
    const min = decimalOrNull(product.min_stock) ?? 0;
    const stats = consumptionByProduct.get(product.id) || {};
    const used30 = decimalOrNull(stats.used_30d) ?? 0;
    const avgPerDay = used30 / 30;
    const daysBeforeBreak = avgPerDay > 0 ? stock / avgPerDay : null;
    const usedInFrequentAct = (frequentByProduct.get(product.id) || 0) >= 3;
    const expiry = expirationStatus(product.expiration_date);
    const missingPrice = calculateUnitCost(product) === null;
    let priority = 0;
    const reasons = [];

    if (stock <= min) {
      priority += 50;
      reasons.push('stock sous seuil');
    }
    if (daysBeforeBreak !== null && daysBeforeBreak < 7) {
      priority += 40;
      reasons.push('rupture estimee < 7 jours');
    } else if (daysBeforeBreak !== null && daysBeforeBreak < 15) {
      priority += 30;
      reasons.push('rupture estimee < 15 jours');
    }
    if (usedInFrequentAct) {
      priority += 20;
      reasons.push('utilise dans des actes frequents');
    }
    if (product.supplier_lead_days && Number(product.supplier_lead_days) >= 7) {
      priority += 15;
      reasons.push('delai fournisseur long');
    }
    if (missingPrice) {
      priority += 10;
      reasons.push('prix a completer');
    }
    if (expiry) reasons.push(expiry === 'EXPIRED' ? 'produit perime' : 'peremption proche');

    const target = avgPerDay > 0 ? Math.max(min * 2, avgPerDay * 30) : min * 2;
    let recommended = Math.max(0, target - stock);
    if (expiry === 'SOON') recommended = Math.min(recommended, Math.max(0, min - stock));
    if (priority > 0 || recommended > 0 || expiry) {
      suggestions.push({
        product_id: product.id,
        product_name: product.name,
        category: product.category,
        tracking_unit: product.tracking_unit,
        current_stock: stock,
        min_stock: min,
        used_30d: used30,
        avg_per_day_30d: Number(avgPerDay.toFixed(4)),
        days_before_break: daysBeforeBreak === null ? null : Number(daysBeforeBreak.toFixed(1)),
        expiration_status: expiry,
        missing_price: missingPrice,
        priority,
        recommended_quantity: Number(recommended.toFixed(4)),
        reason: reasons.join(', ') || 'surveillance',
        justification: buildShoppingJustification(product, stock, min, avgPerDay, daysBeforeBreak, reasons),
      });
    }
  }
  return suggestions.sort((a, b) => b.priority - a.priority || a.product_name.localeCompare(b.product_name));
}

function buildShoppingJustification(product, stock, min, avgPerDay, daysBeforeBreak, reasons) {
  const parts = [`Stock ${stock} ${product.tracking_unit}, seuil ${min}.`];
  if (avgPerDay > 0) parts.push(`Consommation moyenne 30j: ${avgPerDay.toFixed(3)} ${product.tracking_unit}/jour.`);
  if (daysBeforeBreak !== null) parts.push(`Rupture estimee dans ${daysBeforeBreak.toFixed(1)} jours.`);
  if (reasons.length) parts.push(`Motifs: ${reasons.join(', ')}.`);
  return parts.join(' ');
}

async function buildInventoryInsights(db) {
  const [products] = await db.query('SELECT * FROM inventory_products WHERE is_active = 1 ORDER BY name');
  const [consumption] = await db.query(
    `SELECT product_id,
            SUM(CASE WHEN log_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY) THEN quantity ELSE 0 END) AS used_30d,
            SUM(CASE WHEN log_date >= DATE_SUB(CURDATE(), INTERVAL 90 DAY) THEN quantity ELSE 0 END) AS used_90d
     FROM consumption_logs
     WHERE log_date >= DATE_SUB(CURDATE(), INTERVAL 90 DAY)
     GROUP BY product_id`
  );
  const [lots] = await db.query(
    `SELECT product_id,
            COUNT(*) AS lot_count,
            MIN(expiration_date) AS next_expiration,
            SUM(CASE WHEN expiration_date IS NOT NULL AND expiration_date <= DATE_ADD(CURDATE(), INTERVAL 30 DAY) THEN quantity_current ELSE 0 END) AS qty_expiring_30d,
            SUM(CASE WHEN expiration_date IS NOT NULL AND expiration_date <= DATE_ADD(CURDATE(), INTERVAL 90 DAY) THEN quantity_current ELSE 0 END) AS qty_expiring_90d
     FROM inventory_lots
     WHERE status IN ('ACTIVE','QUARANTINE')
     GROUP BY product_id`
  );
  const cMap = new Map(consumption.map(row => [row.product_id, row]));
  const lMap = new Map(lots.map(row => [row.product_id, row]));

  const rows = products.map(product => {
    const c = cMap.get(product.id) || {};
    const lot = lMap.get(product.id) || {};
    const stock = decimalOrNull(product.current_stock) ?? 0;
    const reserved = decimalOrNull(product.reserved_stock) ?? 0;
    const min = decimalOrNull(product.min_stock) ?? 0;
    const max = decimalOrNull(product.max_stock);
    const usableStock = Math.max(0, stock - reserved);
    const used30 = decimalOrNull(c.used_30d) ?? 0;
    const used90 = decimalOrNull(c.used_90d) ?? 0;
    const avg30 = used30 / 30;
    const avg90 = used90 / 90;
    const avg = avg30 > 0 ? avg30 : avg90;
    const coverageDays = avg > 0 ? usableStock / avg : null;
    const expiry = expirationStatus(lot.next_expiration || product.expiration_date);
    let risk = 0;
    const reasons = [];

    if (usableStock <= 0) { risk += 45; reasons.push('rupture ou stock reserve'); }
    else if (usableStock <= min) { risk += 35; reasons.push('sous seuil minimum'); }
    if (coverageDays !== null && coverageDays < 7) { risk += 35; reasons.push('couverture < 7 jours'); }
    else if (coverageDays !== null && coverageDays < 30) { risk += 20; reasons.push('couverture < 30 jours'); }
    if (expiry === 'EXPIRED') { risk += 45; reasons.push('peremption depassee'); }
    else if (expiry === 'SOON') { risk += 25; reasons.push('peremption proche'); }
    if (max !== null && max > 0 && stock > max) { risk += 10; reasons.push('surstock'); }
    if (calculateUnitCost(product) === null) { risk += 8; reasons.push('cout incomplet'); }

    const unitCost = calculateUnitCost(product);
    const target = avg > 0 ? Math.max(min * 2, avg * 30) : min * 2;
    const recommended = Math.max(0, target - usableStock);
    const recommendedValue = unitCost === null ? null : recommended * unitCost;

    return {
      product_id: product.id,
      product_name: product.name,
      category: product.category,
      unit: product.tracking_unit,
      unit_cost_tnd: unitCost,
      stock,
      reserved_stock: reserved,
      usable_stock: usableStock,
      min_stock: min,
      max_stock: max,
      used_30d: used30,
      used_90d: used90,
      avg_per_day: Number(avg.toFixed(4)),
      coverage_days: coverageDays === null ? null : Number(coverageDays.toFixed(1)),
      next_expiration: lot.next_expiration || product.expiration_date || null,
      qty_expiring_30d: decimalOrNull(lot.qty_expiring_30d) ?? 0,
      qty_expiring_90d: decimalOrNull(lot.qty_expiring_90d) ?? 0,
      lot_count: Number(lot.lot_count || 0),
      risk_score: Math.min(100, risk),
      recommended_quantity: Number(recommended.toFixed(4)),
      recommended_value_tnd: recommendedValue === null ? null : Number(recommendedValue.toFixed(3)),
      reasons: reasons.length ? reasons : ['surveillance simple'],
      recommendation: buildInsightRecommendation(product, coverageDays, recommended, reasons),
    };
  });

  const critical = rows.filter(row => row.risk_score >= 70).length;
  const warning = rows.filter(row => row.risk_score >= 35 && row.risk_score < 70).length;
  const totalValue = products.reduce((sum, product) => {
    const cost = calculateUnitCost(product);
    const stock = decimalOrNull(product.current_stock) ?? 0;
    return cost === null ? sum : sum + cost * stock;
  }, 0);
  const productsToBuy = rows.filter(row => row.recommended_quantity > 0);
  const estimatedPurchaseValue = productsToBuy.reduce((sum, row) => {
    return row.recommended_value_tnd === null ? sum : sum + row.recommended_value_tnd;
  }, 0);
  const coverageRows = rows.filter(row => row.coverage_days !== null);
  const avgCoverage = coverageRows.length
    ? coverageRows.reduce((sum, row) => sum + row.coverage_days, 0) / coverageRows.length
    : null;

  return {
    generated_at: new Date().toISOString(),
    provider: 'local-rules-statistical-scoring',
    requires_validation: true,
    summary: {
      product_count: rows.length,
      critical_count: critical,
      warning_count: warning,
      estimated_stock_value_tnd: Number(totalValue.toFixed(3)),
      products_to_buy_count: productsToBuy.length,
      estimated_purchase_value_tnd: Number(estimatedPurchaseValue.toFixed(3)),
      avg_coverage_days: avgCoverage === null ? null : Number(avgCoverage.toFixed(1)),
      expiring_90d_count: rows.filter(row => Number(row.qty_expiring_90d || 0) > 0).length,
      stockout_risk_count: rows.filter(row => row.coverage_days !== null && row.coverage_days < 15).length,
    },
    products: rows.sort((a, b) => b.risk_score - a.risk_score || a.product_name.localeCompare(b.product_name)),
  };
}

function buildInsightRecommendation(product, coverageDays, recommended, reasons) {
  if (reasons.includes('peremption depassee')) return 'Isoler le lot et enregistrer une sortie peremption avant tout usage.';
  if (recommended > 0) return `Prevoir environ ${recommended.toFixed(2)} ${product.tracking_unit} et verifier le fournisseur.`;
  if (coverageDays !== null && coverageDays > 60) return 'Surveiller le surstock et eviter un achat inutile.';
  return 'Pas d achat urgent; garder la validation humaine avant decision.';
}

module.exports = {
  decimalOrNull,
  normalizeUnit,
  unitsMatch,
  calculateUnitCost,
  calculateRecipeLineCost,
  calculateActCost,
  expirationStatus,
  fetchRecipeRows,
  summarizeRecipeRows,
  withTransaction,
  recordInventoryMovement,
  refreshAiAlerts,
  buildShoppingList,
  buildInventoryInsights,
};
