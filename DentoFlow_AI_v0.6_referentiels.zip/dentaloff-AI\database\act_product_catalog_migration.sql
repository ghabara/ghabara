USE dentaloff_ai;

CREATE TABLE IF NOT EXISTS dental_act_catalog (
  id INT AUTO_INCREMENT PRIMARY KEY,
  act_key VARCHAR(160) NOT NULL,
  act_name VARCHAR(255) NOT NULL,
  family VARCHAR(120) NOT NULL,
  subfamily VARCHAR(160) NULL,
  clinical_context TEXT NULL,
  nomenclature_status ENUM('standard','cnam_tn_known','modern_out_of_nomenclature','lab_linked','to_map') NOT NULL DEFAULT 'to_map',
  modernity_status ENUM('standard','modern','specialized') NOT NULL DEFAULT 'standard',
  context_type ENUM('CABINET','LAB','BOTH') NOT NULL DEFAULT 'CABINET',
  source_name VARCHAR(255) NULL,
  validation_status ENUM('candidate','validated','rejected','conflict') NOT NULL DEFAULT 'candidate',
  target_clinical_act_id INT NULL,
  notes TEXT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_dental_act_catalog_key (act_key),
  KEY idx_dental_act_catalog_family (family),
  KEY idx_dental_act_catalog_status (validation_status)
);

CREATE TABLE IF NOT EXISTS dental_product_catalog (
  id INT AUTO_INCREMENT PRIMARY KEY,
  product_key VARCHAR(160) NOT NULL,
  product_name VARCHAR(255) NOT NULL,
  category VARCHAR(120) NOT NULL,
  subcategory VARCHAR(160) NULL,
  tracking_unit VARCHAR(40) NOT NULL DEFAULT 'unite',
  typical_package VARCHAR(160) NULL,
  context_type ENUM('CABINET','LAB','BOTH') NOT NULL DEFAULT 'CABINET',
  risk_level ENUM('low','medium','high') NOT NULL DEFAULT 'medium',
  source_name VARCHAR(255) NULL,
  validation_status ENUM('candidate','validated','rejected','conflict') NOT NULL DEFAULT 'candidate',
  target_inventory_product_id INT NULL,
  notes TEXT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_dental_product_catalog_key (product_key),
  KEY idx_dental_product_catalog_category (category),
  KEY idx_dental_product_catalog_status (validation_status)
);

CREATE TABLE IF NOT EXISTS act_product_recipes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  recipe_key VARCHAR(220) NOT NULL,
  act_catalog_id INT NOT NULL,
  product_catalog_id INT NOT NULL,
  recipe_variant VARCHAR(120) NOT NULL DEFAULT 'Standard',
  consumption_min DECIMAL(12,4) NULL,
  consumption_typical DECIMAL(12,4) NOT NULL,
  consumption_max DECIMAL(12,4) NULL,
  unit VARCHAR(40) NOT NULL,
  required TINYINT(1) NOT NULL DEFAULT 1,
  context_type ENUM('CABINET','LAB','BOTH') NOT NULL DEFAULT 'CABINET',
  confidence_level ENUM('faible','moyenne','bonne') NOT NULL DEFAULT 'moyenne',
  source_name VARCHAR(255) NULL,
  unit_cost_tnd DECIMAL(12,4) NULL,
  unit_cost_source VARCHAR(255) NULL,
  unit_cost_status ENUM('none','real_stock','candidate_reference','unavailable','conflict') NOT NULL DEFAULT 'unavailable',
  estimated_cost_tnd_min DECIMAL(12,4) NULL,
  estimated_cost_tnd_typical DECIMAL(12,4) NULL,
  estimated_cost_tnd_max DECIMAL(12,4) NULL,
  cost_validation_status ENUM('none','candidate','validated','rejected','conflict') NOT NULL DEFAULT 'none',
  validation_status ENUM('pending','validated','rejected','conflict') NOT NULL DEFAULT 'pending',
  validated_by_user TINYINT(1) NOT NULL DEFAULT 0,
  target_act_recipe_id INT NULL,
  conflict_reason VARCHAR(255) NULL,
  notes TEXT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_act_product_recipe_line (recipe_key, act_catalog_id, product_catalog_id, recipe_variant),
  KEY idx_act_product_recipe_act (act_catalog_id),
  KEY idx_act_product_recipe_product (product_catalog_id),
  KEY idx_act_product_recipe_status (validation_status)
);

CREATE TABLE IF NOT EXISTS act_product_catalog_import_logs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  run_id VARCHAR(80) NOT NULL,
  entity_type VARCHAR(80) NOT NULL,
  operation ENUM('added','updated','duplicate','conflict','error','validated','rejected','candidate') NOT NULL,
  entity_id INT NULL,
  label VARCHAR(255) NULL,
  details_json TEXT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  KEY idx_act_product_catalog_run (run_id),
  KEY idx_act_product_catalog_operation (operation)
);

ALTER TABLE act_product_recipes
  ADD COLUMN IF NOT EXISTS unit_cost_tnd DECIMAL(12,4) NULL AFTER source_name,
  ADD COLUMN IF NOT EXISTS unit_cost_source VARCHAR(255) NULL AFTER unit_cost_tnd,
  ADD COLUMN IF NOT EXISTS unit_cost_status ENUM('none','real_stock','candidate_reference','unavailable','conflict') NOT NULL DEFAULT 'unavailable' AFTER unit_cost_source,
  ADD COLUMN IF NOT EXISTS estimated_cost_tnd_min DECIMAL(12,4) NULL AFTER unit_cost_status,
  ADD COLUMN IF NOT EXISTS estimated_cost_tnd_typical DECIMAL(12,4) NULL AFTER estimated_cost_tnd_min,
  ADD COLUMN IF NOT EXISTS estimated_cost_tnd_max DECIMAL(12,4) NULL AFTER estimated_cost_tnd_typical,
  ADD COLUMN IF NOT EXISTS cost_validation_status ENUM('none','candidate','validated','rejected','conflict') NOT NULL DEFAULT 'none' AFTER estimated_cost_tnd_max,
  ADD COLUMN IF NOT EXISTS validated_by_user TINYINT(1) NOT NULL DEFAULT 0 AFTER validation_status;
