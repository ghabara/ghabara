const express = require('express');
const { pool } = require('../db');
const { auth, adminOnly } = require('../middleware/auth');
const router = express.Router();

// Liste des patients (+ nombre de RDV) — admin
router.get('/', auth, adminOnly, async (req, res) => {
  try {
    const [patients] = await pool.query('SELECT id_patient, prenom, nom, age, genre, tel, email, created_at FROM patients ORDER BY id_patient');
    const [counts] = await pool.query('SELECT id_patient, COUNT(*) AS n FROM rendez_vous GROUP BY id_patient');
    const map = {}; counts.forEach(c => map[c.id_patient] = c.n);
    res.json(patients.map(p => ({ ...p, rdvCount: map[p.id_patient] || 0 })));
  } catch (e) { res.status(500).json({ error: 'Erreur serveur.' }); }
});

// Un patient
router.get('/:id', auth, adminOnly, async (req, res) => {
  const [rows] = await pool.query('SELECT id_patient, prenom, nom, age, genre, tel, email FROM patients WHERE id_patient = ?', [req.params.id]);
  if (!rows.length) return res.status(404).json({ error: 'Patient introuvable.' });
  res.json(rows[0]);
});

// Supprimer un patient (cascade : dossier, RDV, notes)
router.delete('/:id', auth, adminOnly, async (req, res) => {
  await pool.query('DELETE FROM patients WHERE id_patient = ?', [req.params.id]);
  res.json({ ok: true });
});

module.exports = router;
