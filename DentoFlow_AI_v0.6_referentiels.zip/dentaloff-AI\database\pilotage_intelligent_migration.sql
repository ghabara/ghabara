﻿USE dentaloff_ai;

-- DentoFlow AI V0.3 — Pilotage intelligent du cabinet dentaire
-- Objectif : cabinet + RDV + dossier + actes + cout matiere + stock + achats + labo + audit.

ALTER TABLE admins
  MODIFY COLUMN role ENUM('admin','docteur','assistant','secretaire') DEFAULT 'admin';

ALTER TABLE rendez_vous
  MODIFY COLUMN statut ENUM('pending','confirmed','arrived','in_treatment','done','cancelled','no_show') DEFAULT 'pending';

ALTER TABLE rendez_vous
  ADD COLUMN IF NOT EXISTS duration_minutes INT NULL DEFAULT 30,
  ADD COLUMN IF NOT EXISTS practitioner VARCHAR(120) NULL DEFAULT 'Docteur',
  ADD COLUMN IF NOT EXISTS chair VARCHAR(80) NULL DEFAULT 'Fauteuil 1',
  ADD COLUMN IF NOT EXISTS room VARCHAR(80) NULL,
  ADD COLUMN IF NOT EXISTS notes TEXT NULL,
  ADD COLUMN IF NOT EXISTS planned_act_id INT NULL;

ALTER TABLE inventory_products
  ADD COLUMN IF NOT EXISTS max_stock DECIMAL(12,4) NULL,
  ADD COLUMN IF NOT EXISTS reserved_stock DECIMAL(12,4) NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS storage_location VARCHAR(120) NULL,
  ADD COLUMN IF NOT EXISTS barcode VARCHAR(120) NULL,
  ADD COLUMN IF NOT EXISTS lot_strategy ENUM('GLOBAL','LOT_FEFO') NOT NULL DEFAULT 'GLOBAL';

CREATE TABLE IF NOT EXISTS inventory_lots (
  id INT AUTO_INCREMENT PRIMARY KEY,
  product_id INT NOT NULL,
  lot_number VARCHAR(80) NOT NULL,
  quantity_current DECIMAL(12,4) NOT NULL DEFAULT 0,
  quantity_initial DECIMAL(12,4) NULL,
  expiration_date DATE NULL,
  purchase_id INT NULL,
  status ENUM('ACTIVE','QUARANTINE','EXPIRED','CONSUMED','DISCARDED','CORRECTED') NOT NULL DEFAULT 'ACTIVE',
  storage_location VARCHAR(120) NULL,
  comment TEXT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY idx_inventory_lots_product (product_id),
  KEY idx_inventory_lots_expiration (expiration_date),
  CONSTRAINT fk_inventory_lot_product FOREIGN KEY (product_id) REFERENCES inventory_products(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS audit_logs (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  actor VARCHAR(120) NULL,
  actor_role VARCHAR(40) NULL,
  action VARCHAR(80) NOT NULL,
  entity_type VARCHAR(80) NULL,
  entity_id VARCHAR(80) NULL,
  patient_id VARCHAR(12) NULL,
  ip_address VARCHAR(64) NULL,
  user_agent VARCHAR(255) NULL,
  details_json TEXT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  KEY idx_audit_patient (patient_id),
  KEY idx_audit_entity (entity_type, entity_id),
  KEY idx_audit_action (action),
  CONSTRAINT fk_audit_patient FOREIGN KEY (patient_id) REFERENCES patients(id_patient) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS treatment_plans (
  id INT AUTO_INCREMENT PRIMARY KEY,
  patient_id VARCHAR(12) NOT NULL,
  title VARCHAR(160) NOT NULL,
  status ENUM('draft','proposed','accepted','in_progress','completed','cancelled') NOT NULL DEFAULT 'draft',
  estimated_total_tnd DECIMAL(12,3) NULL,
  notes TEXT NULL,
  created_by VARCHAR(80) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_treatment_plan_patient FOREIGN KEY (patient_id) REFERENCES patients(id_patient) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS treatment_plan_items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  plan_id INT NOT NULL,
  act_id INT NULL,
  tooth_number VARCHAR(20) NULL,
  quadrant VARCHAR(20) NULL,
  label VARCHAR(160) NOT NULL,
  status ENUM('planned','accepted','performed','cancelled') NOT NULL DEFAULT 'planned',
  estimated_price_tnd DECIMAL(12,3) NULL,
  estimated_material_cost_tnd DECIMAL(12,3) NULL,
  performed_act_id INT NULL,
  display_order INT NOT NULL DEFAULT 0,
  notes TEXT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_treatment_item_plan FOREIGN KEY (plan_id) REFERENCES treatment_plans(id) ON DELETE CASCADE,
  CONSTRAINT fk_treatment_item_act FOREIGN KEY (act_id) REFERENCES clinical_acts(id) ON DELETE SET NULL,
  CONSTRAINT fk_treatment_item_performed FOREIGN KEY (performed_act_id) REFERENCES performed_acts(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS documents_index (
  id INT AUTO_INCREMENT PRIMARY KEY,
  document_id INT NULL,
  patient_id VARCHAR(12) NULL,
  product_id INT NULL,
  title VARCHAR(180) NOT NULL,
  doc_type VARCHAR(80) NULL,
  tags VARCHAR(255) NULL,
  summary TEXT NULL,
  source_path VARCHAR(255) NULL,
  is_external TINYINT(1) NOT NULL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_doc_index_document FOREIGN KEY (document_id) REFERENCES documents(id) ON DELETE SET NULL,
  CONSTRAINT fk_doc_index_patient FOREIGN KEY (patient_id) REFERENCES patients(id_patient) ON DELETE SET NULL,
  CONSTRAINT fk_doc_index_product FOREIGN KEY (product_id) REFERENCES inventory_products(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE lab_cases
  ADD COLUMN IF NOT EXISTS performed_act_id INT NULL,
  ADD COLUMN IF NOT EXISTS external_lab_name VARCHAR(160) NULL,
  ADD COLUMN IF NOT EXISTS material VARCHAR(120) NULL,
  ADD COLUMN IF NOT EXISTS sent_date DATE NULL,
  ADD COLUMN IF NOT EXISTS received_date DATE NULL,
  ADD COLUMN IF NOT EXISTS lab_cost_tnd DECIMAL(12,3) NULL;

CREATE TABLE IF NOT EXISTS lab_case_events (
  id INT AUTO_INCREMENT PRIMARY KEY,
  lab_case_id INT NOT NULL,
  previous_status VARCHAR(40) NULL,
  new_status VARCHAR(40) NOT NULL,
  event_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  actor VARCHAR(120) NULL,
  notes TEXT NULL,
  CONSTRAINT fk_lab_case_event_case FOREIGN KEY (lab_case_id) REFERENCES lab_cases(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
