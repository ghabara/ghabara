const express = require('express');
const { pool } = require('../db');
const { auth, adminOnly, docteurOnly } = require('../middleware/auth');
const {
  importActProductCatalog,
  listActs,
  listProducts,
  listRecipes,
  listLogs,
  getDashboard,
  updateStatus,
  updateRecipeStatus,
  createProductCandidate,
} = require('../services/actProductCatalogService');

const router = express.Router();
const asyncHandler = fn => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

router.get('/dashboard', auth, adminOnly, asyncHandler(async (_req, res) => {
  res.json(await getDashboard(pool));
}));

router.post('/import', auth, docteurOnly, asyncHandler(async (req, res) => {
  res.json(await importActProductCatalog(pool, req));
}));

router.get('/acts', auth, adminOnly, asyncHandler(async (req, res) => {
  res.json(await listActs(pool, req.query));
}));

router.post('/acts/:id/validate', auth, docteurOnly, asyncHandler(async (req, res) => {
  const row = await updateStatus(pool, 'dental_act_catalog', req.params.id, 'validated', req);
  if (!row) return res.status(404).json({ error: 'Acte reference introuvable.' });
  res.json(row);
}));

router.post('/acts/:id/reject', auth, docteurOnly, asyncHandler(async (req, res) => {
  const row = await updateStatus(pool, 'dental_act_catalog', req.params.id, 'rejected', req);
  if (!row) return res.status(404).json({ error: 'Acte reference introuvable.' });
  res.json(row);
}));

router.get('/products', auth, adminOnly, asyncHandler(async (req, res) => {
  res.json(await listProducts(pool, req.query));
}));

router.post('/products/:id/validate', auth, docteurOnly, asyncHandler(async (req, res) => {
  const row = await updateStatus(pool, 'dental_product_catalog', req.params.id, 'validated', req);
  if (!row) return res.status(404).json({ error: 'Produit reference introuvable.' });
  res.json(row);
}));

router.post('/products/:id/reject', auth, docteurOnly, asyncHandler(async (req, res) => {
  const row = await updateStatus(pool, 'dental_product_catalog', req.params.id, 'rejected', req);
  if (!row) return res.status(404).json({ error: 'Produit reference introuvable.' });
  res.json(row);
}));

router.post('/products/:id/create-real-product', auth, docteurOnly, asyncHandler(async (req, res) => {
  const row = await createProductCandidate(pool, req.params.id, req);
  if (!row) return res.status(404).json({ error: 'Produit reference introuvable.' });
  res.json(row);
}));

router.get('/recipes', auth, adminOnly, asyncHandler(async (req, res) => {
  res.json(await listRecipes(pool, req.query));
}));

router.post('/recipes/:id/validate', auth, docteurOnly, asyncHandler(async (req, res) => {
  const row = await updateRecipeStatus(pool, req.params.id, 'validated', req);
  if (!row) return res.status(404).json({ error: 'Recette reference introuvable.' });
  res.json(row);
}));

router.post('/recipes/:id/reject', auth, docteurOnly, asyncHandler(async (req, res) => {
  const row = await updateRecipeStatus(pool, req.params.id, 'rejected', req);
  if (!row) return res.status(404).json({ error: 'Recette reference introuvable.' });
  res.json(row);
}));

router.get('/logs', auth, adminOnly, asyncHandler(async (_req, res) => {
  res.json(await listLogs(pool));
}));

module.exports = router;
