USE dentaloff_ai;

-- Couche d'harmonisation des referentiels.
-- Cette migration ne remplace aucune table existante : elle ajoute une couche
-- d'alias, de conflits, de logs et de revue humaine.

CREATE TABLE IF NOT EXISTS reference_sources (
  id INT AUTO_INCREMENT PRIMARY KEY,
  source_key VARCHAR(120) NOT NULL,
  title VARCHAR(220) NOT NULL,
  source_type VARCHAR(80) NOT NULL DEFAULT 'reference',
  country VARCHAR(80) NULL,
  system_name VARCHAR(120) NULL,
  source_path VARCHAR(255) NULL,
  source_date DATE NULL,
  notes TEXT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_reference_source_key (source_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS reference_aliases (
  id INT AUTO_INCREMENT PRIMARY KEY,
  entity_type ENUM('act','consumable','brand','supplier','rule') NOT NULL,
  canonical_id INT NULL,
  alias_name VARCHAR(220) NOT NULL,
  normalized_alias VARCHAR(220) NOT NULL,
  source_id INT NULL,
  country VARCHAR(80) NULL,
  confidence_score DECIMAL(5,4) NOT NULL DEFAULT 0.5000,
  validated_by_user TINYINT(1) NOT NULL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_reference_alias (entity_type, canonical_id, normalized_alias),
  KEY idx_reference_alias_normalized (normalized_alias),
  CONSTRAINT fk_reference_alias_source FOREIGN KEY (source_id) REFERENCES reference_sources(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS reference_conflicts (
  id INT AUTO_INCREMENT PRIMARY KEY,
  conflict_key VARCHAR(180) NOT NULL,
  entity_type VARCHAR(60) NOT NULL,
  entity_id INT NULL,
  field_name VARCHAR(120) NOT NULL,
  current_value TEXT NULL,
  new_value TEXT NULL,
  source_current VARCHAR(180) NULL,
  source_new VARCHAR(180) NULL,
  conflict_type VARCHAR(80) NOT NULL,
  severity ENUM('info','warning','critical') NOT NULL DEFAULT 'warning',
  suggested_resolution TEXT NULL,
  status ENUM('pending','accepted','rejected','merged') NOT NULL DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  resolved_at DATETIME NULL,
  UNIQUE KEY uq_reference_conflict_key (conflict_key),
  KEY idx_reference_conflict_status (status),
  KEY idx_reference_conflict_entity (entity_type, entity_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS reference_import_logs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  run_id VARCHAR(80) NOT NULL,
  source_id INT NULL,
  operation ENUM('added','updated','unchanged','duplicate','conflict','error') NOT NULL,
  entity_type VARCHAR(60) NULL,
  entity_id INT NULL,
  label VARCHAR(220) NULL,
  details_json TEXT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  KEY idx_reference_import_run (run_id),
  KEY idx_reference_import_operation (operation),
  CONSTRAINT fk_reference_import_source FOREIGN KEY (source_id) REFERENCES reference_sources(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS reference_mapping_review (
  id INT AUTO_INCREMENT PRIMARY KEY,
  entity_type ENUM('act','consumable','brand','supplier','rule') NOT NULL,
  source_id INT NULL,
  incoming_name VARCHAR(220) NOT NULL,
  normalized_incoming VARCHAR(220) NOT NULL,
  canonical_id INT NULL,
  canonical_name VARCHAR(220) NULL,
  match_score DECIMAL(5,4) NOT NULL DEFAULT 0.5000,
  review_reason TEXT NULL,
  status ENUM('pending','validated','ignored','new_entry','conflict') NOT NULL DEFAULT 'pending',
  action_taken VARCHAR(120) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_reference_mapping_review (entity_type, normalized_incoming, canonical_id),
  KEY idx_reference_mapping_status (status),
  CONSTRAINT fk_reference_mapping_source FOREIGN KEY (source_id) REFERENCES reference_sources(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS brand_aliases (
  id INT AUTO_INCREMENT PRIMARY KEY,
  canonical_brand VARCHAR(160) NOT NULL,
  alias_name VARCHAR(160) NOT NULL,
  normalized_alias VARCHAR(160) NOT NULL,
  source_id INT NULL,
  confidence_score DECIMAL(5,4) NOT NULL DEFAULT 0.8000,
  validated_by_user TINYINT(1) NOT NULL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_brand_alias (canonical_brand, normalized_alias),
  CONSTRAINT fk_brand_alias_source FOREIGN KEY (source_id) REFERENCES reference_sources(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS supplier_aliases (
  id INT AUTO_INCREMENT PRIMARY KEY,
  canonical_supplier VARCHAR(160) NOT NULL,
  alias_name VARCHAR(160) NOT NULL,
  normalized_alias VARCHAR(160) NOT NULL,
  source_id INT NULL,
  confidence_score DECIMAL(5,4) NOT NULL DEFAULT 0.8000,
  validated_by_user TINYINT(1) NOT NULL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_supplier_alias (canonical_supplier, normalized_alias),
  CONSTRAINT fk_supplier_alias_source FOREIGN KEY (source_id) REFERENCES reference_sources(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS commercial_equivalences (
  id INT AUTO_INCREMENT PRIMARY KEY,
  entity_type ENUM('brand','consumable','supplier') NOT NULL DEFAULT 'brand',
  canonical_name VARCHAR(180) NOT NULL,
  equivalent_name VARCHAR(180) NOT NULL,
  normalized_equivalent VARCHAR(180) NOT NULL,
  source_id INT NULL,
  confidence_score DECIMAL(5,4) NOT NULL DEFAULT 0.8000,
  validation_status ENUM('pending','validated','rejected') NOT NULL DEFAULT 'pending',
  notes TEXT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_commercial_equivalence (entity_type, canonical_name, normalized_equivalent),
  CONSTRAINT fk_commercial_equivalence_source FOREIGN KEY (source_id) REFERENCES reference_sources(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS recipe_versions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  act_id INT NOT NULL,
  version_label VARCHAR(120) NOT NULL DEFAULT 'Standard',
  source_id INT NULL,
  validated TINYINT(1) NOT NULL DEFAULT 0,
  active TINYINT(1) NOT NULL DEFAULT 0,
  notes TEXT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_recipe_version (act_id, version_label, source_id),
  CONSTRAINT fk_recipe_version_act FOREIGN KEY (act_id) REFERENCES clinical_acts(id) ON DELETE CASCADE,
  CONSTRAINT fk_recipe_version_source FOREIGN KEY (source_id) REFERENCES reference_sources(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE reference_consumption_standards
  ADD COLUMN IF NOT EXISTS standard_key VARCHAR(120) NULL,
  ADD COLUMN IF NOT EXISTS confidence_level VARCHAR(30) NULL DEFAULT 'estimation',
  ADD COLUMN IF NOT EXISTS source_country VARCHAR(80) NULL DEFAULT 'France',
  ADD COLUMN IF NOT EXISTS source_note VARCHAR(255) NULL;

ALTER TABLE act_recipes
  ADD COLUMN IF NOT EXISTS source_id INT NULL,
  ADD COLUMN IF NOT EXISTS version_label VARCHAR(120) NULL,
  ADD COLUMN IF NOT EXISTS validated TINYINT(1) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS active TINYINT(1) NOT NULL DEFAULT 1,
  ADD COLUMN IF NOT EXISTS quantity_min DECIMAL(12,4) NULL,
  ADD COLUMN IF NOT EXISTS quantity_max DECIMAL(12,4) NULL,
  ADD COLUMN IF NOT EXISTS factor_loss DECIMAL(8,4) NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS required TINYINT(1) NOT NULL DEFAULT 1;
