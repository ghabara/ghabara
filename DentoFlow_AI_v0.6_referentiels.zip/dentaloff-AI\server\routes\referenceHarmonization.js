const express = require('express');
const { pool } = require('../db');
const { auth, adminOnly, docteurOnly } = require('../middleware/auth');
const {
  getHarmonizationDashboard,
  harmonizeReferenceCatalogs,
  updateConflictStatus,
  updateMappingStatus,
} = require('../services/referenceHarmonizationService');

const router = express.Router();

const asyncHandler = fn => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

router.get('/', auth, adminOnly, asyncHandler(async (_req, res) => {
  res.json(await getHarmonizationDashboard(pool));
}));

router.post('/run', auth, docteurOnly, asyncHandler(async (req, res) => {
  const summary = await harmonizeReferenceCatalogs(pool, { actor: req.user });
  const dashboard = await getHarmonizationDashboard(pool);
  res.json({ summary, dashboard });
}));

router.patch('/conflicts/:id', auth, docteurOnly, asyncHandler(async (req, res) => {
  const row = await updateConflictStatus(pool, req.params.id, req.body.status, req.user);
  if (!row) return res.status(404).json({ error: 'Conflit introuvable.' });
  res.json(row);
}));

router.patch('/mappings/:id', auth, docteurOnly, asyncHandler(async (req, res) => {
  const row = await updateMappingStatus(pool, req.params.id, req.body.status, req.body.action_taken, req.user);
  if (!row) return res.status(404).json({ error: 'Mapping introuvable.' });
  res.json(row);
}));

module.exports = router;
