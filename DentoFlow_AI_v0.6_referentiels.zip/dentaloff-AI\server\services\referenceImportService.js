const crypto = require('crypto');
const { logAudit } = require('./auditService');

const SOURCE_FILES = {
  labInventory: 'Inventaire mondial des consommables de laboratoire dentaire.pdf',
  labConsumablePrices: 'Etude preparatoire sur les prix internationaux des consommables de laboratoire dentaire.pdf',
  productPrices: 'Prix moyens des produits dentaires dans le monde.pdf',
  dentalActPrices: 'Prix moyens et conventionnels des actes dentaires dans le monde.pdf',
  labActPrices: 'Benchmark mondial des prix des actes de laboratoire dentaire.pdf',
};

const countries = [
  ['Tunisie', 'TN', 'TND', 'Afrique / Moyen-Orient'],
  ['France', 'FR', 'EUR', 'Europe'],
  ['Suisse', 'CH', 'CHF', 'Europe'],
  ['Royaume-Uni', 'GB', 'GBP', 'Europe'],
  ['Allemagne', 'DE', 'EUR', 'Europe'],
  ['Japon', 'JP', 'JPY', 'Asie-Pacifique'],
  ['Chine', 'CN', 'CNY', 'Asie-Pacifique'],
  ['Inde', 'IN', 'INR', 'Asie-Pacifique'],
  ['Arabie saoudite', 'SA', 'SAR', 'Moyen-Orient'],
  ['Emirats arabes unis', 'AE', 'AED', 'Moyen-Orient'],
  ['Afrique du Sud', 'ZA', 'ZAR', 'Afrique'],
  ['Canada', 'CA', 'CAD', 'Ameriques'],
  ['Etats-Unis', 'US', 'USD', 'Ameriques'],
  ['Argentine', 'AR', 'ARS', 'Ameriques'],
  ['Bresil', 'BR', 'BRL', 'Ameriques'],
];

const labConsumables = [
  ['Disque zircone Y-TZP', 'Ceramiques CFAO', 'Disques zircone', 'Usinage couronnes et bridges zircone', 'disque', 'disque', '98 mm', 'zircone', 35, 220, 'EUR'],
  ['Bloc disilicate de lithium', 'Ceramiques CFAO', 'Blocs disilicate', 'Couronnes, facettes, inlay/onlay CFAO', 'bloc', 'bloc', 'boite / unitaire', 'disilicate lithium', 18, 65, 'EUR'],
  ['Poudre ceramique stratification', 'Ceramiques CFAO', 'Poudres ceramiques', 'Stratification esthetique', 'pot', 'g', 'pot 20-50 g', 'ceramique', 25, 95, 'EUR'],
  ['Stains et glaze ceramique', 'Ceramiques CFAO', 'Stains glaze', 'Maquillage et glacage', 'kit', 'ml', 'kit ou flacon', 'ceramique', 30, 160, 'EUR'],
  ['Alliage Co-Cr dentaire', 'Alliages et metallurgie', 'Co-Cr', 'Chassis, couronnes metal, bridges', 'boite', 'g', 'lingot / pastille', 'alliage', 45, 190, 'EUR'],
  ['Premilled blank titane', 'Alliages et metallurgie', 'Titane', 'Piliers implanto-prothetiques CFAO', 'blank', 'unite', 'unitaire', 'titane', 18, 85, 'EUR'],
  ['Revetement phosphate', 'Alliages et metallurgie', 'Revetements', 'Coulée, pressée, modelage', 'sac', 'g', 'sac 2-5 kg', 'revetement', 25, 120, 'EUR'],
  ['Creuset ceramique', 'Alliages et metallurgie', 'Creusets', 'Coulée metallique', 'unite', 'unite', 'unitaire', 'ceramique', 8, 45, 'EUR'],
  ['Resine acrylique poudre', 'Resines conventionnelles', 'Acrylique', 'Base prothese amovible', 'pot', 'g', 'pot 500-1000 g', 'PMMA', 25, 110, 'EUR'],
  ['Monomere liquide acrylique', 'Resines conventionnelles', 'Monomere', 'Polymerisation resine acrylique', 'flacon', 'ml', 'flacon 250-1000 ml', 'monomere', 14, 65, 'EUR'],
  ['PMMA disque provisoire', 'Resines conventionnelles', 'PMMA CFAO', 'Provisoires usines', 'disque', 'disque', '98 mm', 'PMMA', 18, 75, 'EUR'],
  ['Resine 3D modele', 'Resines 3D', 'Modele', 'Modeles imprimes', 'bouteille', 'ml', '1 kg / 1 L', 'resine photopolymere', 45, 180, 'EUR'],
  ['Resine 3D guide chirurgical', 'Resines 3D', 'Guide chirurgical', 'Guides chirurgicaux', 'bouteille', 'ml', '1 kg / 1 L', 'resine biocompatible', 120, 350, 'EUR'],
  ['Resine 3D gouttiere', 'Resines 3D', 'Gouttiere', 'Gouttieres et splints', 'bouteille', 'ml', '1 kg / 1 L', 'resine biocompatible', 95, 320, 'EUR'],
  ['Resine 3D calcinable', 'Resines 3D', 'Calcinable', 'Pattern de coulée', 'bouteille', 'ml', '0.5-1 kg', 'resine calcinable', 80, 260, 'EUR'],
  ['Cire occlusion', 'Cires', 'Occlusion', 'Enregistrement d’occlusion', 'boite', 'feuille', 'boite de feuilles', 'cire', 8, 45, 'EUR'],
  ['Wax disc CFAO', 'Cires', 'Wax discs', 'Wax-up usine', 'disque', 'disque', '98 mm', 'cire', 12, 50, 'EUR'],
  ['Platre type III', 'Gypse et revetements', 'Platre III', 'Modeles diagnostic', 'sac', 'kg', 'sac 5-25 kg', 'gypse', 8, 45, 'EUR'],
  ['Platre type IV', 'Gypse et revetements', 'Platre IV', 'Modeles de travail', 'sac', 'kg', 'sac 5-25 kg', 'gypse dur', 15, 70, 'EUR'],
  ['Silicone duplication', 'Silicones et controle', 'Duplication', 'Duplicata de modele', 'kit', 'ml', 'kit base/catalyseur', 'silicone', 35, 160, 'EUR'],
  ['Fit checker silicone', 'Silicones et controle', 'Controle ajustage', 'Controle intrados prothese', 'cartouche', 'ml', 'cartouche', 'silicone', 22, 95, 'EUR'],
  ['Silane dentaire', 'Adhesifs et separateurs', 'Silane', 'Conditionnement ceramique', 'flacon', 'ml', 'flacon 5-10 ml', 'silane', 15, 80, 'EUR'],
  ['Primer zircone metal', 'Adhesifs et separateurs', 'Primer', 'Collage zircone/metal', 'flacon', 'ml', 'flacon 5-10 ml', 'primer', 20, 95, 'EUR'],
  ['Isolant platre resine', 'Adhesifs et separateurs', 'Separateur', 'Isolation platre/resine', 'flacon', 'ml', 'flacon 250-1000 ml', 'separateur', 8, 45, 'EUR'],
  ['Plaque thermoformable aligneur', 'Orthodontie aligneurs', 'Thermoformage', 'Aligneurs et contention', 'boite', 'plaque', 'boite 20-100 plaques', 'PETG / PU', 25, 180, 'EUR'],
  ['Fraise de fraisage zircone', 'Finition et polissage', 'Fraise CFAO', 'Usinage zircone', 'unite', 'unite', 'unitaire', 'carbure / diamant', 18, 95, 'EUR'],
  ['Disque separation', 'Finition et polissage', 'Disques', 'Separation et finition', 'boite', 'unite', 'boite', 'abrasif', 6, 35, 'EUR'],
  ['Pate diamantée polissage', 'Finition et polissage', 'Pate diamantée', 'Polissage ceramique', 'seringue', 'g', 'seringue', 'diamant', 12, 80, 'EUR'],
  ['Masque laboratoire', 'EPI et emballages', 'Masques', 'Protection respiratoire', 'boite', 'unite', 'boite 50', 'EPI', 3, 25, 'EUR'],
  ['Boite prothetique livraison', 'EPI et emballages', 'Emballage', 'Livraison prothese', 'lot', 'unite', 'lot 50-100', 'plastique / carton', 10, 60, 'EUR'],
];

const productPrices = [
  ['cabinet_consumable', 'Pate dentifrice standard', 'OTC', 'Tunisie', 'TND', 3.42, 5.5, 8.0, 1.1, '75-100 ml', 'Prix moyens produits dentaires'],
  ['cabinet_consumable', 'Pate dentifrice standard', 'OTC', 'France', 'EUR', 1.99, 3.2, 6.0, 3.5, '75-100 ml', 'Prix moyens produits dentaires'],
  ['cabinet_consumable', 'Pate dentifrice standard', 'OTC', 'Suisse', 'CHF', 3.75, 5.9, 9.5, 6.6, '75-100 ml', 'Prix moyens produits dentaires'],
  ['cabinet_consumable', 'Fil dentaire', 'OTC', 'Tunisie', 'TND', 4.0, 7.5, 18.0, 2.4, '50 m', 'Prix moyens produits dentaires'],
  ['cabinet_consumable', 'Fil dentaire', 'OTC', 'France', 'EUR', 1.99, 3.5, 8.0, 3.8, '50 m', 'Prix moyens produits dentaires'],
  ['cabinet_consumable', 'Bain de bouche', 'OTC', 'Allemagne', 'EUR', 2.5, 5.0, 11.0, 5.5, '500 ml', 'Prix moyens produits dentaires'],
  ['cabinet_consumable', 'Anesthesique local cartouche', 'Intrant clinique', 'France', 'EUR', 0.45, 0.9, 1.8, 1.0, '1 cartouche', 'Prix moyens produits dentaires'],
  ['cabinet_consumable', 'Anesthesique local cartouche', 'Intrant clinique', 'Etats-Unis', 'USD', 0.7, 1.4, 3.2, 1.4, '1 cartouche', 'Prix moyens produits dentaires'],
  ['cabinet_consumable', 'Composite restauration', 'Intrant clinique', 'France', 'EUR', 18, 35, 70, 39, 'seringue 3-4 g', 'Prix moyens produits dentaires'],
  ['cabinet_consumable', 'Composite restauration', 'Intrant clinique', 'Tunisie', 'TND', 45, 75, 140, 24, 'seringue 3-4 g', 'Prix moyens produits dentaires'],
  ['lab_consumable', 'Disque zircone Y-TZP', 'Ceramiques CFAO', 'Chine', 'CNY', 180, 380, 900, 53, 'disque 98 mm', 'Prix consommables labo'],
  ['lab_consumable', 'Disque zircone Y-TZP', 'Ceramiques CFAO', 'France', 'EUR', 45, 120, 240, 132, 'disque 98 mm', 'Prix consommables labo'],
  ['lab_consumable', 'Disque zircone Y-TZP', 'Ceramiques CFAO', 'Etats-Unis', 'USD', 60, 150, 320, 150, 'disque 98 mm', 'Prix consommables labo'],
  ['lab_consumable', 'Bloc disilicate de lithium', 'Ceramiques CFAO', 'Japon', 'JPY', 2800, 5400, 9500, 34, 'bloc', 'Prix consommables labo'],
  ['lab_consumable', 'Resine 3D modele', 'Resines 3D', 'Canada', 'CAD', 70, 160, 320, 118, '1 kg', 'Prix consommables labo'],
  ['lab_consumable', 'Ti-base implant', 'Implantologie labo', 'Suisse', 'CHF', 35, 95, 160, 106, 'unite', 'Prix consommables labo'],
  ['lab_consumable', 'Ti-base implant', 'Implantologie labo', 'Inde', 'INR', 1200, 2800, 6200, 29, 'unite', 'Prix consommables labo'],
];

const dentalActs = [
  ['consultation', 'Consultation', 'Diagnostic', 'standard'],
  ['urgence', 'Urgence dentaire', 'Diagnostic', 'standard'],
  ['detartrage', 'Detartrage', 'Prevention', 'standard'],
  ['radio_intraorale', 'Radio intra-orale', 'Imagerie', 'standard'],
  ['panoramique', 'Radiographie panoramique', 'Imagerie', 'standard'],
  ['obturation_1_face', 'Obturation 1 face', 'Soins conservateurs', 'standard'],
  ['obturation_2_faces', 'Obturation 2 faces', 'Soins conservateurs', 'standard'],
  ['obturation_3_faces', 'Obturation 3 faces', 'Soins conservateurs', 'standard'],
  ['endo_incisive_canine', 'Traitement endodontique incisive/canine', 'Endodontie', 'standard'],
  ['endo_premolaire', 'Traitement endodontique premolaire', 'Endodontie', 'standard'],
  ['endo_molaire', 'Traitement endodontique molaire', 'Endodontie', 'standard'],
  ['extraction_simple', 'Extraction simple', 'Chirurgie', 'standard'],
  ['extraction_chirurgicale', 'Extraction chirurgicale', 'Chirurgie', 'specialized'],
  ['couronne_ceramique', 'Couronne ceramique', 'Prothese fixe', 'standard'],
  ['couronne_zircone', 'Couronne zircone', 'Prothese fixe', 'modern'],
  ['couronne_metal_ceramique', 'Couronne metal-ceramique', 'Prothese fixe', 'standard'],
  ['bridge_3_elements', 'Bridge 3 elements', 'Prothese fixe', 'standard'],
  ['facette', 'Facette', 'Esthetique', 'modern'],
  ['inlay_onlay', 'Inlay / onlay', 'Restauratrice indirecte', 'modern'],
  ['prothese_partielle', 'Prothese partielle', 'Prothese amovible', 'standard'],
  ['prothese_complete', 'Prothese complete', 'Prothese amovible', 'standard'],
  ['implant_unitaire', 'Implant unitaire', 'Implantologie', 'modern'],
  ['pilier_implantaire', 'Pilier implantaire', 'Implantologie', 'modern'],
  ['couronne_implant', 'Couronne sur implant', 'Implantologie', 'modern'],
  ['gouttiere', 'Gouttiere', 'Orthodontie / occlusodontie', 'standard'],
  ['aligneur', 'Aligneur', 'Orthodontie', 'modern'],
  ['blanchiment', 'Blanchiment', 'Esthetique', 'modern'],
  ['laser', 'Acte laser', 'Technologie avancee', 'modern'],
];

const dentalActPrices = [
  ['consultation', 'Tunisie', 'TND', 'private_indicative', 40, 70, 120, null, 'Prix actes dentaires monde'],
  ['consultation', 'France', 'EUR', 'conventional_tariff', 23, 23, 30, 0.7, 'Prix actes dentaires monde'],
  ['consultation', 'Suisse', 'CHF', 'private_indicative', 80, 130, 220, null, 'Prix actes dentaires monde'],
  ['detartrage', 'France', 'EUR', 'conventional_tariff', 28.92, 43.38, 70, 0.7, 'Prix actes dentaires monde'],
  ['detartrage', 'Etats-Unis', 'USD', 'clinical_average', 80, 150, 300, null, 'Prix actes dentaires monde'],
  ['obturation_1_face', 'France', 'EUR', 'conventional_tariff', 26.97, 35, 55, 0.7, 'Prix actes dentaires monde'],
  ['obturation_2_faces', 'Allemagne', 'EUR', 'private_indicative', 60, 110, 220, null, 'Prix actes dentaires monde'],
  ['endo_molaire', 'Canada', 'CAD', 'clinical_average', 650, 950, 1400, null, 'Prix actes dentaires monde'],
  ['extraction_simple', 'Inde', 'INR', 'clinical_average', 800, 1800, 4500, null, 'Prix actes dentaires monde'],
  ['couronne_zircone', 'Suisse', 'CHF', 'private_indicative', 900, 1400, 2200, null, 'Prix actes dentaires monde'],
  ['couronne_zircone', 'Chine', 'CNY', 'clinical_average', 1000, 2600, 6000, null, 'Prix actes dentaires monde'],
  ['implant_unitaire', 'Etats-Unis', 'USD', 'private_indicative', 1800, 3500, 6500, null, 'Prix actes dentaires monde'],
  ['implant_unitaire', 'Emirats arabes unis', 'AED', 'private_indicative', 4500, 9000, 16000, null, 'Prix actes dentaires monde'],
  ['aligneur', 'France', 'EUR', 'out_of_nomenclature', 1500, 3500, 6500, 0, 'Prix actes dentaires monde'],
  ['laser', 'Tunisie', 'TND', 'out_of_nomenclature', 80, 180, 450, 0, 'Prix actes dentaires monde'],
];

const labActPrices = [
  ['couronne_zircone_labo', 'Couronne zircone labo', 'Japon', 'JPY', 'lab_b2b', 15000, 15000, 19000, 92],
  ['couronne_pfm_labo', 'Couronne PFM labo', 'Japon', 'JPY', 'lab_b2b', 19000, 19000, 20000, 117],
  ['bridge_3_labo', 'Bridge 3 elements labo', 'Japon', 'JPY', 'lab_b2b', 66000, 66000, 66000, 406],
  ['couronne_zircone_labo', 'Couronne zircone labo', 'Chine', 'CNY', 'lab_b2b', 238, 238, 238, 35],
  ['couronne_pfm_labo', 'Couronne PFM labo', 'Chine', 'CNY', 'lab_b2b', 126, 126, 126, 19],
  ['bridge_3_labo', 'Bridge 3 elements labo', 'Chine', 'CNY', 'lab_b2b', 377, 377, 377, 56],
  ['prothese_complete_labo', 'Prothese complete labo', 'Chine', 'CNY', 'lab_b2b', 611, 611, 611, 90],
  ['couronne_zircone_labo', 'Couronne zircone labo', 'Inde', 'INR', 'lab_b2b', 6500, 6500, 10000, 68],
  ['bridge_3_labo', 'Bridge 3 elements labo', 'Inde', 'INR', 'lab_b2b', 19500, 19500, 35000, 205],
  ['couronne_zircone_labo', 'Couronne zircone labo', 'Arabie saoudite', 'SAR', 'lab_b2b', 800, 800, 800, 213],
  ['couronne_pfm_labo', 'Couronne PFM labo', 'Afrique du Sud', 'ZAR', 'lab_b2b', 1347, 1779, 1779, 83],
  ['bridge_3_labo', 'Bridge 3 elements labo', 'Canada', 'CAD', 'lab_b2b', 900, 900, 900, 634],
  ['couronne_zircone_labo', 'Couronne zircone labo', 'Canada', 'CAD', 'lab_b2b', 215, 215, 300, 151],
];

const exchangeRates = [
  ['USD', 'EUR', 0.8865], ['EUR', 'USD', 1.1280], ['USD', 'TND', 3.05], ['USD', 'CHF', 0.80],
  ['USD', 'GBP', 0.73], ['USD', 'JPY', 162.5], ['USD', 'CNY', 7.15], ['USD', 'INR', 95.2],
  ['USD', 'SAR', 3.75], ['USD', 'AED', 3.67], ['USD', 'ZAR', 16.2], ['USD', 'CAD', 1.42],
  ['USD', 'ARS', 1200], ['USD', 'BRL', 5.45],
];

const countryMarketProfiles = [
  ['Tunisie', 'TND', 3.05, 0.72, 0.45, 0.55],
  ['France', 'EUR', 0.8865, 1.00, 0.92, 1.00],
  ['Suisse', 'CHF', 0.80, 1.45, 1.85, 1.55],
  ['Royaume-Uni', 'GBP', 0.73, 1.12, 1.15, 1.10],
  ['Allemagne', 'EUR', 0.8865, 0.95, 1.02, 0.98],
  ['Japon', 'JPY', 162.5, 1.15, 1.20, 1.12],
  ['Chine', 'CNY', 7.15, 0.58, 0.55, 0.48],
  ['Inde', 'INR', 95.2, 0.42, 0.38, 0.36],
  ['Arabie saoudite', 'SAR', 3.75, 1.08, 1.05, 1.00],
  ['Emirats arabes unis', 'AED', 3.67, 1.18, 1.28, 1.18],
  ['Afrique du Sud', 'ZAR', 16.2, 0.74, 0.72, 0.70],
  ['Canada', 'CAD', 1.42, 1.16, 1.18, 1.12],
  ['Etats-Unis', 'USD', 1.00, 1.28, 1.45, 1.30],
  ['Argentine', 'ARS', 1200, 0.54, 0.48, 0.46],
  ['Bresil', 'BRL', 5.45, 0.68, 0.62, 0.60],
];

const clinicalProducts = [
  ['cabinet_consumable', 'Gants nitrile', 'EPI cabinet', 'boite 100', 4, 8, 18],
  ['cabinet_consumable', 'Masques chirurgicaux', 'EPI cabinet', 'boite 50', 3, 6, 14],
  ['cabinet_consumable', 'Champ operatoire sterile', 'EPI cabinet', 'unite', 0.7, 1.6, 4.5],
  ['cabinet_consumable', 'Aiguille dentaire courte', 'Anesthesie', 'boite 100', 5, 12, 30],
  ['cabinet_consumable', 'Anesthesique local cartouche', 'Anesthesie', 'cartouche', 0.55, 1.2, 3.2],
  ['cabinet_consumable', 'Composite restauration', 'Restauratrice', 'seringue 3-4 g', 18, 38, 82],
  ['cabinet_consumable', 'Adhesif universel', 'Restauratrice', 'flacon 5 ml', 28, 55, 110],
  ['cabinet_consumable', 'Gel mordancage phosphorique', 'Restauratrice', 'seringue', 4, 9, 20],
  ['cabinet_consumable', 'Digue dentaire', 'Endodontie', 'boite', 8, 18, 45],
  ['cabinet_consumable', 'Limes endodontiques NiTi', 'Endodontie', 'set', 18, 45, 120],
  ['cabinet_consumable', 'Irrigant hypochlorite', 'Endodontie', 'flacon', 4, 9, 25],
  ['cabinet_consumable', 'Pointes gutta-percha', 'Endodontie', 'boite', 5, 12, 30],
  ['cabinet_consumable', 'Alginate empreinte', 'Empreinte', 'sachet', 6, 14, 35],
  ['cabinet_consumable', 'Silicone empreinte VPS', 'Empreinte', 'cartouche', 18, 45, 95],
  ['cabinet_consumable', 'Ciment verre ionomere', 'Scellement', 'kit', 18, 40, 90],
  ['cabinet_consumable', 'Ciment resine', 'Scellement', 'seringue', 25, 60, 130],
  ['cabinet_consumable', 'Sutures resorbables', 'Chirurgie', 'boite', 18, 45, 110],
  ['cabinet_consumable', 'Implant titane generique', 'Implantologie', 'unite', 70, 145, 350],
  ['cabinet_consumable', 'Pilier implantaire standard', 'Implantologie', 'unite', 28, 70, 160],
  ['cabinet_consumable', 'Brosse a dents', 'OTC', 'unite', 0.6, 2.5, 7],
  ['cabinet_consumable', 'Bain de bouche', 'OTC', '500 ml', 1.8, 5, 13],
  ['cabinet_consumable', 'Brossettes interdentaires', 'OTC', 'pack', 2, 5.5, 15],
  ['cabinet_consumable', 'Gel fluorure', 'Prevention', 'tube', 4, 9, 25],
];

const dentalActBaseUsd = {
  consultation: [18, 45, 95],
  urgence: [30, 75, 180],
  detartrage: [35, 90, 220],
  radio_intraorale: [8, 25, 70],
  panoramique: [28, 75, 180],
  obturation_1_face: [35, 95, 220],
  obturation_2_faces: [45, 130, 300],
  obturation_3_faces: [60, 170, 380],
  endo_incisive_canine: [100, 280, 650],
  endo_premolaire: [150, 420, 850],
  endo_molaire: [220, 650, 1400],
  extraction_simple: [35, 110, 300],
  extraction_chirurgicale: [90, 260, 750],
  couronne_ceramique: [260, 720, 1800],
  couronne_zircone: [300, 850, 2200],
  couronne_metal_ceramique: [220, 620, 1500],
  bridge_3_elements: [700, 1800, 4800],
  facette: [280, 850, 2200],
  inlay_onlay: [240, 680, 1700],
  prothese_partielle: [260, 750, 1900],
  prothese_complete: [450, 1300, 3200],
  implant_unitaire: [850, 2400, 6500],
  pilier_implantaire: [140, 450, 1200],
  couronne_implant: [350, 950, 2400],
  gouttiere: [80, 220, 550],
  aligneur: [900, 2800, 7000],
  blanchiment: [120, 420, 1200],
  laser: [60, 180, 520],
};

const labActBaseUsd = [
  ['couronne_zircone_labo', 'Couronne zircone labo', 45, 130, 310],
  ['couronne_pfm_labo', 'Couronne PFM labo', 38, 115, 280],
  ['couronne_ceramique_labo', 'Couronne ceramique labo', 50, 150, 360],
  ['facette_labo', 'Facette ceramique labo', 45, 140, 340],
  ['inlay_onlay_labo', 'Inlay / onlay labo', 40, 125, 300],
  ['bridge_3_labo', 'Bridge 3 elements labo', 130, 380, 950],
  ['prothese_partielle_labo', 'Prothese partielle labo', 90, 260, 650],
  ['prothese_complete_labo', 'Prothese complete labo', 120, 360, 900],
  ['gouttiere_labo', 'Gouttiere thermoformee labo', 18, 65, 170],
  ['aligneur_labo', 'Aligneur unitaire labo', 20, 75, 180],
  ['guide_chirurgical_labo', 'Guide chirurgical imprime labo', 55, 170, 420],
  ['modele_3d_labo', 'Modele 3D labo', 8, 28, 80],
  ['pilier_personnalise_labo', 'Pilier personnalise labo', 85, 260, 650],
  ['waxup_labo', 'Wax-up diagnostic labo', 35, 110, 280],
];

function normalizeName(value) {
  return String(value || '')
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .toLowerCase().replace(/[^a-z0-9]+/g, ' ')
    .trim();
}

function roundPrice(value, currency) {
  const n = Number(value || 0);
  if (['JPY', 'INR', 'ARS', 'CNY', 'ZAR'].includes(currency)) return Math.round(n);
  return Number(n.toFixed(2));
}

function buildInternationalPriceRows() {
  const rows = [...productPrices];
  for (const [country, currency, usdRate, productMultiplier] of countryMarketProfiles) {
    for (const [entityType, name, category, unit, minUsd, avgUsd, maxUsd] of clinicalProducts) {
      const min = minUsd * productMultiplier;
      const avg = avgUsd * productMultiplier;
      const max = maxUsd * productMultiplier;
      rows.push([
        entityType,
        name,
        category,
        country,
        currency,
        roundPrice(min * usdRate, currency),
        roundPrice(avg * usdRate, currency),
        roundPrice(max * usdRate, currency),
        Number(avg.toFixed(2)),
        unit,
        'Prix produits dentaires monde - estimation pays',
      ]);
    }
    for (const item of labConsumables) {
      const [name, category, , , purchaseUnit, storageUnit, packaging, , minEur, maxEur] = item;
      const minUsd = Number(minEur || 0) * 1.128 * productMultiplier;
      const maxUsd = Number(maxEur || minEur || 0) * 1.128 * productMultiplier;
      const avgUsd = (minUsd + maxUsd) / 2;
      rows.push([
        'lab_consumable',
        name,
        category,
        country,
        currency,
        roundPrice(minUsd * usdRate, currency),
        roundPrice(avgUsd * usdRate, currency),
        roundPrice(maxUsd * usdRate, currency),
        Number(avgUsd.toFixed(2)),
        packaging || storageUnit || purchaseUnit || 'unite',
        'Prix consommables laboratoire monde - estimation pays',
      ]);
    }
  }
  return rows;
}

function buildDentalActPriceRows() {
  const rows = [...dentalActPrices];
  for (const [country, currency, usdRate, , actMultiplier] of countryMarketProfiles) {
    for (const [key, , family] of dentalActs) {
      const base = dentalActBaseUsd[key];
      if (!base) continue;
      const [minUsd, avgUsd, maxUsd] = base.map(value => value * actMultiplier);
      const isFranceConvention = country === 'France' && ['Diagnostic', 'Prevention', 'Imagerie', 'Soins conservateurs', 'Endodontie', 'Chirurgie'].includes(family);
      const isOutOfNomenclature = ['Esthetique', 'Orthodontie', 'Technologie avancee'].includes(family) || key === 'aligneur';
      const priceType = isFranceConvention ? 'conventional_tariff' : isOutOfNomenclature ? 'out_of_nomenclature' : 'clinical_average';
      const reimbursementRate = isFranceConvention ? 0.7 : isOutOfNomenclature ? 0 : null;
      rows.push([
        key,
        country,
        currency,
        priceType,
        roundPrice(minUsd * usdRate, currency),
        roundPrice(avgUsd * usdRate, currency),
        roundPrice(maxUsd * usdRate, currency),
        reimbursementRate,
        'Prix actes dentaires monde - estimation pays',
      ]);
    }
  }
  return rows;
}

function buildLabActPriceRows() {
  const rows = [...labActPrices];
  for (const [country, currency, usdRate, , , labMultiplier] of countryMarketProfiles) {
    for (const [key, name, minUsdBase, avgUsdBase, maxUsdBase] of labActBaseUsd) {
      const minUsd = minUsdBase * labMultiplier;
      const avgUsd = avgUsdBase * labMultiplier;
      const maxUsd = maxUsdBase * labMultiplier;
      rows.push([
        key,
        name,
        country,
        currency,
        'lab_b2b',
        roundPrice(minUsd * usdRate, currency),
        roundPrice(avgUsd * usdRate, currency),
        roundPrice(maxUsd * usdRate, currency),
        Number(avgUsd.toFixed(2)),
      ]);
    }
  }
  return rows;
}

async function logImport(db, runId, entityType, operation, entityId, label, details = {}) {
  await db.query(
    `INSERT INTO dental_act_price_import_logs (run_id, entity_type, operation, entity_id, label, details_json)
     VALUES (?, ?, ?, ?, ?, ?)`,
    [runId, entityType, operation, entityId || null, label || null, JSON.stringify(details).slice(0, 5000)]
  );
}

async function upsert(db, sql, params) {
  const [result] = await db.query(sql, params);
  return result.insertId || null;
}

async function importReferencePack(db, req) {
  const runId = `ref-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`;
  const summary = { run_id: runId, added: 0, updated: 0, conflicts: 0, candidates: 0 };

  for (const [country, iso, currency, region] of countries) {
    await upsert(db, `INSERT INTO countries_reference (country, iso_code, currency, region)
      VALUES (?, ?, ?, ?)
      ON DUPLICATE KEY UPDATE currency = VALUES(currency), region = VALUES(region), active = 1`,
      [country, iso, currency, region]);
  }
  await logImport(db, runId, 'country', 'updated', null, 'countries_reference', { count: countries.length });

  for (const [base, target, rate] of exchangeRates) {
    await upsert(db, `INSERT INTO exchange_rate_references (base_currency, target_currency, rate, effective_date, source_name, confidence_score)
      VALUES (?, ?, ?, '2026-07-05', 'Reference pack DentoFlow AI', 0.75)
      ON DUPLICATE KEY UPDATE rate = VALUES(rate), confidence_score = VALUES(confidence_score)`,
      [base, target, rate]);
  }
  await logImport(db, runId, 'exchange_rate', 'updated', null, 'exchange_rate_references', { count: exchangeRates.length });

  for (const row of labConsumables) {
    const [name, category, subcategory, typicalUse, purchaseUnit, storageUnit, packaging, materialType, min, max, currency] = row;
    await upsert(db, `INSERT INTO lab_consumable_reference
      (canonical_name, category, subcategory, typical_use, purchase_unit, storage_unit, packaging, material_type,
       price_min, price_max, price_currency, source_name, source_file, source_page, source_quality, validation_status)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Inventaire labo mondial', ?, '1-17', 'to_confirm_supplier', 'candidate')
      ON DUPLICATE KEY UPDATE
        typical_use = IF(validation_status = 'validated', typical_use, VALUES(typical_use)),
        purchase_unit = IF(validation_status = 'validated', purchase_unit, VALUES(purchase_unit)),
        storage_unit = IF(validation_status = 'validated', storage_unit, VALUES(storage_unit)),
        packaging = IF(validation_status = 'validated', packaging, VALUES(packaging)),
        material_type = IF(validation_status = 'validated', material_type, VALUES(material_type)),
        price_min = IF(validation_status = 'validated', price_min, VALUES(price_min)),
        price_max = IF(validation_status = 'validated', price_max, VALUES(price_max))`,
      [name, category, subcategory, typicalUse, purchaseUnit, storageUnit, packaging, materialType, min, max, currency, SOURCE_FILES.labInventory]);
    summary.candidates += 1;
  }
  await logImport(db, runId, 'lab_consumable', 'updated', null, 'lab_consumable_reference', { count: labConsumables.length });

  const allProductPrices = buildInternationalPriceRows();
  for (const row of allProductPrices) {
    const [entityType, name, category, country, currency, min, avg, max, usd, unit, sourceName] = row;
    await upsert(db, `INSERT INTO international_price_references
      (entity_type, candidate_name, category, country, currency, price_min, price_avg, price_max, price_usd, unit,
       source_name, source_file, source_page, observed_at, effective_date, confidence_score, validation_status)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, '1-10', '2026-07-05 00:00:00', '2026-07-05', 0.70, 'candidate')
      ON DUPLICATE KEY UPDATE
        price_min = IF(validation_status = 'validated', price_min, VALUES(price_min)),
        price_avg = IF(validation_status = 'validated', price_avg, VALUES(price_avg)),
        price_max = IF(validation_status = 'validated', price_max, VALUES(price_max)),
        price_usd = IF(validation_status = 'validated', price_usd, VALUES(price_usd)),
        confidence_score = VALUES(confidence_score)`,
      [entityType, name, category, country, currency, min, avg, max, usd, unit, sourceName, entityType === 'lab_consumable' ? SOURCE_FILES.labConsumablePrices : SOURCE_FILES.productPrices]);
  }
  await logImport(db, runId, 'international_price', 'updated', null, 'international_price_references', { count: allProductPrices.length });

  const actIds = new Map();
  for (const [key, name, family, status] of dentalActs) {
    await upsert(db, `INSERT INTO dental_act_global_catalog (act_key, act_name, family, modernity_status)
      VALUES (?, ?, ?, ?)
      ON DUPLICATE KEY UPDATE act_name = VALUES(act_name), family = VALUES(family), modernity_status = VALUES(modernity_status), active = 1`,
      [key, name, family, status]);
    const [[row]] = await db.query('SELECT id FROM dental_act_global_catalog WHERE act_key = ?', [key]);
    actIds.set(key, row.id);
  }
  await logImport(db, runId, 'dental_act', 'updated', null, 'dental_act_global_catalog', { count: dentalActs.length });

  const allDentalActPrices = buildDentalActPriceRows();
  for (const row of allDentalActPrices) {
    const [key, country, currency, priceType, min, avg, max, rate, sourceName] = row;
    const actId = actIds.get(key);
    await upsert(db, `INSERT INTO dental_act_price_references
      (act_id, country, currency, price_type, price_min, price_avg, price_max, reimbursement_rate,
       source_name, source_file, source_page, observed_at, effective_date, confidence_score, validation_status)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, '1-15', '2026-07-05 00:00:00', '2026-07-05', 0.68, 'candidate')
      ON DUPLICATE KEY UPDATE
        price_min = IF(validation_status = 'validated', price_min, VALUES(price_min)),
        price_avg = IF(validation_status = 'validated', price_avg, VALUES(price_avg)),
        price_max = IF(validation_status = 'validated', price_max, VALUES(price_max)),
        reimbursement_rate = IF(validation_status = 'validated', reimbursement_rate, VALUES(reimbursement_rate)),
        confidence_score = VALUES(confidence_score)`,
      [actId, country, currency, priceType, min, avg, max, rate, sourceName, SOURCE_FILES.dentalActPrices]);
  }
  await logImport(db, runId, 'dental_act_price', 'updated', null, 'dental_act_price_references', { count: allDentalActPrices.length });

  const allLabActPrices = buildLabActPriceRows();
  for (const row of allLabActPrices) {
    const [key, name, country, currency, priceType, min, avg, max, usd] = row;
    await upsert(db, `INSERT INTO lab_act_price_references
      (act_key, act_name, country, currency, price_type, price_min, price_avg, price_max, price_usd,
       source_name, source_file, source_page, confidence_score, validation_status)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'Benchmark prix actes labo', ?, '1-9', 0.72, 'candidate')
      ON DUPLICATE KEY UPDATE
        price_min = IF(validation_status = 'validated', price_min, VALUES(price_min)),
        price_avg = IF(validation_status = 'validated', price_avg, VALUES(price_avg)),
        price_max = IF(validation_status = 'validated', price_max, VALUES(price_max)),
        price_usd = IF(validation_status = 'validated', price_usd, VALUES(price_usd))`,
      [key, name, country, currency, priceType, min, avg, max, usd, SOURCE_FILES.labActPrices]);
  }
  await logImport(db, runId, 'lab_act_price', 'updated', null, 'lab_act_price_references', { count: allLabActPrices.length });

  await detectPriceConflicts(db, runId, summary);
  await logAudit(db, req, { action: 'REFERENCE_PACK_IMPORT', entity_type: 'reference_catalog', entity_id: runId, details: summary });
  summary.updated = labConsumables.length + allProductPrices.length + allDentalActPrices.length + allLabActPrices.length;
  return summary;
}

async function detectPriceConflicts(db, runId, summary) {
  const [prices] = await db.query(`SELECT * FROM international_price_references WHERE validation_status IN ('candidate','conflict')`);
  const [products] = await db.query(`SELECT id, name, package_price_tnd, package_quantity, tracking_unit FROM inventory_products WHERE is_active = 1`);
  for (const price of prices) {
    const product = products.find(p => normalizeName(p.name) === normalizeName(price.candidate_name));
    if (!product || !product.package_price_tnd || !product.package_quantity || !price.price_usd) continue;
    const cabinetUsdEstimate = Number(product.package_price_tnd) / Math.max(Number(product.package_quantity), 1) / 3.05;
    const refUsd = Number(price.price_usd);
    if (!Number.isFinite(cabinetUsdEstimate) || !Number.isFinite(refUsd) || refUsd <= 0) continue;
    const ratio = Math.abs(cabinetUsdEstimate - refUsd) / refUsd;
    if (ratio >= 0.5) {
      await db.query(`INSERT INTO international_price_conflicts
        (entity_type, entity_id, candidate_name, country, field_name, current_value, candidate_value, conflict_reason, severity, source_name)
        VALUES (?, ?, ?, ?, 'price_usd', ?, ?, 'Ecart superieur a 50% avec prix reel cabinet estime', 'warning', ?)
        ON DUPLICATE KEY UPDATE candidate_value = VALUES(candidate_value), status = IF(status = 'resolved', status, 'pending')`,
        [price.entity_type, product.id, price.candidate_name, price.country, cabinetUsdEstimate.toFixed(3), refUsd.toFixed(3), price.source_name]);
      summary.conflicts += 1;
    }
  }
  await logImport(db, runId, 'price_conflict', 'conflict', null, 'international_price_conflicts', { conflicts: summary.conflicts });
}

function addFilters(params, query, mapping) {
  const where = [];
  const values = [];
  for (const [key, column] of Object.entries(mapping)) {
    if (query[key]) {
      where.push(`${column} = ?`);
      values.push(query[key]);
    }
  }
  if (query.q) {
    where.push('(canonical_name LIKE ? OR candidate_name LIKE ? OR act_name LIKE ? OR category LIKE ?)');
    const like = `%${query.q}%`;
    values.push(like, like, like, like);
  }
  return { clause: where.length ? `WHERE ${where.join(' AND ')}` : '', values, limit: Math.min(Number(query.limit || 200), 500) };
}

async function listLabConsumables(db, query) {
  const where = [];
  const values = [];
  if (query.status) { where.push('validation_status = ?'); values.push(query.status); }
  if (query.category) { where.push('category = ?'); values.push(query.category); }
  if (query.source) { where.push('source_name = ?'); values.push(query.source); }
  if (query.q) { where.push('(canonical_name LIKE ? OR category LIKE ? OR subcategory LIKE ?)'); const like = `%${query.q}%`; values.push(like, like, like); }
  const limit = Math.min(Number(query.limit || 200), 500);
  const [rows] = await db.query(`SELECT * FROM lab_consumable_reference ${where.length ? `WHERE ${where.join(' AND ')}` : ''} ORDER BY category, canonical_name LIMIT ?`, [...values, limit]);
  return rows;
}

async function listInternationalPrices(db, query) {
  const where = [];
  const values = [];
  if (query.status) { where.push('validation_status = ?'); values.push(query.status); }
  if (query.country) { where.push('country = ?'); values.push(query.country); }
  if (query.category) { where.push('category = ?'); values.push(query.category); }
  if (query.source) { where.push('source_name = ?'); values.push(query.source); }
  if (query.q) { where.push('(candidate_name LIKE ? OR category LIKE ? OR brand LIKE ?)'); const like = `%${query.q}%`; values.push(like, like, like); }
  const limit = Math.min(Number(query.limit || 200), 500);
  const [rows] = await db.query(`SELECT * FROM international_price_references ${where.length ? `WHERE ${where.join(' AND ')}` : ''} ORDER BY country, candidate_name LIMIT ?`, [...values, limit]);
  return rows;
}

async function listDentalActPrices(db, query) {
  const where = [];
  const values = [];
  if (query.status) { where.push('p.validation_status = ?'); values.push(query.status); }
  if (query.country) { where.push('p.country = ?'); values.push(query.country); }
  if (query.category) { where.push('a.family = ?'); values.push(query.category); }
  if (query.q) { where.push('(a.act_name LIKE ? OR a.family LIKE ? OR p.price_type LIKE ?)'); const like = `%${query.q}%`; values.push(like, like, like); }
  const limit = Math.min(Number(query.limit || 200), 500);
  const [rows] = await db.query(`SELECT p.*, a.act_key, a.act_name, a.family, a.modernity_status
    FROM dental_act_price_references p
    JOIN dental_act_global_catalog a ON a.id = p.act_id
    ${where.length ? `WHERE ${where.join(' AND ')}` : ''}
    ORDER BY p.country, a.act_name LIMIT ?`, [...values, limit]);
  return rows;
}

async function listLabActPrices(db, query) {
  const where = [];
  const values = [];
  if (query.status) { where.push('validation_status = ?'); values.push(query.status); }
  if (query.country) { where.push('country = ?'); values.push(query.country); }
  if (query.q) { where.push('(act_name LIKE ? OR act_key LIKE ?)'); const like = `%${query.q}%`; values.push(like, like); }
  const limit = Math.min(Number(query.limit || 200), 500);
  const [rows] = await db.query(`SELECT * FROM lab_act_price_references ${where.length ? `WHERE ${where.join(' AND ')}` : ''} ORDER BY country, act_name LIMIT ?`, [...values, limit]);
  return rows;
}

async function listReferenceConflicts(db) {
  const [referenceConflicts] = await db.query(`SELECT id, 'reference_conflicts' AS source_table, entity_type, field_name, current_value, new_value AS candidate_value, severity, status, created_at FROM reference_conflicts ORDER BY status = 'pending' DESC, created_at DESC LIMIT 100`);
  const [priceConflicts] = await db.query(`SELECT id, 'international_price_conflicts' AS source_table, entity_type, field_name, current_value, candidate_value, severity, status, created_at FROM international_price_conflicts ORDER BY status = 'pending' DESC, created_at DESC LIMIT 100`);
  const [actConflicts] = await db.query(`SELECT id, 'dental_act_price_conflicts' AS source_table, 'dental_act_price' AS entity_type, price_type AS field_name, current_value, candidate_value, severity, status, created_at FROM dental_act_price_conflicts ORDER BY status = 'pending' DESC, created_at DESC LIMIT 100`);
  return [...referenceConflicts, ...priceConflicts, ...actConflicts];
}

async function listImportLogs(db) {
  const [rows] = await db.query(`SELECT * FROM dental_act_price_import_logs ORDER BY created_at DESC LIMIT 200`);
  return rows;
}

async function updateValidation(db, table, id, status, req) {
  const allowedTables = new Set(['lab_consumable_reference', 'international_price_references', 'dental_act_price_references', 'lab_act_price_references']);
  const allowedStatuses = new Set(['candidate', 'validated', 'rejected', 'conflict']);
  if (!allowedTables.has(table) || !allowedStatuses.has(status)) throw new Error('Validation non autorisee.');
  await db.query(`UPDATE ${table} SET validation_status = ? WHERE id = ?`, [status, id]);
  await logAudit(db, req, { action: `REFERENCE_${status.toUpperCase()}`, entity_type: table, entity_id: id, details: { status } });
  const [[row]] = await db.query(`SELECT * FROM ${table} WHERE id = ?`, [id]);
  return row;
}

async function resolveConflict(db, id, sourceTable, status, req) {
  const allowedTables = new Set(['international_price_conflicts', 'dental_act_price_conflicts', 'reference_conflicts']);
  const allowedStatuses = new Set(['accepted', 'rejected', 'resolved', 'pending']);
  if (!allowedTables.has(sourceTable) || !allowedStatuses.has(status)) throw new Error('Resolution non autorisee.');
  await db.query(`UPDATE ${sourceTable} SET status = ?, resolved_at = CASE WHEN ? = 'pending' THEN NULL ELSE NOW() END WHERE id = ?`, [status, status, id]);
  await logAudit(db, req, { action: 'REFERENCE_CONFLICT_RESOLVE', entity_type: sourceTable, entity_id: id, details: { status } });
  const [[row]] = await db.query(`SELECT * FROM ${sourceTable} WHERE id = ?`, [id]);
  return row;
}

async function createProductCandidate(db, sourceTable, sourceId, req) {
  const allowed = {
    lab_consumable_reference: 'SELECT canonical_name AS name, category, context_type, purchase_unit, storage_unit, packaging, price_min, price_max, price_currency FROM lab_consumable_reference WHERE id = ?',
    international_price_references: 'SELECT candidate_name AS name, category, entity_type, unit, packaging, price_avg, currency FROM international_price_references WHERE id = ?',
  };
  if (!allowed[sourceTable]) throw new Error('Source non autorisee.');
  const [[source]] = await db.query(allowed[sourceTable], [sourceId]);
  if (!source) return null;
  const context = source.context_type || (source.entity_type === 'lab_consumable' ? 'LAB' : 'CABINET');
  const proposal = {
    name: source.name,
    category: source.category || 'A classer',
    tracking_unit: source.storage_unit || source.unit || 'unite',
    package_unit: source.purchase_unit || source.unit || null,
    packaging: source.packaging || null,
    reference_price: source.price_avg || source.price_min || null,
    currency: source.price_currency || source.currency || null,
    validation_required: true,
  };
  await db.query(`INSERT INTO reference_product_candidates
    (source_table, source_id, candidate_name, category, context_type, proposal_json, created_by)
    VALUES (?, ?, ?, ?, ?, ?, ?)
    ON DUPLICATE KEY UPDATE proposal_json = VALUES(proposal_json), status = IF(status = 'converted', status, 'candidate')`,
    [sourceTable, sourceId, source.name, proposal.category, context, JSON.stringify(proposal), req?.user?.username || req?.user?.role || 'admin']);
  const [[row]] = await db.query('SELECT * FROM reference_product_candidates WHERE source_table = ? AND source_id = ?', [sourceTable, sourceId]);
  await logAudit(db, req, { action: 'REFERENCE_PRODUCT_CANDIDATE_CREATE', entity_type: sourceTable, entity_id: sourceId, details: proposal });
  return row;
}

async function createAlias(db, entityType, canonicalId, aliasName, country, req) {
  const allowed = new Set(['act', 'consumable', 'brand', 'supplier', 'rule']);
  if (!allowed.has(entityType)) throw new Error('Type alias non autorise.');
  await db.query(`INSERT INTO reference_aliases
    (entity_type, canonical_id, alias_name, normalized_alias, country, confidence_score, validated_by_user)
    VALUES (?, ?, ?, ?, ?, 0.7000, 1)
    ON DUPLICATE KEY UPDATE validated_by_user = 1, confidence_score = GREATEST(confidence_score, VALUES(confidence_score))`,
    [entityType, canonicalId || null, aliasName, normalizeName(aliasName), country || null]);
  await logAudit(db, req, { action: 'REFERENCE_ALIAS_CREATE', entity_type: entityType, entity_id: canonicalId, details: { aliasName, country } });
  return { ok: true };
}

async function getReferenceDashboard(db) {
  const [[lab]] = await db.query(`SELECT COUNT(*) total, SUM(validation_status='candidate') candidates, SUM(validation_status='validated') validated, SUM(validation_status='conflict') conflicts FROM lab_consumable_reference`);
  const [[prices]] = await db.query(`SELECT COUNT(*) total, SUM(validation_status='candidate') candidates, SUM(validation_status='validated') validated, SUM(validation_status='conflict') conflicts FROM international_price_references`);
  const [[acts]] = await db.query(`SELECT COUNT(*) total, SUM(validation_status='candidate') candidates, SUM(validation_status='validated') validated, SUM(validation_status='conflict') conflicts FROM dental_act_price_references`);
  const [[labActs]] = await db.query(`SELECT COUNT(*) total, SUM(validation_status='candidate') candidates, SUM(validation_status='validated') validated, SUM(validation_status='conflict') conflicts FROM lab_act_price_references`);
  const [[conflicts]] = await db.query(`SELECT
    (SELECT COUNT(*) FROM international_price_conflicts WHERE status='pending') +
    (SELECT COUNT(*) FROM dental_act_price_conflicts WHERE status='pending') +
    (SELECT COUNT(*) FROM reference_conflicts WHERE status='pending') AS pending`);
  return { lab, prices, acts, labActs, conflicts };
}

module.exports = {
  importReferencePack,
  listLabConsumables,
  listInternationalPrices,
  listDentalActPrices,
  listLabActPrices,
  listReferenceConflicts,
  listImportLogs,
  updateValidation,
  resolveConflict,
  createProductCandidate,
  createAlias,
  getReferenceDashboard,
};
