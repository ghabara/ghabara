import { useEffect, useState } from 'react';
import { adminApi } from '../api';

const tabLabels = [
  ['acts', 'Referentiel actes'],
  ['products', 'Referentiel produits'],
  ['recipes', 'Consommations par acte'],
  ['logs', 'Journaux'],
];

const endpoints = {
  acts: '/act-product-catalog/acts',
  products: '/act-product-catalog/products',
  recipes: '/act-product-catalog/recipes',
  logs: '/act-product-catalog/logs',
};

export default function ActProductCatalogPanel({ initialTab = 'acts' }) {
  const [tab, setTab] = useState(initialTab);
  const [rows, setRows] = useState([]);
  const [dashboard, setDashboard] = useState(null);
  const [filters, setFilters] = useState({ q: '', family: '', category: '', status: '' });
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  useEffect(() => { setTab(initialTab); }, [initialTab]);

  const load = async (nextTab = tab) => {
    setBusy(true);
    setError('');
    try {
      const params = nextTab === 'logs' ? {} : clean({ ...filters, limit: nextTab === 'recipes' ? 300 : 250 });
      const [dashboardResponse, rowsResponse] = await Promise.all([
        adminApi.get('/act-product-catalog/dashboard'),
        adminApi.get(endpoints[nextTab], { params }),
      ]);
      setDashboard(dashboardResponse.data);
      setRows(Array.isArray(rowsResponse.data) ? rowsResponse.data : []);
    } catch (e) {
      setError(e.response?.data?.error || 'Referentiel actes-produits indisponible.');
    } finally {
      setBusy(false);
    }
  };

  useEffect(() => { load(tab); }, [tab]);

  const importCatalog = async () => {
    setBusy(true);
    setError('');
    setMessage('');
    try {
      const { data } = await adminApi.post('/act-product-catalog/import');
      setMessage(`Import termine : ${data.acts || 0} actes, ${data.products || 0} produits, ${data.recipes || 0} lignes de consommation, ${data.costed_recipes || 0} couts estimes, ${data.conflicts || 0} conflits.`);
      await load(tab);
    } catch (e) {
      setError(e.response?.data?.error || 'Import impossible.');
    } finally {
      setBusy(false);
    }
  };

  const doAction = async (path, label) => {
    setError('');
    setMessage('');
    try {
      await adminApi.post(path, {});
      setMessage(label);
      await load(tab);
    } catch (e) {
      setError(e.response?.data?.error || 'Action impossible.');
    }
  };

  return (
    <>
      <PanelTitle sub="Bibliotheque candidate : acte dentaire -> produits utilises -> consommation moyenne -> cout matiere.">
        {tab === 'products' ? 'Referentiel produits' : tab === 'recipes' ? 'Consommations par acte' : 'Referentiel actes'}
      </PanelTitle>
      {error && <div className="alert error">{error}</div>}
      {message && <div className="alert success">{message}</div>}

      <div className="card" style={{ marginBottom: 16 }}>
        <div className="dashboard-line">
          <div>
            <strong>Inventaire complet, en validation humaine</strong>
            <p className="muted" style={{ margin: '4px 0 0' }}>
              Les lignes restent candidates. Elles ne creent pas de stock reel et ne deduisent rien sans validation.
            </p>
          </div>
          <button className="btn btn-primary" disabled={busy} onClick={importCatalog}>
            {busy ? 'Traitement...' : 'Importer / mettre a jour'}
          </button>
        </div>
        <div className="dashboard-grid" style={{ marginTop: 16 }}>
          <MiniKpi label="Actes reference" value={dashboard?.acts?.total} hint={`${count(dashboard?.acts?.candidates)} candidats`} />
          <MiniKpi label="Produits reference" value={dashboard?.products?.total} hint={`${count(dashboard?.products?.candidates)} candidats`} />
          <MiniKpi label="Lignes consommation" value={dashboard?.recipes?.total} hint={`${count(dashboard?.recipes?.pending)} a valider`} />
          <MiniKpi label="Conflits recette" value={dashboard?.recipes?.conflicts} hint="a revoir" />
        </div>
      </div>

      <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 14 }}>
        {tabLabels.map(([key, label]) => (
          <button key={key} className={tab === key ? 'btn btn-primary' : 'btn btn-secondary'} onClick={() => setTab(key)}>
            {label}
          </button>
        ))}
      </div>

      {tab !== 'logs' && (
        <div className="card" style={{ marginBottom: 14 }}>
          <div className="form-grid">
            <div className="fg">
              <label>Recherche</label>
              <input value={filters.q} onChange={e => setFilters({ ...filters, q: e.target.value })} placeholder="Acte, produit, famille..." />
            </div>
            <div className="fg">
              <label>Famille acte</label>
              <input value={filters.family} onChange={e => setFilters({ ...filters, family: e.target.value })} placeholder="Endodontie, Prothese..." />
            </div>
            <div className="fg">
              <label>Categorie produit</label>
              <input value={filters.category} onChange={e => setFilters({ ...filters, category: e.target.value })} placeholder="Restauration, EPI..." />
            </div>
            <div className="fg">
              <label>Statut</label>
              <select value={filters.status} onChange={e => setFilters({ ...filters, status: e.target.value })}>
                <option value="">Tous</option>
                <option value="candidate">Candidat</option>
                <option value="pending">A valider</option>
                <option value="validated">Valide</option>
                <option value="rejected">Rejete</option>
                <option value="conflict">Conflit</option>
              </select>
            </div>
          </div>
          <button className="btn btn-secondary" disabled={busy} onClick={() => load(tab)} style={{ marginTop: 10 }}>
            Filtrer
          </button>
        </div>
      )}

      {tab === 'acts' && <ActsTable rows={rows} onAction={doAction} />}
      {tab === 'products' && <ProductsTable rows={rows} onAction={doAction} />}
      {tab === 'recipes' && <RecipesTable rows={rows} onAction={doAction} />}
      {tab === 'logs' && <LogsTable rows={rows} />}
    </>
  );
}

function PanelTitle({ children, sub }) {
  return (
    <div style={{ marginBottom: 22 }}>
      <h2 className="section-title">{children}</h2>
      {sub && <p className="muted">{sub}</p>}
    </div>
  );
}

function MiniKpi({ label, value, hint }) {
  return (
    <div className="kpi-card">
      <span className="kpi-value">{count(value)}</span>
      <span className="kpi-label">{label}</span>
      <span className="kpi-hint">{hint}</span>
    </div>
  );
}

function ActsTable({ rows, onAction }) {
  return (
    <div className="table-wrap">
      <table>
        <thead><tr><th>Acte</th><th>Famille</th><th>Nomenclature</th><th>Statut</th><th>Actions</th></tr></thead>
        <tbody>
          {rows.map(row => (
            <tr key={row.id}>
              <td><strong>{row.act_name}</strong><br /><small className="muted">{row.clinical_context || '-'}</small></td>
              <td>{row.family}<br /><small className="muted">{row.subfamily || '-'}</small></td>
              <td>{row.nomenclature_status}<br /><small className="muted">{row.modernity_status}</small></td>
              <td>{status(row.validation_status)}</td>
              <td style={{ minWidth: 200 }}>
                <button className="btn btn-green" onClick={() => onAction(`/act-product-catalog/acts/${row.id}/validate`, 'Acte reference valide.')}>Valider</button>{' '}
                <button className="btn btn-secondary" onClick={() => onAction(`/act-product-catalog/acts/${row.id}/reject`, 'Acte reference rejete.')}>Rejeter</button>
              </td>
            </tr>
          ))}
          {!rows.length && <Empty columns={5} text="Aucun acte reference." />}
        </tbody>
      </table>
    </div>
  );
}

function ProductsTable({ rows, onAction }) {
  return (
    <div className="table-wrap">
      <table>
        <thead><tr><th>Produit</th><th>Categorie</th><th>Unite</th><th>Contexte</th><th>Statut</th><th>Actions</th></tr></thead>
        <tbody>
          {rows.map(row => (
            <tr key={row.id}>
              <td><strong>{row.product_name}</strong><br /><small className="muted">{row.typical_package || '-'}</small></td>
              <td>{row.category}<br /><small className="muted">{row.subcategory || '-'}</small></td>
              <td>{row.tracking_unit}</td>
              <td>{row.context_type}</td>
              <td>{status(row.validation_status)}</td>
              <td style={{ minWidth: 360 }}>
                <button className="btn btn-green" onClick={() => onAction(`/act-product-catalog/products/${row.id}/validate`, 'Produit reference valide.')}>Valider</button>{' '}
                <button className="btn btn-secondary" onClick={() => onAction(`/act-product-catalog/products/${row.id}/reject`, 'Produit reference rejete.')}>Rejeter</button>{' '}
                <button className="btn btn-secondary" onClick={() => onAction(`/act-product-catalog/products/${row.id}/create-real-product`, 'Candidat produit reel prepare, sans stock reel cree.')}>Creer produit reel depuis reference</button>
              </td>
            </tr>
          ))}
          {!rows.length && <Empty columns={6} text="Aucun produit reference." />}
        </tbody>
      </table>
    </div>
  );
}

function RecipesTable({ rows, onAction }) {
  return (
    <div className="table-wrap">
      <table>
        <thead><tr><th>Acte</th><th>Produit</th><th>Consommation</th><th>Cout estime</th><th>Obligatoire</th><th>Confiance</th><th>Statut</th><th>Actions</th></tr></thead>
        <tbody>
          {rows.map(row => (
            <tr key={row.id}>
              <td><strong>{row.act_name}</strong><br /><small className="muted">{row.family}</small></td>
              <td>{row.product_name}<br /><small className="muted">{row.category}</small></td>
              <td>{range(row.consumption_min, row.consumption_typical, row.consumption_max, row.unit)}</td>
              <td>{costBlock(row)}</td>
              <td>{row.required ? 'Oui' : 'Optionnel'}</td>
              <td>{row.confidence_level}</td>
              <td>{status(row.validation_status)}</td>
              <td style={{ minWidth: 200 }}>
                <button className="btn btn-green" onClick={() => onAction(`/act-product-catalog/recipes/${row.id}/validate`, 'Recette candidate validee.')}>Valider</button>{' '}
                <button className="btn btn-secondary" onClick={() => onAction(`/act-product-catalog/recipes/${row.id}/reject`, 'Recette candidate rejetee.')}>Rejeter</button>
              </td>
            </tr>
          ))}
          {!rows.length && <Empty columns={8} text="Aucune recette candidate." />}
        </tbody>
      </table>
    </div>
  );
}

function LogsTable({ rows }) {
  return (
    <div className="table-wrap">
      <table>
        <thead><tr><th>Date</th><th>Run</th><th>Operation</th><th>Type</th><th>Libelle</th><th>Details</th></tr></thead>
        <tbody>
          {rows.map(row => (
            <tr key={row.id}>
              <td className="muted">{formatDate(row.created_at)}</td>
              <td>{row.run_id}</td>
              <td>{row.operation}</td>
              <td>{row.entity_type}</td>
              <td>{row.label || '-'}</td>
              <td className="muted">{shortJson(row.details_json)}</td>
            </tr>
          ))}
          {!rows.length && <Empty columns={6} text="Aucun journal." />}
        </tbody>
      </table>
    </div>
  );
}

function Empty({ columns, text }) {
  return <tr><td colSpan={columns} className="center muted" style={{ padding: 24 }}>{text}</td></tr>;
}

function clean(params) {
  return Object.fromEntries(Object.entries(params).filter(([, value]) => value !== '' && value !== null && value !== undefined));
}

function count(value) {
  const n = Number(value || 0);
  return Number.isFinite(n) ? n : 0;
}

function status(value) {
  const map = { candidate: 'Candidat', pending: 'A valider', validated: 'Valide', rejected: 'Rejete', conflict: 'Conflit' };
  return map[value] || value || '-';
}

function formatDate(value) {
  if (!value) return '-';
  try { return new Date(value).toLocaleString('fr-FR'); }
  catch { return value; }
}

function shortJson(value) {
  if (!value) return '-';
  try {
    const parsed = typeof value === 'string' ? JSON.parse(value) : value;
    return Object.entries(parsed).slice(0, 4).map(([key, val]) => `${key}: ${val}`).join(', ');
  } catch {
    return String(value).slice(0, 140);
  }
}

function trim(value) {
  const n = Number(value);
  if (!Number.isFinite(n)) return '-';
  return n.toFixed(4).replace(/0+$/, '').replace(/\.$/, '');
}

function range(min, typical, max, unit) {
  const left = min === null || min === undefined ? '?' : trim(min);
  const middle = typical === null || typical === undefined ? '?' : trim(typical);
  const right = max === null || max === undefined ? '?' : trim(max);
  return `${left} - ${middle} - ${right} ${unit || ''}`;
}

function money(value) {
  if (value === null || value === undefined || value === '') return null;
  const n = Number(value);
  if (!Number.isFinite(n)) return null;
  return `${n.toFixed(3)} TND`;
}

function costBlock(row) {
  const typical = money(row.estimated_cost_tnd_typical);
  if (!typical) {
    return (
      <>
        <span>-</span><br />
        <small className="muted">{row.unit_cost_source || 'Prix/conditionnement a completer'}</small>
      </>
    );
  }
  const min = money(row.estimated_cost_tnd_min);
  const max = money(row.estimated_cost_tnd_max);
  const source = row.unit_cost_status === 'real_stock' ? 'Prix reel stock' : 'Prix indicatif a valider';
  return (
    <>
      <strong>{typical}</strong><br />
      <small className="muted">{min || '?'} - {max || '?'} - {source}</small>
    </>
  );
}
