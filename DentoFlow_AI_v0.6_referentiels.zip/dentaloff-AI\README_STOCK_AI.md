﻿# DentoFlow AI Pilotage & Stock AI

Moteur de pilotage du cabinet integre a l'administration DentoFlow AI. Le stock reste central, mais il sert surtout a relier actes, consommations, couts, achats, lots et alertes avant rupture.

## Principe

```text
RDV -> acte realise -> recette par acte -> consommation automatique -> cout matiere -> mouvements -> lots/peremption -> liste d'achat -> alertes -> cockpit cabinet
```

L'assistant IA est local et deterministe : il analyse des textes libres, prepare des brouillons et propose des alertes. Il ne modifie pas le stock sans validation humaine.

## Objectif metier

Savoir ce que chaque acte consomme, combien il coute, et quoi acheter avant d'etre en rupture.

## Ecrans

- Cockpit cabinet : indicateurs patients, RDV, actes, cout matiere, achats, alertes, labo.
- Produits : catalogue, conditionnement, prix, seuils, fournisseur, lot, peremption.
- Actes : actes cliniques, prix, duree, variantes.
- Recettes : consommables par acte, quantite, unite, niveau de confiance.
- Actes realises : deduction de stock et cout matiere.
- Achats : reception, fournisseur, facture, mise a jour prix/lot/peremption.
- Liste d'achat : priorites, quantites recommandees et justification.
- Pilotage IA : risque rupture, peremption, surstock, couverture, budget achat suggere.
- Alertes IA : stock bas, peremption proche, prix manquant, recettes incompletes.
- Assistant local : commandes naturelles et previsions.
- Laboratoire : cas labo, statuts, cout externe et retards.

## Routes principales

- `GET /api/pilotage/overview`
- `GET /api/inventory/dashboard`
- `GET /api/inventory/insights`
- `GET /api/ai/inventory-insights`
- `GET|POST /api/inventory/products`
- `GET|POST /api/clinical-acts`
- `GET|POST /api/recipes`
- `GET|POST /api/performed-acts`
- `GET|POST /api/purchases`
- `GET /api/shopping-list`
- `GET /api/ai/forecast`
- `POST /api/ai/normalize-product`
- `POST /api/ai/parse-command`
- `GET /api/lab/overview`

## Base de donnees

- `database/dentaloff_ai.sql` : base principale.
- `database/stock_ai_migration.sql` : tables Stock AI.
- `database/pilotage_intelligent_migration.sql` : audit, lots, plans de traitement, labo enrichi.
- `database/stock_ai_demo_seed.sql` : produits, actes et recettes de demonstration.

## Roles

- `admin` : lecture, achats, liste d'achat, alertes, assistant local.
- `docteur` : toutes les actions admin + creation/modification produits, actes et recettes sensibles.

## Tests conseilles

```bash
cd client
npm run build

cd ../server
npm run check
```
