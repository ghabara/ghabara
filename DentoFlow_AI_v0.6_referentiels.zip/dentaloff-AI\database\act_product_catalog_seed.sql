USE dentaloff_ai;

INSERT INTO dental_act_catalog
  (act_key, act_name, family, subfamily, clinical_context, nomenclature_status, modernity_status, context_type, source_name, validation_status)
VALUES
  ('obturation_1_face', 'Composite 1 face / classe I simple', 'Soins conservateurs', 'Obturation simple', 'Restauration composite simple', 'cnam_tn_known', 'standard', 'CABINET', 'Seed SQL actes-produits', 'candidate'),
  ('obturation_2_faces', 'Composite 2 faces / classe II', 'Soins conservateurs', 'Obturation composee', 'Composite avec matrice, coin et collage', 'cnam_tn_known', 'standard', 'CABINET', 'Seed SQL actes-produits', 'candidate'),
  ('endo_molaire', 'Traitement endodontique molaire', 'Endodontie', 'Traitement canalaire', 'Molaire, plusieurs canaux', 'standard', 'specialized', 'CABINET', 'Seed SQL actes-produits', 'candidate'),
  ('extraction_simple', 'Extraction simple', 'Chirurgie orale', 'Extraction', 'Extraction avec anesthesie et compression', 'cnam_tn_known', 'standard', 'CABINET', 'Seed SQL actes-produits', 'candidate'),
  ('detartrage_sus_gingival', 'Detartrage sus-gingival', 'Prevention', 'Hygiene', 'Detartrage, polissage et controle plaque', 'standard', 'standard', 'CABINET', 'Seed SQL actes-produits', 'candidate'),
  ('empreinte_alginate', 'Empreinte alginate complete', 'Prothese fixe', 'Empreinte', 'Empreinte complete alginate', 'standard', 'standard', 'CABINET', 'Seed SQL actes-produits', 'candidate'),
  ('couronne_ceramique', 'Couronne ceramique', 'Prothese fixe', 'Couronne', 'Preparation, empreinte ou scan, provisoire, collage', 'standard', 'standard', 'CABINET', 'Seed SQL actes-produits', 'candidate'),
  ('implant_unitaire', 'Pose implant unitaire', 'Implantologie', 'Chirurgie', 'Forage, implant, vis de couverture', 'modern_out_of_nomenclature', 'specialized', 'CABINET', 'Seed SQL actes-produits', 'candidate')
ON DUPLICATE KEY UPDATE
  act_name = IF(validation_status = 'validated', act_name, VALUES(act_name)),
  family = IF(validation_status = 'validated', family, VALUES(family));

INSERT INTO dental_product_catalog
  (product_key, product_name, category, subcategory, tracking_unit, typical_package, context_type, risk_level, source_name, validation_status)
VALUES
  ('gants_nitrile', 'Gants nitrile', 'EPI et barrieres', 'Gants', 'paire', 'boite 100', 'CABINET', 'low', 'Seed SQL actes-produits', 'candidate'),
  ('masque_chirurgical', 'Masque chirurgical', 'EPI et barrieres', 'Masques', 'unite', 'boite 50', 'CABINET', 'low', 'Seed SQL actes-produits', 'candidate'),
  ('bavoir_patient', 'Bavoir patient', 'EPI et barrieres', 'Protection patient', 'unite', 'paquet', 'CABINET', 'low', 'Seed SQL actes-produits', 'candidate'),
  ('canule_aspiration', 'Canule aspiration salivaire', 'Aspiration et absorbants', 'Aspiration', 'unite', 'sachet', 'CABINET', 'low', 'Seed SQL actes-produits', 'candidate'),
  ('carpule_anesthesie', 'Anesthesie carpule', 'Anesthesie', 'Carpules', 'carpule', 'boite 50', 'CABINET', 'high', 'Seed SQL actes-produits', 'candidate'),
  ('aiguille_dentaire', 'Aiguille dentaire', 'Anesthesie', 'Aiguilles', 'unite', 'boite 100', 'CABINET', 'high', 'Seed SQL actes-produits', 'candidate'),
  ('acide_ortho', 'Acide orthophosphorique 37%', 'Restauration', 'Mordancage', 'ml', 'seringue', 'CABINET', 'medium', 'Seed SQL actes-produits', 'candidate'),
  ('adhesif_bonding', 'Adhesif / bonding universel', 'Restauration', 'Adhesion', 'ml', 'flacon 5 ml', 'CABINET', 'medium', 'Seed SQL actes-produits', 'candidate'),
  ('microbrush', 'Microbrush / micro-applicateur', 'Restauration', 'Applicateurs', 'unite', 'boite', 'CABINET', 'low', 'Seed SQL actes-produits', 'candidate'),
  ('composite_seringue', 'Composite seringue', 'Restauration', 'Composite', 'g', 'seringue 3-4 g', 'CABINET', 'medium', 'Seed SQL actes-produits', 'candidate'),
  ('matrice_sectionnelle', 'Matrice sectionnelle', 'Restauration', 'Matrices', 'unite', 'boite', 'CABINET', 'medium', 'Seed SQL actes-produits', 'candidate'),
  ('coin_interdentaire', 'Coin interdentaire', 'Restauration', 'Coins', 'unite', 'boite', 'CABINET', 'low', 'Seed SQL actes-produits', 'candidate'),
  ('digue', 'Digue dentaire', 'Endodontie', 'Isolation', 'unite', 'boite', 'CABINET', 'medium', 'Seed SQL actes-produits', 'candidate'),
  ('lime_niti', 'Lime NiTi rotative', 'Endodontie', 'Instruments', 'unite', 'set', 'CABINET', 'high', 'Seed SQL actes-produits', 'candidate'),
  ('naocl', 'Hypochlorite de sodium', 'Endodontie', 'Irrigation', 'ml', 'flacon', 'CABINET', 'medium', 'Seed SQL actes-produits', 'candidate'),
  ('pointe_papier', 'Pointes papier', 'Endodontie', 'Sechage', 'unite', 'boite', 'CABINET', 'medium', 'Seed SQL actes-produits', 'candidate'),
  ('gutta_percha', 'Gutta-percha', 'Endodontie', 'Obturation', 'unite', 'boite', 'CABINET', 'medium', 'Seed SQL actes-produits', 'candidate'),
  ('compresse_sterile', 'Compresses steriles', 'Chirurgie', 'Absorbants steriles', 'unite', 'boite', 'CABINET', 'medium', 'Seed SQL actes-produits', 'candidate'),
  ('alginate', 'Alginate empreinte', 'Empreinte', 'Alginate', 'g', 'sachet 450 g', 'CABINET', 'medium', 'Seed SQL actes-produits', 'candidate'),
  ('vps_silicone', 'Silicone empreinte VPS', 'Empreinte', 'VPS', 'ml', 'cartouche 50 ml', 'CABINET', 'medium', 'Seed SQL actes-produits', 'candidate')
ON DUPLICATE KEY UPDATE
  product_name = IF(validation_status = 'validated', product_name, VALUES(product_name)),
  category = IF(validation_status = 'validated', category, VALUES(category));

INSERT INTO act_product_recipes
  (recipe_key, act_catalog_id, product_catalog_id, consumption_min, consumption_typical, consumption_max, unit, required, confidence_level, source_name, validation_status)
SELECT seed.recipe_key, a.id, p.id, seed.consumption_min, seed.consumption_typical, seed.consumption_max,
       seed.unit, seed.required, seed.confidence_level, 'Seed SQL actes-produits', 'pending'
FROM (
  SELECT 'obturation_2_faces:composite_seringue' recipe_key, 'obturation_2_faces' act_key, 'composite_seringue' product_key, 0.3000 consumption_min, 0.4000 consumption_typical, 0.5000 consumption_max, 'g' unit, 1 required, 'bonne' confidence_level
  UNION ALL SELECT 'obturation_2_faces:adhesif_bonding', 'obturation_2_faces', 'adhesif_bonding', 0.0500, 0.0750, 0.1000, 'ml', 1, 'moyenne'
  UNION ALL SELECT 'obturation_2_faces:acide_ortho', 'obturation_2_faces', 'acide_ortho', 0.0500, 0.0750, 0.1000, 'ml', 1, 'moyenne'
  UNION ALL SELECT 'obturation_2_faces:microbrush', 'obturation_2_faces', 'microbrush', 1.0000, 2.0000, 2.0000, 'unite', 1, 'moyenne'
  UNION ALL SELECT 'obturation_2_faces:matrice_sectionnelle', 'obturation_2_faces', 'matrice_sectionnelle', 1.0000, 1.0000, 1.0000, 'unite', 1, 'moyenne'
  UNION ALL SELECT 'obturation_2_faces:coin_interdentaire', 'obturation_2_faces', 'coin_interdentaire', 1.0000, 1.0000, 1.0000, 'unite', 1, 'moyenne'
  UNION ALL SELECT 'endo_molaire:digue', 'endo_molaire', 'digue', 1.0000, 1.0000, 1.0000, 'unite', 1, 'moyenne'
  UNION ALL SELECT 'endo_molaire:lime_niti', 'endo_molaire', 'lime_niti', 2.0000, 4.0000, 6.0000, 'unite', 1, 'moyenne'
  UNION ALL SELECT 'endo_molaire:naocl', 'endo_molaire', 'naocl', 10.0000, 25.0000, 50.0000, 'ml', 1, 'moyenne'
  UNION ALL SELECT 'endo_molaire:pointe_papier', 'endo_molaire', 'pointe_papier', 8.0000, 12.0000, 20.0000, 'unite', 1, 'moyenne'
  UNION ALL SELECT 'endo_molaire:gutta_percha', 'endo_molaire', 'gutta_percha', 4.0000, 8.0000, 14.0000, 'unite', 1, 'moyenne'
  UNION ALL SELECT 'extraction_simple:carpule_anesthesie', 'extraction_simple', 'carpule_anesthesie', 1.0000, 1.0000, 2.0000, 'carpule', 1, 'moyenne'
  UNION ALL SELECT 'extraction_simple:aiguille_dentaire', 'extraction_simple', 'aiguille_dentaire', 1.0000, 1.0000, 1.0000, 'unite', 1, 'moyenne'
  UNION ALL SELECT 'extraction_simple:compresse_sterile', 'extraction_simple', 'compresse_sterile', 2.0000, 4.0000, 6.0000, 'unite', 1, 'moyenne'
  UNION ALL SELECT 'empreinte_alginate:alginate', 'empreinte_alginate', 'alginate', 20.0000, 25.0000, 30.0000, 'g', 1, 'bonne'
  UNION ALL SELECT 'couronne_ceramique:vps_silicone', 'couronne_ceramique', 'vps_silicone', 15.0000, 20.0000, 30.0000, 'ml', 1, 'moyenne'
) seed
JOIN dental_act_catalog a ON a.act_key = seed.act_key
JOIN dental_product_catalog p ON p.product_key = seed.product_key
ON DUPLICATE KEY UPDATE
  consumption_min = IF(act_product_recipes.validation_status = 'validated', act_product_recipes.consumption_min, VALUES(consumption_min)),
  consumption_typical = IF(act_product_recipes.validation_status = 'validated', act_product_recipes.consumption_typical, VALUES(consumption_typical)),
  consumption_max = IF(act_product_recipes.validation_status = 'validated', act_product_recipes.consumption_max, VALUES(consumption_max));
