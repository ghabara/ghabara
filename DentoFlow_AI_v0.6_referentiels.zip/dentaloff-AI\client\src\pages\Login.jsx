﻿import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import api, { saveSession } from '../api';
import BrandLogo from '../components/BrandLogo.jsx';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [alert, setAlert] = useState(null);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const submit = async () => {
    setAlert(null);
    if (!email || !password) return setAlert({ type: 'error', msg: 'Veuillez remplir tous les champs.' });
    setLoading(true);
    try {
      const { data } = await api.post('/login', { email, password });
      saveSession(data.user, data.token);
      setAlert({ type: 'success', msg: 'Connexion réussie ! Redirection…' });
      setTimeout(() => navigate('/profil'), 900);
    } catch (e) {
      setAlert({ type: 'error', msg: e.response?.data?.error || 'Erreur de connexion.' });
      setLoading(false);
    }
  };

  return (
    <div className="dc">
      <div className="dc-formpage center">
        <div className="dc-halo">
          <div className="dc-card dc-reveal dc-d1" style={{ width: 430, maxWidth: '92vw' }}>
            <div className="dc-card-head">
              <Link to="/" className="brand-link"><BrandLogo className="brand-logo--login" /></Link>
              <span className="dc-eyebrow">Espace patient</span>
              <h2 style={{ marginTop: 12 }}>Heureux de vous revoir</h2>
              <p>Connectez-vous pour retrouver vos rendez-vous.</p>
            </div>

            {alert && <div className={`dc-alert ${alert.type}`}>{alert.msg}</div>}

            <div className="dc-field">
              <label>Adresse e-mail</label>
              <input type="email" value={email} onChange={e => setEmail(e.target.value)}
                     onKeyDown={e => e.key === 'Enter' && submit()} placeholder="vous@email.com" />
            </div>
            <div className="dc-field">
              <label>Mot de passe</label>
              <input type="password" value={password} onChange={e => setPassword(e.target.value)}
                     onKeyDown={e => e.key === 'Enter' && submit()} placeholder="••••••••" />
            </div>

            <button className="dc-btn dc-btn-solid dc-btn-block" onClick={submit} disabled={loading}>
              {loading ? 'Connexion…' : 'Se connecter'}
            </button>

            <p className="dc-switch">
              Pas encore de compte ? <Link to="/inscription">Créer un compte</Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
