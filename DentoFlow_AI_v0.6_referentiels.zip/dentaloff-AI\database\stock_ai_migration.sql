﻿USE dentaloff_ai;

CREATE TABLE IF NOT EXISTS inventory_products (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(160) NOT NULL,
  category VARCHAR(100) NOT NULL DEFAULT 'A classer',
  sub_category VARCHAR(120) NULL,
  tracking_unit VARCHAR(30) NOT NULL DEFAULT 'unite',
  package_quantity DECIMAL(12,4) NULL,
  package_unit VARCHAR(30) NULL,
  package_price_tnd DECIMAL(12,3) NULL,
  current_stock DECIMAL(12,4) NULL DEFAULT 0,
  min_stock DECIMAL(12,4) NULL DEFAULT 0,
  supplier_alias VARCHAR(120) NULL,
  supplier_lead_days INT NULL,
  expiration_date DATE NULL,
  lot_number VARCHAR(80) NULL,
  source_type VARCHAR(80) NOT NULL DEFAULT 'A completer',
  context_type ENUM('CABINET','LAB','BOTH') NOT NULL DEFAULT 'CABINET',
  notes TEXT NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_inventory_product_name (name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS clinical_acts (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  clinical_variant VARCHAR(120) NOT NULL DEFAULT 'Standard',
  category VARCHAR(100) NULL,
  default_duration_minutes INT NULL,
  default_price_tnd DECIMAL(12,3) NULL,
  context_type ENUM('CABINET','LAB') NOT NULL DEFAULT 'CABINET',
  notes TEXT NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_clinical_act_variant (name, clinical_variant)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS act_recipes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  act_id INT NOT NULL,
  product_id INT NOT NULL,
  recipe_variant VARCHAR(120) NOT NULL DEFAULT 'Standard',
  quantity_per_act DECIMAL(12,4) NOT NULL,
  unit VARCHAR(30) NOT NULL,
  measurement_mode VARCHAR(50) NOT NULL DEFAULT 'estimation',
  confidence VARCHAR(30) NOT NULL DEFAULT 'moyenne',
  measurement_count INT NOT NULL DEFAULT 0,
  source_note VARCHAR(255) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_act_recipe_variant (act_id, product_id, recipe_variant),
  CONSTRAINT fk_act_recipe_act FOREIGN KEY (act_id) REFERENCES clinical_acts(id) ON DELETE CASCADE,
  CONSTRAINT fk_act_recipe_product FOREIGN KEY (product_id) REFERENCES inventory_products(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS performed_acts (
  id INT AUTO_INCREMENT PRIMARY KEY,
  performed_date DATE NOT NULL,
  patient_id VARCHAR(12) NULL,
  patient_label VARCHAR(120) NOT NULL DEFAULT 'Patient anonymise',
  act_id INT NOT NULL,
  rdv_id INT NULL,
  estimated_total_cost_tnd DECIMAL(12,3) NULL,
  actual_total_cost_tnd DECIMAL(12,3) NULL,
  comment TEXT NULL,
  created_by VARCHAR(80) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_performed_act_act FOREIGN KEY (act_id) REFERENCES clinical_acts(id) ON DELETE CASCADE,
  CONSTRAINT fk_performed_act_patient FOREIGN KEY (patient_id) REFERENCES patients(id_patient) ON DELETE SET NULL,
  CONSTRAINT fk_performed_act_rdv FOREIGN KEY (rdv_id) REFERENCES rendez_vous(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS consumption_logs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  performed_act_id INT NULL,
  log_date DATE NOT NULL,
  act_id INT NOT NULL,
  product_id INT NOT NULL,
  quantity DECIMAL(12,4) NOT NULL,
  unit VARCHAR(30) NOT NULL,
  measurement_mode VARCHAR(50) NOT NULL,
  confidence VARCHAR(30) NOT NULL DEFAULT 'moyenne',
  line_cost_tnd DECIMAL(12,3) NULL,
  stock_before DECIMAL(12,4) NULL,
  stock_after DECIMAL(12,4) NULL,
  comment TEXT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_consumption_performed_act FOREIGN KEY (performed_act_id) REFERENCES performed_acts(id) ON DELETE SET NULL,
  CONSTRAINT fk_consumption_act FOREIGN KEY (act_id) REFERENCES clinical_acts(id) ON DELETE CASCADE,
  CONSTRAINT fk_consumption_product FOREIGN KEY (product_id) REFERENCES inventory_products(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS inventory_purchases (
  id INT AUTO_INCREMENT PRIMARY KEY,
  purchase_date DATE NOT NULL,
  supplier VARCHAR(120) NOT NULL,
  product_id INT NOT NULL,
  quantity_purchased DECIMAL(12,4) NOT NULL,
  unit VARCHAR(30) NOT NULL,
  total_price_tnd DECIMAL(12,3) NOT NULL,
  package_price_tnd DECIMAL(12,3) NULL,
  invoice_number VARCHAR(80) NULL,
  lot_number VARCHAR(80) NULL,
  expiration_date DATE NULL,
  comment TEXT NULL,
  updated_package_price TINYINT(1) NOT NULL DEFAULT 0,
  stock_after DECIMAL(12,4) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_inventory_purchase_product FOREIGN KEY (product_id) REFERENCES inventory_products(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS inventory_movements (
  id INT AUTO_INCREMENT PRIMARY KEY,
  product_id INT NULL,
  product_name_snapshot VARCHAR(160) NULL,
  quantity DECIMAL(12,4) NOT NULL,
  unit VARCHAR(30) NOT NULL,
  direction ENUM('IN','OUT') NOT NULL,
  origin ENUM('PURCHASE','PERFORMED_ACT','RDV_RESERVATION','CORRECTION','LAB_CASE') NOT NULL,
  origin_id INT NULL,
  stock_before DECIMAL(12,4) NULL,
  stock_after DECIMAL(12,4) NULL,
  created_by VARCHAR(80) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_inventory_movement_product FOREIGN KEY (product_id) REFERENCES inventory_products(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS ai_alerts (
  id INT AUTO_INCREMENT PRIMARY KEY,
  type VARCHAR(50) NOT NULL,
  severity VARCHAR(20) NOT NULL DEFAULT 'INFO',
  entity_type VARCHAR(50) NULL,
  entity_id INT NULL,
  message TEXT NOT NULL,
  recommendation TEXT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'OPEN',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  resolved_at DATETIME NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS lab_cases (
  id INT AUTO_INCREMENT PRIMARY KEY,
  patient_id VARCHAR(12) NULL,
  dentist_client_id INT NULL,
  case_code VARCHAR(80) NOT NULL,
  prosthesis_type VARCHAR(120) NOT NULL,
  status VARCHAR(40) NOT NULL DEFAULT 'draft',
  shade VARCHAR(40) NULL,
  tooth_numbers VARCHAR(120) NULL,
  due_date DATE NULL,
  notes TEXT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_lab_case_patient FOREIGN KEY (patient_id) REFERENCES patients(id_patient) ON DELETE SET NULL,
  UNIQUE KEY uq_lab_case_code (case_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS lab_steps (
  id INT AUTO_INCREMENT PRIMARY KEY,
  lab_case_id INT NOT NULL,
  step_name VARCHAR(120) NOT NULL,
  status VARCHAR(40) NOT NULL DEFAULT 'todo',
  started_at DATETIME NULL,
  completed_at DATETIME NULL,
  assigned_to VARCHAR(120) NULL,
  notes TEXT NULL,
  CONSTRAINT fk_lab_step_case FOREIGN KEY (lab_case_id) REFERENCES lab_cases(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS lab_recipes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  prosthesis_type VARCHAR(120) NOT NULL,
  step_name VARCHAR(120) NULL,
  product_id INT NOT NULL,
  quantity_per_case DECIMAL(12,4) NOT NULL,
  unit VARCHAR(30) NOT NULL,
  cost_tnd DECIMAL(12,3) NULL,
  notes TEXT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_lab_recipe_product FOREIGN KEY (product_id) REFERENCES inventory_products(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS lab_consumption_logs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  lab_case_id INT NOT NULL,
  product_id INT NOT NULL,
  quantity DECIMAL(12,4) NOT NULL,
  unit VARCHAR(30) NOT NULL,
  line_cost_tnd DECIMAL(12,3) NULL,
  stock_before DECIMAL(12,4) NULL,
  stock_after DECIMAL(12,4) NULL,
  comment TEXT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_lab_consumption_case FOREIGN KEY (lab_case_id) REFERENCES lab_cases(id) ON DELETE CASCADE,
  CONSTRAINT fk_lab_consumption_product FOREIGN KEY (product_id) REFERENCES inventory_products(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

