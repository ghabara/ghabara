const express = require('express');
const bcrypt = require('bcryptjs');
const { pool } = require('../db');
const { sign, auth, docteurOnly } = require('../middleware/auth');
const { logAudit } = require('../services/auditService');
const router = express.Router();

// Génère le prochain id_patient (PAT-0001) sans doublon
async function nextPatientId(conn) {
  const [rows] = await conn.query('SELECT id_patient FROM patients');
  let max = 0;
  rows.forEach(r => {
    const n = parseInt(String(r.id_patient).replace(/\D/g, ''), 10);
    if (!isNaN(n) && n > max) max = n;
  });
  return 'PAT-' + String(max + 1).padStart(4, '0');
}

// ── INSCRIPTION ─────────────────────────────────────────────
router.post('/register', async (req, res) => {
  try {
    const { prenom, nom, age, genre, tel, email, password } = req.body;

    // Mêmes règles que le site d'origine
    if (!prenom || !nom || !age || !genre || !tel || !email || !password)
      return res.status(400).json({ error: 'Veuillez remplir tous les champs obligatoires.' });
    if (/\d/.test(prenom) || !/^[a-zA-ZÀ-ÿ\s\-']+$/.test(prenom))
      return res.status(400).json({ error: 'Le prénom ne doit contenir que des lettres.' });
    if (/\d/.test(nom) || !/^[a-zA-ZÀ-ÿ\s\-']+$/.test(nom))
      return res.status(400).json({ error: 'Le nom ne doit contenir que des lettres.' });
    if (isNaN(age) || age < 1 || age > 120)
      return res.status(400).json({ error: 'Veuillez entrer un âge valide (1–120).' });
    const telDigits = String(tel).replace(/\D/g, '');
    if (telDigits.length !== 8)
      return res.status(400).json({ error: 'Le téléphone doit contenir exactement 8 chiffres.' });
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email))
      return res.status(400).json({ error: 'Adresse e-mail invalide.' });
    if (String(password).length < 6)
      return res.status(400).json({ error: 'Le mot de passe doit contenir au moins 6 caractères.' });

    const conn = await pool.getConnection();
    try {
      const [exist] = await conn.query('SELECT id_patient FROM patients WHERE email = ?', [email]);
      if (exist.length) { conn.release(); return res.status(409).json({ error: 'Un compte avec cet e-mail existe déjà.' }); }

      const id_patient = await nextPatientId(conn);
      const hash = await bcrypt.hash(password, 10);
      await conn.query(
        `INSERT INTO patients (id_patient, prenom, nom, age, genre, tel, email, password_hash)
         VALUES (?,?,?,?,?,?,?,?)`,
        [id_patient, prenom, nom, parseInt(age), genre, telDigits, email, hash]
      );
      conn.release();

      const user = { id_patient, prenom, nom, age: parseInt(age), genre, tel: telDigits, email, role: 'patient' };
      const token = sign(user);
      res.status(201).json({ user, token });
    } catch (e) { conn.release(); throw e; }
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Erreur serveur.' });
  }
});

// ── CONNEXION PATIENT ───────────────────────────────────────
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ error: 'Veuillez remplir tous les champs.' });

    const [rows] = await pool.query('SELECT * FROM patients WHERE email = ?', [email]);
    if (!rows.length) return res.status(401).json({ error: 'Email ou mot de passe incorrect.' });

    const p = rows[0];
    const ok = await bcrypt.compare(password, p.password_hash);
    if (!ok) return res.status(401).json({ error: 'Email ou mot de passe incorrect.' });

    const user = { id_patient: p.id_patient, prenom: p.prenom, nom: p.nom, age: p.age, genre: p.genre, tel: p.tel, email: p.email, role: 'patient' };
    res.json({ user, token: sign(user) });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Erreur serveur.' });
  }
});

// ── CONNEXION ADMIN / DOCTEUR ───────────────────────────────
router.post('/admin/login', async (req, res) => {
  try {
    const { username, password } = req.body;
    const [rows] = await pool.query('SELECT * FROM admins WHERE username = ?', [username]);
    if (!rows.length) return res.status(401).json({ error: 'Identifiant ou mot de passe incorrect.' });

    const a = rows[0];
    const ok = await bcrypt.compare(password, a.password_hash);
    if (!ok) return res.status(401).json({ error: 'Identifiant ou mot de passe incorrect.' });

    const user = { id: a.id, username: a.username, role: a.role };
    res.json({ user, token: sign(user) });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Erreur serveur.' });
  }
});

// ── CHANGER SES IDENTIFIANTS (docteur uniquement) ───────────
// Le rôle ne change jamais : seuls le login et/ou le mot de passe changent.
router.put('/admin/credentials', auth, docteurOnly, async (req, res) => {
  try {
    const { username, newPassword, currentPassword } = req.body;
    const [rows] = await pool.query('SELECT * FROM admins WHERE id = ?', [req.user.id]);
    if (!rows.length) return res.status(404).json({ error: 'Compte introuvable.' });
    const a = rows[0];

    const ok = await bcrypt.compare(currentPassword || '', a.password_hash);
    if (!ok) return res.status(401).json({ error: 'Mot de passe actuel incorrect.' });

    const newUsername = (username || a.username).trim();
    if (!newUsername) return res.status(400).json({ error: 'Identifiant requis.' });
    const [dup] = await pool.query('SELECT id FROM admins WHERE username = ? AND id <> ?', [newUsername, a.id]);
    if (dup.length) return res.status(409).json({ error: 'Cet identifiant est déjà utilisé.' });

    let hash = a.password_hash;
    if (newPassword) {
      if (String(newPassword).length < 10 || !/[A-Z]/.test(newPassword) || !/[a-z]/.test(newPassword) || !/\d/.test(newPassword)) return res.status(400).json({ error: 'Mot de passe trop faible : minimum 10 caractères avec majuscule, minuscule et chiffre.' });
      hash = await bcrypt.hash(newPassword, 10);
    }
    await pool.query('UPDATE admins SET username = ?, password_hash = ? WHERE id = ?', [newUsername, hash, a.id]);

    // role inchangé ; nouveau jeton avec le nouvel identifiant
    const user = { id: a.id, username: newUsername, role: a.role };
    await logAudit(pool, req, { action: 'ADMIN_CREDENTIALS_UPDATE', entity_type: 'admin', entity_id: a.id, details: { username_changed: newUsername !== a.username, password_changed: !!newPassword } });
    res.json({ ok: true, user, token: sign(user) });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Erreur serveur.' });
  }
});

module.exports = router;
