USE dentaloff_ai;

ALTER TABLE inventory_products
  ADD COLUMN IF NOT EXISTS reference_price_min DECIMAL(12,3) NULL AFTER package_price_tnd,
  ADD COLUMN IF NOT EXISTS reference_price_avg DECIMAL(12,3) NULL AFTER reference_price_min,
  ADD COLUMN IF NOT EXISTS reference_price_max DECIMAL(12,3) NULL AFTER reference_price_avg,
  ADD COLUMN IF NOT EXISTS reference_price_tnd_min DECIMAL(12,3) NULL AFTER reference_price_max,
  ADD COLUMN IF NOT EXISTS reference_price_tnd_avg DECIMAL(12,3) NULL AFTER reference_price_tnd_min,
  ADD COLUMN IF NOT EXISTS reference_price_tnd_max DECIMAL(12,3) NULL AFTER reference_price_tnd_avg,
  ADD COLUMN IF NOT EXISTS reference_currency VARCHAR(12) NULL AFTER reference_price_tnd_max,
  ADD COLUMN IF NOT EXISTS price_source VARCHAR(255) NULL AFTER reference_currency,
  ADD COLUMN IF NOT EXISTS price_source_table VARCHAR(80) NULL AFTER price_source,
  ADD COLUMN IF NOT EXISTS price_source_id INT NULL AFTER price_source_table,
  ADD COLUMN IF NOT EXISTS price_validation_status ENUM('none','candidate','validated','rejected','conflict') NOT NULL DEFAULT 'none' AFTER price_source_id,
  ADD COLUMN IF NOT EXISTS is_real_price TINYINT(1) NOT NULL DEFAULT 0 AFTER price_validation_status,
  ADD COLUMN IF NOT EXISTS reference_price_note TEXT NULL AFTER is_real_price,
  ADD COLUMN IF NOT EXISTS price_validated_by VARCHAR(120) NULL AFTER reference_price_note,
  ADD COLUMN IF NOT EXISTS price_validated_at DATETIME NULL AFTER price_validated_by;

UPDATE inventory_products
SET is_real_price = 1
WHERE package_price_tnd IS NOT NULL
  AND package_price_tnd > 0
  AND is_real_price = 0;

CREATE INDEX IF NOT EXISTS idx_inventory_reference_price_status
  ON inventory_products (price_validation_status, is_real_price);
