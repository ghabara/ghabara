﻿const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
require('dotenv').config();

const { seed } = require('./db');

const app = express();

const allowedOrigins = (process.env.CLIENT_ORIGIN || 'http://localhost:5173,http://127.0.0.1:5173')
  .split(',')
  .map(origin => origin.trim())
  .filter(Boolean);

app.use(helmet({
  crossOriginResourcePolicy: { policy: 'cross-origin' },
}));
app.use(cors({
  origin(origin, cb) {
    if (!origin || allowedOrigins.includes(origin)) return cb(null, true);
    return cb(new Error('Origine non autorisée par CORS.'));
  },
}));
app.use(express.json({ limit: '5mb' }));

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 25,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Trop de tentatives. Réessayez plus tard.' },
});
app.use(['/api/login', '/api/register', '/api/admin/login'], authLimiter);

// Les documents medicaux ne sont pas servis en statique public.
// Ils passent par une route authentifiee dans routes/dossiers.js.

// Routes API
app.use('/api', require('./routes/auth'));
app.use('/api/patients', require('./routes/patients'));
app.use('/api/dossiers', require('./routes/dossiers'));
app.use('/api/rdv', require('./routes/rdv'));
app.use('/api', require('./routes/settings'));
app.use('/api', require('./routes/stock'));
app.use('/api/inventory', require('./routes/inventory'));
app.use('/api/clinical-acts', require('./routes/clinicalActs'));
app.use('/api/recipes', require('./routes/recipes'));
app.use('/api/performed-acts', require('./routes/performedActs'));
app.use('/api/purchases', require('./routes/purchases'));
app.use('/api/shopping-list', require('./routes/shoppingList'));
app.use('/api/ai', require('./routes/ai'));
app.use('/api/lab', require('./routes/lab'));
app.use('/api/treatment-plans', require('./routes/treatmentPlans'));
app.use('/api/security', require('./routes/security'));
app.use('/api/pilotage', require('./routes/pilotage'));
app.use('/api/reference-harmonization', require('./routes/referenceHarmonization'));
app.use('/api/references', require('./routes/references'));
app.use('/api/act-product-catalog', require('./routes/actProductCatalog'));

app.get('/', (req, res) => res.json({ status: 'DentoFlow AI API en ligne ✅' }));

const PORT = process.env.PORT || 4000;
app.listen(PORT, async () => {
  await seed();
  console.log(`Serveur DentoFlow AI sur http://localhost:${PORT}`);
});
