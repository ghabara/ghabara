import { surfaces, toothStatuses } from './dentalChartConfig';

export default function DentalToothEditor({ tooth, selectedNumber, onChange }) {
  const selectedSurfaces = tooth.surfaces || [];

  const toggleSurface = (surface) => {
    const next = selectedSurfaces.includes(surface)
      ? selectedSurfaces.filter(item => item !== surface)
      : [...selectedSurfaces, surface];
    onChange({ ...tooth, surfaces: next });
  };

  return (
    <div className="dental-editor">
      <div>
        <span className="admin-eyebrow">Dent selectionnee</span>
        <h3>{selectedNumber}</h3>
      </div>
      <label className="fg">
        <span>Statut</span>
        <select value={tooth.status} onChange={e => onChange({ ...tooth, status: e.target.value })}>
          {toothStatuses.map(([key, label]) => <option key={key} value={key}>{label}</option>)}
        </select>
      </label>
      <div className="surface-picker">
        {surfaces.map(surface => (
          <button
            type="button"
            key={surface}
            className={selectedSurfaces.includes(surface) ? 'active' : ''}
            onClick={() => toggleSurface(surface)}
          >
            {surface}
          </button>
        ))}
      </div>
      <label className="fg">
        <span>Notes brouillon</span>
        <textarea rows="3" value={tooth.notes || ''} onChange={e => onChange({ ...tooth, notes: e.target.value })} />
      </label>
      <p className="muted">Ce brouillon ne modifie pas le dossier patient, les actes realises ou le stock.</p>
    </div>
  );
}
