﻿import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import api, { getUser, logout } from '../api';
import BrandLogo from '../components/BrandLogo.jsx';

/* Icônes SVG (remplacent les emojis) */
const Tooth = () => (
  <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
    <path d="M12 2C8.6 2 6 4.2 6 7.2c0 1.9.5 3.4.8 5.3.3 2 .6 4.6 1.3 6.6.3 1 .8 1.9 1.5 1.9s1-.9 1.2-2.1c.2-1 .3-2 .3-2.9 0-.6.4-1 1-1s1 .4 1 1c0 .9.1 1.9.3 2.9.2 1.2.6 2.1 1.3 2.1s1.2-.9 1.5-1.9c.7-2 1-4.6 1.3-6.6.3-1.9.8-3.4.8-5.3C18 4.2 15.4 2 12 2z" />
  </svg>
);
const IcoPhone = () => (
  <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M6.6 10.8c1.4 2.8 3.8 5.2 6.6 6.6l2.2-2.2c.3-.3.7-.4 1-.2 1.1.4 2.4.6 3.6.6.6 0 1 .4 1 1V20c0 .6-.4 1-1 1C10.6 21 3 13.4 3 4c0-.6.4-1 1-1h3.5c.6 0 1 .4 1 1 0 1.3.2 2.5.6 3.6.1.4 0 .8-.3 1l-2.2 2.2z" /></svg>
);
const IcoPin = () => (
  <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M12 2C8.1 2 5 5.1 5 9c0 5 7 13 7 13s7-8 7-13c0-3.9-3.1-7-7-7zm0 9.5A2.5 2.5 0 1 1 12 6.5a2.5 2.5 0 0 1 0 5z" /></svg>
);
const IcoClock = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true"><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 2" /></svg>
);

export default function Home() {
  const [services, setServices] = useState([]);
  const [hours, setHours] = useState([]);
  const [info, setInfo] = useState({});
  const user = getUser();
  const navigate = useNavigate();

  useEffect(() => {
    api.get('/services').then(r => setServices(r.data)).catch(() => {});
    api.get('/horaires').then(r => setHours(r.data)).catch(() => {});
    api.get('/info').then(r => setInfo(r.data)).catch(() => {});
  }, []);

  const goRdv = (service, prix) => {
    sessionStorage.setItem('dc_preselect', JSON.stringify({ service, prix }));
    navigate('/rdv');
  };

  const openDays = hours.filter(h => !h.ferme);
  const hoursStr = openDays.length
    ? `${openDays[0].jour.slice(0,3)}–${openDays[openDays.length-1].jour.slice(0,3)} · ${openDays[0].ouverture}–${openDays[0].fermeture}`
    : '';

  return (
    <div className="dc">
      {/* Bandeau coordonnées */}
      <div className="dc-topbar">
        <div className="dc-wrap">
          <span><IcoPhone /> <strong>{info.tel || '+216 22 369 195'}</strong></span>
          <span><IcoPin /> {info.addr || 'El Mourouj 1, Ben Arous, Tunisie'}</span>
          {hoursStr && <span><IcoClock /> {hoursStr}</span>}
        </div>
      </div>

      {/* Navigation */}
      <nav className="dc-nav">
        <div className="dc-wrap">
          <Link to="/" className="brand-link"><BrandLogo compact className="brand-logo--nav" /></Link>
          <div className="dc-navlinks">
            <a href="#services" className="plain hide-sm">Soins</a>
            <a href="#horaires" className="plain hide-sm">Horaires</a>
            {user ? (
              <>
                <Link to="/profil" className="plain">{user.prenom}</Link>
                <a className="plain" onClick={() => { logout(); window.location.reload(); }} style={{ cursor: 'pointer' }}>Déconnexion</a>
              </>
            ) : (
              <Link to="/login" className="plain">Connexion</Link>
            )}
            <Link to="/rdv" className="dc-btn dc-btn-gold" style={{ padding: '11px 22px' }}>Prendre RDV</Link>
          </div>
        </div>
      </nav>

      {/* Hero */}
      <header className="dc-hero">
        <span className="blob b1" /><span className="blob b2" />
        <div className="dc-wrap">
          <div className="dc-hero-copy">
            <span className="dc-eyebrow dc-reveal dc-d1">Cabinet dentaire · Tunis</span>
            <h1 className="dc-display dc-reveal dc-d2">Vos soins dentaires,<br /><em>en toute sérénité</em>.</h1>
            <p className="dc-reveal dc-d3">
              Le {info.doctor || 'Dr. Wael Ghabara'} et son équipe prennent soin de votre sourire
              dans un cadre apaisant. Réservez en quelques secondes — sans même créer de compte.
            </p>
            <div className="dc-hero-cta dc-reveal dc-d4">
              <Link to="/rdv" className="dc-btn dc-btn-gold">Prendre rendez-vous</Link>
              <a href="#services" className="dc-btn dc-btn-ghost">Découvrir nos soins</a>
            </div>
            <div className="dc-hero-stats dc-reveal dc-d5">
              <div><div className="n">{services.length || 6}</div><div className="l">soins proposés</div></div>
              <div><div className="n">4</div><div className="l">étapes pour réserver</div></div>
              <div><div className="n">0</div><div className="l">compte requis</div></div>
            </div>
          </div>
          <div className="dc-orb dc-reveal dc-d3"><img src="/photos/hero.jpg" alt="Soin dentaire" /></div>
        </div>
      </header>

      {/* Pourquoi nous */}
      <section className="dc-section dc-why">
        <div className="dc-wrap">
          <div className="dc-head">
            <span className="dc-eyebrow">Notre différence</span>
            <h2 className="dc-display">Pourquoi choisir DentoFlow AI ?</h2>
            <p>Une approche centrée sur le patient, alliant perfection médicale et confort optimal.</p>
          </div>
          <div className="dc-why-list">
            <div className="dc-why-item">
              <div className="ico"><img src="/photos/clinic.jpg" alt="" /></div>
              <div><h4>Équipements de pointe</h4><p>Technologie numérique dernière génération pour des diagnostics précis.</p></div>
            </div>
            <div className="dc-why-item">
              <div className="ico"><img src="/photos/smile.jpg" alt="" /></div>
              <div><h4>Approche humaine</h4><p>Écoute attentive et accompagnement personnalisé pour chaque patient.</p></div>
            </div>
            <div className="dc-why-item">
              <div className="ico"><img src="/photos/implant.jpg" alt="" /></div>
              <div><h4>Excellence clinique</h4><p>Formations continues et certifications internationales.</p></div>
            </div>
            <div className="dc-why-item">
              <div className="ico"><img src="/photos/care.jpg" alt="" /></div>
              <div><h4>RDV facile &amp; rapide</h4><p>Prise de rendez-vous en ligne, sans inscription, confirmation immédiate.</p></div>
            </div>
          </div>
        </div>
      </section>

      {/* Services */}
      <section id="services" className="dc-section">
        <div className="dc-wrap">
          <div className="dc-head">
            <span className="dc-eyebrow">Nos prestations</span>
            <h2 className="dc-display">Des soins pensés pour votre confort</h2>
            <p>Choisissez un soin pour lancer votre réservation en ligne.</p>
          </div>
          <div className="dc-services">
            {services.map(s => (
              <div key={s.id} className="dc-svc" onClick={() => goRdv(s.name, s.prix)}>
                <h3>{s.name}</h3>
                <p>{s.descr}</p>
                <div className="price">À partir de {s.prix}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Horaires */}
      <section id="horaires" className="dc-section dc-hours-sec">
        <div className="dc-wrap">
          <div className="dc-head" style={{ margin: '0 auto 40px', textAlign: 'center' }}>
            <span className="dc-eyebrow" style={{ justifyContent: 'center' }}>Disponibilités</span>
            <h2 className="dc-display">Horaires d'ouverture</h2>
          </div>
          <div className="dc-hours">
            {hours.map(h => (
              <div key={h.id} className="row">
                <span className="day">{h.jour}</span>
                <span className={h.ferme ? 'closed' : 'open'}>
                  {h.ferme ? 'Fermé' : `${h.ouverture} – ${h.fermeture}`}
                </span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="dc-footer">
        <div className="fmark"><BrandLogo compact className="brand-logo--footer" /></div>
        <p>{info.doctor || 'Dr. Wael Ghabara'} · {info.addr || 'El Mourouj 1, Ben Arous, Tunisie'} · {info.tel || '+216 22 369 195'}</p>
        <p className="copy">© {new Date().getFullYear()} DentoFlow AI — Tous droits réservés</p>
      </footer>
    </div>
  );
}
