const express = require('express');
const { pool } = require('../db');
const { auth, optionalAuth, adminOnly } = require('../middleware/auth');
const { logAudit } = require('../services/auditService');
const router = express.Router();
const VALID_STATUTS = new Set(['pending', 'confirmed', 'arrived', 'in_treatment', 'done', 'cancelled', 'no_show']);
const VALID_SLOTS = new Set(['08:30', '09:00', '09:30', '10:00', '10:30', '11:00', '11:30', '14:00', '14:30', '15:00', '15:30', '16:00', '16:30', '17:00']);

function isValidFutureDate(value) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(String(value || ''))) return false;
  const chosen = new Date(`${value}T00:00:00`);
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  return !Number.isNaN(chosen.getTime()) && chosen >= today;
}

async function assertSlotFree(date, heure, chair = 'Fauteuil 1', excludeId = null) {
  let sql = "SELECT id FROM rendez_vous WHERE date = ? AND heure = ? AND COALESCE(chair, 'Fauteuil 1') = ? AND statut NOT IN ('cancelled','no_show')";
  const params = [date, heure, chair || 'Fauteuil 1'];
  if (excludeId) {
    sql += ' AND id <> ?';
    params.push(excludeId);
  }
  sql += ' LIMIT 1';
  const [rows] = await pool.query(sql, params);
  return rows.length === 0;
}

// Créneaux déjà réservés pour une date (pour les masquer côté client)
router.get('/taken', async (req, res) => {
  const { date } = req.query;
  if (!date) return res.json([]);
  const [rows] = await pool.query(
    "SELECT heure FROM rendez_vous WHERE date = ? AND statut NOT IN ('cancelled','no_show') AND COALESCE(chair, 'Fauteuil 1') = ?", [date, req.query.chair || 'Fauteuil 1']
  );
  res.json(rows.map(r => r.heure));
});

// Mes rendez-vous (patient connecté)
router.get('/me', auth, async (req, res) => {
  const [rows] = await pool.query('SELECT * FROM rendez_vous WHERE id_patient = ? ORDER BY date, heure', [req.user.id_patient]);
  res.json(rows);
});

// Tous les rendez-vous (admin)
router.get('/', auth, adminOnly, async (req, res) => {
  const where = [];
  const params = [];
  if (req.query.date_from) { where.push('date >= ?'); params.push(req.query.date_from); }
  if (req.query.date_to) { where.push('date <= ?'); params.push(req.query.date_to); }
  if (req.query.statut) { where.push('statut = ?'); params.push(req.query.statut); }
  const [rows] = await pool.query(
    `SELECT rv.*, ca.name AS planned_act_name, ca.default_duration_minutes
     FROM rendez_vous rv
     LEFT JOIN clinical_acts ca ON ca.id = rv.planned_act_id
     ${where.length ? `WHERE ${where.join(' AND ')}` : ''}
     ORDER BY rv.date DESC, rv.heure DESC, rv.created_at DESC
     LIMIT 500`,
    params
  );
  res.json(rows);
});

// Créer un rendez-vous — patient connecté OU visiteur non inscrit
router.post('/', optionalAuth, async (req, res) => {
  const { service, prix, date, heure } = req.body;
  const chair = String(req.body.chair || 'Fauteuil 1').trim() || 'Fauteuil 1';
  const duration = Number(req.body.duration_minutes || 30);
  const practitioner = String(req.body.practitioner || 'Docteur').trim() || 'Docteur';
  if (!service || !date || !heure) return res.status(400).json({ error: 'Informations incomplètes.' });
  if (!isValidFutureDate(date)) return res.status(400).json({ error: 'Date de rendez-vous invalide ou passée.' });
  if (!VALID_SLOTS.has(heure)) return res.status(400).json({ error: 'Créneau horaire invalide.' });
  if (!Number.isFinite(duration) || duration <= 0 || duration > 240) return res.status(400).json({ error: 'Durée de rendez-vous invalide.' });
  if (!(await assertSlotFree(date, heure, chair))) return res.status(409).json({ error: 'Ce fauteuil est déjà réservé sur ce créneau.' });

  let id_patient = null, nom = '', tel = '', email = null;

  if (req.user && req.user.id_patient) {
    // Patient connecté : on prend ses infos
    id_patient = req.user.id_patient;
    nom = `${req.user.prenom} ${req.user.nom}`;
    tel = req.user.tel || '';
    email = req.user.email || null;
  } else {
    // Visiteur non inscrit : nom + prénom + tél obligatoires, email facultatif
    const prenom = (req.body.prenom || '').trim();
    const gnom = (req.body.nom || '').trim();
    const gtel = String(req.body.tel || '').replace(/\D/g, '');
    const gemail = (req.body.email || '').trim();

    if (!prenom || !gnom || !gtel)
      return res.status(400).json({ error: 'Nom, prénom et téléphone sont obligatoires.' });
    if (gtel.length !== 8)
      return res.status(400).json({ error: 'Le téléphone doit contenir exactement 8 chiffres.' });
    if (gemail && !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(gemail))
      return res.status(400).json({ error: 'Adresse e-mail invalide.' });

    nom = `${prenom} ${gnom}`;
    tel = gtel;
    email = gemail || null; // email NON obligatoire pour un visiteur
  }

  const ref = 'RDV-' + Date.now().toString().slice(-6);
  await pool.query(
    `INSERT INTO rendez_vous
       (ref, id_patient, patient_nom, patient_tel, patient_email, service, prix, date, heure, statut,
        duration_minutes, practitioner, chair, room, notes, planned_act_id)
     VALUES (?,?,?,?,?,?,?,?,?, 'pending', ?, ?, ?, ?, ?, ?)`,
    [
      ref, id_patient, nom, tel, email, service, prix || '', date, heure,
      duration, practitioner, chair, String(req.body.room || '').trim() || null,
      String(req.body.notes || '').trim() || null, req.body.planned_act_id || null,
    ]
  );
  const [[rdv]] = await pool.query('SELECT * FROM rendez_vous WHERE ref = ?', [ref]);

  // Réservation automatique des consommables prévus pour ce service (panier prévisionnel)
  try {
    const [modele] = await pool.query(
      'SELECT id_produit, quantite FROM service_consommables WHERE service = ?', [service]
    );
    for (const m of modele) {
      await pool.query(
        'INSERT INTO reservations (id_rdv, id_produit, quantite, statut) VALUES (?,?,?, "en_attente")',
        [rdv.id, m.id_produit, m.quantite]
      );
    }
  } catch (e) {
    console.error('⚠️  Réservation auto des consommables impossible :', e.message);
  }

  await logAudit(pool, req, { action: 'RDV_CREATE', entity_type: 'rendez_vous', entity_id: rdv.id, patient_id: id_patient, details: { service, date, heure, chair } });
  res.status(201).json(rdv);
});

// Modifier le statut (admin)
router.put('/:id/status', auth, adminOnly, async (req, res) => {
  const { statut } = req.body;
  if (!VALID_STATUTS.has(statut)) return res.status(400).json({ error: 'Statut invalide.' });
  const [[before]] = await pool.query('SELECT * FROM rendez_vous WHERE id = ?', [req.params.id]);
  await pool.query('UPDATE rendez_vous SET statut = ? WHERE id = ?', [statut, req.params.id]);
  // Annulation du RDV -> on libère les consommables encore réservés (prévisionnel)
  if (statut === 'cancelled') {
    try {
      await pool.query(
        "UPDATE reservations SET statut = 'annulee' WHERE id_rdv = ? AND statut = 'en_attente'",
        [req.params.id]
      );
    } catch (e) { console.error('⚠️  Libération des réservations impossible :', e.message); }
  }
  await logAudit(pool, req, { action: 'RDV_STATUS_UPDATE', entity_type: 'rendez_vous', entity_id: req.params.id, patient_id: before?.id_patient || null, details: { previous: before?.statut, next: statut } });
  res.json({ ok: true });
});

// Annuler son propre RDV (patient) ou modifier date/heure
router.put('/:id', auth, async (req, res) => {
  const { date, heure, statut } = req.body;
  const chair = String(req.body.chair || '').trim();
  const [[rdv]] = await pool.query('SELECT * FROM rendez_vous WHERE id = ?', [req.params.id]);
  if (!rdv) return res.status(404).json({ error: 'RDV introuvable.' });
  // un patient ne peut toucher que ses propres RDV
  if (req.user.role === 'patient' && rdv.id_patient !== req.user.id_patient)
    return res.status(403).json({ error: 'Accès refusé.' });
  const nextDate = date || rdv.date;
  const nextHeure = heure || rdv.heure;
  const nextStatut = statut || rdv.statut;
  const nextChair = chair || rdv.chair || 'Fauteuil 1';
  if (!isValidFutureDate(nextDate)) return res.status(400).json({ error: 'Date de rendez-vous invalide ou passée.' });
  if (!VALID_SLOTS.has(nextHeure)) return res.status(400).json({ error: 'Créneau horaire invalide.' });
  if (!VALID_STATUTS.has(nextStatut)) return res.status(400).json({ error: 'Statut invalide.' });
  if (!(await assertSlotFree(nextDate, nextHeure, nextChair, req.params.id))) return res.status(409).json({ error: 'Ce fauteuil est déjà réservé sur ce créneau.' });
  await pool.query(
    `UPDATE rendez_vous
     SET date = ?, heure = ?, statut = ?, chair = ?, duration_minutes = COALESCE(?, duration_minutes),
         practitioner = COALESCE(?, practitioner), room = COALESCE(?, room), notes = COALESCE(?, notes),
         planned_act_id = COALESCE(?, planned_act_id)
     WHERE id = ?`,
    [
      nextDate, nextHeure, nextStatut, nextChair, req.body.duration_minutes || null,
      req.body.practitioner || null, req.body.room || null, req.body.notes || null,
      req.body.planned_act_id || null, req.params.id,
    ]
  );
  await logAudit(pool, req, { action: 'RDV_UPDATE', entity_type: 'rendez_vous', entity_id: req.params.id, patient_id: rdv.id_patient, details: { date: nextDate, heure: nextHeure, chair: nextChair, statut: nextStatut } });
  res.json({ ok: true });
});

// Supprimer (admin)
router.delete('/:id', auth, adminOnly, async (req, res) => {
  const [[rdv]] = await pool.query('SELECT * FROM rendez_vous WHERE id = ?', [req.params.id]);
  await pool.query('DELETE FROM rendez_vous WHERE id = ?', [req.params.id]);
  await logAudit(pool, req, { action: 'RDV_DELETE', entity_type: 'rendez_vous', entity_id: req.params.id, patient_id: rdv?.id_patient || null });
  res.json({ ok: true });
});

module.exports = router;
