﻿USE dentaloff_ai;

INSERT IGNORE INTO inventory_products
(name, category, sub_category, tracking_unit, package_quantity, package_unit,
 package_price_tnd, current_stock, min_stock, supplier_alias, source_type, notes, context_type)
VALUES
('Resine / composite A2', 'Restauratrice', 'Composite', 'g', 4, 'g', 45.000, 8, 1, 'Fournisseur a completer', 'Demo Stock AI', 'Consommation initiale 0.400 g par composite.', 'CABINET'),
('Acide orthophosphorique gel bleu', 'Restauratrice', 'Mordancage', 'g', NULL, 'g', NULL, 5, 0.5, 'Fournisseur a completer', 'Demo Stock AI', 'Prix et conditionnement a completer.', 'CABINET'),
('Adhesif / bonding', 'Restauratrice', 'Adhesif', 'g', NULL, 'g', NULL, 3, 0.3, 'Fournisseur a completer', 'Demo Stock AI', 'Prix et conditionnement a completer.', 'CABINET'),
('Microbrush', 'Usage unique', 'Application', 'unite', 100, 'unite', 18.000, 80, 20, 'Fournisseur a completer', 'Demo Stock AI', 'Moyenne initiale 1.09 unite par composite.', 'CABINET'),
('Anesthesie carpule', 'Anesthesie', NULL, 'carpule', 50, 'carpule', 75.000, 40, 10, 'Fournisseur a completer', 'Demo Stock AI', 'Endo 1.20 carpule, extraction 1.10 carpule.', 'CABINET'),
('Resine dual / automix', 'Reconstitution', 'Automix', 'g', 9, 'g', 65.000, 9, 1.5, 'Fournisseur a completer', 'Demo Stock AI', 'Reconstitution coronaire 1.65 g.', 'CABINET'),
('Embout automix jete', 'Usage unique', 'Embout', 'unite', 20, 'unite', 12.000, 20, 5, 'Fournisseur a completer', 'Demo Stock AI', 'Perte embout suivie separement.', 'CABINET'),
('Gants', 'Usage unique', 'Protection', 'paire', 100, 'paire', 16.000, 100, 20, 'Fournisseur a completer', 'Demo Stock AI', 'Produit non encore relie a toutes les recettes.', 'BOTH'),
('Aiguille dentaire', 'Anesthesie', NULL, 'unite', 100, 'unite', NULL, 80, 20, 'Fournisseur a completer', 'Demo Stock AI', 'A compter par acte avec anesthesie.', 'CABINET'),
('Ciment de scellement', 'Collage', 'Scellement', 'g', NULL, 'g', NULL, 4, 0.5, 'Fournisseur a completer', 'Demo Stock AI', 'Produit a mesurer pour collage couronne.', 'CABINET'),
('Papier absorbant endo', 'Endodontie', NULL, 'unite', NULL, 'unite', NULL, 60, 15, 'Fournisseur a completer', 'Demo Stock AI', 'A ajouter aux recettes endo quand mesure.', 'CABINET'),
('Gutta percha', 'Endodontie', NULL, 'unite', NULL, 'unite', NULL, 50, 10, 'Fournisseur a completer', 'Demo Stock AI', 'A ajouter aux recettes endo quand mesure.', 'CABINET'),
('Granulotec', 'Endodontie', NULL, 'g', NULL, 'g', NULL, 2, 0.5, 'Fournisseur a completer', 'Demo Stock AI', 'A ajouter aux recettes endo quand mesure.', 'CABINET');

INSERT IGNORE INTO clinical_acts
(name, clinical_variant, category, default_duration_minutes, default_price_tnd, notes)
VALUES
('Composite', 'Acte restaurateur standard', 'Restauratrice', 45, 120.000, 'Composite + acide + adhesif + microbrush.'),
('Endo', 'Standard', 'Endodontie', 75, 220.000, 'Anesthesie suivie en carpules pour le MVP.'),
('Extraction', 'Simple', 'Chirurgie', 35, 100.000, 'Anesthesie suivie en carpules.'),
('Empreinte', 'Standard', 'Prothese', 30, 80.000, 'Recette a completer selon materiau.'),
('Detartrage / desinfection', 'Standard', 'Parodontologie', 40, 90.000, 'Recette a completer selon consommables suivis.'),
('Reconstitution coronaire', 'Resine dual / automix', 'Restauratrice', 50, 150.000, 'Resine dual + embout.'),
('Collage couronne', 'Standard', 'Prothese', 45, 160.000, 'Acide, adhesif, ciment, microbrush, embout si utilise.');

INSERT IGNORE INTO act_recipes
(act_id, product_id, quantity_per_act, unit, measurement_mode, confidence, source_note)
SELECT a.id, p.id, 0.400, 'g', 'pesee', 'bonne', 'V0.2 Stock AI'
FROM clinical_acts a, inventory_products p
WHERE a.name = 'Composite' AND p.name = 'Resine / composite A2';

INSERT IGNORE INTO act_recipes
(act_id, product_id, quantity_per_act, unit, measurement_mode, confidence, source_note)
SELECT a.id, p.id, 0.100, 'g', 'pesee', 'bonne', 'V0.2 Stock AI'
FROM clinical_acts a, inventory_products p
WHERE a.name = 'Composite' AND p.name = 'Acide orthophosphorique gel bleu';

INSERT IGNORE INTO act_recipes
(act_id, product_id, quantity_per_act, unit, measurement_mode, confidence, source_note)
SELECT a.id, p.id, 0.019, 'g', 'pesee', 'bonne', 'V0.2 Stock AI'
FROM clinical_acts a, inventory_products p
WHERE a.name = 'Composite' AND p.name = 'Adhesif / bonding';

INSERT IGNORE INTO act_recipes
(act_id, product_id, quantity_per_act, unit, measurement_mode, confidence, source_note)
SELECT a.id, p.id, 1.090, 'unite', 'comptage', 'bonne', 'V0.2 Stock AI'
FROM clinical_acts a, inventory_products p
WHERE a.name = 'Composite' AND p.name = 'Microbrush';

INSERT IGNORE INTO act_recipes
(act_id, product_id, quantity_per_act, unit, measurement_mode, confidence, source_note)
SELECT a.id, p.id, 1.200, 'carpule', 'estimation', 'moyenne', 'V0.2 Stock AI'
FROM clinical_acts a, inventory_products p
WHERE a.name = 'Endo' AND p.name = 'Anesthesie carpule';

INSERT IGNORE INTO act_recipes
(act_id, product_id, quantity_per_act, unit, measurement_mode, confidence, source_note)
SELECT a.id, p.id, 1.100, 'carpule', 'estimation', 'moyenne', 'V0.2 Stock AI'
FROM clinical_acts a, inventory_products p
WHERE a.name = 'Extraction' AND p.name = 'Anesthesie carpule';

INSERT IGNORE INTO act_recipes
(act_id, product_id, quantity_per_act, unit, measurement_mode, confidence, source_note)
SELECT a.id, p.id, 1.650, 'g', 'pesee', 'moyenne', 'Plage 1.5 a 1.8 g'
FROM clinical_acts a, inventory_products p
WHERE a.name = 'Reconstitution coronaire' AND p.name = 'Resine dual / automix';

INSERT IGNORE INTO act_recipes
(act_id, product_id, quantity_per_act, unit, measurement_mode, confidence, source_note)
SELECT a.id, p.id, 1.000, 'unite', 'comptage', 'moyenne', 'Perte embout separee'
FROM clinical_acts a, inventory_products p
WHERE a.name = 'Reconstitution coronaire' AND p.name = 'Embout automix jete';

INSERT IGNORE INTO act_recipes
(act_id, product_id, quantity_per_act, unit, measurement_mode, confidence, source_note)
SELECT a.id, p.id, 0.100, 'g', 'estimation', 'faible', 'A mesurer au cabinet'
FROM clinical_acts a, inventory_products p
WHERE a.name = 'Collage couronne' AND p.name = 'Acide orthophosphorique gel bleu';

INSERT IGNORE INTO act_recipes
(act_id, product_id, quantity_per_act, unit, measurement_mode, confidence, source_note)
SELECT a.id, p.id, 0.019, 'g', 'estimation', 'faible', 'A mesurer au cabinet'
FROM clinical_acts a, inventory_products p
WHERE a.name = 'Collage couronne' AND p.name = 'Adhesif / bonding';

INSERT IGNORE INTO act_recipes
(act_id, product_id, quantity_per_act, unit, measurement_mode, confidence, source_note)
SELECT a.id, p.id, 0.300, 'g', 'estimation', 'faible', 'A mesurer au cabinet'
FROM clinical_acts a, inventory_products p
WHERE a.name = 'Collage couronne' AND p.name = 'Ciment de scellement';

INSERT IGNORE INTO act_recipes
(act_id, product_id, quantity_per_act, unit, measurement_mode, confidence, source_note)
SELECT a.id, p.id, 1.000, 'unite', 'comptage', 'moyenne', 'A mesurer au cabinet'
FROM clinical_acts a, inventory_products p
WHERE a.name = 'Collage couronne' AND p.name = 'Microbrush';

INSERT IGNORE INTO act_recipes
(act_id, product_id, quantity_per_act, unit, measurement_mode, confidence, source_note)
SELECT a.id, p.id, 1.000, 'unite', 'comptage', 'moyenne', 'Si embout automix utilise'
FROM clinical_acts a, inventory_products p
WHERE a.name = 'Collage couronne' AND p.name = 'Embout automix jete';

