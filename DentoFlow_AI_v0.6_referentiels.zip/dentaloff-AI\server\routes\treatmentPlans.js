const express = require('express');
const { pool } = require('../db');
const { auth, adminOnly, docteurOnly } = require('../middleware/auth');
const { calculateActCost } = require('../services/inventoryService');
const { logAudit } = require('../services/auditService');

const router = express.Router();
const asyncHandler = fn => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

const PLAN_STATUSES = new Set(['draft', 'proposed', 'accepted', 'in_progress', 'completed', 'cancelled']);
const ITEM_STATUSES = new Set(['planned', 'accepted', 'performed', 'cancelled']);

async function enrichPlan(plan) {
  const [items] = await pool.query(
    `SELECT tpi.*, ca.name AS act_name, ca.clinical_variant
     FROM treatment_plan_items tpi
     LEFT JOIN clinical_acts ca ON ca.id = tpi.act_id
     WHERE tpi.plan_id = ?
     ORDER BY tpi.display_order, tpi.id`,
    [plan.id]
  );
  return { ...plan, items };
}

router.get('/', auth, adminOnly, asyncHandler(async (req, res) => {
  const params = [];
  const where = [];
  if (req.query.patient_id) { where.push('tp.patient_id = ?'); params.push(req.query.patient_id); }
  if (req.query.status) { where.push('tp.status = ?'); params.push(req.query.status); }
  const [rows] = await pool.query(
    `SELECT tp.*, CONCAT(p.prenom, ' ', p.nom) AS patient_name,
            COUNT(tpi.id) AS item_count
     FROM treatment_plans tp
     JOIN patients p ON p.id_patient = tp.patient_id
     LEFT JOIN treatment_plan_items tpi ON tpi.plan_id = tp.id
     ${where.length ? `WHERE ${where.join(' AND ')}` : ''}
     GROUP BY tp.id
     ORDER BY tp.updated_at DESC, tp.id DESC
     LIMIT 300`,
    params
  );
  res.json(rows);
}));

router.get('/:id', auth, adminOnly, asyncHandler(async (req, res) => {
  const [[plan]] = await pool.query('SELECT * FROM treatment_plans WHERE id = ?', [req.params.id]);
  if (!plan) return res.status(404).json({ error: 'Plan de traitement introuvable.' });
  res.json(await enrichPlan(plan));
}));

router.post('/', auth, docteurOnly, asyncHandler(async (req, res) => {
  const patientId = String(req.body.patient_id || '').trim();
  const title = String(req.body.title || 'Plan de traitement').trim();
  const status = PLAN_STATUSES.has(req.body.status) ? req.body.status : 'draft';
  if (!patientId || !title) return res.status(400).json({ error: 'Patient et titre requis.' });
  const [[patient]] = await pool.query('SELECT id_patient FROM patients WHERE id_patient = ?', [patientId]);
  if (!patient) return res.status(404).json({ error: 'Patient introuvable.' });
  const [result] = await pool.query(
    `INSERT INTO treatment_plans (patient_id, title, status, estimated_total_tnd, notes, created_by)
     VALUES (?, ?, ?, ?, ?, ?)`,
    [patientId, title, status, req.body.estimated_total_tnd || null, String(req.body.notes || '').trim() || null, req.user?.username || req.user?.role || null]
  );
  await logAudit(pool, req, { action: 'TREATMENT_PLAN_CREATE', entity_type: 'treatment_plan', entity_id: result.insertId, patient_id: patientId });
  res.status(201).json(await enrichPlan({ id: result.insertId, patient_id: patientId, title, status }));
}));

router.post('/:id/items', auth, docteurOnly, asyncHandler(async (req, res) => {
  const [[plan]] = await pool.query('SELECT * FROM treatment_plans WHERE id = ?', [req.params.id]);
  if (!plan) return res.status(404).json({ error: 'Plan de traitement introuvable.' });
  const actId = req.body.act_id ? Number(req.body.act_id) : null;
  const label = String(req.body.label || '').trim();
  const status = ITEM_STATUSES.has(req.body.status) ? req.body.status : 'planned';
  if (!label && !actId) return res.status(400).json({ error: 'Libelle ou acte requis.' });
  let estimatedMaterialCost = req.body.estimated_material_cost_tnd || null;
  let finalLabel = label;
  if (actId) {
    const [[act]] = await pool.query('SELECT * FROM clinical_acts WHERE id = ?', [actId]);
    if (!act) return res.status(404).json({ error: 'Acte introuvable.' });
    if (!finalLabel) finalLabel = `${act.name} - ${act.clinical_variant}`;
    const cost = await calculateActCost(pool, actId);
    estimatedMaterialCost = cost.total_cost_tnd ?? cost.partial_cost_tnd ?? estimatedMaterialCost;
  }
  const [result] = await pool.query(
    `INSERT INTO treatment_plan_items
       (plan_id, act_id, tooth_number, quadrant, label, status, estimated_price_tnd,
        estimated_material_cost_tnd, display_order, notes)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      req.params.id,
      actId,
      String(req.body.tooth_number || '').trim() || null,
      String(req.body.quadrant || '').trim() || null,
      finalLabel,
      status,
      req.body.estimated_price_tnd || null,
      estimatedMaterialCost,
      Number(req.body.display_order || 0),
      String(req.body.notes || '').trim() || null,
    ]
  );
  await logAudit(pool, req, { action: 'TREATMENT_PLAN_ITEM_CREATE', entity_type: 'treatment_plan_item', entity_id: result.insertId, patient_id: plan.patient_id, details: { plan_id: req.params.id, act_id: actId } });
  res.status(201).json(await enrichPlan(plan));
}));

router.put('/:id/status', auth, docteurOnly, asyncHandler(async (req, res) => {
  const status = String(req.body.status || '');
  if (!PLAN_STATUSES.has(status)) return res.status(400).json({ error: 'Statut plan invalide.' });
  const [[plan]] = await pool.query('SELECT * FROM treatment_plans WHERE id = ?', [req.params.id]);
  if (!plan) return res.status(404).json({ error: 'Plan de traitement introuvable.' });
  await pool.query('UPDATE treatment_plans SET status = ? WHERE id = ?', [status, req.params.id]);
  await logAudit(pool, req, { action: 'TREATMENT_PLAN_STATUS_UPDATE', entity_type: 'treatment_plan', entity_id: req.params.id, patient_id: plan.patient_id, details: { previous: plan.status, next: status } });
  res.json({ ok: true });
}));

router.use((err, _req, res, _next) => {
  res.status(400).json({ error: err.message || 'Erreur plan de traitement.' });
});

module.exports = router;
