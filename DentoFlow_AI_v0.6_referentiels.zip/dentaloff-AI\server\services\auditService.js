async function logAudit(db, req, entry = {}) {
  try {
    const user = req?.user || {};
    const actor = user.username || user.email || user.id_patient || user.role || 'anonymous';
    const role = user.role || (user.id_patient ? 'patient' : 'visitor');
    const details = entry.details === undefined ? null : JSON.stringify(entry.details).slice(0, 5000);
    await db.query(
      `INSERT INTO audit_logs
         (actor, actor_role, action, entity_type, entity_id, patient_id, ip_address, user_agent, details_json)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        String(actor).slice(0, 120),
        String(role).slice(0, 40),
        String(entry.action || 'UNSPECIFIED').slice(0, 80),
        entry.entity_type ? String(entry.entity_type).slice(0, 80) : null,
        entry.entity_id === undefined || entry.entity_id === null ? null : String(entry.entity_id).slice(0, 80),
        entry.patient_id || null,
        req?.ip ? String(req.ip).slice(0, 64) : null,
        req?.headers?.['user-agent'] ? String(req.headers['user-agent']).slice(0, 255) : null,
        details,
      ]
    );
  } catch (error) {
    console.error('Audit log impossible:', error.message);
  }
}

module.exports = { logAudit };
