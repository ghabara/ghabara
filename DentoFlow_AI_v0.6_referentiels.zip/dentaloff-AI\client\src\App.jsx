import { Routes, Route, Navigate } from 'react-router-dom';
import { getUser } from './api';
import Home from './pages/Home.jsx';
import Login from './pages/Login.jsx';
import Register from './pages/Register.jsx';
import Rdv from './pages/Rdv.jsx';
import Profil from './pages/Profil.jsx';
import Admin from './pages/Admin.jsx';

// Protège l'accès au profil patient
function Private({ children }) {
  return getUser() ? children : <Navigate to="/login" replace />;
}

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/login" element={<Login />} />
      <Route path="/inscription" element={<Register />} />
      <Route path="/rdv" element={<Rdv />} />
      <Route path="/profil" element={<Private><Profil /></Private>} />
      <Route path="/admin" element={<Admin />} />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
