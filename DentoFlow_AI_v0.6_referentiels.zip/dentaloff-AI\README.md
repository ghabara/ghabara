﻿# DentoFlow AI

Application web full-stack pour cabinet dentaire : portail patient, rendez-vous, dossiers cliniques, administration et plateforme de pilotage intelligent.

Positionnement produit :

```text
Savoir ce que chaque acte consomme, combien il coûte, et quoi acheter avant d'être en rupture.
```

Stack : React/Vite, Express.js, MySQL ou MariaDB.

## Installation

### 1. Base de donnees

1. Demarrer MySQL/MariaDB.
2. Importer `database/dentaloff_ai.sql`.
3. Importer ensuite `database/stock_ai_migration.sql` si besoin.
4. Importer `database/pilotage_intelligent_migration.sql` pour les tables audit, lots, plans de traitement et laboratoire enrichi.
5. Importer `database/reference_harmonization_migration.sql` pour la couche alias, conflits, revue et logs.
6. Importer `database/dentoflow_branding_migration.sql` pour l'identite visible DentoFlow AI.
7. Importer `database/cabinet_info_wael_ghabara_migration.sql` pour les coordonnees cabinet officielles.
8. Importer `database/lab_stock_migration.sql`, `database/lab_communication_migration.sql`, `database/clinical_assistant_migration.sql` et `database/online_sync_candidates_migration.sql` pour les extensions controlees.
9. Importer `database/reference_catalogs_migration.sql` pour les bibliotheques candidates : consommables laboratoire, prix produits internationaux, prix actes dentaires, prix actes de laboratoire, conflits et journaux d'import.
10. Importer `database/inventory_reference_price_backfill_migration.sql` pour rattacher les prix indicatifs candidats aux produits actifs sans prix reel.
11. Importer `database/act_product_catalog_migration.sql` puis `database/act_product_catalog_seed.sql` pour le referentiel actes dentaires, produits cabinet et consommations moyennes par acte.
12. Importer `database/rapport_france_consumption_seed.sql` pour les standards issus du rapport France : consommations par acte, conditionnements, patients couverts et indicateurs macro.
13. Importer facultativement `database/stock_ai_demo_seed.sql` pour les donnees de demo Stock AI.

La base par defaut s'appelle `dentaloff_ai`.

### 2. Serveur

```bash
cd server
copy .env.example .env
npm install
npm run dev
```

API locale : `http://localhost:4000`.

### 3. Client

```bash
cd client
npm install
npm run dev
```

Interface locale : `http://localhost:5173`.

## Modules

- Site public du cabinet et reservation en ligne.
- Espace patient : rendez-vous, annulation, notes.
- Administration : cockpit de pilotage, patients, rendez-vous, dossiers cliniques, odontogramme, cas cliniques assistes, workflow numerique, services, horaires, informations cabinet.
- Dossiers cliniques : fiche medicale et documents telecharges via route authentifiee.
- Espace docteur : fiches, ordonnances, corrections sensibles.
- Stock AI : vues cabinet et laboratoire sur le meme moteur, produits, achats, lots, peremptions, recettes par acte, actes realises, mouvements, cout matiere, alertes, liste d’achat et assistant IA local.
- Pilotage IA : scoring rupture/peremption/surstock, couverture estimee, quantite recommandee a commander.
- References France : 15 standards de consommation extraits du rapport PDF et 11 indicateurs de marche/fiscalite, relies aux produits et recettes Stock AI.
- Harmonisation des referentiels : alias produits/actes/marques, doublons probables, conflits a valider, logs d'import et audit des decisions humaines.
- Referentiels candidats : import et consultation de catalogues internationaux produits/actes/laboratoire sous `/api/references`, sans ecrasement des stocks reels, lots, mouvements ni prix cabinet valides.
- Rattrapage prix indicatifs : les produits actifs sans prix reel peuvent recevoir un prix referentiel candidat, affiche comme `Indicatif a valider` avant validation explicite comme prix d'achat.
- Referentiel actes-produits : 72 actes dentaires, 107 produits cabinet/labo et 107 lignes de consommation candidate sous `/api/act-product-catalog`, avec quantite min/typique/max, validation praticien et cout matiere estime si un prix reel ou indicatif fiable existe.
- API cockpit : `/api/pilotage/overview` agrège agenda, actes, coût matière, achats, alertes, labo et produits à commander.
- Plans de traitement : actes prevus, dent/quadrant, passage vers acte realise et cout matiere estime.
- Laboratoire : demande labo, statut, date envoi/retour, teinte, materiau, cout labo, historique evenementiel et tables de communication cabinet-laboratoire.

Documentation detaillee : `README_STOCK_AI.md`, `RAPPORT_CODEX_PILOTAGE_INTELLIGENT.md`, `RAPPORT_HARMONISATION_REFERENTIELS.md`, `RAPPORT_HARMONISATION_CODEX.md` et `RAPPORT_DENTOFLOW_AI_V0.5.md`.

## Harmonisation des referentiels

La commande suivante harmonise les sources deja integrees sans repartir d'une base vide :

```bash
cd server
npm run harmonize
```

Elle cree ou complete `reference_aliases`, `reference_conflicts`, `reference_import_logs`, `reference_mapping_review`, `brand_aliases`, `commercial_equivalences` et `recipe_versions`. Les conflits restent en attente de validation humaine dans l'admin, onglet `Harmonisation`.

## Referentiels candidats

L'admin contient un onglet `Referentiels` separe de l'harmonisation. Il permet d'importer ou de mettre a jour les bibliotheques candidates, de filtrer par pays/categorie/statut, de valider ou rejeter une reference, de preparer une fiche produit candidate et de consulter les conflits et journaux d'import.

Routes principales : `/api/references/dashboard`, `/api/references/lab-consumables`, `/api/references/international-prices`, `/api/references/dental-act-prices`, `/api/references/lab-act-prices`, `/api/references/conflicts` et `/api/references/import-logs`.

## Referentiel actes-produits

L'admin contient deux entrees dediees : `Referentiel actes` et `Referentiel produits`. Elles exposent aussi le sous-onglet `Consommations par acte`, qui relie :

```text
acte dentaire -> produit consomme -> quantite min/typique/max -> cout matiere estime -> validation humaine
```

L'import `/api/act-product-catalog/import` est idempotent. Il ne cree pas de stock reel, ne deduit aucun produit et n'ecrase pas les actes, produits, recettes ou prix deja valides. Le bouton `Creer produit reel depuis reference` cree seulement un candidat dans `reference_product_candidates`; la fiche stock reelle reste a valider manuellement.

## Securite

Les donnees patients et documents medicaux sont sensibles. Avant production : changer `JWT_SECRET`, les mots de passe initiaux, le mot de passe MySQL, activer HTTPS, sauvegarder regulierement, tester les droits par role, conserver les logs d’audit et valider la configuration serveur.

## Inspiration open source

La refonte s'inspire de bonnes pratiques observees dans des projets open source de gestion d'inventaire, agenda et systemes cliniques. Aucun code GPL/AGPL n'est integre directement dans ce livrable. Voir `THIRD_PARTY_NOTICES.md`.
