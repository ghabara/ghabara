﻿import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import api, { saveSession } from '../api';
import BrandLogo from '../components/BrandLogo.jsx';

export default function Register() {
  const [f, setF] = useState({ prenom: '', nom: '', age: '', genre: '', tel: '', email: '', pass: '', pass2: '' });
  const [consent, setConsent] = useState(false);
  const [alert, setAlert] = useState(null);
  const [done, setDone] = useState(false);
  const navigate = useNavigate();
  const set = (k, v) => setF({ ...f, [k]: v });

  const submit = async () => {
    setAlert(null);
    const { prenom, nom, age, genre, tel, email, pass, pass2 } = f;
    if (!prenom || !nom || !age || !genre || !tel || !email || !pass)
      return setAlert('Veuillez remplir tous les champs obligatoires.');
    if (/\d/.test(prenom) || !/^[a-zA-ZÀ-ÿ\s\-']+$/.test(prenom))
      return setAlert('Le prénom ne doit contenir que des lettres.');
    if (/\d/.test(nom) || !/^[a-zA-ZÀ-ÿ\s\-']+$/.test(nom))
      return setAlert('Le nom ne doit contenir que des lettres.');
    if (isNaN(age) || age < 1 || age > 120) return setAlert('Âge invalide (1–120).');
    if (tel.replace(/\D/g, '').length !== 8) return setAlert('Le téléphone doit contenir exactement 8 chiffres.');
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) return setAlert('Adresse e-mail invalide.');
    if (pass.length < 6) return setAlert('Mot de passe : au moins 6 caractères.');
    if (pass !== pass2) return setAlert('Les mots de passe ne correspondent pas.');
    if (!consent) return setAlert("Veuillez accepter les conditions d'utilisation.");

    try {
      const { data } = await api.post('/register', { prenom, nom, age, genre, tel, email, password: pass });
      saveSession(data.user, data.token);
      setDone(data.user.id_patient);
    } catch (e) {
      setAlert(e.response?.data?.error || 'Erreur lors de la création.');
    }
  };

  if (done) {
    return (
      <div className="dc">
        <div className="dc-formpage center">
          <div className="dc-halo">
            <div className="dc-card dc-reveal dc-d1" style={{ width: 470, maxWidth: '92vw', textAlign: 'center' }}>
              <div className="dc-bigemoji">🌿</div>
              <h2 style={{ fontFamily: "'Fraunces',serif", fontWeight: 600, fontSize: 28, color: 'var(--ink)', marginTop: 6 }}>
                Bienvenue chez DentoFlow AI
              </h2>
              <p className="dc-muted" style={{ margin: '12px 0' }}>
                Votre compte est créé.<br />Votre identifiant patient : <strong style={{ color: 'var(--ink)' }}>{done}</strong>
              </p>
              <div style={{ display: 'flex', gap: 10, justifyContent: 'center', flexWrap: 'wrap', marginTop: 18 }}>
                <Link to="/" className="dc-btn dc-btn-soft">Accueil</Link>
                <Link to="/rdv" className="dc-btn dc-btn-gold">Prendre RDV</Link>
                <Link to="/profil" className="dc-btn dc-btn-solid">Mon espace</Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="dc">
      <div className="dc-formpage center">
        <div className="dc-halo">
          <div className="dc-card dc-reveal dc-d1" style={{ width: 580, maxWidth: '94vw' }}>
            <div className="dc-card-head">
              <Link to="/" className="brand-link"><BrandLogo className="brand-logo--login" /></Link>
              <span className="dc-eyebrow">Nouveau patient</span>
              <h2 style={{ marginTop: 12 }}>Créer votre compte</h2>
              <p>Les champs marqués <span style={{ color: 'var(--gold-deep)' }}>*</span> sont obligatoires.</p>
            </div>

            {alert && <div className="dc-alert error">{alert}</div>}

            <div className="dc-row2">
              <div className="dc-field"><label>Prénom <span className="req">*</span></label>
                <input value={f.prenom} onChange={e => set('prenom', e.target.value)} placeholder="Mohamed" /></div>
              <div className="dc-field"><label>Nom <span className="req">*</span></label>
                <input value={f.nom} onChange={e => set('nom', e.target.value)} placeholder="Ben Ali" /></div>
            </div>
            <div className="dc-row2">
              <div className="dc-field"><label>Âge <span className="req">*</span></label>
                <input type="number" value={f.age} onChange={e => set('age', e.target.value)} placeholder="30" /></div>
              <div className="dc-field"><label>Genre <span className="req">*</span></label>
                <select value={f.genre} onChange={e => set('genre', e.target.value)}>
                  <option value="">— Choisir —</option>
                  <option value="Masculin">Masculin</option>
                  <option value="Féminin">Féminin</option>
                </select></div>
            </div>
            <div className="dc-field"><label>Téléphone <span className="req">*</span></label>
              <input value={f.tel} onChange={e => set('tel', e.target.value)} placeholder="8 chiffres" /></div>
            <div className="dc-field"><label>Adresse e-mail <span className="req">*</span></label>
              <input type="email" value={f.email} onChange={e => set('email', e.target.value)} placeholder="vous@email.com" /></div>
            <div className="dc-row2">
              <div className="dc-field"><label>Mot de passe <span className="req">*</span></label>
                <input type="password" value={f.pass} onChange={e => set('pass', e.target.value)} placeholder="••••••••" /></div>
              <div className="dc-field"><label>Confirmer <span className="req">*</span></label>
                <input type="password" value={f.pass2} onChange={e => set('pass2', e.target.value)} placeholder="••••••••" /></div>
            </div>

            <label className="dc-check">
              <input type="checkbox" checked={consent} onChange={e => setConsent(e.target.checked)} />
              J'accepte les conditions d'utilisation et la politique de confidentialité de DentoFlow AI.
            </label>

            <button className="dc-btn dc-btn-solid dc-btn-block" onClick={submit}>Créer mon compte</button>
            <p className="dc-switch">Déjà inscrit ? <Link to="/login">Se connecter</Link></p>
          </div>
        </div>
      </div>
    </div>
  );
}
