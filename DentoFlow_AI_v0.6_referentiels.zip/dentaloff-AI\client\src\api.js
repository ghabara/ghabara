import axios from 'axios';

// Instance axios : toutes les requêtes passent par /api (proxy Vite -> Express)
const api = axios.create({ baseURL: '/api' });

// Ajoute automatiquement le jeton à chaque requête
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('dc_token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// ── Session patient ─────────────────────────────────────────
export const saveSession = (user, token) => {
  localStorage.setItem('dc_token', token);
  localStorage.setItem('dc_user', JSON.stringify(user));
};
export const getUser = () => {
  try { return JSON.parse(localStorage.getItem('dc_user') || 'null'); }
  catch { return null; }
};
export const logout = () => {
  localStorage.removeItem('dc_token');
  localStorage.removeItem('dc_user');
};

// ── Session admin (séparée) ─────────────────────────────────
export const saveAdmin = (user, token) => {
  localStorage.setItem('dc_admin_token', token);
  localStorage.setItem('dc_admin', JSON.stringify(user));
};
export const getAdmin = () => {
  try { return JSON.parse(localStorage.getItem('dc_admin') || 'null'); }
  catch { return null; }
};
export const adminLogout = () => {
  localStorage.removeItem('dc_admin_token');
  localStorage.removeItem('dc_admin');
};

// Pour l'admin on utilise un en-tête dédié au moment de l'appel
export const adminApi = axios.create({ baseURL: '/api' });
adminApi.interceptors.request.use((config) => {
  const token = localStorage.getItem('dc_admin_token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

export default api;
