﻿import { useEffect, useMemo, useState } from 'react';
import { adminApi } from '../api';

const units = ['g', 'ml', 'unite', 'paire', 'carpule', 'sachet', 'seringue', 'embout', 'cartouche', 'bloc', 'disque', 'boite'];
const tabs = [
  ['dashboard', 'Tableau de bord'],
  ['products', 'Stock AI Cabinet'],
  ['labProducts', 'Stock AI Laboratoire'],
  ['acts', 'Actes'],
  ['recipes', 'Recettes'],
  ['performed', 'Actes realises'],
  ['purchases', 'Achats'],
  ['shopping', "Liste d'achat"],
  ['insights', 'Pilotage IA'],
  ['alerts', 'Alertes IA'],
  ['assistant', 'Assistant local'],
  ['lab', 'Laboratoire'],
];

const emptyProduct = {
  name: '',
  category: '',
  sub_category: '',
  tracking_unit: 'unite',
  package_quantity: '',
  package_unit: '',
  package_price_tnd: '',
  current_stock: '0',
  min_stock: '0',
  max_stock: '',
  reserved_stock: '0',
  storage_location: '',
  barcode: '',
  lot_strategy: 'GLOBAL',
  supplier_alias: '',
  supplier_lead_days: '',
  expiration_date: '',
  lot_number: '',
  source_type: 'Saisie cabinet',
  context_type: 'CABINET',
  notes: '',
};

const emptyAct = {
  name: '',
  clinical_variant: 'Standard',
  category: '',
  default_duration_minutes: '',
  default_price_tnd: '',
  notes: '',
};

const emptyRecipe = {
  act_id: '',
  product_id: '',
  recipe_variant: 'Standard',
  quantity_per_act: '',
  unit: 'unite',
  measurement_mode: 'estimation',
  confidence: 'moyenne',
  source_note: 'Saisie manuelle',
};

export default function StockAiModule({ admin }) {
  const [tab, setTab] = useState('dashboard');
  const canDoctor = ['docteur', 'admin'].includes(admin?.role);
  return (
    <>
      <PanelTitle
        title="DentoFlow AI Pilotage & Stock AI"
        sub="Plateforme de pilotage du cabinet : ce que chaque acte consomme, combien il coute, et quoi acheter avant rupture."
      />
      <div style={{ display: 'flex', gap: 8, marginBottom: 20, flexWrap: 'wrap' }}>
        {tabs.map(([key, label]) => (
          <button
            key={key}
            className={tab === key ? 'btn btn-primary' : 'btn btn-secondary'}
            onClick={() => setTab(key)}
            style={{ fontSize: 13 }}
          >
            {label}
          </button>
        ))}
      </div>
      {tab === 'dashboard' && <Dashboard canDoctor={canDoctor} />}
      {tab === 'products' && <Products canDoctor={canDoctor} contextFilter="CABINET" defaultContext="CABINET" />}
      {tab === 'labProducts' && <Products canDoctor={canDoctor} contextFilter="LAB" defaultContext="LAB" />}
      {tab === 'acts' && <Acts canDoctor={canDoctor} />}
      {tab === 'recipes' && <Recipes canDoctor={canDoctor} />}
      {tab === 'performed' && <PerformedActs canDoctor={canDoctor} />}
      {tab === 'purchases' && <Purchases />}
      {tab === 'shopping' && <ShoppingList />}
      {tab === 'insights' && <InventoryInsights />}
      {tab === 'alerts' && <AiAlerts />}
      {tab === 'assistant' && <AssistantAi />}
      {tab === 'lab' && <LabPlaceholder />}
    </>
  );
}

function PanelTitle({ title, sub }) {
  return (
    <div style={{ marginBottom: 22 }}>
      <h2 className="section-title">{title}</h2>
      {sub && <p className="muted">{sub}</p>}
    </div>
  );
}

function Money({ value }) {
  if (value === null || value === undefined || value === '') return <span className="muted">-</span>;
  const n = Number(value);
  if (!Number.isFinite(n)) return <span className="muted">-</span>;
  return <span>{n.toFixed(3)} TND</span>;
}

function CurrencyMoney({ value, currency }) {
  if (value === null || value === undefined || value === '') return <span className="muted">-</span>;
  const n = Number(value);
  if (!Number.isFinite(n)) return <span className="muted">-</span>;
  return <span>{n.toFixed(3)} {currency || ''}</span>;
}

function Qty({ value, unit }) {
  if (value === null || value === undefined || value === '') return <span className="muted">-</span>;
  const n = Number(value);
  return <span>{Number.isFinite(n) ? trimNumber(n) : value} {unit || ''}</span>;
}

function trimNumber(n) {
  return n.toFixed(4).replace(/0+$/, '').replace(/\.$/, '');
}

function Badge({ tone = 'info', children }) {
  const palette = {
    ok: ['var(--g5)', 'var(--g2)'],
    warn: ['#fff3e0', '#e65100'],
    err: ['#fdecea', '#c62828'],
    info: ['#eef5ff', 'var(--color-primary)'],
  };
  const [bg, color] = palette[tone] || palette.info;
  return <span className="badge-status" style={{ background: bg, color }}>{children}</span>;
}

function ErrorLine({ error }) {
  return error ? <div className="alert error">{error}</div> : null;
}

function SuccessLine({ message }) {
  return message ? <div className="alert success">{message}</div> : null;
}

function Dashboard({ canDoctor }) {
  const [data, setData] = useState(null);
  const [error, setError] = useState('');
  const [message, setMessage] = useState('');
  const load = () => Promise.all([adminApi.get('/inventory/dashboard'), adminApi.get('/ai/inventory-insights')])
    .then(([d, i]) => setData({ ...d.data, insights: i.data }))
    .catch(e => setError(e.response?.data?.error || 'Erreur tableau de bord.'));
  useEffect(() => { load(); }, []);
  const backfillPrices = async () => {
    setError(''); setMessage('');
    try {
      const { data: result } = await adminApi.post('/inventory/products/backfill-reference-prices');
      setMessage(`${result.updated || 0} prix indicatifs candidats rattaches sur ${result.found || 0} produits a verifier.`);
      await load();
    } catch (e) { setError(e.response?.data?.error || 'Rattrapage impossible.'); }
  };
  if (!data) return <ErrorLine error={error} />;
  return (
    <>
      <ErrorLine error={error} />
      <SuccessLine message={message} />
      {canDoctor && (
        <div className="card" style={{ marginBottom: 16 }}>
          <div className="dashboard-line">
            <div>
              <strong>Rattrapage controle des prix manquants</strong>
              <p className="muted" style={{ margin: '4px 0 0' }}>Ajoute seulement des prix indicatifs candidats, sans ecrire de prix reel dans le stock.</p>
            </div>
            <button className="btn btn-secondary" onClick={backfillPrices}>Rattacher prix indicatifs</button>
          </div>
        </div>
      )}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(180px,1fr))', gap: 16 }}>
        <Kpi label="Produits actifs" value={data.product_count || 0} />
        <Kpi label="Valeur stock" value={<Money value={data.estimated_stock_value_tnd} />} />
        <Kpi label="Stock bas" value={data.low_stock_count || 0} tone={data.low_stock_count ? 'err' : 'ok'} />
        <Kpi label="Peremption proche" value={data.expiration_soon_count || 0} tone={data.expiration_soon_count ? 'warn' : 'ok'} />
        <Kpi label="Prix reel manquant" value={data.missing_real_price_count ?? data.missing_price_count ?? 0} tone={data.missing_real_price_count ? 'warn' : 'ok'} />
        <Kpi label="Indicatifs a valider" value={data.reference_price_candidate_count || 0} tone={data.reference_price_candidate_count ? 'warn' : 'ok'} />
        <Kpi label="Conditionnement manquant" value={data.missing_package_quantity_count || 0} tone={data.missing_package_quantity_count ? 'warn' : 'ok'} />
        <Kpi label="Actes ce mois" value={data.performed_this_month || 0} />
        <Kpi label="Cout moyen" value={<Money value={data.average_actual_cost_tnd} />} />
        <Kpi label="Risque critique" value={data.insights?.summary?.critical_count || 0} tone={data.insights?.summary?.critical_count ? 'err' : 'ok'} />
      </div>

      <div className="table-wrap" style={{ marginTop: 18 }}>
        <table>
          <thead><tr><th>Alerte prioritaire</th><th>Severite</th><th>Recommandation</th></tr></thead>
          <tbody>
            {(data.alerts || []).map(a => (
              <tr key={a.id}>
                <td>{a.message}</td>
                <td><Severity severity={a.severity} /></td>
                <td className="muted">{a.recommendation || '-'}</td>
              </tr>
            ))}
            {!(data.alerts || []).length && <tr><td colSpan="3" className="center muted" style={{ padding: 24 }}>Aucune alerte ouverte.</td></tr>}
          </tbody>
        </table>
      </div>
    </>
  );
}

function Kpi({ label, value, tone = 'info' }) {
  const color = tone === 'err' ? '#c62828' : tone === 'warn' ? '#e65100' : 'var(--g1)';
  return (
    <div className="card">
      <div style={{ fontSize: 28, fontWeight: 700, color, marginBottom: 8 }}>{value}</div>
      <div className="muted">{label}</div>
    </div>
  );
}

function Severity({ severity }) {
  if (severity === 'CRITICAL') return <Badge tone="err">Critique</Badge>;
  if (severity === 'WARNING') return <Badge tone="warn">A surveiller</Badge>;
  return <Badge>Info</Badge>;
}

function makeEmptyProduct(contextType = 'CABINET') {
  return {
    ...emptyProduct,
    context_type: contextType,
    source_type: contextType === 'LAB' ? 'Saisie laboratoire' : 'Saisie cabinet',
  };
}

function Products({ canDoctor, contextFilter = '', defaultContext = 'CABINET' }) {
  const [products, setProducts] = useState([]);
  const [form, setForm] = useState(makeEmptyProduct(defaultContext));
  const [editing, setEditing] = useState(null);
  const [aiText, setAiText] = useState('');
  const [aiProposal, setAiProposal] = useState(null);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const load = () => adminApi.get('/inventory/products').then(r => setProducts(r.data)).catch(e => setError(e.response?.data?.error || 'Erreur produits.'));
  const visibleProducts = contextFilter ? products.filter(p => [contextFilter, 'BOTH'].includes(p.context_type || 'CABINET')) : products;
  const contextLabel = defaultContext === 'LAB' ? 'laboratoire' : 'cabinet';
  useEffect(() => { load(); }, []);

  const save = async () => {
    if (!canDoctor) return;
    setError(''); setMessage('');
    try {
      if (editing) await adminApi.put(`/inventory/products/${editing}`, form);
      else await adminApi.post('/inventory/products', form);
      setForm(makeEmptyProduct(defaultContext)); setEditing(null); setAiProposal(null); setMessage('Produit enregistre.'); load();
    } catch (e) { setError(e.response?.data?.error || 'Erreur enregistrement produit.'); }
  };
  const edit = (p) => {
    setEditing(p.id);
    setForm({
      ...emptyProduct,
      ...p,
      expiration_date: p.expiration_date ? String(p.expiration_date).slice(0, 10) : '',
    });
  };
  const deactivate = async (id) => {
    if (!confirm('Desactiver ce produit ?')) return;
    await adminApi.delete(`/inventory/products/${id}`);
    load();
  };
  const normalize = async () => {
    setError(''); setAiProposal(null);
    try {
      const { data } = await adminApi.post('/ai/normalize-product', { text: aiText });
      setAiProposal(data.proposal);
      setForm({ ...makeEmptyProduct(defaultContext), ...data.proposal, context_type: defaultContext, source_type: 'IA locale a valider' });
    } catch (e) { setError(e.response?.data?.error || 'Normalisation impossible.'); }
  };
  const correctStock = async (p) => {
    const value = prompt(`Nouveau stock pour ${p.name} (${p.tracking_unit})`, p.current_stock ?? 0);
    if (value === null) return;
    try {
      await adminApi.post(`/inventory/products/${p.id}/correction`, { new_stock: value, comment: 'Correction manuelle depuis Stock AI' });
      load();
    } catch (e) { alert(e.response?.data?.error || 'Correction impossible.'); }
  };
  const validateReferencePriceForProduct = async (p) => {
    if (!confirm(`Valider le prix indicatif de ${p.name} comme prix d'achat ?`)) return;
    try {
      await adminApi.post(`/inventory/products/${p.id}/validate-reference-price`);
      setMessage('Prix indicatif valide comme prix d achat.'); load();
    } catch (e) { alert(e.response?.data?.error || 'Validation du prix impossible.'); }
  };

  return (
    <>
      <ErrorLine error={error} />
      <SuccessLine message={message} />
      {canDoctor && (
        <div className="form-card">
          <h3>{editing ? 'Modifier un produit' : `Ajouter un produit ${contextLabel}`}</h3>
          <div className="form-row2">
            <Field label="Nom" value={form.name} onChange={v => setForm({ ...form, name: v })} />
            <Field label="Categorie" value={form.category} onChange={v => setForm({ ...form, category: v })} />
          </div>
          <div className="form-row2">
            <Field label="Sous-categorie" value={form.sub_category || ''} onChange={v => setForm({ ...form, sub_category: v })} />
            <SelectField label="Unite de suivi" value={form.tracking_unit} onChange={v => setForm({ ...form, tracking_unit: v, package_unit: form.package_unit || v })} options={units} />
          </div>
          <div className="form-row2">
            <Field label="Stock actuel" type="number" step="0.0001" value={form.current_stock ?? ''} onChange={v => setForm({ ...form, current_stock: v })} />
            <Field label="Seuil minimum" type="number" step="0.0001" value={form.min_stock ?? ''} onChange={v => setForm({ ...form, min_stock: v })} />
          </div>
          <div className="form-row2">
            <Field label="Seuil maximum" type="number" step="0.0001" value={form.max_stock ?? ''} onChange={v => setForm({ ...form, max_stock: v })} />
            <Field label="Stock reserve" type="number" step="0.0001" value={form.reserved_stock ?? ''} onChange={v => setForm({ ...form, reserved_stock: v })} />
          </div>
          <div className="form-row2">
            <Field label="Prix conditionnement TND" type="number" step="0.001" value={form.package_price_tnd ?? ''} onChange={v => setForm({ ...form, package_price_tnd: v })} />
            <Field label="Quantite conditionnement" type="number" step="0.0001" value={form.package_quantity ?? ''} onChange={v => setForm({ ...form, package_quantity: v })} />
          </div>
          <div className="form-row2">
            <Field label="Fournisseur" value={form.supplier_alias || ''} onChange={v => setForm({ ...form, supplier_alias: v })} />
            <Field label="Peremption" type="date" value={form.expiration_date || ''} onChange={v => setForm({ ...form, expiration_date: v })} />
          </div>
          <div className="form-row2">
            <Field label="Emplacement" value={form.storage_location || ''} onChange={v => setForm({ ...form, storage_location: v })} />
            <Field label="Code-barres / QR" value={form.barcode || ''} onChange={v => setForm({ ...form, barcode: v })} />
          </div>
          <div className="form-row2">
            <SelectField label="Contexte stock" value={form.context_type || defaultContext} onChange={v => setForm({ ...form, context_type: v })} options={[["CABINET", "Cabinet"], ["LAB", "Laboratoire"], ["BOTH", "Partage"]]} />
            <SelectField label="Strategie lots" value={form.lot_strategy || 'GLOBAL'} onChange={v => setForm({ ...form, lot_strategy: v })} options={[["GLOBAL", "Stock global"], ["LOT_FEFO", "Lots FEFO - peremption prioritaire"]]} />
          </div>
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
            <button className="btn btn-primary" onClick={save}>{editing ? 'Enregistrer' : 'Ajouter'}</button>
            {editing && <button className="btn btn-secondary" onClick={() => { setEditing(null); setForm(makeEmptyProduct(defaultContext)); }}>Annuler</button>}
          </div>
        </div>
      )}

      <div className="form-card">
        <h3>Ajouter avec assistant local</h3>
        <div className="form-row2">
          <Field label="Texte libre" value={aiText} onChange={setAiText} placeholder="comp A2 4g 45dt fournisseur zied exp 12/2026" />
          <div className="fg" style={{ justifyContent: 'end' }}><button className="btn btn-secondary" onClick={normalize}>Analyser</button></div>
        </div>
        {aiProposal && (
          <div className="alert success">
            Proposition prete a valider: {aiProposal.name || '-'} {aiProposal.package_quantity ? `(${aiProposal.package_quantity} ${aiProposal.package_unit})` : ''}
          </div>
        )}
      </div>

      <div className="table-wrap">
        <table>
          <thead><tr><th>Produit</th><th>Stock utile</th><th>Prix unitaire</th><th>Tracabilite</th><th>Contexte</th><th>Alertes</th><th>Actions</th></tr></thead>
          <tbody>
            {visibleProducts.map(p => (
              <tr key={p.id}>
                <td><strong>{p.name}</strong><br /><small className="muted">{p.category} {p.sub_category ? `/ ${p.sub_category}` : ''}</small></td>
                <td><Qty value={Number(p.current_stock || 0) - Number(p.reserved_stock || 0)} unit={p.tracking_unit} /><br /><small className="muted">stock <Qty value={p.current_stock} unit={p.tracking_unit} /> · seuil <Qty value={p.min_stock} unit={p.tracking_unit} /></small></td>
                <td>
                  {p.unit_cost_tnd !== null && p.unit_cost_tnd !== undefined ? <Money value={p.unit_cost_tnd} /> : <Badge tone="warn">Prix reel manquant</Badge>}
                  <ReferencePriceInfo product={p} />
                </td>
                <td className="muted">{p.supplier_alias || '-'}<br /><small>{p.storage_location || 'emplacement a completer'} · {p.lot_strategy === 'LOT_FEFO' ? 'FEFO' : 'global'}</small></td>
                <td><Badge tone={p.context_type === 'LAB' ? 'info' : p.context_type === 'BOTH' ? 'warn' : 'ok'}>{p.context_type === 'LAB' ? 'Laboratoire' : p.context_type === 'BOTH' ? 'Partage' : 'Cabinet'}</Badge></td>
                <td style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                  {p.is_low_stock && <Badge tone="warn">Stock bas</Badge>}
                  {p.real_price_missing && <Badge tone="warn">Prix reel manquant</Badge>}
                  {p.package_quantity_missing && <Badge tone="warn">Conditionnement manquant</Badge>}
                  {p.has_reference_price_candidate && <Badge>Indicatif a valider</Badge>}
                  {p.expiration_status && <Badge tone={p.expiration_status === 'EXPIRED' ? 'err' : 'warn'}>{p.expiration_status === 'EXPIRED' ? 'Perime' : 'Peremption'}</Badge>}
                  {!p.is_low_stock && !p.has_missing_price && !p.expiration_status && <Badge tone="ok">OK</Badge>}
                </td>
                <td>
                  {canDoctor ? (
                    <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                      <button className="btn btn-secondary" style={{ padding: '6px 10px' }} onClick={() => edit(p)}>Modifier</button>
                      <button className="btn btn-secondary" style={{ padding: '6px 10px' }} onClick={() => correctStock(p)}>Corriger</button>
                      {p.has_reference_price_candidate && p.real_price_missing && <button className="btn btn-green" style={{ padding: '6px 10px' }} onClick={() => validateReferencePriceForProduct(p)}>Valider prix</button>}
                      <button className="btn-red" onClick={() => deactivate(p.id)}>Desactiver</button>
                    </div>
                  ) : <span className="muted">Lecture seule</span>}
                </td>
              </tr>
            ))}
            {!visibleProducts.length && <tr><td colSpan="7" className="center muted" style={{ padding: 24 }}>Aucun produit.</td></tr>}
          </tbody>
        </table>
      </div>
    </>
  );
}

function ReferencePriceInfo({ product }) {
  if (!product?.has_reference_price_candidate) return null;
  return (
    <div style={{ marginTop: 6 }}>
      <small className="muted">
        Indicatif a valider : <CurrencyMoney value={product.reference_price_tnd_avg} currency="TND" />
        {product.reference_currency && product.reference_currency !== 'TND' && (
          <> (<CurrencyMoney value={product.reference_price_avg} currency={product.reference_currency} />)</>
        )}
        <br />
        {product.price_source || 'source referentiel'} · non valide fournisseur
      </small>
    </div>
  );
}

function Acts({ canDoctor }) {
  const [acts, setActs] = useState([]);
  const [form, setForm] = useState(emptyAct);
  const [editing, setEditing] = useState(null);
  const [error, setError] = useState('');
  const load = () => adminApi.get('/clinical-acts').then(r => setActs(r.data)).catch(e => setError(e.response?.data?.error || 'Erreur actes.'));
  useEffect(() => { load(); }, []);
  const save = async () => {
    try {
      if (editing) await adminApi.put(`/clinical-acts/${editing}`, form);
      else await adminApi.post('/clinical-acts', form);
      setForm(emptyAct); setEditing(null); load();
    } catch (e) { setError(e.response?.data?.error || 'Erreur enregistrement acte.'); }
  };
  return (
    <>
      <ErrorLine error={error} />
      {canDoctor && (
        <div className="form-card">
          <h3>{editing ? 'Modifier un acte' : 'Creer un acte'}</h3>
          <div className="form-row2">
            <Field label="Nom" value={form.name} onChange={v => setForm({ ...form, name: v })} />
            <Field label="Variante" value={form.clinical_variant} onChange={v => setForm({ ...form, clinical_variant: v })} />
          </div>
          <div className="form-row2">
            <Field label="Categorie" value={form.category || ''} onChange={v => setForm({ ...form, category: v })} />
            <Field label="Prix par defaut TND" type="number" step="0.001" value={form.default_price_tnd || ''} onChange={v => setForm({ ...form, default_price_tnd: v })} />
          </div>
          <button className="btn btn-primary" onClick={save}>{editing ? 'Enregistrer' : 'Ajouter'}</button>
          {editing && <button className="btn btn-secondary" style={{ marginLeft: 8 }} onClick={() => { setEditing(null); setForm(emptyAct); }}>Annuler</button>}
        </div>
      )}
      <div className="table-wrap">
        <table>
          <thead><tr><th>Acte</th><th>Recette</th><th>Cout matiere</th><th>Actes possibles</th><th>Fiabilite</th><th>Action</th></tr></thead>
          <tbody>
            {acts.map(a => (
              <tr key={a.id}>
                <td><strong>{a.name}</strong><br /><small className="muted">{a.clinical_variant}</small></td>
                <td>{a.recipe_line_count} ligne(s)</td>
                <td><Money value={a.cost_summary?.total_cost_tnd ?? a.cost_summary?.partial_cost_tnd} /></td>
                <td>{a.cost_summary?.possible_floor ?? '-'}</td>
                <td>{Math.round((a.cost_summary?.reliability_score || 0) * 100)}%</td>
                <td>{canDoctor && <button className="btn btn-secondary" style={{ padding: '6px 10px' }} onClick={() => { setEditing(a.id); setForm({ ...emptyAct, ...a }); }}>Modifier</button>}</td>
              </tr>
            ))}
            {!acts.length && <tr><td colSpan="6" className="center muted" style={{ padding: 24 }}>Aucun acte.</td></tr>}
          </tbody>
        </table>
      </div>
    </>
  );
}

function Recipes({ canDoctor }) {
  const [acts, setActs] = useState([]);
  const [products, setProducts] = useState([]);
  const [recipes, setRecipes] = useState([]);
  const [selectedAct, setSelectedAct] = useState('');
  const [summary, setSummary] = useState(null);
  const [form, setForm] = useState(emptyRecipe);
  const [suggestion, setSuggestion] = useState(null);
  const [error, setError] = useState('');
  const loadBase = async () => {
    const [a, p] = await Promise.all([adminApi.get('/clinical-acts'), adminApi.get('/inventory/products')]);
    setActs(a.data); setProducts(p.data);
    const first = selectedAct || a.data[0]?.id || '';
    if (first) setSelectedAct(String(first));
  };
  const loadRecipes = async (actId) => {
    if (!actId) return;
    const [r, c] = await Promise.all([adminApi.get(`/recipes?act_id=${actId}`), adminApi.get(`/recipes/act/${actId}/cost`)]);
    setRecipes(r.data); setSummary(c.data);
    setForm(f => ({ ...f, act_id: actId }));
  };
  useEffect(() => { loadBase().catch(e => setError(e.response?.data?.error || 'Erreur recettes.')); }, []);
  useEffect(() => { loadRecipes(selectedAct).catch(e => setError(e.response?.data?.error || 'Erreur chargement recette.')); }, [selectedAct]);
  const save = async () => {
    try {
      await adminApi.post('/recipes', form);
      setForm({ ...emptyRecipe, act_id: selectedAct });
      loadRecipes(selectedAct);
    } catch (e) { setError(e.response?.data?.error || 'Erreur ajout recette.'); }
  };
  const askSuggestion = async () => {
    const act = acts.find(a => String(a.id) === String(selectedAct));
    if (!act) return;
    const { data } = await adminApi.post('/ai/suggest-recipe', { act_name: act.name, clinical_variant: act.clinical_variant });
    setSuggestion(data);
  };
  const useSuggestion = (s) => {
    setForm({
      ...emptyRecipe,
      act_id: selectedAct,
      product_id: s.product_id,
      quantity_per_act: s.quantity_per_act,
      unit: s.unit,
      confidence: s.confidence,
      source_note: `Suggestion IA: ${s.justification}`,
    });
  };
  return (
    <>
      <ErrorLine error={error} />
      <div className="form-card">
        <h3>Choisir un acte</h3>
        <SelectField label="Acte" value={selectedAct} onChange={setSelectedAct} options={acts.map(a => [a.id, `${a.name} - ${a.clinical_variant}`])} />
        {summary && (
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginTop: 8 }}>
            <Badge tone={summary.unknown_cost_count ? 'warn' : 'ok'}>Cout: {summary.total_cost_tnd === null ? 'partiel' : 'complet'}</Badge>
            <Badge>Actes possibles: {summary.possible_floor ?? '-'}</Badge>
            <Badge>Produit limitant: {summary.limiting_product || '-'}</Badge>
          </div>
        )}
      </div>
      {canDoctor && (
        <div className="form-card">
          <h3>Ajouter une ligne de recette</h3>
          <div className="form-row2">
            <SelectField label="Produit" value={form.product_id} onChange={v => setForm({ ...form, product_id: v })} options={products.map(p => [p.id, `${p.name} (${p.tracking_unit})`])} />
            <Field label="Quantite par acte" type="number" step="0.0001" value={form.quantity_per_act} onChange={v => setForm({ ...form, quantity_per_act: v })} />
          </div>
          <div className="form-row2">
            <SelectField label="Unite" value={form.unit} onChange={v => setForm({ ...form, unit: v })} options={units} />
            <SelectField label="Confiance" value={form.confidence} onChange={v => setForm({ ...form, confidence: v })} options={['bonne', 'moyenne', 'faible']} />
          </div>
          <button className="btn btn-primary" onClick={save}>Ajouter</button>
          <button className="btn btn-secondary" style={{ marginLeft: 8 }} onClick={askSuggestion}>Suggérer avec assistant local</button>
        </div>
      )}
      {suggestion && (
        <div className="table-wrap" style={{ marginBottom: 18 }}>
          <table>
            <thead><tr><th>Suggestion</th><th>Quantite</th><th>Confiance</th><th></th></tr></thead>
            <tbody>
              {(suggestion.suggestions || []).map(s => (
                <tr key={`${s.product_id}-${s.product_name}`}>
                  <td>{s.product_name}<br /><small className="muted">{s.justification}</small></td>
                  <td><Qty value={s.quantity_per_act} unit={s.unit} /></td>
                  <td>{s.confidence}</td>
                  <td><button className="btn btn-secondary" onClick={() => useSuggestion(s)}>Utiliser</button></td>
                </tr>
              ))}
              {!(suggestion.suggestions || []).length && <tr><td colSpan="4" className="center muted" style={{ padding: 18 }}>Aucune suggestion exploitable.</td></tr>}
            </tbody>
          </table>
        </div>
      )}
      <div className="table-wrap">
        <table>
          <thead><tr><th>Produit</th><th>Consommation</th><th>Mode</th><th>Mesures</th><th>Alerte</th></tr></thead>
          <tbody>
            {recipes.map(r => (
              <tr key={r.id}>
                <td><strong>{r.product_name}</strong></td>
                <td><Qty value={r.quantity_per_act} unit={r.unit} /></td>
                <td className="muted">{r.measurement_mode} / {r.confidence}</td>
                <td>{r.measurement_count}</td>
                <td>{r.unit_match ? <Badge tone="ok">OK</Badge> : <Badge tone="warn">Unite incoherente</Badge>}</td>
              </tr>
            ))}
            {!recipes.length && <tr><td colSpan="5" className="center muted" style={{ padding: 24 }}>Aucune recette pour cet acte.</td></tr>}
          </tbody>
        </table>
      </div>
    </>
  );
}

function PerformedActs({ canDoctor }) {
  const [acts, setActs] = useState([]);
  const [history, setHistory] = useState([]);
  const [selectedAct, setSelectedAct] = useState('');
  const [draft, setDraft] = useState(null);
  const [quantities, setQuantities] = useState({});
  const [form, setForm] = useState({ performed_date: new Date().toISOString().slice(0, 10), patient_label: 'Patient anonymise', comment: '' });
  const [result, setResult] = useState(null);
  const [error, setError] = useState('');
  const load = async () => {
    const [a, h] = await Promise.all([adminApi.get('/clinical-acts'), adminApi.get('/performed-acts')]);
    setActs(a.data); setHistory(h.data);
    if (!selectedAct && a.data[0]) setSelectedAct(String(a.data[0].id));
  };
  useEffect(() => { load().catch(e => setError(e.response?.data?.error || 'Erreur actes realises.')); }, []);
  useEffect(() => {
    if (!selectedAct) return;
    adminApi.get(`/recipes/act/${selectedAct}/cost`).then(r => {
      setDraft(r.data);
      const next = {};
      (r.data.lines || []).forEach(line => { next[line.recipe_id] = line.quantity_per_act; });
      setQuantities(next);
    }).catch(e => setError(e.response?.data?.error || 'Erreur brouillon acte.'));
  }, [selectedAct]);
  const submit = async () => {
    setError(''); setResult(null);
    try {
      const { data } = await adminApi.post('/performed-acts', {
        ...form,
        act_id: selectedAct,
        actual_quantities: quantities,
      });
      setResult(data); load();
    } catch (e) { setError(e.response?.data?.error || 'Validation impossible.'); }
  };
  return (
    <>
      <ErrorLine error={error} />
      {result && <div className="alert success">Acte #{result.performed_act_id} enregistre. Cout partiel: <Money value={result.actual_partial_cost_tnd} /></div>}
      <div className="form-card">
        <h3>Valider un acte realise</h3>
        <div className="form-row2">
          <SelectField label="Acte" value={selectedAct} onChange={setSelectedAct} options={acts.map(a => [a.id, `${a.name} - ${a.clinical_variant}`])} />
          <Field label="Date" type="date" value={form.performed_date} onChange={v => setForm({ ...form, performed_date: v })} />
        </div>
        <div className="form-row2">
          <Field label="Patient stock" value={form.patient_label} onChange={v => setForm({ ...form, patient_label: v })} />
          <Field label="Commentaire" value={form.comment} onChange={v => setForm({ ...form, comment: v })} />
        </div>
      </div>
      {draft && (
        <div className="table-wrap" style={{ marginBottom: 16 }}>
          <table>
            <thead><tr><th>Produit</th><th>Moyenne</th><th>Utilise</th><th>Stock avant</th><th>Cout ligne</th></tr></thead>
            <tbody>
              {(draft.lines || []).map(line => (
                <tr key={line.recipe_id}>
                  <td>{line.product_name}</td>
                  <td><Qty value={line.quantity_per_act} unit={line.unit} /></td>
                  <td><input type="number" step="0.0001" value={quantities[line.recipe_id] ?? ''} onChange={e => setQuantities({ ...quantities, [line.recipe_id]: e.target.value })} style={{ width: 100, padding: 8, borderRadius: 8, border: '1.5px solid rgba(82,183,136,.25)' }} /></td>
                  <td><Qty value={line.current_stock} unit={line.tracking_unit} /></td>
                  <td><Money value={line.line_cost_tnd} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      <button className="btn btn-green" disabled={!canDoctor || !selectedAct} onClick={submit}>Valider et deduire le stock</button>
      {!canDoctor && <p className="muted" style={{ marginTop: 8 }}>Validation reservee au docteur.</p>}
      <div className="table-wrap" style={{ marginTop: 18 }}>
        <table>
          <thead><tr><th>Date</th><th>Acte</th><th>Patient stock</th><th>Cout reel</th><th>Lignes</th></tr></thead>
          <tbody>
            {history.map(h => (
              <tr key={h.id}><td>{String(h.performed_date).slice(0, 10)}</td><td>{h.act_name}</td><td>{h.patient_label}</td><td><Money value={h.actual_total_cost_tnd ?? h.estimated_total_cost_tnd} /></td><td>{h.line_count}</td></tr>
            ))}
            {!history.length && <tr><td colSpan="5" className="center muted" style={{ padding: 24 }}>Aucun acte realise.</td></tr>}
          </tbody>
        </table>
      </div>
    </>
  );
}

function Purchases() {
  const [products, setProducts] = useState([]);
  const [purchases, setPurchases] = useState([]);
  const [form, setForm] = useState({ purchase_date: new Date().toISOString().slice(0, 10), supplier: '', product_id: '', quantity_purchased: '', total_price_tnd: '', package_price_tnd: '', invoice_number: '', lot_number: '', expiration_date: '', updated_package_price: false, comment: '' });
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const load = async () => {
    const [productsRes, purchasesRes] = await Promise.all([adminApi.get('/inventory/products'), adminApi.get('/purchases')]);
    setProducts(productsRes.data); setPurchases(purchasesRes.data);
  };
  useEffect(() => { load().catch(e => setError(e.response?.data?.error || 'Erreur achats.')); }, []);
  const save = async () => {
    setError(''); setMessage('');
    try {
      const { data } = await adminApi.post('/purchases', form);
      setMessage(`Achat enregistre. Stock apres: ${trimNumber(Number(data.stock_after))} ${data.unit}.`);
      setForm({ ...form, quantity_purchased: '', total_price_tnd: '', package_price_tnd: '', invoice_number: '', comment: '' });
      load();
    } catch (e) { setError(e.response?.data?.error || 'Erreur achat.'); }
  };
  return (
    <>
      <ErrorLine error={error} /><SuccessLine message={message} />
      <div className="form-card">
        <h3>Reception achat</h3>
        <div className="form-row2">
          <Field label="Date" type="date" value={form.purchase_date} onChange={v => setForm({ ...form, purchase_date: v })} />
          <Field label="Fournisseur" value={form.supplier} onChange={v => setForm({ ...form, supplier: v })} />
        </div>
        <div className="form-row2">
          <SelectField label="Produit" value={form.product_id} onChange={v => setForm({ ...form, product_id: v })} options={products.map(p => [p.id, `${p.name} (${p.tracking_unit})`])} />
          <Field label="Quantite recue" type="number" step="0.0001" value={form.quantity_purchased} onChange={v => setForm({ ...form, quantity_purchased: v })} />
        </div>
        <div className="form-row2">
          <Field label="Prix total TND" type="number" step="0.001" value={form.total_price_tnd} onChange={v => setForm({ ...form, total_price_tnd: v })} />
          <Field label="Prix conditionnement TND" type="number" step="0.001" value={form.package_price_tnd} onChange={v => setForm({ ...form, package_price_tnd: v })} />
        </div>
        <div className="form-row2">
          <Field label="Facture" value={form.invoice_number} onChange={v => setForm({ ...form, invoice_number: v })} />
          <Field label="Lot" value={form.lot_number} onChange={v => setForm({ ...form, lot_number: v })} />
        </div>
        <label style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 12 }}>
          <input type="checkbox" checked={form.updated_package_price} onChange={e => setForm({ ...form, updated_package_price: e.target.checked })} />
          Mettre a jour le prix du conditionnement
        </label>
        <button className="btn btn-primary" onClick={save}>Enregistrer achat</button>
      </div>
      <div className="table-wrap">
        <table>
          <thead><tr><th>Date</th><th>Produit</th><th>Fournisseur</th><th>Quantite</th><th>Total</th><th>Stock apres</th></tr></thead>
          <tbody>
            {purchases.map(p => <tr key={p.id}><td>{String(p.purchase_date).slice(0, 10)}</td><td>{p.product_name}</td><td>{p.supplier}</td><td><Qty value={p.quantity_purchased} unit={p.unit} /></td><td><Money value={p.total_price_tnd} /></td><td><Qty value={p.stock_after} unit={p.unit} /></td></tr>)}
            {!purchases.length && <tr><td colSpan="6" className="center muted" style={{ padding: 24 }}>Aucun achat.</td></tr>}
          </tbody>
        </table>
      </div>
    </>
  );
}

function ShoppingList() {
  const [rows, setRows] = useState([]);
  const [error, setError] = useState('');
  const load = () => adminApi.get('/shopping-list').then(r => setRows(r.data)).catch(e => setError(e.response?.data?.error || 'Erreur liste achat.'));
  useEffect(() => { load(); }, []);
  return (
    <>
      <ErrorLine error={error} />
      <div className="table-wrap">
        <table>
          <thead><tr><th>Produit</th><th>Priorite</th><th>Motif</th><th>Stock</th><th>Rupture</th><th>Quantite recommandee</th></tr></thead>
          <tbody>
            {rows.map(r => (
              <tr key={r.product_id}>
                <td><strong>{r.product_name}</strong><br /><small className="muted">{r.justification}</small></td>
                <td><Badge tone={r.priority >= 70 ? 'err' : r.priority >= 40 ? 'warn' : 'info'}>{r.priority}</Badge></td>
                <td>{r.reason}</td>
                <td><Qty value={r.current_stock} unit={r.tracking_unit} /></td>
                <td>{r.days_before_break === null ? '-' : `${r.days_before_break} j`}</td>
                <td><Qty value={r.recommended_quantity} unit={r.tracking_unit} /></td>
              </tr>
            ))}
            {!rows.length && <tr><td colSpan="6" className="center muted" style={{ padding: 24 }}>Aucun achat prioritaire.</td></tr>}
          </tbody>
        </table>
      </div>
    </>
  );
}


function InventoryInsights() {
  const [data, setData] = useState(null);
  const [error, setError] = useState('');
  const load = () => adminApi.get('/ai/inventory-insights').then(r => setData(r.data)).catch(e => setError(e.response?.data?.error || 'Erreur pilotage IA.'));
  useEffect(() => { load(); }, []);
  return (
    <>
      <ErrorLine error={error} />
      <div className="form-card">
        <h3>Pilotage intelligent du cabinet</h3>
        <p className="muted">Score local non medical : consommation par acte, cout matiere, rupture, surstock, peremption et achat recommande. Validation humaine obligatoire.</p>
        <button className="btn btn-secondary" onClick={load}>Rafraichir le scoring</button>
      </div>
      {data && (
        <>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(180px,1fr))', gap: 16, marginBottom: 16 }}>
            <Kpi label="Produits suivis" value={data.summary.product_count} />
            <Kpi label="Critiques" value={data.summary.critical_count} tone={data.summary.critical_count ? 'err' : 'ok'} />
            <Kpi label="A surveiller" value={data.summary.warning_count} tone={data.summary.warning_count ? 'warn' : 'ok'} />
            <Kpi label="Valeur estimee" value={<Money value={data.summary.estimated_stock_value_tnd} />} />
            <Kpi label="A commander" value={data.summary.products_to_buy_count || 0} tone={data.summary.products_to_buy_count ? 'warn' : 'ok'} />
            <Kpi label="Budget achat suggere" value={<Money value={data.summary.estimated_purchase_value_tnd} />} />
            <Kpi label="Couverture moyenne" value={data.summary.avg_coverage_days === null ? '-' : `${data.summary.avg_coverage_days} j`} />
            <Kpi label="Peremption 90j" value={data.summary.expiring_90d_count || 0} tone={data.summary.expiring_90d_count ? 'warn' : 'ok'} />
          </div>
          <div className="card" style={{ marginBottom: 16 }}>
            <h3 className="card-title">Lecture operationnelle</h3>
            <p className="muted">
              Le score combine le stock utile, le stock reserve, les consommations 30/90 jours, les lots proches de la peremption,
              les couts incomplets et les seuils min/max. Il sert a preparer une decision d'achat, pas a automatiser une commande.
            </p>
          </div>
          <div className="table-wrap">
            <table>
              <thead><tr><th>Produit</th><th>Score</th><th>Couverture</th><th>Consommation</th><th>Cout</th><th>Peremption</th><th>Achat recommande</th></tr></thead>
              <tbody>
                {(data.products || []).map(p => (
                  <tr key={p.product_id}>
                    <td><strong>{p.product_name}</strong><br /><small className="muted">{p.reasons.join(', ')}</small></td>
                    <td><Badge tone={p.risk_score >= 70 ? 'err' : p.risk_score >= 35 ? 'warn' : 'ok'}>{p.risk_score}/100</Badge></td>
                    <td>{p.coverage_days === null ? '-' : `${p.coverage_days} j`}<br /><small className="muted">utile <Qty value={p.usable_stock} unit={p.unit} /></small></td>
                    <td><Qty value={p.used_30d} unit={p.unit} /><br /><small className="muted">90j: <Qty value={p.used_90d} unit={p.unit} /></small></td>
                    <td><Money value={p.unit_cost_tnd} /><br /><small className="muted">par {p.unit}</small></td>
                    <td>{p.next_expiration ? String(p.next_expiration).slice(0, 10) : '-'}<br /><small className="muted">90j: <Qty value={p.qty_expiring_90d} unit={p.unit} /></small></td>
                    <td>{p.recommendation}<br /><small className="muted"><Qty value={p.recommended_quantity} unit={p.unit} /> - <Money value={p.recommended_value_tnd} /></small></td>
                  </tr>
                ))}
                {!(data.products || []).length && <tr><td colSpan="7" className="center muted" style={{ padding: 24 }}>Aucune donnée de scoring.</td></tr>}
              </tbody>
            </table>
          </div>
        </>
      )}
    </>
  );
}

function AiAlerts() {
  const [alerts, setAlerts] = useState([]);
  const [anomalies, setAnomalies] = useState(null);
  const [error, setError] = useState('');
  const load = async () => {
    const [a, n] = await Promise.all([adminApi.get('/inventory/alerts'), adminApi.get('/ai/anomalies')]);
    setAlerts(a.data); setAnomalies(n.data);
  };
  useEffect(() => { load().catch(e => setError(e.response?.data?.error || 'Erreur alertes.')); }, []);
  return (
    <>
      <ErrorLine error={error} />
      <button className="btn btn-secondary" style={{ marginBottom: 12 }} onClick={load}>Rafraichir</button>
      <div className="table-wrap">
        <table>
          <thead><tr><th>Type</th><th>Message</th><th>Severite</th><th>Recommendation</th></tr></thead>
          <tbody>
            {alerts.map(a => <tr key={a.id}><td>{a.type}</td><td>{a.message}</td><td><Severity severity={a.severity} /></td><td className="muted">{a.recommendation || '-'}</td></tr>)}
            {!alerts.length && <tr><td colSpan="4" className="center muted" style={{ padding: 24 }}>Aucune alerte.</td></tr>}
          </tbody>
        </table>
      </div>
      {!!anomalies?.overconsumption?.length && (
        <div className="table-wrap" style={{ marginTop: 16 }}>
          <table>
            <thead><tr><th>Surconsommation</th><th>Quantite</th><th>Moyenne</th></tr></thead>
            <tbody>{anomalies.overconsumption.map((a, i) => <tr key={i}><td>{a.message}</td><td>{a.quantity}</td><td>{a.expected}</td></tr>)}</tbody>
          </table>
        </div>
      )}
    </>
  );
}

function AssistantAi() {
  const [command, setCommand] = useState("Aujourd'hui j'ai fait deux composites et une extraction.");
  const [draft, setDraft] = useState(null);
  const [forecast, setForecast] = useState([]);
  const [error, setError] = useState('');
  const parse = async () => {
    setError('');
    try {
      const { data } = await adminApi.post('/ai/parse-command', { text: command });
      setDraft(data);
    } catch (e) { setError(e.response?.data?.error || 'Analyse impossible.'); }
  };
  const loadForecast = async () => {
    const { data } = await adminApi.get('/ai/forecast');
    setForecast(data);
  };
  useEffect(() => { loadForecast().catch(() => {}); }, []);
  return (
    <>
      <ErrorLine error={error} />
      <div className="form-card">
        <h3>Assistant IA local</h3>
        <p className="muted" style={{ marginBottom: 12 }}>Analyse par règles locales : aucune modification du stock n'est appliquée sans validation humaine.</p>
        <div className="fg"><textarea rows="4" value={command} onChange={e => setCommand(e.target.value)} /></div>
        <button className="btn btn-primary" onClick={parse}>Analyser</button>
      </div>
      {draft && (
        <div className="form-card">
          <h3>Brouillon avant validation</h3>
          <p><strong>Date detectee:</strong> {draft.detected_date}</p>
          {(draft.detected_acts || []).map((a, i) => <p key={i}>{a.quantity} x {a.name} <span className="muted">({a.clinical_variant})</span></p>)}
          {(draft.ambiguities || []).map((a, i) => <p key={i}><Badge tone="warn">{a}</Badge></p>)}
        </div>
      )}
      <div className="table-wrap">
        <table>
          <thead><tr><th>Prevision achat</th><th>Jours restants</th><th>Priorite</th><th>Quantite recommandee</th></tr></thead>
          <tbody>
            {forecast.map(f => <tr key={f.product_id}><td>{f.product_name}</td><td>{f.days_remaining ?? '-'}</td><td>{f.purchase_priority}</td><td><Qty value={f.recommended_quantity} unit={f.unit} /></td></tr>)}
            {!forecast.length && <tr><td colSpan="4" className="center muted" style={{ padding: 24 }}>Aucune prevision critique.</td></tr>}
          </tbody>
        </table>
      </div>
    </>
  );
}

function LabPlaceholder() {
  const [data, setData] = useState(null);
  const [error, setError] = useState('');
  useEffect(() => { adminApi.get('/lab/overview').then(r => setData(r.data)).catch(e => setError(e.response?.data?.error || 'Erreur laboratoire.')); }, []);
  return (
    <>
      <ErrorLine error={error} />
      <div className="card">
        <h3>Laboratoire prothese</h3>
        <p className="muted">Architecture preparee pour les cas labo, etapes, recettes labo et consommations LAB_CASE.</p>
        {data && (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(160px,1fr))', gap: 12, marginTop: 12 }}>
            <Kpi label="Cas labo" value={data.counts.cases} />
            <Kpi label="Etapes" value={data.counts.steps} />
            <Kpi label="Recettes labo" value={data.counts.recipes} />
          </div>
        )}
      </div>
    </>
  );
}

function Field({ label, value, onChange, type = 'text', step, placeholder }) {
  return (
    <div className="fg">
      <label>{label}</label>
      <input type={type} step={step} value={value ?? ''} placeholder={placeholder} onChange={e => onChange(e.target.value)} />
    </div>
  );
}

function SelectField({ label, value, onChange, options }) {
  const normalized = useMemo(() => options.map(item => Array.isArray(item) ? item : [item, item]), [options]);
  return (
    <div className="fg">
      <label>{label}</label>
      <select value={value ?? ''} onChange={e => onChange(e.target.value)}>
        <option value="">Choisir...</option>
        {normalized.map(([valueOption, labelOption]) => <option key={valueOption} value={valueOption}>{labelOption}</option>)}
      </select>
    </div>
  );
}
