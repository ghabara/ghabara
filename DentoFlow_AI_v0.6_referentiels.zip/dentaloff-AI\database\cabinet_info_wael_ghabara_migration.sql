USE dentaloff_ai;

INSERT INTO cabinet_info (id, name, doctor, tel, email, addr)
VALUES (1, 'DentoFlow AI', 'Dr. Wael Ghabara', '+216 22 369 195', 'w.ghabara@hotmail.fr', 'El Mourouj 1, Ben Arous, Tunisie')
ON DUPLICATE KEY UPDATE
  name = 'DentoFlow AI',
  doctor = CASE
    WHEN doctor IS NULL OR doctor = '' OR doctor LIKE CONCAT('%', 'Mo', 'lka', '%') OR doctor LIKE CONCAT('%', 'Chou', 'ika', '%') THEN 'Dr. Wael Ghabara'
    ELSE doctor
  END,
  tel = CASE
    WHEN tel IS NULL OR tel = '' OR tel = CONCAT('+216 ', '71 ', '25 ', '98 ', '55') THEN '+216 22 369 195'
    ELSE tel
  END,
  email = CASE
    WHEN email IS NULL OR email = '' OR email LIKE '%dentoflow.local%' THEN 'w.ghabara@hotmail.fr'
    ELSE email
  END,
  addr = CASE
    WHEN addr IS NULL OR addr = '' OR addr = CONCAT('Tunis', ', Mourouj 1') THEN 'El Mourouj 1, Ben Arous, Tunisie'
    ELSE addr
  END;

UPDATE ordonnances
SET medecin = 'Dr. Wael Ghabara'
WHERE medecin LIKE CONCAT('%', 'Mo', 'lka', '%') OR medecin LIKE CONCAT('%', 'Chou', 'ika', '%');

UPDATE ordonnances
SET contenu = REPLACE(REPLACE(contenu, CONCAT('Dr. Mo', 'lka Chou', 'ika'), 'Dr. Wael Ghabara'), CONCAT('Mo', 'lka Chou', 'ika'), 'Dr. Wael Ghabara')
WHERE contenu LIKE CONCAT('%', 'Mo', 'lka', '%') OR contenu LIKE CONCAT('%', 'Chou', 'ika', '%');

UPDATE rendez_vous
SET practitioner = 'Dr. Wael Ghabara'
WHERE practitioner LIKE CONCAT('%', 'Mo', 'lka', '%') OR practitioner LIKE CONCAT('%', 'Chou', 'ika', '%');

UPDATE notes
SET texte = REPLACE(REPLACE(texte, CONCAT('Dr. Mo', 'lka Chou', 'ika'), 'Dr. Wael Ghabara'), CONCAT('Mo', 'lka Chou', 'ika'), 'Dr. Wael Ghabara')
WHERE texte LIKE CONCAT('%', 'Mo', 'lka', '%') OR texte LIKE CONCAT('%', 'Chou', 'ika', '%');
