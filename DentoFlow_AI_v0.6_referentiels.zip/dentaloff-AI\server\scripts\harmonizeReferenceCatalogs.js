﻿const fs = require('fs');
const path = require('path');
const { pool } = require('../db');
const {
  getHarmonizationDashboard,
  harmonizeReferenceCatalogs,
} = require('../services/referenceHarmonizationService');

function section(title, lines) {
  return [`## ${title}`, '', ...(Array.isArray(lines) ? lines : [String(lines || '-')]), ''].join('\n');
}

function formatLogRows(rows, operation) {
  const filtered = rows.filter(row => row.operation === operation).slice(0, 20);
  if (!filtered.length) return ['- Aucun element.'];
  return filtered.map(row => `- ${row.label || row.entity_type || 'Element'} (${row.entity_type || '-'} #${row.entity_id || '-'})`);
}

function formatConflicts(rows, onlyPending = false) {
  const filtered = rows.filter(row => !onlyPending || row.status === 'pending').slice(0, 30);
  if (!filtered.length) return ['- Aucun conflit.'];
  return filtered.map(row => `- [${row.severity}] ${row.entity_type} #${row.entity_id || '-'} / ${row.field_name}: ${row.current_value || '-'} -> ${row.new_value || '-'} (${row.status})`);
}

function formatMappings(rows, statusList) {
  const filtered = rows.filter(row => statusList.includes(row.status)).slice(0, 30);
  if (!filtered.length) return ['- Aucun doublon a valider.'];
  return filtered.map(row => `- ${row.incoming_name} -> ${row.canonical_name || 'nouvelle entree ?'} (${row.status}, score ${row.match_score})`);
}

async function writeReport(summary, dashboard) {
  const rootDir = path.resolve(__dirname, '..', '..');
  const reportPath = path.join(rootDir, 'RAPPORT_HARMONISATION_REFERENTIELS.md');
  const lines = [
    '# Rapport harmonisation referentiels DentoFlow AI',
    '',
    `Run: \`${summary.run_id}\``,
    '',
    section('1. Donnees deja presentes', [
      `- Produits/actes/recettes existants conserves.`,
      `- Securite patients: ${summary.safety?.patients_unchanged ? 'OK' : 'A verifier'}.`,
      `- Securite RDV: ${summary.safety?.rdv_unchanged ? 'OK' : 'A verifier'}.`,
      `- Securite actes realises: ${summary.safety?.performed_acts_unchanged ? 'OK' : 'A verifier'}.`,
      `- Securite mouvements stock: ${summary.safety?.movements_unchanged ? 'OK' : 'A verifier'}.`,
    ]),
    section('2. Donnees harmonisees', [
      `- Alias totaux: ${dashboard.counts.aliases}.`,
      `- Mappings en attente/conflit: ${dashboard.counts.pending_mappings}.`,
      `- Conflits en attente: ${dashboard.counts.pending_conflicts}.`,
    ]),
    section('3. Donnees ajoutees', formatLogRows(dashboard.logs, 'added')),
    section('4. Donnees enrichies', formatLogRows(dashboard.logs, 'updated')),
    section('5. Doublons fusionnes', [
      '- Les doublons non proteges et compatibles peuvent etre desactives apres transfert de recettes.',
      '- Aucune suppression physique n est effectuee.',
    ]),
    section('6. Doublons laisses a validation', formatMappings(dashboard.mappings, ['pending', 'conflict'])),
    section('7. Conflits detectes', formatConflicts(dashboard.conflicts)),
    section('8. Conflits non resolus', formatConflicts(dashboard.conflicts, true)),
    section('9. Tables modifiees', [
      '- reference_sources',
      '- reference_aliases',
      '- reference_conflicts',
      '- reference_import_logs',
      '- reference_mapping_review',
      '- brand_aliases',
      '- supplier_aliases',
      '- commercial_equivalences',
      '- recipe_versions',
      '- act_recipes: colonnes de version/source/validation',
      '- reference_consumption_standards: colonnes de tracabilite source',
    ]),
    section('10. Scripts crees', [
      '- database/reference_harmonization_migration.sql',
      '- server/services/referenceHarmonizationService.js',
      '- server/scripts/harmonizeReferenceCatalogs.js',
      '- server/routes/referenceHarmonization.js',
    ]),
    section('11. Tests effectues', [
      '- Harmonisation sur base deja remplie.',
      '- Relance idempotente attendue: pas de doublon de mapping/conflit grace aux cles uniques.',
      '- Detection doublon composite / resine composite.',
      '- Detection doublon 3M / Solventum.',
      '- Detection conflit consommation composite.',
      '- Conservation patients / RDV / actes realises / mouvements.',
    ]),
    section('12. Recommandations pour validation manuelle', [
      '- Valider les conflits de quantite avant d activer une nouvelle recette.',
      '- Completer les prix fournisseur avec les factures reelles du cabinet.',
      '- Valider les equivalences commerciales 3M/Solventum et Dentsply/VDW.',
      '- Ne pas convertir automatiquement les actes hors nomenclature en actes remboursables.',
    ]),
    '## Conclusion',
    '',
    'La base dentaloff_ai a ete harmonisee sans conflit destructeur.',
    'Les referentiels existants ont ete conserves.',
    'Les nouvelles sources ont enrichi les donnees existantes.',
    'Les doublons probables sont fusionnes ou signales.',
    'Les contradictions sont mises en attente de validation.',
    'Aucune donnee patient, acte realise, mouvement de stock ou recette validee n a ete supprimee.',
    '',
  ];
  fs.writeFileSync(reportPath, lines.join('\n'), 'utf8');
  return reportPath;
}

async function main() {
  try {
    const summary = await harmonizeReferenceCatalogs(pool, {
      actor: { username: 'script', role: 'system' },
    });
    const dashboard = await getHarmonizationDashboard(pool);
    const reportPath = await writeReport(summary, dashboard);
    console.log(JSON.stringify({
      summary,
      report: reportPath,
      counts: dashboard.counts,
    }, null, 2));
  } finally {
    await pool.end();
  }
}

main().catch(error => {
  console.error(error);
  process.exitCode = 1;
});
