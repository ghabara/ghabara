const express = require('express');
const { pool } = require('../db');
const { auth, adminOnly, docteurOnly } = require('../middleware/auth');
const router = express.Router();

/* ════════════════════════════════════════════════════════════
 *  GESTION DE STOCK — produits consommables
 *
 *  Principe :
 *   - stock_reel  = quantité physiquement en stock
 *                   (= Σ ENTREE − Σ SORTIE du journal ; maintenu en transaction)
 *   - prévisionnel = stock_reel − (réservations encore "en_attente")
 *   - une réservation N'EST PAS un mouvement (intention, pas un fait)
 *   - confirmer un panier = SORTIE de stock réel (après la consultation)
 *   - le journal (mouvements) est immuable : on n'y inscrit que des faits réels
 * ════════════════════════════════════════════════════════════ */

/* Exécute une fonction dans une transaction SQL */
async function tx(fn) {
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    const result = await fn(conn);
    await conn.commit();
    return result;
  } catch (e) {
    await conn.rollback();
    throw e;
  } finally {
    conn.release();
  }
}

/* Inscrit une ligne dans le journal (avec un instantané nom/type pour la traçabilité) */
async function logMouvement(conn, produit, quantite, sens, origine, id_origine) {
  await conn.query(
    `INSERT INTO mouvements (id_produit, nom_produit, type_produit, quantite, sens, origine, id_origine)
     VALUES (?,?,?,?,?,?,?)`,
    [produit.id, produit.nom, produit.type, quantite, sens, origine, id_origine ?? null]
  );
}

/* ─────────────── PRODUITS (catalogue + stock réel) ─────────────── */

// Liste des produits avec stock réel, réservé, prévisionnel et alerte
router.get('/produits', auth, adminOnly, async (req, res) => {
  const [rows] = await pool.query(`
    SELECT p.*,
      COALESCE((SELECT SUM(r.quantite) FROM reservations r
                WHERE r.id_produit = p.id AND r.statut = 'en_attente'), 0) AS reserve
    FROM produits p
    ORDER BY p.nom
  `);
  const out = rows.map(p => {
    const previsionnel = p.stock_reel - p.reserve;
    return { ...p, previsionnel, alerte: previsionnel <= p.seuil_secu };
  });
  res.json(out);
});

// Créer un produit (docteur uniquement)
router.post('/produits', auth, docteurOnly, async (req, res) => {
  const { nom, type, unite, seuil_secu } = req.body;
  if (!nom) return res.status(400).json({ error: 'Nom du produit requis.' });
  await pool.query(
    'INSERT INTO produits (nom, type, unite, stock_reel, seuil_secu) VALUES (?,?,?,0,?)',
    [nom, type || '', unite || 'pièce', Number.isFinite(+seuil_secu) ? +seuil_secu : 100]
  );
  res.status(201).json({ ok: true });
});

// Modifier un produit (docteur uniquement)
router.put('/produits/:id', auth, docteurOnly, async (req, res) => {
  const { nom, type, unite, seuil_secu } = req.body;
  await pool.query(
    'UPDATE produits SET nom=?, type=?, unite=?, seuil_secu=? WHERE id=?',
    [nom, type, unite, +seuil_secu, req.params.id]
  );
  res.json({ ok: true });
});

// Supprimer un produit (docteur uniquement — le journal survit : id_produit -> NULL)
router.delete('/produits/:id', auth, docteurOnly, async (req, res) => {
  await pool.query('DELETE FROM produits WHERE id = ?', [req.params.id]);
  res.json({ ok: true });
});

/* ─────────────── CORRECTION DE STOCK (docteur uniquement) ───────────────
 * Le docteur saisit la NOUVELLE quantité réelle. L'écart est journalisé
 * comme un mouvement d'origine CORRECTION (affiché en rouge côté admin). */
router.post('/produits/:id/correction', auth, docteurOnly, async (req, res) => {
  const nouvelle = parseInt(req.body.nouvelle_quantite, 10);
  if (!Number.isFinite(nouvelle) || nouvelle < 0)
    return res.status(400).json({ error: 'Nouvelle quantité invalide.' });
  try {
    await tx(async (conn) => {
      const [[produit]] = await conn.query('SELECT * FROM produits WHERE id = ? FOR UPDATE', [req.params.id]);
      if (!produit) throw new Error('Produit introuvable.');
      const delta = nouvelle - produit.stock_reel;
      if (delta === 0) throw new Error('La quantité est déjà à cette valeur.');
      await conn.query('UPDATE produits SET stock_reel = ? WHERE id = ?', [nouvelle, produit.id]);
      // sens selon le signe, mais origine CORRECTION -> affiché en rouge
      const sens = delta > 0 ? 'ENTREE' : 'SORTIE';
      await logMouvement(conn, produit, Math.abs(delta), sens, 'CORRECTION', null);
    });
    res.json({ ok: true });
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

/* Réception d'un NOUVEAU produit ("Autre") : l'admin crée le produit ET l'approvisionne d'un coup */
router.post('/produits/reception-autre', auth, adminOnly, async (req, res) => {
  const { nom, type, unite } = req.body;
  const quantite = parseInt(req.body.quantite, 10);
  if (!nom) return res.status(400).json({ error: 'Nom du produit requis.' });
  if (!Number.isFinite(quantite) || quantite <= 0)
    return res.status(400).json({ error: 'Quantité reçue invalide.' });
  try {
    await tx(async (conn) => {
      const [r] = await conn.query(
        'INSERT INTO produits (nom, type, unite, stock_reel, seuil_secu) VALUES (?,?,?,?,100)',
        [nom, type || '', unite || 'pièce', quantite]
      );
      await logMouvement(conn, { id: r.insertId, nom, type: type || '' }, quantite, 'ENTREE', 'RECEPTION', null);
    });
    res.status(201).json({ ok: true });
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

/* ─────────────── RÉCEPTION = ENTRÉE de stock ─────────────── */
router.post('/produits/:id/reception', auth, adminOnly, async (req, res) => {
  const quantite = parseInt(req.body.quantite, 10);
  if (!Number.isFinite(quantite) || quantite <= 0)
    return res.status(400).json({ error: 'Quantité reçue invalide.' });

  try {
    await tx(async (conn) => {
      const [[produit]] = await conn.query('SELECT * FROM produits WHERE id = ? FOR UPDATE', [req.params.id]);
      if (!produit) throw new Error('Produit introuvable.');
      await conn.query('UPDATE produits SET stock_reel = stock_reel + ? WHERE id = ?', [quantite, produit.id]);
      await logMouvement(conn, produit, quantite, 'ENTREE', 'RECEPTION', null);
    });
    res.json({ ok: true });
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

/* ─────────────── PANIER d'un rendez-vous (réservations) ─────────────── */

// Lire le panier d'un RDV
router.get('/rdv/:id/panier', auth, adminOnly, async (req, res) => {
  const [rows] = await pool.query(`
    SELECT r.id, r.id_produit, r.quantite, r.statut, r.created_at,
           p.nom, p.type, p.unite, p.stock_reel
    FROM reservations r
    JOIN produits p ON p.id = r.id_produit
    WHERE r.id_rdv = ?
    ORDER BY r.id
  `, [req.params.id]);
  res.json(rows);
});

// Ajouter une ligne au panier (réservation -> baisse le prévisionnel)
router.post('/rdv/:id/panier', auth, adminOnly, async (req, res) => {
  const { id_produit } = req.body;
  const quantite = parseInt(req.body.quantite, 10);
  if (!id_produit || !Number.isFinite(quantite) || quantite <= 0)
    return res.status(400).json({ error: 'Produit et quantité requis.' });

  const [[produit]] = await pool.query('SELECT * FROM produits WHERE id = ?', [id_produit]);
  if (!produit) return res.status(404).json({ error: 'Produit introuvable.' });

  await pool.query(
    'INSERT INTO reservations (id_rdv, id_produit, quantite, statut) VALUES (?,?,?, "en_attente")',
    [req.params.id, id_produit, quantite]
  );
  res.status(201).json({ ok: true });
});

// Retirer une ligne du panier (libère la réservation) — seulement si en attente
router.delete('/panier/:lineId', auth, adminOnly, async (req, res) => {
  const [[line]] = await pool.query('SELECT * FROM reservations WHERE id = ?', [req.params.lineId]);
  if (!line) return res.status(404).json({ error: 'Ligne introuvable.' });
  if (line.statut !== 'en_attente')
    return res.status(400).json({ error: 'Cette ligne est déjà confirmée, impossible de la retirer.' });
  await pool.query('DELETE FROM reservations WHERE id = ?', [req.params.lineId]);
  res.json({ ok: true });
});

/* ─────────────── CONFIRMATION = SORTIE de stock réel ─────────────── */
// Après la consultation : transforme chaque réservation "en_attente" en sortie réelle.
router.post('/rdv/:id/panier/confirmer', auth, adminOnly, async (req, res) => {
  try {
    const resultat = await tx(async (conn) => {
      const [lignes] = await conn.query(
        "SELECT * FROM reservations WHERE id_rdv = ? AND statut = 'en_attente'",
        [req.params.id]
      );
      if (lignes.length === 0) throw new Error('Aucune réservation à confirmer pour ce rendez-vous.');

      // 1) Vérifier la dispo réelle pour TOUTES les lignes avant d'agir
      for (const l of lignes) {
        const [[p]] = await conn.query('SELECT * FROM produits WHERE id = ? FOR UPDATE', [l.id_produit]);
        if (!p) throw new Error('Un produit du panier a été supprimé.');
        if (p.stock_reel < l.quantite)
          throw new Error(`Stock réel insuffisant pour "${p.nom}" (réel ${p.stock_reel}, demandé ${l.quantite}).`);
      }
      // 2) Appliquer : sortie réelle + journal + marquer la réservation confirmée
      for (const l of lignes) {
        const [[p]] = await conn.query('SELECT * FROM produits WHERE id = ?', [l.id_produit]);
        await conn.query('UPDATE produits SET stock_reel = stock_reel - ? WHERE id = ?', [l.quantite, p.id]);
        await logMouvement(conn, p, l.quantite, 'SORTIE', 'RENDEZVOUS', req.params.id);
        await conn.query("UPDATE reservations SET statut = 'confirmee' WHERE id = ?", [l.id]);
      }
      // 3) Le RDV est marqué comme terminé (consultation faite)
      await conn.query("UPDATE rendez_vous SET statut = 'done' WHERE id = ?", [req.params.id]);
      return lignes.length;
    });
    res.json({ ok: true, lignes_confirmees: resultat });
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

/* ─────────────── MODÈLES PAR SERVICE (réservation auto) ─────────────── */
// Chaque service a une liste de consommables réservés automatiquement à la prise de RDV.
router.get('/service-consommables', auth, adminOnly, async (req, res) => {
  const [rows] = await pool.query(`
    SELECT sc.id, sc.service, sc.id_produit, sc.quantite, p.nom, p.type, p.unite
    FROM service_consommables sc
    JOIN produits p ON p.id = sc.id_produit
    ORDER BY sc.service, p.nom
  `);
  res.json(rows);
});
router.post('/service-consommables', auth, adminOnly, async (req, res) => {
  const { service, id_produit } = req.body;
  const quantite = parseInt(req.body.quantite, 10);
  if (!service || !id_produit || !Number.isFinite(quantite) || quantite <= 0)
    return res.status(400).json({ error: 'Service, produit et quantité requis.' });
  await pool.query(
    'INSERT INTO service_consommables (service, id_produit, quantite) VALUES (?,?,?)',
    [service, id_produit, quantite]
  );
  res.status(201).json({ ok: true });
});
router.delete('/service-consommables/:id', auth, adminOnly, async (req, res) => {
  await pool.query('DELETE FROM service_consommables WHERE id = ?', [req.params.id]);
  res.json({ ok: true });
});

/* ─────────────── JOURNAL (traçabilité — docteur uniquement) ─────────────── */
router.get('/mouvements', auth, docteurOnly, async (req, res) => {
  const { id_produit, sens } = req.query;
  let sql = 'SELECT * FROM mouvements';
  const where = [], params = [];
  if (id_produit) { where.push('id_produit = ?'); params.push(id_produit); }
  if (sens) { where.push('sens = ?'); params.push(sens); }
  if (where.length) sql += ' WHERE ' + where.join(' AND ');
  sql += ' ORDER BY date_mouv DESC, id DESC LIMIT 500';
  const [rows] = await pool.query(sql, params);
  res.json(rows);
});

/* ─────────────── ALERTES (stock bas) ─────────────── */
router.get('/stock/alertes', auth, adminOnly, async (req, res) => {
  const [rows] = await pool.query(`
    SELECT p.*,
      COALESCE((SELECT SUM(r.quantite) FROM reservations r
                WHERE r.id_produit = p.id AND r.statut = 'en_attente'), 0) AS reserve
    FROM produits p
  `);
  const alertes = rows
    .map(p => ({ ...p, previsionnel: p.stock_reel - p.reserve }))
    .filter(p => p.previsionnel <= p.seuil_secu);
  res.json(alertes);
});

module.exports = router;
