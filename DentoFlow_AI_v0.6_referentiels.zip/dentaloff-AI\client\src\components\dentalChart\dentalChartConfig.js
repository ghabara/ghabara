export const permanentRows = [
  [18, 17, 16, 15, 14, 13, 12, 11, 21, 22, 23, 24, 25, 26, 27, 28],
  [48, 47, 46, 45, 44, 43, 42, 41, 31, 32, 33, 34, 35, 36, 37, 38],
];

export const temporaryRows = [
  [55, 54, 53, 52, 51, 61, 62, 63, 64, 65],
  [85, 84, 83, 82, 81, 71, 72, 73, 74, 75],
];

export const toothStatuses = [
  ['healthy', 'Saine', '#F8FAFC'],
  ['caries', 'Carie', '#F59E0B'],
  ['restored', 'Restauree', '#38BDF8'],
  ['endo', 'Endodontie', '#8B5CF6'],
  ['crown', 'Couronne', '#64748B'],
  ['implant', 'Implant', '#12B8B2'],
  ['missing', 'Absente', '#CBD5E1'],
  ['extract', 'A extraire', '#DC2626'],
  ['watch', 'Surveillee', '#0F62FE'],
];

export const surfaces = ['O', 'M', 'D', 'V', 'L'];

export function getToothMeta(number) {
  const n = Number(number);
  const quadrant = String(number).slice(0, 1);
  const upper = ['1', '2', '5', '6'].includes(quadrant);
  return {
    tooth_number: n,
    dentition_type: n >= 50 ? 'temporary' : 'permanent',
    arcade: upper ? 'maxillaire' : 'mandibulaire',
    quadrant,
  };
}
